﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Population_Data
{
    public partial class Form1 : Form
    {
        List<int> yearsList = new List<int>();
        List<int> populationList = new List<int>();
        List<int> changeList = new List<int>();

        private int highestYear, lowestYear, highestChange, lowestChange;
        private double averageChanges;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            populationInformationLabel.Text = "This program will analyze population changes from 1950 through 1990.";
        }

        private void analyzeButton_Click(object sender, EventArgs e)
        {
            PopulateYearsList();
            PopulatePopulationList();
            PopulateChangesList();
            CalculateGreatestIncrease();
            CalculateGreatestDecrease();
            DisplaySummary();
        }

        private void PopulateYearsList()
        {
            int endingYear = 1990;
            for (int year = 1950; year <= endingYear; year++)
            {
                yearsList.Add(year);
            }
        }

        private void PopulatePopulationList()
        {
            try
            {
                StreamReader inputFile = File.OpenText("USPopulation.txt");

                while (!inputFile.EndOfStream)
                {
                    populationList.Add(int.Parse(inputFile.ReadLine()));
                }

                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PopulateChangesList()
        {
            changeList.Add(0);
            int totalChanges = 0;

            for (int index = 1; index < populationList.Count; index++)
            {
                changeList.Add(populationList[index] - populationList[index - 1]);
                totalChanges += populationList[index] - populationList[index - 1];
            }

            averageChanges = totalChanges / populationList.Count;
        }

        private void CalculateGreatestIncrease()
        {
            highestYear = yearsList[0];
            highestChange = changeList[0];

            for (int index = 1; index < changeList.Count; index++)
            {
                if (changeList[index] > highestChange)
                {
                    highestYear = yearsList[index];
                    highestChange = changeList[index];
                }
            }
        }

        private void CalculateGreatestDecrease()
        {
            lowestYear = yearsList[1];
            lowestChange = changeList[1];

            for (int index = 2; index < changeList.Count; index++)
            {
                if (changeList[index] < lowestChange)
                {
                    lowestYear = yearsList[index];
                    lowestChange = changeList[index];
                }
            }
        }

        private void DisplaySummary()
        {
            averagePopulationChangeLabel.Text = averageChanges.ToString("n1");
            yearMostIncreasedLabel.Text = highestYear + " @ " + highestChange.ToString("n0");
            yearMostDecreasedLabel.Text = lowestYear + " @ " + lowestChange.ToString("n0");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
