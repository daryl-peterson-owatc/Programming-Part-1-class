﻿namespace Population_Data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.populationInformationLabel = new System.Windows.Forms.Label();
            this.analyzeButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.averagePopulationChangeLabel = new System.Windows.Forms.Label();
            this.yearMostIncreasedLabel = new System.Windows.Forms.Label();
            this.yearMostDecreasedLabel = new System.Windows.Forms.Label();
            this.averageChangeInfoLabel = new System.Windows.Forms.Label();
            this.highestChangeInfoLabel = new System.Windows.Forms.Label();
            this.lowestChangeInfoLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // populationInformationLabel
            // 
            this.populationInformationLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.populationInformationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.populationInformationLabel.Location = new System.Drawing.Point(12, 9);
            this.populationInformationLabel.Name = "populationInformationLabel";
            this.populationInformationLabel.Size = new System.Drawing.Size(287, 39);
            this.populationInformationLabel.TabIndex = 0;
            // 
            // analyzeButton
            // 
            this.analyzeButton.Location = new System.Drawing.Point(53, 186);
            this.analyzeButton.Name = "analyzeButton";
            this.analyzeButton.Size = new System.Drawing.Size(75, 23);
            this.analyzeButton.TabIndex = 1;
            this.analyzeButton.Text = "Analyze";
            this.analyzeButton.UseVisualStyleBackColor = true;
            this.analyzeButton.Click += new System.EventHandler(this.analyzeButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(199, 186);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // averagePopulationChangeLabel
            // 
            this.averagePopulationChangeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averagePopulationChangeLabel.Location = new System.Drawing.Point(199, 64);
            this.averagePopulationChangeLabel.Name = "averagePopulationChangeLabel";
            this.averagePopulationChangeLabel.Size = new System.Drawing.Size(100, 23);
            this.averagePopulationChangeLabel.TabIndex = 3;
            this.averagePopulationChangeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yearMostIncreasedLabel
            // 
            this.yearMostIncreasedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearMostIncreasedLabel.Location = new System.Drawing.Point(199, 102);
            this.yearMostIncreasedLabel.Name = "yearMostIncreasedLabel";
            this.yearMostIncreasedLabel.Size = new System.Drawing.Size(100, 23);
            this.yearMostIncreasedLabel.TabIndex = 4;
            this.yearMostIncreasedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yearMostDecreasedLabel
            // 
            this.yearMostDecreasedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearMostDecreasedLabel.Location = new System.Drawing.Point(199, 138);
            this.yearMostDecreasedLabel.Name = "yearMostDecreasedLabel";
            this.yearMostDecreasedLabel.Size = new System.Drawing.Size(100, 23);
            this.yearMostDecreasedLabel.TabIndex = 5;
            this.yearMostDecreasedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // averageChangeInfoLabel
            // 
            this.averageChangeInfoLabel.AutoSize = true;
            this.averageChangeInfoLabel.Location = new System.Drawing.Point(50, 69);
            this.averageChangeInfoLabel.Name = "averageChangeInfoLabel";
            this.averageChangeInfoLabel.Size = new System.Drawing.Size(143, 13);
            this.averageChangeInfoLabel.TabIndex = 6;
            this.averageChangeInfoLabel.Text = "Average Population Change:";
            // 
            // highestChangeInfoLabel
            // 
            this.highestChangeInfoLabel.AutoSize = true;
            this.highestChangeInfoLabel.Location = new System.Drawing.Point(13, 107);
            this.highestChangeInfoLabel.Name = "highestChangeInfoLabel";
            this.highestChangeInfoLabel.Size = new System.Drawing.Size(180, 13);
            this.highestChangeInfoLabel.TabIndex = 7;
            this.highestChangeInfoLabel.Text = "Year of greatest population increase:";
            // 
            // lowestChangeInfoLabel
            // 
            this.lowestChangeInfoLabel.AutoSize = true;
            this.lowestChangeInfoLabel.Location = new System.Drawing.Point(9, 143);
            this.lowestChangeInfoLabel.Name = "lowestChangeInfoLabel";
            this.lowestChangeInfoLabel.Size = new System.Drawing.Size(184, 13);
            this.lowestChangeInfoLabel.TabIndex = 8;
            this.lowestChangeInfoLabel.Text = "Year of greatest population decrease:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 225);
            this.Controls.Add(this.lowestChangeInfoLabel);
            this.Controls.Add(this.highestChangeInfoLabel);
            this.Controls.Add(this.averageChangeInfoLabel);
            this.Controls.Add(this.yearMostDecreasedLabel);
            this.Controls.Add(this.yearMostIncreasedLabel);
            this.Controls.Add(this.averagePopulationChangeLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.analyzeButton);
            this.Controls.Add(this.populationInformationLabel);
            this.Name = "Form1";
            this.Text = "Population Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label populationInformationLabel;
        private System.Windows.Forms.Button analyzeButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label averagePopulationChangeLabel;
        private System.Windows.Forms.Label yearMostIncreasedLabel;
        private System.Windows.Forms.Label yearMostDecreasedLabel;
        private System.Windows.Forms.Label averageChangeInfoLabel;
        private System.Windows.Forms.Label highestChangeInfoLabel;
        private System.Windows.Forms.Label lowestChangeInfoLabel;
    }
}

