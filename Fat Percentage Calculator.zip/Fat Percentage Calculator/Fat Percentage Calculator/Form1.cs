﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fat_Percentage_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculateFat_Click(object sender, EventArgs e)
        {
            double totalCalories;
            double totalFatGrams;
            double caloriesFromFat;
            double percentageOfCaloriesFromFat;

            if (double.TryParse(txtCalories.Text, out totalCalories) && double.TryParse(txtFatGrams.Text, out totalFatGrams))
            {
                caloriesFromFat = totalFatGrams * 9;
                percentageOfCaloriesFromFat = (caloriesFromFat / totalCalories);

                lblCaloriesFromFat.Text = caloriesFromFat.ToString("n2");
                lblPercentageOfCaloriesFromFat.Text = percentageOfCaloriesFromFat.ToString("p");

                if  (ckbxLessThan30Percent.Checked && percentageOfCaloriesFromFat <= .30)
                {
                    lblLowFatIndicator.Visible = true;
                }
                else
                {
                    lblLowFatIndicator.Visible = false;
                }
            }
            else
            {
                MessageBox.Show("Input fields must be numeric.");
                txtCalories.Focus();
            }
        }
    }
}
