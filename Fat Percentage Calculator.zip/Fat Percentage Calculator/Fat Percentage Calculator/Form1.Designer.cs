﻿namespace Fat_Percentage_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCaloriesDescription = new System.Windows.Forms.Label();
            this.lblFatGramsDescription = new System.Windows.Forms.Label();
            this.txtCalories = new System.Windows.Forms.TextBox();
            this.txtFatGrams = new System.Windows.Forms.TextBox();
            this.lblCaloriesFromFatDescription = new System.Windows.Forms.Label();
            this.lblCaloriesFromFat = new System.Windows.Forms.Label();
            this.lblPercentageCaloriesFromFat = new System.Windows.Forms.Label();
            this.lblPercentageOfCaloriesFromFat = new System.Windows.Forms.Label();
            this.ckbxLessThan30Percent = new System.Windows.Forms.CheckBox();
            this.btnCalculateFat = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblLowFatIndicator = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCaloriesDescription
            // 
            this.lblCaloriesDescription.AutoSize = true;
            this.lblCaloriesDescription.Location = new System.Drawing.Point(111, 24);
            this.lblCaloriesDescription.Name = "lblCaloriesDescription";
            this.lblCaloriesDescription.Size = new System.Drawing.Size(73, 13);
            this.lblCaloriesDescription.TabIndex = 0;
            this.lblCaloriesDescription.Text = "Total calories:";
            // 
            // lblFatGramsDescription
            // 
            this.lblFatGramsDescription.AutoSize = true;
            this.lblFatGramsDescription.Location = new System.Drawing.Point(79, 51);
            this.lblFatGramsDescription.Name = "lblFatGramsDescription";
            this.lblFatGramsDescription.Size = new System.Drawing.Size(105, 13);
            this.lblFatGramsDescription.TabIndex = 1;
            this.lblFatGramsDescription.Text = "Number of fat grams:";
            // 
            // txtCalories
            // 
            this.txtCalories.Location = new System.Drawing.Point(190, 21);
            this.txtCalories.Name = "txtCalories";
            this.txtCalories.Size = new System.Drawing.Size(100, 20);
            this.txtCalories.TabIndex = 2;
            this.txtCalories.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFatGrams
            // 
            this.txtFatGrams.Location = new System.Drawing.Point(190, 48);
            this.txtFatGrams.Name = "txtFatGrams";
            this.txtFatGrams.Size = new System.Drawing.Size(100, 20);
            this.txtFatGrams.TabIndex = 3;
            this.txtFatGrams.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCaloriesFromFatDescription
            // 
            this.lblCaloriesFromFatDescription.AutoSize = true;
            this.lblCaloriesFromFatDescription.Location = new System.Drawing.Point(48, 126);
            this.lblCaloriesFromFatDescription.Name = "lblCaloriesFromFatDescription";
            this.lblCaloriesFromFatDescription.Size = new System.Drawing.Size(136, 13);
            this.lblCaloriesFromFatDescription.TabIndex = 4;
            this.lblCaloriesFromFatDescription.Text = "Number of calories from fat:";
            // 
            // lblCaloriesFromFat
            // 
            this.lblCaloriesFromFat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCaloriesFromFat.Location = new System.Drawing.Point(190, 121);
            this.lblCaloriesFromFat.Name = "lblCaloriesFromFat";
            this.lblCaloriesFromFat.Size = new System.Drawing.Size(100, 23);
            this.lblCaloriesFromFat.TabIndex = 5;
            this.lblCaloriesFromFat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPercentageCaloriesFromFat
            // 
            this.lblPercentageCaloriesFromFat.AutoSize = true;
            this.lblPercentageCaloriesFromFat.Location = new System.Drawing.Point(42, 160);
            this.lblPercentageCaloriesFromFat.Name = "lblPercentageCaloriesFromFat";
            this.lblPercentageCaloriesFromFat.Size = new System.Drawing.Size(142, 13);
            this.lblPercentageCaloriesFromFat.TabIndex = 6;
            this.lblPercentageCaloriesFromFat.Text = "Percentage calories from fat:";
            this.lblPercentageCaloriesFromFat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPercentageOfCaloriesFromFat
            // 
            this.lblPercentageOfCaloriesFromFat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPercentageOfCaloriesFromFat.Location = new System.Drawing.Point(190, 155);
            this.lblPercentageOfCaloriesFromFat.Name = "lblPercentageOfCaloriesFromFat";
            this.lblPercentageOfCaloriesFromFat.Size = new System.Drawing.Size(100, 23);
            this.lblPercentageOfCaloriesFromFat.TabIndex = 7;
            this.lblPercentageOfCaloriesFromFat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ckbxLessThan30Percent
            // 
            this.ckbxLessThan30Percent.AutoSize = true;
            this.ckbxLessThan30Percent.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbxLessThan30Percent.Location = new System.Drawing.Point(30, 74);
            this.ckbxLessThan30Percent.Name = "ckbxLessThan30Percent";
            this.ckbxLessThan30Percent.Size = new System.Drawing.Size(175, 17);
            this.ckbxLessThan30Percent.TabIndex = 8;
            this.ckbxLessThan30Percent.Text = "Less than 30% calories from fat:";
            this.ckbxLessThan30Percent.UseVisualStyleBackColor = true;
            // 
            // btnCalculateFat
            // 
            this.btnCalculateFat.Location = new System.Drawing.Point(82, 193);
            this.btnCalculateFat.Name = "btnCalculateFat";
            this.btnCalculateFat.Size = new System.Drawing.Size(75, 38);
            this.btnCalculateFat.TabIndex = 9;
            this.btnCalculateFat.Text = "Calculate Fat";
            this.btnCalculateFat.UseVisualStyleBackColor = true;
            this.btnCalculateFat.Click += new System.EventHandler(this.btnCalculateFat_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(190, 193);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 38);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblLowFatIndicator
            // 
            this.lblLowFatIndicator.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblLowFatIndicator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLowFatIndicator.ForeColor = System.Drawing.Color.Yellow;
            this.lblLowFatIndicator.Location = new System.Drawing.Point(30, 94);
            this.lblLowFatIndicator.Name = "lblLowFatIndicator";
            this.lblLowFatIndicator.Size = new System.Drawing.Size(260, 23);
            this.lblLowFatIndicator.TabIndex = 11;
            this.lblLowFatIndicator.Text = "This food item is a Low Fat food";
            this.lblLowFatIndicator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLowFatIndicator.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 243);
            this.Controls.Add(this.lblLowFatIndicator);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculateFat);
            this.Controls.Add(this.ckbxLessThan30Percent);
            this.Controls.Add(this.lblPercentageOfCaloriesFromFat);
            this.Controls.Add(this.lblPercentageCaloriesFromFat);
            this.Controls.Add(this.lblCaloriesFromFat);
            this.Controls.Add(this.lblCaloriesFromFatDescription);
            this.Controls.Add(this.txtFatGrams);
            this.Controls.Add(this.txtCalories);
            this.Controls.Add(this.lblFatGramsDescription);
            this.Controls.Add(this.lblCaloriesDescription);
            this.Name = "Form1";
            this.Text = "Fat Percentage Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCaloriesDescription;
        private System.Windows.Forms.Label lblFatGramsDescription;
        private System.Windows.Forms.TextBox txtCalories;
        private System.Windows.Forms.TextBox txtFatGrams;
        private System.Windows.Forms.Label lblCaloriesFromFatDescription;
        private System.Windows.Forms.Label lblCaloriesFromFat;
        private System.Windows.Forms.Label lblPercentageCaloriesFromFat;
        private System.Windows.Forms.Label lblPercentageOfCaloriesFromFat;
        private System.Windows.Forms.CheckBox ckbxLessThan30Percent;
        private System.Windows.Forms.Button btnCalculateFat;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblLowFatIndicator;
    }
}

