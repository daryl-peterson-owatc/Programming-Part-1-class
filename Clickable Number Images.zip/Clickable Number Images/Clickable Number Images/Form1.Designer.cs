﻿namespace Clickable_Number_Images
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInstructions = new System.Windows.Forms.Label();
            this.picBoxFive = new System.Windows.Forms.PictureBox();
            this.picBoxFour = new System.Windows.Forms.PictureBox();
            this.picBoxThree = new System.Windows.Forms.PictureBox();
            this.picBoxTwo = new System.Windows.Forms.PictureBox();
            this.picBoxOne = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOne)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Location = new System.Drawing.Point(225, 28);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(199, 13);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "Click an Image for it\'s text numeric value.";
            // 
            // picBoxFive
            // 
            this.picBoxFive.Image = global::Clickable_Number_Images.Properties.Resources.Five;
            this.picBoxFive.Location = new System.Drawing.Point(543, 63);
            this.picBoxFive.Name = "picBoxFive";
            this.picBoxFive.Size = new System.Drawing.Size(100, 133);
            this.picBoxFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxFive.TabIndex = 5;
            this.picBoxFive.TabStop = false;
            this.picBoxFive.Click += new System.EventHandler(this.picBoxFive_Click);
            // 
            // picBoxFour
            // 
            this.picBoxFour.Image = global::Clickable_Number_Images.Properties.Resources.Four;
            this.picBoxFour.Location = new System.Drawing.Point(414, 63);
            this.picBoxFour.Name = "picBoxFour";
            this.picBoxFour.Size = new System.Drawing.Size(100, 133);
            this.picBoxFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxFour.TabIndex = 4;
            this.picBoxFour.TabStop = false;
            this.picBoxFour.Click += new System.EventHandler(this.picBoxFour_Click);
            // 
            // picBoxThree
            // 
            this.picBoxThree.Image = global::Clickable_Number_Images.Properties.Resources.Three;
            this.picBoxThree.Location = new System.Drawing.Point(281, 63);
            this.picBoxThree.Name = "picBoxThree";
            this.picBoxThree.Size = new System.Drawing.Size(100, 133);
            this.picBoxThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxThree.TabIndex = 3;
            this.picBoxThree.TabStop = false;
            this.picBoxThree.Click += new System.EventHandler(this.picBoxThree_Click);
            // 
            // picBoxTwo
            // 
            this.picBoxTwo.Image = global::Clickable_Number_Images.Properties.Resources.Two;
            this.picBoxTwo.Location = new System.Drawing.Point(150, 63);
            this.picBoxTwo.Name = "picBoxTwo";
            this.picBoxTwo.Size = new System.Drawing.Size(100, 133);
            this.picBoxTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxTwo.TabIndex = 2;
            this.picBoxTwo.TabStop = false;
            this.picBoxTwo.Click += new System.EventHandler(this.picBoxTwo_Click);
            // 
            // picBoxOne
            // 
            this.picBoxOne.Image = global::Clickable_Number_Images.Properties.Resources.One;
            this.picBoxOne.Location = new System.Drawing.Point(21, 63);
            this.picBoxOne.Name = "picBoxOne";
            this.picBoxOne.Size = new System.Drawing.Size(100, 133);
            this.picBoxOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxOne.TabIndex = 1;
            this.picBoxOne.TabStop = false;
            this.picBoxOne.Click += new System.EventHandler(this.picBoxOne_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 238);
            this.Controls.Add(this.picBoxFive);
            this.Controls.Add(this.picBoxFour);
            this.Controls.Add(this.picBoxThree);
            this.Controls.Add(this.picBoxTwo);
            this.Controls.Add(this.picBoxOne);
            this.Controls.Add(this.lblInstructions);
            this.Name = "Form1";
            this.Text = "Clickable Number Images";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOne)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.PictureBox picBoxOne;
        private System.Windows.Forms.PictureBox picBoxTwo;
        private System.Windows.Forms.PictureBox picBoxThree;
        private System.Windows.Forms.PictureBox picBoxFour;
        private System.Windows.Forms.PictureBox picBoxFive;
    }
}

