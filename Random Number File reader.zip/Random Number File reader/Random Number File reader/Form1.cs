﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void openAndReadButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;
            int nextNumber;
            int numberCounter = 0;
            int numbersTotal = 0;

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                inputFile = File.OpenText(openFile.FileName);

                while (!inputFile.EndOfStream)
                {
                    if (int.TryParse(inputFile.ReadLine(), out nextNumber))
                    {
                        numberCounter += 1;
                        numbersTotal += nextNumber;
                        fileContentListBox.Items.Add(nextNumber.ToString());
                    }
                    
                }

                inputFile.Close();

                lblNumbersCounted.Text = numberCounter.ToString("n");
                lblTotalOfNumbers.Text = numbersTotal.ToString();
            }
            else
            {
                MessageBox.Show("No file was selected.");
            }
        }
    }
}
