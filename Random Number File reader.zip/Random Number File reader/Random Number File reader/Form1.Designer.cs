﻿namespace Random_Number_File_reader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.fileContentListBox = new System.Windows.Forms.ListBox();
            this.totalNumbersLabel = new System.Windows.Forms.Label();
            this.randomNumbersCounted = new System.Windows.Forms.Label();
            this.lblTotalOfNumbers = new System.Windows.Forms.Label();
            this.lblNumbersCounted = new System.Windows.Forms.Label();
            this.openAndReadButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Program to read the contents of a text file.";
            // 
            // fileContentListBox
            // 
            this.fileContentListBox.FormattingEnabled = true;
            this.fileContentListBox.Location = new System.Drawing.Point(50, 25);
            this.fileContentListBox.Name = "fileContentListBox";
            this.fileContentListBox.Size = new System.Drawing.Size(239, 160);
            this.fileContentListBox.TabIndex = 1;
            // 
            // totalNumbersLabel
            // 
            this.totalNumbersLabel.AutoSize = true;
            this.totalNumbersLabel.Location = new System.Drawing.Point(94, 196);
            this.totalNumbersLabel.Name = "totalNumbersLabel";
            this.totalNumbersLabel.Size = new System.Drawing.Size(89, 13);
            this.totalNumbersLabel.TabIndex = 2;
            this.totalNumbersLabel.Text = "Total of numbers:";
            // 
            // randomNumbersCounted
            // 
            this.randomNumbersCounted.AutoSize = true;
            this.randomNumbersCounted.Location = new System.Drawing.Point(47, 227);
            this.randomNumbersCounted.Name = "randomNumbersCounted";
            this.randomNumbersCounted.Size = new System.Drawing.Size(135, 13);
            this.randomNumbersCounted.TabIndex = 3;
            this.randomNumbersCounted.Text = "Random numbers counted:";
            // 
            // lblTotalOfNumbers
            // 
            this.lblTotalOfNumbers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalOfNumbers.Location = new System.Drawing.Point(189, 191);
            this.lblTotalOfNumbers.Name = "lblTotalOfNumbers";
            this.lblTotalOfNumbers.Size = new System.Drawing.Size(100, 23);
            this.lblTotalOfNumbers.TabIndex = 4;
            this.lblTotalOfNumbers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNumbersCounted
            // 
            this.lblNumbersCounted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumbersCounted.Location = new System.Drawing.Point(189, 222);
            this.lblNumbersCounted.Name = "lblNumbersCounted";
            this.lblNumbersCounted.Size = new System.Drawing.Size(100, 23);
            this.lblNumbersCounted.TabIndex = 5;
            this.lblNumbersCounted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // openAndReadButton
            // 
            this.openAndReadButton.Location = new System.Drawing.Point(82, 260);
            this.openAndReadButton.Name = "openAndReadButton";
            this.openAndReadButton.Size = new System.Drawing.Size(75, 44);
            this.openAndReadButton.TabIndex = 6;
            this.openAndReadButton.Text = "Open and Read File";
            this.openAndReadButton.UseVisualStyleBackColor = true;
            this.openAndReadButton.Click += new System.EventHandler(this.openAndReadButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(188, 260);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 44);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 316);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.openAndReadButton);
            this.Controls.Add(this.lblNumbersCounted);
            this.Controls.Add(this.lblTotalOfNumbers);
            this.Controls.Add(this.randomNumbersCounted);
            this.Controls.Add(this.totalNumbersLabel);
            this.Controls.Add(this.fileContentListBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Random Number File Reader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox fileContentListBox;
        private System.Windows.Forms.Label totalNumbersLabel;
        private System.Windows.Forms.Label randomNumbersCounted;
        private System.Windows.Forms.Label lblTotalOfNumbers;
        private System.Windows.Forms.Label lblNumbersCounted;
        private System.Windows.Forms.Button openAndReadButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.OpenFileDialog openFile;
    }
}

