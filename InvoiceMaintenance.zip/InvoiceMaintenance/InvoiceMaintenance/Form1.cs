﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace InvoiceMaintenance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void vendorsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.vendorsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.payablesDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'payablesDataSet.Invoices' table. You can move, or remove it, as needed.
            //this.invoicesTableAdapter.Fill(this.payablesDataSet.Invoices);
            // TODO: This line of code loads data into the 'payablesDataSet.Vendors' table. You can move, or remove it, as needed.
            //this.vendorsTableAdapter.Fill(this.payablesDataSet.Vendors);

        }

        private void invoicesDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            int row = e.RowIndex + 1;
            string errorMessage = "A data error occurred.\n" +
                "Row: " + row + "\n" +
                "Error: " + e.Exception.Message;
            MessageBox.Show(errorMessage, "Data Error");
        }

        private void invoicesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("Clicked column: " + e.ColumnIndex);
            if (e.ColumnIndex == 8)
            {
                int i = e.RowIndex;
                DataGridViewRow row = invoicesDataGridView.Rows[i];
                DataGridViewCell cell = row.Cells[0];
                int invoiceID = (int)cell.Value;

                Form lineItemsForm = new frmLineItems();
                lineItemsForm.Tag = invoiceID;
                lineItemsForm.ShowDialog();
            }
        }

        private void fillByVendorIDToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                int vendorID = Convert.ToInt32(vendorIDToolStripTextBox.Text);
                this.vendorsTableAdapter.FillByVendorID(this.payablesDataSet.Vendors, vendorID);
                if (vendorsBindingSource.Count > 0)
                {
                    this.invoicesTableAdapter.FillByVendorID(this.payablesDataSet.Invoices, vendorID);
                }
                else
                {
                    MessageBox.Show("No vendor found with this ID. Please try again.", "Vendor Not Found");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Vendor ID must be an integer", "Entry Error");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                this.invoicesBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.payablesDataSet);
            }
            catch (DBConcurrencyException)
            {
                MessageBox.Show("A concurrencty error occurred. The row was not update.", "Concurrency Exception");
                this.vendorsTableAdapter.Fill(this.payablesDataSet.Vendors);
            }
            catch (DataException ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
                this.invoicesBindingSource.CancelEdit();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Server error # " + ex.Number +
                    ": " + ex.Message, ex.GetType().ToString());
            }
        }
    }
}
