﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace InvoiceMaintenance
{
    public partial class frmLineItems : Form
    {
        public frmLineItems()
        {
            InitializeComponent();
        }

        private void invoiceLineItemsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.invoiceLineItemsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.payablesDataSet);

        }

        private void frmLineItems_Load(object sender, EventArgs e)
        {
            try
            {
                int invoiceID = (int)this.Tag;
                this.invoiceLineItemsTableAdapter.FillByInvoiceID(
                    this.payablesDataSet.InvoiceLineItems, invoiceID);
            }
            catch (InvalidCastException)
            {
                MessageBox.Show("Invoice ID is not an Integer.", "Property Error");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Server error # " + ex.Number +
                    ": " + ex.Message, ex.GetType().ToString());
            }
            // TODO: This line of code loads data into the 'payablesDataSet.InvoiceLineItems' table. You can move, or remove it, as needed.
            //this.invoiceLineItemsTableAdapter.Fill(this.payablesDataSet.InvoiceLineItems);

        }

        private void fillByInvoiceIDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.invoiceLineItemsTableAdapter.FillByInvoiceID(this.payablesDataSet.InvoiceLineItems, ((int)(System.Convert.ChangeType(invoiceIDToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
