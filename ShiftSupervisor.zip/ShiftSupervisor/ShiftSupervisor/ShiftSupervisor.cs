﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace ShiftSupervisor
{
    class ShiftSupervisor : Employee.Employee
    {
        private decimal _annualSalary;
        private decimal _productionBouns;

        public ShiftSupervisor()
        {
            _annualSalary = 0m;
            _productionBouns = 0m;
        }

        public ShiftSupervisor(decimal salary, decimal bonus)
        {
            _annualSalary = salary;
            _productionBouns = bonus;
        }

        public decimal AnnualSalary
        {
            get { return _annualSalary; }
            set { _annualSalary = value; }
        }

        public decimal ProductionBonus
        {
            get { return _productionBouns; }
            set { _productionBouns = value; }
        }
    }
}
