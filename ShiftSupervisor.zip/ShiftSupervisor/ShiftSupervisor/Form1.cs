﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShiftSupervisor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetSupervisorInfo(ShiftSupervisor supervisor)
        {
            decimal annualSalary;
            decimal productionBonus;

            supervisor.Number = employeeNumberTextBox.Text;
            supervisor.Name = employeeNameTextBox.Text;

            if (decimal.TryParse(annualSalaryTextBox.Text, out annualSalary))
            {
                supervisor.AnnualSalary = annualSalary;
            }
            else
            {
                MessageBox.Show("Invalid number");
            }

            if (decimal.TryParse(productionBonusTextBox.Text, out productionBonus))
            {
                supervisor.ProductionBonus = productionBonus;
            }
            else
            {
                MessageBox.Show("Invalid number");
            }
        }

        private void createObjectButton_Click(object sender, EventArgs e)
        {
            ShiftSupervisor supervisor = new ShiftSupervisor();

            GetSupervisorInfo(supervisor);

            employeeNameLabel.Text = supervisor.Name;
            employeeNumberLabel.Text = supervisor.Number;
            annualSalaryLabel.Text = supervisor.AnnualSalary.ToString("c");
            productionBonusLabel.Text = supervisor.ProductionBonus.ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
