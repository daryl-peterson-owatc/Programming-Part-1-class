﻿namespace ShiftSupervisor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.annualSalaryTextBox = new System.Windows.Forms.TextBox();
            this.productionBonusTextBox = new System.Windows.Forms.TextBox();
            this.inputPanel = new System.Windows.Forms.Panel();
            this.inputNumberLabel = new System.Windows.Forms.Label();
            this.inputNameLabel = new System.Windows.Forms.Label();
            this.inputAnnualSalaryLabel = new System.Windows.Forms.Label();
            this.inputProductionBonusLabel = new System.Windows.Forms.Label();
            this.createObjectButton = new System.Windows.Forms.Button();
            this.outputPanel = new System.Windows.Forms.Panel();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.annualSalaryLabel = new System.Windows.Forms.Label();
            this.productionBonusLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputPanel.SuspendLayout();
            this.outputPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(119, 23);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeNumberTextBox.TabIndex = 0;
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(119, 49);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(135, 20);
            this.employeeNameTextBox.TabIndex = 1;
            // 
            // annualSalaryTextBox
            // 
            this.annualSalaryTextBox.Location = new System.Drawing.Point(119, 75);
            this.annualSalaryTextBox.Name = "annualSalaryTextBox";
            this.annualSalaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.annualSalaryTextBox.TabIndex = 2;
            // 
            // productionBonusTextBox
            // 
            this.productionBonusTextBox.Location = new System.Drawing.Point(119, 101);
            this.productionBonusTextBox.Name = "productionBonusTextBox";
            this.productionBonusTextBox.Size = new System.Drawing.Size(100, 20);
            this.productionBonusTextBox.TabIndex = 3;
            // 
            // inputPanel
            // 
            this.inputPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.inputPanel.Controls.Add(this.inputProductionBonusLabel);
            this.inputPanel.Controls.Add(this.productionBonusTextBox);
            this.inputPanel.Controls.Add(this.inputAnnualSalaryLabel);
            this.inputPanel.Controls.Add(this.annualSalaryTextBox);
            this.inputPanel.Controls.Add(this.inputNameLabel);
            this.inputPanel.Controls.Add(this.employeeNameTextBox);
            this.inputPanel.Controls.Add(this.inputNumberLabel);
            this.inputPanel.Controls.Add(this.employeeNumberTextBox);
            this.inputPanel.Location = new System.Drawing.Point(12, 12);
            this.inputPanel.Name = "inputPanel";
            this.inputPanel.Size = new System.Drawing.Size(263, 136);
            this.inputPanel.TabIndex = 4;
            // 
            // inputNumberLabel
            // 
            this.inputNumberLabel.AutoSize = true;
            this.inputNumberLabel.Location = new System.Drawing.Point(17, 26);
            this.inputNumberLabel.Name = "inputNumberLabel";
            this.inputNumberLabel.Size = new System.Drawing.Size(96, 13);
            this.inputNumberLabel.TabIndex = 5;
            this.inputNumberLabel.Text = "Employee Number:";
            // 
            // inputNameLabel
            // 
            this.inputNameLabel.AutoSize = true;
            this.inputNameLabel.Location = new System.Drawing.Point(75, 52);
            this.inputNameLabel.Name = "inputNameLabel";
            this.inputNameLabel.Size = new System.Drawing.Size(38, 13);
            this.inputNameLabel.TabIndex = 6;
            this.inputNameLabel.Text = "Name:";
            // 
            // inputAnnualSalaryLabel
            // 
            this.inputAnnualSalaryLabel.AutoSize = true;
            this.inputAnnualSalaryLabel.Location = new System.Drawing.Point(38, 78);
            this.inputAnnualSalaryLabel.Name = "inputAnnualSalaryLabel";
            this.inputAnnualSalaryLabel.Size = new System.Drawing.Size(75, 13);
            this.inputAnnualSalaryLabel.TabIndex = 7;
            this.inputAnnualSalaryLabel.Text = "Annual Salary:";
            // 
            // inputProductionBonusLabel
            // 
            this.inputProductionBonusLabel.AutoSize = true;
            this.inputProductionBonusLabel.Location = new System.Drawing.Point(19, 104);
            this.inputProductionBonusLabel.Name = "inputProductionBonusLabel";
            this.inputProductionBonusLabel.Size = new System.Drawing.Size(94, 13);
            this.inputProductionBonusLabel.TabIndex = 8;
            this.inputProductionBonusLabel.Text = "Production Bonus:";
            // 
            // createObjectButton
            // 
            this.createObjectButton.Location = new System.Drawing.Point(92, 164);
            this.createObjectButton.Name = "createObjectButton";
            this.createObjectButton.Size = new System.Drawing.Size(112, 23);
            this.createObjectButton.TabIndex = 5;
            this.createObjectButton.Text = "Create Object";
            this.createObjectButton.UseVisualStyleBackColor = true;
            this.createObjectButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // outputPanel
            // 
            this.outputPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputPanel.Controls.Add(this.productionBonusLabel);
            this.outputPanel.Controls.Add(this.annualSalaryLabel);
            this.outputPanel.Controls.Add(this.employeeNameLabel);
            this.outputPanel.Controls.Add(this.employeeNumberLabel);
            this.outputPanel.Location = new System.Drawing.Point(12, 204);
            this.outputPanel.Name = "outputPanel";
            this.outputPanel.Size = new System.Drawing.Size(262, 144);
            this.outputPanel.TabIndex = 6;
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNumberLabel.Location = new System.Drawing.Point(20, 10);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(220, 23);
            this.employeeNumberLabel.TabIndex = 0;
            this.employeeNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNameLabel.Location = new System.Drawing.Point(20, 42);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(220, 23);
            this.employeeNameLabel.TabIndex = 1;
            this.employeeNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // annualSalaryLabel
            // 
            this.annualSalaryLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.annualSalaryLabel.Location = new System.Drawing.Point(20, 75);
            this.annualSalaryLabel.Name = "annualSalaryLabel";
            this.annualSalaryLabel.Size = new System.Drawing.Size(220, 23);
            this.annualSalaryLabel.TabIndex = 2;
            this.annualSalaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // productionBonusLabel
            // 
            this.productionBonusLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.productionBonusLabel.Location = new System.Drawing.Point(20, 107);
            this.productionBonusLabel.Name = "productionBonusLabel";
            this.productionBonusLabel.Size = new System.Drawing.Size(220, 23);
            this.productionBonusLabel.TabIndex = 3;
            this.productionBonusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(107, 365);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 400);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputPanel);
            this.Controls.Add(this.createObjectButton);
            this.Controls.Add(this.inputPanel);
            this.Name = "Form1";
            this.Text = "Shift Supervisor";
            this.inputPanel.ResumeLayout(false);
            this.inputPanel.PerformLayout();
            this.outputPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox annualSalaryTextBox;
        private System.Windows.Forms.TextBox productionBonusTextBox;
        private System.Windows.Forms.Panel inputPanel;
        private System.Windows.Forms.Label inputProductionBonusLabel;
        private System.Windows.Forms.Label inputAnnualSalaryLabel;
        private System.Windows.Forms.Label inputNameLabel;
        private System.Windows.Forms.Label inputNumberLabel;
        private System.Windows.Forms.Button createObjectButton;
        private System.Windows.Forms.Panel outputPanel;
        private System.Windows.Forms.Label productionBonusLabel;
        private System.Windows.Forms.Label annualSalaryLabel;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

