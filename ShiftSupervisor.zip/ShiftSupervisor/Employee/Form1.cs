﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetProductionWorkerInfo(ProductionWorker proWorker)
        {
            int shift;
            decimal hourlyRate;

            proWorker.Number = employeeNumberTextBox.Text;
            proWorker.Name = nameTextBox.Text;

            if (decimal.TryParse(hourlyPayRateTextBox.Text, out hourlyRate))
            {
                proWorker.HourlyPayRate = hourlyRate;
            }
            else
            {
                MessageBox.Show("Invalid number");
            }

            if (dayShiftRadioButton.Checked)
            {
                shift = 1;
            }
            else
            {
                shift = 2;
            }

            proWorker.ShiftNumber = shift;
        }

        private void createObjectButton_Click(object sender, EventArgs e)
        {
            ProductionWorker proWorker = new ProductionWorker();
            string shiftDescription;

            GetProductionWorkerInfo(proWorker);

            if (proWorker.ShiftNumber == 1)
            {
                shiftDescription = proWorker.ShiftNumber + " - Day Shift";
            }
            else
            {
                shiftDescription = proWorker.ShiftNumber + " - Night Shift";
            }

            employeeNumberLabel.Text = proWorker.Number;
            employeeNameLabel.Text = proWorker.Name;
            hourlyPayRateLabel.Text = proWorker.HourlyPayRate.ToString("c");
            shiftLabel.Text = shiftDescription;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
