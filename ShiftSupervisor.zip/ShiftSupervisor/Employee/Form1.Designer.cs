﻿namespace Employee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayRateTextBox = new System.Windows.Forms.TextBox();
            this.inputEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.inputNameLabel = new System.Windows.Forms.Label();
            this.inputHourlyPayRateLabel = new System.Windows.Forms.Label();
            this.dayShiftRadioButton = new System.Windows.Forms.RadioButton();
            this.nightShiftRadioButton = new System.Windows.Forms.RadioButton();
            this.createObjectButton = new System.Windows.Forms.Button();
            this.entryPanel = new System.Windows.Forms.Panel();
            this.displayPanel = new System.Windows.Forms.Panel();
            this.exitButton = new System.Windows.Forms.Button();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.hourlyPayRateLabel = new System.Windows.Forms.Label();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.entryPanel.SuspendLayout();
            this.displayPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(118, 13);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeNumberTextBox.TabIndex = 0;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(118, 39);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(137, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // hourlyPayRateTextBox
            // 
            this.hourlyPayRateTextBox.Location = new System.Drawing.Point(118, 65);
            this.hourlyPayRateTextBox.Name = "hourlyPayRateTextBox";
            this.hourlyPayRateTextBox.Size = new System.Drawing.Size(63, 20);
            this.hourlyPayRateTextBox.TabIndex = 2;
            // 
            // inputEmployeeNumberLabel
            // 
            this.inputEmployeeNumberLabel.AutoSize = true;
            this.inputEmployeeNumberLabel.Location = new System.Drawing.Point(16, 16);
            this.inputEmployeeNumberLabel.Name = "inputEmployeeNumberLabel";
            this.inputEmployeeNumberLabel.Size = new System.Drawing.Size(96, 13);
            this.inputEmployeeNumberLabel.TabIndex = 3;
            this.inputEmployeeNumberLabel.Text = "Employee Number:";
            // 
            // inputNameLabel
            // 
            this.inputNameLabel.AutoSize = true;
            this.inputNameLabel.Location = new System.Drawing.Point(25, 42);
            this.inputNameLabel.Name = "inputNameLabel";
            this.inputNameLabel.Size = new System.Drawing.Size(87, 13);
            this.inputNameLabel.TabIndex = 4;
            this.inputNameLabel.Text = "Employee Name:";
            // 
            // inputHourlyPayRateLabel
            // 
            this.inputHourlyPayRateLabel.AutoSize = true;
            this.inputHourlyPayRateLabel.Location = new System.Drawing.Point(25, 68);
            this.inputHourlyPayRateLabel.Name = "inputHourlyPayRateLabel";
            this.inputHourlyPayRateLabel.Size = new System.Drawing.Size(87, 13);
            this.inputHourlyPayRateLabel.TabIndex = 5;
            this.inputHourlyPayRateLabel.Text = "Hourly Pay Rate:";
            // 
            // dayShiftRadioButton
            // 
            this.dayShiftRadioButton.AutoSize = true;
            this.dayShiftRadioButton.Location = new System.Drawing.Point(118, 91);
            this.dayShiftRadioButton.Name = "dayShiftRadioButton";
            this.dayShiftRadioButton.Size = new System.Drawing.Size(68, 17);
            this.dayShiftRadioButton.TabIndex = 6;
            this.dayShiftRadioButton.TabStop = true;
            this.dayShiftRadioButton.Text = "Day Shift";
            this.dayShiftRadioButton.UseVisualStyleBackColor = true;
            // 
            // nightShiftRadioButton
            // 
            this.nightShiftRadioButton.AutoSize = true;
            this.nightShiftRadioButton.Location = new System.Drawing.Point(118, 114);
            this.nightShiftRadioButton.Name = "nightShiftRadioButton";
            this.nightShiftRadioButton.Size = new System.Drawing.Size(74, 17);
            this.nightShiftRadioButton.TabIndex = 7;
            this.nightShiftRadioButton.TabStop = true;
            this.nightShiftRadioButton.Text = "Night Shift";
            this.nightShiftRadioButton.UseVisualStyleBackColor = true;
            // 
            // createObjectButton
            // 
            this.createObjectButton.Location = new System.Drawing.Point(79, 162);
            this.createObjectButton.Name = "createObjectButton";
            this.createObjectButton.Size = new System.Drawing.Size(130, 23);
            this.createObjectButton.TabIndex = 8;
            this.createObjectButton.Text = "Create Object";
            this.createObjectButton.UseVisualStyleBackColor = true;
            this.createObjectButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // entryPanel
            // 
            this.entryPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.entryPanel.Controls.Add(this.nightShiftRadioButton);
            this.entryPanel.Controls.Add(this.dayShiftRadioButton);
            this.entryPanel.Controls.Add(this.inputHourlyPayRateLabel);
            this.entryPanel.Controls.Add(this.inputNameLabel);
            this.entryPanel.Controls.Add(this.inputEmployeeNumberLabel);
            this.entryPanel.Controls.Add(this.hourlyPayRateTextBox);
            this.entryPanel.Controls.Add(this.nameTextBox);
            this.entryPanel.Controls.Add(this.employeeNumberTextBox);
            this.entryPanel.Location = new System.Drawing.Point(13, 9);
            this.entryPanel.Name = "entryPanel";
            this.entryPanel.Size = new System.Drawing.Size(275, 141);
            this.entryPanel.TabIndex = 9;
            // 
            // displayPanel
            // 
            this.displayPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayPanel.Controls.Add(this.shiftLabel);
            this.displayPanel.Controls.Add(this.hourlyPayRateLabel);
            this.displayPanel.Controls.Add(this.employeeNameLabel);
            this.displayPanel.Controls.Add(this.employeeNumberLabel);
            this.displayPanel.Location = new System.Drawing.Point(13, 203);
            this.displayPanel.Name = "displayPanel";
            this.displayPanel.Size = new System.Drawing.Size(275, 149);
            this.displayPanel.TabIndex = 10;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(107, 358);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNumberLabel.Location = new System.Drawing.Point(19, 10);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(236, 23);
            this.employeeNumberLabel.TabIndex = 0;
            this.employeeNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNameLabel.Location = new System.Drawing.Point(19, 43);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(236, 23);
            this.employeeNameLabel.TabIndex = 1;
            this.employeeNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hourlyPayRateLabel
            // 
            this.hourlyPayRateLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hourlyPayRateLabel.Location = new System.Drawing.Point(19, 77);
            this.hourlyPayRateLabel.Name = "hourlyPayRateLabel";
            this.hourlyPayRateLabel.Size = new System.Drawing.Size(236, 23);
            this.hourlyPayRateLabel.TabIndex = 2;
            this.hourlyPayRateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shiftLabel
            // 
            this.shiftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shiftLabel.Location = new System.Drawing.Point(19, 110);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(236, 23);
            this.shiftLabel.TabIndex = 3;
            this.shiftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 393);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayPanel);
            this.Controls.Add(this.entryPanel);
            this.Controls.Add(this.createObjectButton);
            this.Name = "Form1";
            this.Text = "Employee";
            this.entryPanel.ResumeLayout(false);
            this.entryPanel.PerformLayout();
            this.displayPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox hourlyPayRateTextBox;
        private System.Windows.Forms.Label inputEmployeeNumberLabel;
        private System.Windows.Forms.Label inputNameLabel;
        private System.Windows.Forms.Label inputHourlyPayRateLabel;
        private System.Windows.Forms.RadioButton dayShiftRadioButton;
        private System.Windows.Forms.RadioButton nightShiftRadioButton;
        private System.Windows.Forms.Button createObjectButton;
        private System.Windows.Forms.Panel entryPanel;
        private System.Windows.Forms.Panel displayPanel;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label hourlyPayRateLabel;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

