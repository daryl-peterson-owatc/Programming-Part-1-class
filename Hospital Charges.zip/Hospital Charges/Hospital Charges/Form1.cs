﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Charges
{
    public partial class Form1 : Form
    {
        const decimal DAILY_RATE = 350.00m;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            daysStayedTextBox.Text = "0";
            medicationChargesTextBox.Text = "0.00";
            surgicalChargesTextBox.Text = "0.00";
            labFeesTextBox.Text = "0.00";
            physicalRehabChargesTextBox.Text = "0.00";
            totalChargesLabel.Text = "";
        }

        private void calculateBillButton_Click(object sender, EventArgs e)
        {
            decimal totalCharges = CalcTotalCharges();
            totalChargesLabel.Text = totalCharges.ToString("c");
        }

        private decimal CalcStayCharges()
        {
            decimal daysStayedCharges = 0;
            int days;

            if (int.TryParse(daysStayedTextBox.Text, out days))
            {
                daysStayedCharges = days * DAILY_RATE;
            }
            else
            {
                MessageBox.Show("Enter a numeric value in the Days fields.");
            }

            return daysStayedCharges;
        }

        private decimal CalcMiscCharges()
        {
            decimal medication = getMedicationCharges();
            decimal surgical = getSurgicalCharges();
            decimal lab = getLabFees();
            decimal rehab = getRehabCharges();

            return medication + surgical + lab + rehab;

        }

        private decimal CalcTotalCharges()
        {
            return CalcStayCharges() + CalcMiscCharges();
        }

        private decimal getMedicationCharges()
        {
            decimal medication = 0;

            if (!decimal.TryParse(medicationChargesTextBox.Text, out medication))
            {
                MessageBox.Show("Enter a numeric value in the Medication field.");
            }

            return medication;
        }

        private decimal getSurgicalCharges()
        {
            decimal surgical = 0;

            if (!decimal.TryParse(surgicalChargesTextBox.Text, out surgical))
            {
                MessageBox.Show("Enter a numeric value in the Surgical field.");
            }

            return surgical;
        }

        private decimal getLabFees()
        {
            decimal lab = 0;

            if (!decimal.TryParse(labFeesTextBox.Text, out lab))
            {
                MessageBox.Show("Enter a numeric value in the Lab field.");
            }

            return lab;
        }

        private decimal getRehabCharges()
        {
            decimal rehab = 0;

            if (!decimal.TryParse(physicalRehabChargesTextBox.Text, out rehab))
            {
                MessageBox.Show("Enter a numeric value in the Pysical field.");
            }

            return rehab;
        }
    }
}
