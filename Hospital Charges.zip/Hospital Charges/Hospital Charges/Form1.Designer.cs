﻿namespace Hospital_Charges
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysStayedTextBox = new System.Windows.Forms.TextBox();
            this.medicationChargesTextBox = new System.Windows.Forms.TextBox();
            this.surgicalChargesTextBox = new System.Windows.Forms.TextBox();
            this.labFeesTextBox = new System.Windows.Forms.TextBox();
            this.physicalRehabChargesTextBox = new System.Windows.Forms.TextBox();
            this.calculateBillButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.totalChargesLabel = new System.Windows.Forms.Label();
            this.numberOfDaysLabel = new System.Windows.Forms.Label();
            this.medicationChargesLabel = new System.Windows.Forms.Label();
            this.surgicalChargesLabel = new System.Windows.Forms.Label();
            this.labFeesLabel = new System.Windows.Forms.Label();
            this.physicalRehabChargesLabel = new System.Windows.Forms.Label();
            this.totalHospitalChargesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // daysStayedTextBox
            // 
            this.daysStayedTextBox.Location = new System.Drawing.Point(178, 19);
            this.daysStayedTextBox.Name = "daysStayedTextBox";
            this.daysStayedTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysStayedTextBox.TabIndex = 0;
            this.daysStayedTextBox.Text = "0";
            this.daysStayedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // medicationChargesTextBox
            // 
            this.medicationChargesTextBox.Location = new System.Drawing.Point(178, 45);
            this.medicationChargesTextBox.Name = "medicationChargesTextBox";
            this.medicationChargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.medicationChargesTextBox.TabIndex = 1;
            this.medicationChargesTextBox.Text = "0.00";
            this.medicationChargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // surgicalChargesTextBox
            // 
            this.surgicalChargesTextBox.Location = new System.Drawing.Point(178, 71);
            this.surgicalChargesTextBox.Name = "surgicalChargesTextBox";
            this.surgicalChargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.surgicalChargesTextBox.TabIndex = 2;
            this.surgicalChargesTextBox.Text = "0.00";
            this.surgicalChargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labFeesTextBox
            // 
            this.labFeesTextBox.Location = new System.Drawing.Point(178, 97);
            this.labFeesTextBox.Name = "labFeesTextBox";
            this.labFeesTextBox.Size = new System.Drawing.Size(100, 20);
            this.labFeesTextBox.TabIndex = 3;
            this.labFeesTextBox.Text = "0.00";
            this.labFeesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // physicalRehabChargesTextBox
            // 
            this.physicalRehabChargesTextBox.Location = new System.Drawing.Point(178, 123);
            this.physicalRehabChargesTextBox.Name = "physicalRehabChargesTextBox";
            this.physicalRehabChargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.physicalRehabChargesTextBox.TabIndex = 4;
            this.physicalRehabChargesTextBox.Text = "0.00";
            this.physicalRehabChargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // calculateBillButton
            // 
            this.calculateBillButton.Location = new System.Drawing.Point(34, 200);
            this.calculateBillButton.Name = "calculateBillButton";
            this.calculateBillButton.Size = new System.Drawing.Size(81, 23);
            this.calculateBillButton.TabIndex = 5;
            this.calculateBillButton.Text = "Calculate Bill";
            this.calculateBillButton.UseVisualStyleBackColor = true;
            this.calculateBillButton.Click += new System.EventHandler(this.calculateBillButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(121, 200);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(203, 200);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalChargesLabel
            // 
            this.totalChargesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalChargesLabel.Location = new System.Drawing.Point(178, 155);
            this.totalChargesLabel.Name = "totalChargesLabel";
            this.totalChargesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalChargesLabel.TabIndex = 8;
            this.totalChargesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numberOfDaysLabel
            // 
            this.numberOfDaysLabel.AutoSize = true;
            this.numberOfDaysLabel.Location = new System.Drawing.Point(36, 22);
            this.numberOfDaysLabel.Name = "numberOfDaysLabel";
            this.numberOfDaysLabel.Size = new System.Drawing.Size(136, 13);
            this.numberOfDaysLabel.TabIndex = 9;
            this.numberOfDaysLabel.Text = "Days stayed in the hospital:";
            // 
            // medicationChargesLabel
            // 
            this.medicationChargesLabel.AutoSize = true;
            this.medicationChargesLabel.Location = new System.Drawing.Point(68, 48);
            this.medicationChargesLabel.Name = "medicationChargesLabel";
            this.medicationChargesLabel.Size = new System.Drawing.Size(104, 13);
            this.medicationChargesLabel.TabIndex = 10;
            this.medicationChargesLabel.Text = "Medication Charges:";
            // 
            // surgicalChargesLabel
            // 
            this.surgicalChargesLabel.AutoSize = true;
            this.surgicalChargesLabel.Location = new System.Drawing.Point(82, 74);
            this.surgicalChargesLabel.Name = "surgicalChargesLabel";
            this.surgicalChargesLabel.Size = new System.Drawing.Size(90, 13);
            this.surgicalChargesLabel.TabIndex = 11;
            this.surgicalChargesLabel.Text = "Surgical Charges:";
            // 
            // labFeesLabel
            // 
            this.labFeesLabel.AutoSize = true;
            this.labFeesLabel.Location = new System.Drawing.Point(118, 100);
            this.labFeesLabel.Name = "labFeesLabel";
            this.labFeesLabel.Size = new System.Drawing.Size(54, 13);
            this.labFeesLabel.TabIndex = 12;
            this.labFeesLabel.Text = "Lab Fees:";
            // 
            // physicalRehabChargesLabel
            // 
            this.physicalRehabChargesLabel.AutoSize = true;
            this.physicalRehabChargesLabel.Location = new System.Drawing.Point(14, 126);
            this.physicalRehabChargesLabel.Name = "physicalRehabChargesLabel";
            this.physicalRehabChargesLabel.Size = new System.Drawing.Size(158, 13);
            this.physicalRehabChargesLabel.TabIndex = 13;
            this.physicalRehabChargesLabel.Text = "Physical Rehabilitation Charges:";
            // 
            // totalHospitalChargesLabel
            // 
            this.totalHospitalChargesLabel.AutoSize = true;
            this.totalHospitalChargesLabel.Location = new System.Drawing.Point(55, 160);
            this.totalHospitalChargesLabel.Name = "totalHospitalChargesLabel";
            this.totalHospitalChargesLabel.Size = new System.Drawing.Size(117, 13);
            this.totalHospitalChargesLabel.TabIndex = 14;
            this.totalHospitalChargesLabel.Text = "Total Hospital Charges:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 242);
            this.Controls.Add(this.totalHospitalChargesLabel);
            this.Controls.Add(this.physicalRehabChargesLabel);
            this.Controls.Add(this.labFeesLabel);
            this.Controls.Add(this.surgicalChargesLabel);
            this.Controls.Add(this.medicationChargesLabel);
            this.Controls.Add(this.numberOfDaysLabel);
            this.Controls.Add(this.totalChargesLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateBillButton);
            this.Controls.Add(this.physicalRehabChargesTextBox);
            this.Controls.Add(this.labFeesTextBox);
            this.Controls.Add(this.surgicalChargesTextBox);
            this.Controls.Add(this.medicationChargesTextBox);
            this.Controls.Add(this.daysStayedTextBox);
            this.Name = "Form1";
            this.Text = "Hospital Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox daysStayedTextBox;
        private System.Windows.Forms.TextBox medicationChargesTextBox;
        private System.Windows.Forms.TextBox surgicalChargesTextBox;
        private System.Windows.Forms.TextBox labFeesTextBox;
        private System.Windows.Forms.TextBox physicalRehabChargesTextBox;
        private System.Windows.Forms.Button calculateBillButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label totalChargesLabel;
        private System.Windows.Forms.Label numberOfDaysLabel;
        private System.Windows.Forms.Label medicationChargesLabel;
        private System.Windows.Forms.Label surgicalChargesLabel;
        private System.Windows.Forms.Label labFeesLabel;
        private System.Windows.Forms.Label physicalRehabChargesLabel;
        private System.Windows.Forms.Label totalHospitalChargesLabel;
    }
}

