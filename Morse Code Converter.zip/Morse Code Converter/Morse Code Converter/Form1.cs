﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Morse_Code_Converter
{
    public partial class Form1 : Form
    {
        List<string> MorseCode = new List<string>(new string[] { " ", "--..--", ".-.-.-", "..--..", "-----",
            ".-----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", ".-", "-...",
            "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.",
            "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..",});

        private string nonMorseCodeCharacters = " ,.?0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            morseCodeLabel.Text = ConvertSentence(sentenceTextBox.Text.ToUpper());
        }

        private string ConvertSentence(string sentence)
        {
            int position = 0;
            string newSentence = "";

            foreach (char letter in sentence)
            {
                position = nonMorseCodeCharacters.IndexOf(letter);
                newSentence += MorseCode[position];
                newSentence += " ";
            }

            return newSentence;
        }
    }
}
