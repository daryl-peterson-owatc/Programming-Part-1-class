﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stadium_Seating
{
    public partial class Form1 : Form
    {
        const decimal CLASS_A_PRICE_PER_SEAT = 15m;
        const decimal CLASS_B_PRICE_PER_SEAT = 12m;
        const decimal CLASS_C_PRICE_PER_SEAT = 9m;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculateRevenue_Click(object sender, EventArgs e)
        {
            decimal classANumberOfSeats = decimal.Parse(txtClassATickets.Text);
            decimal classBNumberOfSeats = decimal.Parse(txtClassBTickets.Text);
            decimal classCNumberOfSeats = decimal.Parse(txtClassCTickets.Text);

            decimal classARevenue = classANumberOfSeats * CLASS_A_PRICE_PER_SEAT;
            decimal classBRevenue = classBNumberOfSeats * CLASS_B_PRICE_PER_SEAT;
            decimal classCRevenue = classCNumberOfSeats * CLASS_C_PRICE_PER_SEAT;

            decimal totalRevenue = classARevenue + classBRevenue + classCRevenue;

            lblClassATotal.Text = classARevenue.ToString("c2");
            lblClassBTotal.Text = classBRevenue.ToString("c2");
            lblClassCTotal.Text = classCRevenue.ToString("c2");

            lblRevenueTotal.Text = totalRevenue.ToString("c2");

            if (totalRevenue < 0)
            {
                MessageBox.Show("It appears that your Total Revenue is in the Red.");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtClassATickets.Text = "";
            txtClassBTickets.Text = "";
            txtClassCTickets.Text = "";

            lblClassATotal.Text = "";
            lblClassBTotal.Text = "";
            lblClassCTotal.Text = "";
            lblRevenueTotal.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
