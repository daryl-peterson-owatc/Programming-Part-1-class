﻿namespace Stadium_Seating
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxTicketsSold = new System.Windows.Forms.GroupBox();
            this.gbxRevenueGenerated = new System.Windows.Forms.GroupBox();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblClassATicketsLabel = new System.Windows.Forms.Label();
            this.lblClassBTicketsLabel = new System.Windows.Forms.Label();
            this.lblClassCTicketsLabel = new System.Windows.Forms.Label();
            this.lblClassATotalLabel = new System.Windows.Forms.Label();
            this.lblClassBTotalLabel = new System.Windows.Forms.Label();
            this.lblClassCTotalLabel = new System.Windows.Forms.Label();
            this.lblTotalLabel = new System.Windows.Forms.Label();
            this.lblClassATotal = new System.Windows.Forms.Label();
            this.lblClassBTotal = new System.Windows.Forms.Label();
            this.lblClassCTotal = new System.Windows.Forms.Label();
            this.lblRevenueTotal = new System.Windows.Forms.Label();
            this.txtClassATickets = new System.Windows.Forms.TextBox();
            this.txtClassBTickets = new System.Windows.Forms.TextBox();
            this.txtClassCTickets = new System.Windows.Forms.TextBox();
            this.btnCalculateRevenue = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbxTicketsSold.SuspendLayout();
            this.gbxRevenueGenerated.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxTicketsSold
            // 
            this.gbxTicketsSold.Controls.Add(this.txtClassCTickets);
            this.gbxTicketsSold.Controls.Add(this.txtClassBTickets);
            this.gbxTicketsSold.Controls.Add(this.txtClassATickets);
            this.gbxTicketsSold.Controls.Add(this.lblClassATicketsLabel);
            this.gbxTicketsSold.Controls.Add(this.lblClassBTicketsLabel);
            this.gbxTicketsSold.Controls.Add(this.lblClassCTicketsLabel);
            this.gbxTicketsSold.Controls.Add(this.lblInstructions);
            this.gbxTicketsSold.Location = new System.Drawing.Point(12, 12);
            this.gbxTicketsSold.Name = "gbxTicketsSold";
            this.gbxTicketsSold.Size = new System.Drawing.Size(243, 173);
            this.gbxTicketsSold.TabIndex = 0;
            this.gbxTicketsSold.TabStop = false;
            this.gbxTicketsSold.Text = "Tickets Sold";
            // 
            // gbxRevenueGenerated
            // 
            this.gbxRevenueGenerated.Controls.Add(this.lblRevenueTotal);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassCTotal);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassBTotal);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassATotalLabel);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassBTotalLabel);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassCTotalLabel);
            this.gbxRevenueGenerated.Controls.Add(this.lblTotalLabel);
            this.gbxRevenueGenerated.Controls.Add(this.lblClassATotal);
            this.gbxRevenueGenerated.Location = new System.Drawing.Point(283, 12);
            this.gbxRevenueGenerated.Name = "gbxRevenueGenerated";
            this.gbxRevenueGenerated.Size = new System.Drawing.Size(203, 173);
            this.gbxRevenueGenerated.TabIndex = 0;
            this.gbxRevenueGenerated.TabStop = false;
            this.gbxRevenueGenerated.Text = "Revenue Generated";
            // 
            // lblInstructions
            // 
            this.lblInstructions.Location = new System.Drawing.Point(38, 33);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(141, 33);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "Enter the number of tickets sold for each class of seats";
            // 
            // lblClassATicketsLabel
            // 
            this.lblClassATicketsLabel.AutoSize = true;
            this.lblClassATicketsLabel.Location = new System.Drawing.Point(38, 77);
            this.lblClassATicketsLabel.Name = "lblClassATicketsLabel";
            this.lblClassATicketsLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassATicketsLabel.TabIndex = 1;
            this.lblClassATicketsLabel.Text = "Class A:";
            // 
            // lblClassBTicketsLabel
            // 
            this.lblClassBTicketsLabel.AutoSize = true;
            this.lblClassBTicketsLabel.Location = new System.Drawing.Point(38, 103);
            this.lblClassBTicketsLabel.Name = "lblClassBTicketsLabel";
            this.lblClassBTicketsLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassBTicketsLabel.TabIndex = 2;
            this.lblClassBTicketsLabel.Text = "Class B:";
            // 
            // lblClassCTicketsLabel
            // 
            this.lblClassCTicketsLabel.AutoSize = true;
            this.lblClassCTicketsLabel.Location = new System.Drawing.Point(38, 129);
            this.lblClassCTicketsLabel.Name = "lblClassCTicketsLabel";
            this.lblClassCTicketsLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassCTicketsLabel.TabIndex = 3;
            this.lblClassCTicketsLabel.Text = "Class C:";
            // 
            // lblClassATotalLabel
            // 
            this.lblClassATotalLabel.AutoSize = true;
            this.lblClassATotalLabel.Location = new System.Drawing.Point(29, 37);
            this.lblClassATotalLabel.Name = "lblClassATotalLabel";
            this.lblClassATotalLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassATotalLabel.TabIndex = 0;
            this.lblClassATotalLabel.Text = "Class A:";
            // 
            // lblClassBTotalLabel
            // 
            this.lblClassBTotalLabel.AutoSize = true;
            this.lblClassBTotalLabel.Location = new System.Drawing.Point(29, 68);
            this.lblClassBTotalLabel.Name = "lblClassBTotalLabel";
            this.lblClassBTotalLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassBTotalLabel.TabIndex = 1;
            this.lblClassBTotalLabel.Text = "Class B:";
            // 
            // lblClassCTotalLabel
            // 
            this.lblClassCTotalLabel.AutoSize = true;
            this.lblClassCTotalLabel.Location = new System.Drawing.Point(29, 101);
            this.lblClassCTotalLabel.Name = "lblClassCTotalLabel";
            this.lblClassCTotalLabel.Size = new System.Drawing.Size(45, 13);
            this.lblClassCTotalLabel.TabIndex = 2;
            this.lblClassCTotalLabel.Text = "Class C:";
            // 
            // lblTotalLabel
            // 
            this.lblTotalLabel.AutoSize = true;
            this.lblTotalLabel.Location = new System.Drawing.Point(40, 133);
            this.lblTotalLabel.Name = "lblTotalLabel";
            this.lblTotalLabel.Size = new System.Drawing.Size(34, 13);
            this.lblTotalLabel.TabIndex = 3;
            this.lblTotalLabel.Text = "Total:";
            // 
            // lblClassATotal
            // 
            this.lblClassATotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblClassATotal.Location = new System.Drawing.Point(80, 33);
            this.lblClassATotal.Name = "lblClassATotal";
            this.lblClassATotal.Size = new System.Drawing.Size(100, 20);
            this.lblClassATotal.TabIndex = 4;
            this.lblClassATotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblClassBTotal
            // 
            this.lblClassBTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblClassBTotal.Location = new System.Drawing.Point(80, 64);
            this.lblClassBTotal.Name = "lblClassBTotal";
            this.lblClassBTotal.Size = new System.Drawing.Size(100, 20);
            this.lblClassBTotal.TabIndex = 5;
            this.lblClassBTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblClassCTotal
            // 
            this.lblClassCTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblClassCTotal.Location = new System.Drawing.Point(80, 97);
            this.lblClassCTotal.Name = "lblClassCTotal";
            this.lblClassCTotal.Size = new System.Drawing.Size(100, 20);
            this.lblClassCTotal.TabIndex = 6;
            this.lblClassCTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRevenueTotal
            // 
            this.lblRevenueTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRevenueTotal.Location = new System.Drawing.Point(80, 129);
            this.lblRevenueTotal.Name = "lblRevenueTotal";
            this.lblRevenueTotal.Size = new System.Drawing.Size(100, 20);
            this.lblRevenueTotal.TabIndex = 7;
            this.lblRevenueTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtClassATickets
            // 
            this.txtClassATickets.Location = new System.Drawing.Point(89, 74);
            this.txtClassATickets.Name = "txtClassATickets";
            this.txtClassATickets.Size = new System.Drawing.Size(100, 20);
            this.txtClassATickets.TabIndex = 4;
            this.txtClassATickets.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtClassBTickets
            // 
            this.txtClassBTickets.Location = new System.Drawing.Point(89, 100);
            this.txtClassBTickets.Name = "txtClassBTickets";
            this.txtClassBTickets.Size = new System.Drawing.Size(100, 20);
            this.txtClassBTickets.TabIndex = 5;
            this.txtClassBTickets.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtClassCTickets
            // 
            this.txtClassCTickets.Location = new System.Drawing.Point(89, 126);
            this.txtClassCTickets.Name = "txtClassCTickets";
            this.txtClassCTickets.Size = new System.Drawing.Size(100, 20);
            this.txtClassCTickets.TabIndex = 6;
            this.txtClassCTickets.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCalculateRevenue
            // 
            this.btnCalculateRevenue.Location = new System.Drawing.Point(116, 204);
            this.btnCalculateRevenue.Name = "btnCalculateRevenue";
            this.btnCalculateRevenue.Size = new System.Drawing.Size(75, 38);
            this.btnCalculateRevenue.TabIndex = 16;
            this.btnCalculateRevenue.Text = "Calculate Revenue";
            this.btnCalculateRevenue.UseVisualStyleBackColor = true;
            this.btnCalculateRevenue.Click += new System.EventHandler(this.btnCalculateRevenue_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(212, 204);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 38);
            this.btnClear.TabIndex = 17;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(315, 204);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 38);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 265);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculateRevenue);
            this.Controls.Add(this.gbxRevenueGenerated);
            this.Controls.Add(this.gbxTicketsSold);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.gbxTicketsSold.ResumeLayout(false);
            this.gbxTicketsSold.PerformLayout();
            this.gbxRevenueGenerated.ResumeLayout(false);
            this.gbxRevenueGenerated.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxTicketsSold;
        private System.Windows.Forms.TextBox txtClassCTickets;
        private System.Windows.Forms.TextBox txtClassBTickets;
        private System.Windows.Forms.TextBox txtClassATickets;
        private System.Windows.Forms.Label lblClassATicketsLabel;
        private System.Windows.Forms.Label lblClassBTicketsLabel;
        private System.Windows.Forms.Label lblClassCTicketsLabel;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.GroupBox gbxRevenueGenerated;
        private System.Windows.Forms.Label lblRevenueTotal;
        private System.Windows.Forms.Label lblClassCTotal;
        private System.Windows.Forms.Label lblClassBTotal;
        private System.Windows.Forms.Label lblClassATotalLabel;
        private System.Windows.Forms.Label lblClassBTotalLabel;
        private System.Windows.Forms.Label lblClassCTotalLabel;
        private System.Windows.Forms.Label lblTotalLabel;
        private System.Windows.Forms.Label lblClassATotal;
        private System.Windows.Forms.Button btnCalculateRevenue;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

