﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        private List<decimal> salesTotals = new List<decimal>();

        public Form1()
        {
            InitializeComponent();
        }

        private void getSalesReportButton_Click(object sender, EventArgs e)
        {
            ReadSalesReport();
            TotalSales();
            AddToListBox();

        }

        private void ReadSalesReport()
        {
            try
            {
                decimal salesAmount;

                StreamReader inputFile;

                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(openFile.FileName);

                    while (!inputFile.EndOfStream)
                    {
                        salesAmount = decimal.Parse(inputFile.ReadLine());
                        salesTotals.Add(salesAmount);
                    }

                    inputFile.Close();
                }
                else
                {
                    MessageBox.Show("Please select a file.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TotalSales()
        {
            decimal totalAmount = 0.00m;

            foreach(decimal amount in salesTotals)
            {
                totalAmount += amount;
            }

            totalSalesLabel.Text = totalAmount.ToString("c");
        }

        private void AddToListBox()
        {
            foreach (decimal amount in salesTotals)
            {
                salesListBox.Items.Add(amount);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
