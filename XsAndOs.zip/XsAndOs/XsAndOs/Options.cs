﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XsAndOs
{
    public class Options
    {

        public string NumberOfGames { get; set; }
        public string GameStyle { get; set; }
        public string Theme { get; set; }
        public string Player1Name { get; set; }
        public string Player2Name { get; set; }
        public string CurrentGame { get; set; }

        public void setGameOptions()
        {
            Player1Name = "Player 1";
            Player2Name = "Player 2";
            NumberOfGames = "5";
            CurrentGame = "0";
            GameStyle = "BEST";
            Theme = "Default";
        }
    }
}
