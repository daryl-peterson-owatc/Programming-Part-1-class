﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XsAndOs
{
    class Options
    {
        public int NumberOfGames { get; set; }
        public string GameStyle { get; set; }
        public string Theme { get; set; }
        public string Player1Name { get; set; }
        public string Player2Name { get; set; }

    }
}
