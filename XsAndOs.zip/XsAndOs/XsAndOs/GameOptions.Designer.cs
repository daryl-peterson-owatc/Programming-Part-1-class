﻿namespace XsAndOs
{
    partial class GameOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameGroupBox = new System.Windows.Forms.GroupBox();
            this.playAllGamesRadioButton = new System.Windows.Forms.RadioButton();
            this.BestOfSeriesRadioButton = new System.Windows.Forms.RadioButton();
            this.numberOfGamesLabel = new System.Windows.Forms.Label();
            this.gamesToBePlayedComboBox = new System.Windows.Forms.ComboBox();
            this.themeGroupBox = new System.Windows.Forms.GroupBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.player1NameLabel = new System.Windows.Forms.Label();
            this.player2NameLabel = new System.Windows.Forms.Label();
            this.player1NameTextBox = new System.Windows.Forms.TextBox();
            this.player2NameTextBox = new System.Windows.Forms.TextBox();
            this.gameGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // gameGroupBox
            // 
            this.gameGroupBox.Controls.Add(this.playAllGamesRadioButton);
            this.gameGroupBox.Controls.Add(this.BestOfSeriesRadioButton);
            this.gameGroupBox.Controls.Add(this.numberOfGamesLabel);
            this.gameGroupBox.Controls.Add(this.gamesToBePlayedComboBox);
            this.gameGroupBox.Location = new System.Drawing.Point(12, 12);
            this.gameGroupBox.Name = "gameGroupBox";
            this.gameGroupBox.Size = new System.Drawing.Size(225, 106);
            this.gameGroupBox.TabIndex = 0;
            this.gameGroupBox.TabStop = false;
            this.gameGroupBox.Text = "Games and Style of Play";
            // 
            // playAllGamesRadioButton
            // 
            this.playAllGamesRadioButton.AutoSize = true;
            this.playAllGamesRadioButton.Location = new System.Drawing.Point(9, 75);
            this.playAllGamesRadioButton.Name = "playAllGamesRadioButton";
            this.playAllGamesRadioButton.Size = new System.Drawing.Size(92, 17);
            this.playAllGamesRadioButton.TabIndex = 3;
            this.playAllGamesRadioButton.Tag = "ALL";
            this.playAllGamesRadioButton.Text = "Play all games";
            this.playAllGamesRadioButton.UseVisualStyleBackColor = true;
            // 
            // BestOfSeriesRadioButton
            // 
            this.BestOfSeriesRadioButton.AutoSize = true;
            this.BestOfSeriesRadioButton.Checked = true;
            this.BestOfSeriesRadioButton.Location = new System.Drawing.Point(9, 51);
            this.BestOfSeriesRadioButton.Name = "BestOfSeriesRadioButton";
            this.BestOfSeriesRadioButton.Size = new System.Drawing.Size(88, 17);
            this.BestOfSeriesRadioButton.TabIndex = 2;
            this.BestOfSeriesRadioButton.TabStop = true;
            this.BestOfSeriesRadioButton.Tag = "";
            this.BestOfSeriesRadioButton.Text = "Best of series";
            this.BestOfSeriesRadioButton.UseVisualStyleBackColor = true;
            // 
            // numberOfGamesLabel
            // 
            this.numberOfGamesLabel.AutoSize = true;
            this.numberOfGamesLabel.Location = new System.Drawing.Point(6, 26);
            this.numberOfGamesLabel.Name = "numberOfGamesLabel";
            this.numberOfGamesLabel.Size = new System.Drawing.Size(154, 13);
            this.numberOfGamesLabel.TabIndex = 1;
            this.numberOfGamesLabel.Text = "Number of games to be played:";
            // 
            // gamesToBePlayedComboBox
            // 
            this.gamesToBePlayedComboBox.FormattingEnabled = true;
            this.gamesToBePlayedComboBox.Items.AddRange(new object[] {
            "3",
            "5",
            "7",
            "9",
            "11",
            "13",
            "15",
            "17",
            "19",
            "21"});
            this.gamesToBePlayedComboBox.Location = new System.Drawing.Point(166, 23);
            this.gamesToBePlayedComboBox.Name = "gamesToBePlayedComboBox";
            this.gamesToBePlayedComboBox.Size = new System.Drawing.Size(47, 21);
            this.gamesToBePlayedComboBox.TabIndex = 0;
            // 
            // themeGroupBox
            // 
            this.themeGroupBox.Location = new System.Drawing.Point(243, 12);
            this.themeGroupBox.Name = "themeGroupBox";
            this.themeGroupBox.Size = new System.Drawing.Size(225, 183);
            this.themeGroupBox.TabIndex = 1;
            this.themeGroupBox.TabStop = false;
            this.themeGroupBox.Text = "Choose a gameboard theme";
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(134, 214);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(225, 23);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "Save Options and Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // player1NameLabel
            // 
            this.player1NameLabel.AutoSize = true;
            this.player1NameLabel.Location = new System.Drawing.Point(40, 137);
            this.player1NameLabel.Name = "player1NameLabel";
            this.player1NameLabel.Size = new System.Drawing.Size(79, 13);
            this.player1NameLabel.TabIndex = 3;
            this.player1NameLabel.Text = "Player 1 Name:";
            // 
            // player2NameLabel
            // 
            this.player2NameLabel.AutoSize = true;
            this.player2NameLabel.Location = new System.Drawing.Point(40, 164);
            this.player2NameLabel.Name = "player2NameLabel";
            this.player2NameLabel.Size = new System.Drawing.Size(79, 13);
            this.player2NameLabel.TabIndex = 4;
            this.player2NameLabel.Text = "Player 2 Name:";
            // 
            // player1NameTextBox
            // 
            this.player1NameTextBox.Location = new System.Drawing.Point(125, 134);
            this.player1NameTextBox.MaxLength = 15;
            this.player1NameTextBox.Name = "player1NameTextBox";
            this.player1NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.player1NameTextBox.TabIndex = 5;
            // 
            // player2NameTextBox
            // 
            this.player2NameTextBox.Location = new System.Drawing.Point(125, 161);
            this.player2NameTextBox.MaxLength = 15;
            this.player2NameTextBox.Name = "player2NameTextBox";
            this.player2NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.player2NameTextBox.TabIndex = 6;
            // 
            // GameOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 249);
            this.Controls.Add(this.player2NameTextBox);
            this.Controls.Add(this.player1NameTextBox);
            this.Controls.Add(this.player2NameLabel);
            this.Controls.Add(this.player1NameLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.themeGroupBox);
            this.Controls.Add(this.gameGroupBox);
            this.Name = "GameOptions";
            this.Text = "Game Options";
            this.Load += new System.EventHandler(this.GameOptions_Load);
            this.gameGroupBox.ResumeLayout(false);
            this.gameGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gameGroupBox;
        private System.Windows.Forms.RadioButton playAllGamesRadioButton;
        private System.Windows.Forms.RadioButton BestOfSeriesRadioButton;
        private System.Windows.Forms.Label numberOfGamesLabel;
        private System.Windows.Forms.ComboBox gamesToBePlayedComboBox;
        private System.Windows.Forms.GroupBox themeGroupBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label player1NameLabel;
        private System.Windows.Forms.Label player2NameLabel;
        private System.Windows.Forms.TextBox player1NameTextBox;
        private System.Windows.Forms.TextBox player2NameTextBox;
    }
}