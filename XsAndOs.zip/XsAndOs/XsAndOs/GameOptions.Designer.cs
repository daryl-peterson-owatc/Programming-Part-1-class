﻿namespace XsAndOs
{
    partial class GameOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberOfGamesLabel = new System.Windows.Forms.Label();
            this.gamesToBePlayedComboBox = new System.Windows.Forms.ComboBox();
            this.themeGroupBox = new System.Windows.Forms.GroupBox();
            this.superheroRadioButton = new System.Windows.Forms.RadioButton();
            this.pastelRadioButon = new System.Windows.Forms.RadioButton();
            this.plainRadioButton = new System.Windows.Forms.RadioButton();
            this.closeButton = new System.Windows.Forms.Button();
            this.player1NameLabel = new System.Windows.Forms.Label();
            this.player2NameLabel = new System.Windows.Forms.Label();
            this.player1NameTextBox = new System.Windows.Forms.TextBox();
            this.player2NameTextBox = new System.Windows.Forms.TextBox();
            this.computer1CheckBox = new System.Windows.Forms.CheckBox();
            this.computer2CheckBox = new System.Windows.Forms.CheckBox();
            this.themeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // numberOfGamesLabel
            // 
            this.numberOfGamesLabel.AutoSize = true;
            this.numberOfGamesLabel.Location = new System.Drawing.Point(18, 40);
            this.numberOfGamesLabel.Name = "numberOfGamesLabel";
            this.numberOfGamesLabel.Size = new System.Drawing.Size(154, 13);
            this.numberOfGamesLabel.TabIndex = 1;
            this.numberOfGamesLabel.Text = "Number of games to be played:";
            // 
            // gamesToBePlayedComboBox
            // 
            this.gamesToBePlayedComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gamesToBePlayedComboBox.FormattingEnabled = true;
            this.gamesToBePlayedComboBox.Location = new System.Drawing.Point(178, 37);
            this.gamesToBePlayedComboBox.Name = "gamesToBePlayedComboBox";
            this.gamesToBePlayedComboBox.Size = new System.Drawing.Size(47, 21);
            this.gamesToBePlayedComboBox.TabIndex = 0;
            // 
            // themeGroupBox
            // 
            this.themeGroupBox.Controls.Add(this.superheroRadioButton);
            this.themeGroupBox.Controls.Add(this.pastelRadioButon);
            this.themeGroupBox.Controls.Add(this.plainRadioButton);
            this.themeGroupBox.Location = new System.Drawing.Point(365, 12);
            this.themeGroupBox.Name = "themeGroupBox";
            this.themeGroupBox.Size = new System.Drawing.Size(123, 111);
            this.themeGroupBox.TabIndex = 1;
            this.themeGroupBox.TabStop = false;
            this.themeGroupBox.Text = "Gameboard themes";
            // 
            // superheroRadioButton
            // 
            this.superheroRadioButton.AutoSize = true;
            this.superheroRadioButton.Location = new System.Drawing.Point(16, 79);
            this.superheroRadioButton.Name = "superheroRadioButton";
            this.superheroRadioButton.Size = new System.Drawing.Size(74, 17);
            this.superheroRadioButton.TabIndex = 2;
            this.superheroRadioButton.TabStop = true;
            this.superheroRadioButton.Text = "Superhero";
            this.superheroRadioButton.UseVisualStyleBackColor = true;
            this.superheroRadioButton.CheckedChanged += new System.EventHandler(this.superheroRadioButton_CheckedChanged);
            // 
            // pastelRadioButon
            // 
            this.pastelRadioButon.AutoSize = true;
            this.pastelRadioButon.Location = new System.Drawing.Point(16, 53);
            this.pastelRadioButon.Name = "pastelRadioButon";
            this.pastelRadioButon.Size = new System.Drawing.Size(54, 17);
            this.pastelRadioButon.TabIndex = 1;
            this.pastelRadioButon.TabStop = true;
            this.pastelRadioButon.Text = "Pastel";
            this.pastelRadioButon.UseVisualStyleBackColor = true;
            this.pastelRadioButon.CheckedChanged += new System.EventHandler(this.pastelRadioButon_CheckedChanged);
            // 
            // plainRadioButton
            // 
            this.plainRadioButton.AutoSize = true;
            this.plainRadioButton.Location = new System.Drawing.Point(16, 26);
            this.plainRadioButton.Name = "plainRadioButton";
            this.plainRadioButton.Size = new System.Drawing.Size(59, 17);
            this.plainRadioButton.TabIndex = 0;
            this.plainRadioButton.TabStop = true;
            this.plainRadioButton.Text = "Default";
            this.plainRadioButton.UseVisualStyleBackColor = true;
            this.plainRadioButton.CheckedChanged += new System.EventHandler(this.plainRadioButton_CheckedChanged);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(178, 142);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(225, 23);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "Save Options and Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // player1NameLabel
            // 
            this.player1NameLabel.AutoSize = true;
            this.player1NameLabel.Location = new System.Drawing.Point(40, 67);
            this.player1NameLabel.Name = "player1NameLabel";
            this.player1NameLabel.Size = new System.Drawing.Size(79, 13);
            this.player1NameLabel.TabIndex = 3;
            this.player1NameLabel.Text = "Player 1 Name:";
            // 
            // player2NameLabel
            // 
            this.player2NameLabel.AutoSize = true;
            this.player2NameLabel.Location = new System.Drawing.Point(40, 93);
            this.player2NameLabel.Name = "player2NameLabel";
            this.player2NameLabel.Size = new System.Drawing.Size(79, 13);
            this.player2NameLabel.TabIndex = 4;
            this.player2NameLabel.Text = "Player 2 Name:";
            // 
            // player1NameTextBox
            // 
            this.player1NameTextBox.Location = new System.Drawing.Point(125, 64);
            this.player1NameTextBox.MaxLength = 15;
            this.player1NameTextBox.Name = "player1NameTextBox";
            this.player1NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.player1NameTextBox.TabIndex = 5;
            // 
            // player2NameTextBox
            // 
            this.player2NameTextBox.Location = new System.Drawing.Point(125, 90);
            this.player2NameTextBox.MaxLength = 15;
            this.player2NameTextBox.Name = "player2NameTextBox";
            this.player2NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.player2NameTextBox.TabIndex = 6;
            // 
            // computer1CheckBox
            // 
            this.computer1CheckBox.AutoSize = true;
            this.computer1CheckBox.Location = new System.Drawing.Point(245, 66);
            this.computer1CheckBox.Name = "computer1CheckBox";
            this.computer1CheckBox.Size = new System.Drawing.Size(102, 17);
            this.computer1CheckBox.TabIndex = 7;
            this.computer1CheckBox.Text = "Computer player";
            this.computer1CheckBox.UseVisualStyleBackColor = true;
            // 
            // computer2CheckBox
            // 
            this.computer2CheckBox.AutoSize = true;
            this.computer2CheckBox.Location = new System.Drawing.Point(245, 92);
            this.computer2CheckBox.Name = "computer2CheckBox";
            this.computer2CheckBox.Size = new System.Drawing.Size(102, 17);
            this.computer2CheckBox.TabIndex = 8;
            this.computer2CheckBox.Text = "Computer player";
            this.computer2CheckBox.UseVisualStyleBackColor = true;
            // 
            // GameOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 177);
            this.Controls.Add(this.computer2CheckBox);
            this.Controls.Add(this.computer1CheckBox);
            this.Controls.Add(this.numberOfGamesLabel);
            this.Controls.Add(this.gamesToBePlayedComboBox);
            this.Controls.Add(this.player2NameTextBox);
            this.Controls.Add(this.player1NameTextBox);
            this.Controls.Add(this.player2NameLabel);
            this.Controls.Add(this.player1NameLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.themeGroupBox);
            this.Name = "GameOptions";
            this.Text = "Game Options";
            this.Load += new System.EventHandler(this.GameOptions_Load);
            this.themeGroupBox.ResumeLayout(false);
            this.themeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label numberOfGamesLabel;
        private System.Windows.Forms.ComboBox gamesToBePlayedComboBox;
        private System.Windows.Forms.GroupBox themeGroupBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label player1NameLabel;
        private System.Windows.Forms.Label player2NameLabel;
        private System.Windows.Forms.TextBox player1NameTextBox;
        private System.Windows.Forms.TextBox player2NameTextBox;
        private System.Windows.Forms.RadioButton superheroRadioButton;
        private System.Windows.Forms.RadioButton pastelRadioButon;
        private System.Windows.Forms.RadioButton plainRadioButton;
        private System.Windows.Forms.CheckBox computer1CheckBox;
        private System.Windows.Forms.CheckBox computer2CheckBox;
    }
}