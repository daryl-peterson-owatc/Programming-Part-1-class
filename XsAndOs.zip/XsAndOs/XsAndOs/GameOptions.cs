﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class GameOptions : Form
    {
        Options options;
        public List<string> numberOfGameOptions = new List<string> { "3", "5", "7", "9", "11", "13", "15", "17", "19", "21" };

        public GameOptions(Options incomingOptions)
        {
            InitializeComponent();
            options = incomingOptions;
        }

        private void GameOptions_Load(object sender, EventArgs e)
        {
            buildNumberOfGamesComboBox();
            gamesToBePlayedComboBox.SelectedItem = options.NumberOfGames;
            player1NameTextBox.Text = options.Player1Name;
            player2NameTextBox.Text = options.Player2Name;
        }

        private void buildNumberOfGamesComboBox()
        {
            foreach(string item in numberOfGameOptions)
            {
                gamesToBePlayedComboBox.Items.Add(item);
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            options.Player1Name = player1NameTextBox.Text;
            options.Player2Name = player2NameTextBox.Text;
            options.Player1Computer = computer1CheckBox.Checked;
            options.Player2Computer = computer2CheckBox.Checked;
            options.NumberOfGames = gamesToBePlayedComboBox.GetItemText(gamesToBePlayedComboBox.SelectedItem);
            this.Close();
        }

        private void plainRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            options.Theme = plainRadioButton.Text;
        }

        private void pastelRadioButon_CheckedChanged(object sender, EventArgs e)
        {
            options.Theme = pastelRadioButon.Text;
        }

        private void superheroRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            options.Theme = superheroRadioButton.Text;
        }
    }
}
