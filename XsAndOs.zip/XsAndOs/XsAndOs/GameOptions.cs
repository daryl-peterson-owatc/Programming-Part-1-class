﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class GameOptions : Form
    {
        public int

        public GameOptions()
        {
            InitializeComponent();
        }

        private void GameOptions_Load(object sender, EventArgs e)
        {
            gamesToBePlayedComboBox.SelectedText = "5";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
