﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class GameOptions : Form
    {
        Options options;

        public GameOptions(Options incomingOptions)
        {
            InitializeComponent();
            options = incomingOptions;
        }

        private void GameOptions_Load(object sender, EventArgs e)
        {
            gamesToBePlayedComboBox.SelectedText = options.NumberOfGames.ToString();
            player1NameTextBox.Text = options.Player1Name;
            player2NameTextBox.Text = options.Player2Name;
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            options.Player1Name = player1NameTextBox.Text;
            options.Player2Name = player2NameTextBox.Text;
            if (BestOfSeriesRadioButton.Checked)
            {
                options.GameStyle = "BEST";
            }
            else
            {
                options.GameStyle = "ALL";
            }
            
            options.NumberOfGames = Convert.ToInt16(gamesToBePlayedComboBox.GetItemText(gamesToBePlayedComboBox.SelectedItem));

            this.Close();
        }
    }
}
