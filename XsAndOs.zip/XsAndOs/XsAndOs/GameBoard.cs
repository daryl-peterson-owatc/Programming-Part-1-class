﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class GameBoard : Form
    {
        Options options = new Options();

        public const string PLAYER_1 = "X";  // used to change the current marker for player 1, whose turn it is to play
        public const string PLAYER_2 = "O";  // used to change the current marker for player 2, whose turn it is to play
        public string currentPlayer = "Player1";  // documents which player is the one who is playing
        public string currentMarker = "X"; // marker that is used to mark the playing board
        public int squares_played = 0;  // counter used to determine if all the blank tiles have been played
        public bool Won = false;  // indicates whether the game has been won or not.

        public GameBoard()
        {
            InitializeComponent();
        }

        private void GameBoard_Load(object sender, EventArgs e)
        {
            options.setGameOptions();
            GameSetup();
            endGameButton.Visible = false; // this button only become visible when a game is being played
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(oneButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                oneButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(twoButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                twoButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(threeButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                threeButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(fourButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                fourButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(fiveButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                fiveButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(sixButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                sixButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(sevenButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                sevenButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(eightButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                eightButton.Text = currentMarker;
                testGameStatus(); // test to see of there is a winner or if all the squares have been played
            }
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(nineButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                nineButton.Text = currentMarker;
                testGameStatus();
            }
        }

        private void testGameStatus()
        {
            squares_played += 1; // add one to the number of tile buttons that have been played
            if (IsWinner())
            {
                makeWinnerVisible();  // make the winner label visible
                addToWinnersScore();  // add to the winners total wins count
                endGame();  // end the game
            }
            else
            {
                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void switchPlayer()
        {
            // method for making all the switches changed to the next player
            if (currentPlayer == "Player1")
            {
                playerOneLabel.BackColor =  Color.Red;
                playerTwoLabel.BackColor = Color.Lime;
                currentPlayer = "Player2";
                currentMarker = PLAYER_2;
                if (options.Player2Computer) // check to see if the player is a computer player
                {
                    playComputerPlayer();
                }
            }
            else
            {
                playerOneLabel.BackColor = Color.Lime;
                playerTwoLabel.BackColor = Color.Red;
                currentPlayer = "Player1";
                currentMarker = PLAYER_1;
                if (options.Player1Computer) // check to see if the player is a computer player
                {
                    playComputerPlayer();
                }
            }
        }

        private void playComputerPlayer()
        {
            Random rnd = new Random((int)DateTime.Now.Ticks);
            int button;
            do // loop to find an open button
            {
                button = rnd.Next(1, 10);
            } while (!testForUnclickedButton(button));
            Task.Delay(2000).Wait();  // added a time delay so i looks like the computer is thinking
            computerClickButton(button);
        }

        private bool testForUnclickedButton(int button)
        {
            // method that checks to see if the button has already been marked
            bool available = false;
            switch (button)
            {
                case 1:
                    if (oneButton.Text == "") { available = true; }
                    break;
                case 2:
                    if (twoButton.Text == "") { available = true; }
                    break;
                case 3:
                    if (threeButton.Text == "") { available = true; }
                    break;
                case 4:
                    if (fourButton.Text == "") { available = true; }
                    break;
                case 5:
                    if (fiveButton.Text == "") { available = true; }
                    break;
                case 6:
                    if (sixButton.Text == "") { available = true; }
                    break;
                case 7:
                    if (sevenButton.Text == "") { available = true; }
                    break;
                case 8:
                    if (eightButton.Text == "") { available = true; }
                    break;
                case 9:
                    if (nineButton.Text == "") { available = true; }
                    break;
            }
            return available;
        }

        private void computerClickButton(int button)
        {
            // method to mark the button for the computer.
            switch (button)
            {
                case 1:
                    oneButton.Text = currentMarker;
                    break;
                case 2:
                    twoButton.Text = currentMarker;
                    break;
                case 3:
                    threeButton.Text = currentMarker;
                    break;
                case 4:
                    fourButton.Text = currentMarker;
                    break;
                case 5:
                    fiveButton.Text = currentMarker;
                    break;
                case 6:
                    sixButton.Text = currentMarker;
                    break;
                case 7:
                    sevenButton.Text = currentMarker;
                    break;
                case 8:
                    eightButton.Text = currentMarker;
                    break;
                case 9:
                    nineButton.Text = currentMarker;
                    break;
            }
            testGameStatus();
        }

        private bool IsEmpty(Control button)
        {
            // test to see if the tile button has already been played before making the play
            bool available = false;
            if (button.Text == "")
            {
                available = true;
            }

            return available;
        }

        private bool IsWinner()
        {
            bool winner = false;

            // test all the horizontal possibilities
            if (oneButton.Text == currentMarker && twoButton.Text == currentMarker && threeButton.Text == currentMarker) winner = true;
            if (fourButton.Text == currentMarker && fiveButton.Text == currentMarker && sixButton.Text == currentMarker) winner = true;
            if (sevenButton.Text == currentMarker && eightButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            // test all the vertical possibilities
            if (oneButton.Text == currentMarker && fourButton.Text == currentMarker && sevenButton.Text == currentMarker) winner = true;
            if (twoButton.Text == currentMarker && fiveButton.Text == currentMarker && eightButton.Text == currentMarker) winner = true;
            if (threeButton.Text == currentMarker && sixButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            // test all the diagonal possibilities
            if (oneButton.Text == currentMarker && fiveButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            if (sevenButton.Text == currentMarker && fiveButton.Text == currentMarker && threeButton.Text == currentMarker) winner = true;

            return winner;
        }

        private void makeWinnerVisible()
        {
            winnerLabel.Visible = true;  // shows the winner label
        }

        private void GameSetup()
        {
            // clears all the text in all the tile buttons
            oneButton.Text = "";
            twoButton.Text = "";
            threeButton.Text = "";
            fourButton.Text = "";
            fiveButton.Text = "";
            sixButton.Text = "";
            sevenButton.Text = "";
            eightButton.Text = "";
            nineButton.Text = "";

            playerOneLabel.Text = options.Player1Name;
            playerTwoLabel.Text = options.Player2Name;

            gameStyleLabel.Text = "Games to Play";
            numberOfGamesLabel.Text = options.NumberOfGames;

            currentGameLabel.Text = options.CurrentGame.ToString();

            winnerLabel.Visible = false;  // turns off the winner label
            completedLabel.Visible = false;
            endGame();
            updateColors();
        }

        private void endGame()
        {
            // disables all the tile buttons so that they cannot be clicked
            oneButton.Enabled = false;
            twoButton.Enabled = false;
            threeButton.Enabled = false;
            fourButton.Enabled = false;
            fiveButton.Enabled = false;
            sixButton.Enabled = false;
            sevenButton.Enabled = false;
            eightButton.Enabled = false;
            nineButton.Enabled = false;
            
            // change the buttons around
            startGameButton.Visible = true;
            endGameButton.Visible = false;

            int currentGame = int.Parse(currentGameLabel.Text);
            int totalGames = int.Parse(numberOfGamesLabel.Text);

            if (currentGame >= totalGames)
            {
                completedLabel.Visible = true;
                options.CurrentGame = "0";
                options.Player1TotalWins = "0";
                options.Player2TotalWins = "0";
                options.TieTotalWins = "0";
            }
        }

        private void startGameButton_Click(object sender, EventArgs e)
        {
            GameSetup();  // clears the tile buttons text

            // enables all the tile buttons so that play can begin
            oneButton.Enabled = true;
            twoButton.Enabled = true;
            threeButton.Enabled = true;
            fourButton.Enabled = true;
            fiveButton.Enabled = true;
            sixButton.Enabled = true;
            sevenButton.Enabled = true;
            eightButton.Enabled = true;
            nineButton.Enabled = true;
            startGameButton.Visible = false;
            endGameButton.Visible = true;

            squares_played = 0;  // restarts the counter for the number of tiles that have been played
            currentPlayer = "Player2";  // sets the current player to 2 so that when the switchPlayer method is called it can then be set to player 1

            options.CurrentGame = (int.Parse(options.CurrentGame) + 1).ToString();
            currentGameLabel.Text = options.CurrentGame;
            player1WinsTotalLabel.Text = options.Player1TotalWins;
            player2WinsTotalLabel.Text = options.Player2TotalWins;
            tieGamesTotalLabel.Text = options.TieTotalWins;
            switchPlayer();
        }

        private void endGameButton_Click(object sender, EventArgs e)
        {
            endGame();
        }

        private bool hasAllSquaresBeenPlayed()
        {
            return squares_played >= 9 ? true : false; // returns true or false if all the tile buttons have or have not been played
        }

        private void addToWinnersScore()
        {
            // method for adding 1 to the appropriate players win totals
            if (currentPlayer == "Player1")
            {
                options.Player1TotalWins = (int.Parse(options.Player1TotalWins) + 1).ToString();
                player1WinsTotalLabel.Text = options.Player1TotalWins;
                changeWonStatus();
            }
            else
            {
                options.Player2TotalWins = (int.Parse(options.Player2TotalWins) + 1).ToString();
                player2WinsTotalLabel.Text = options.Player2TotalWins;
                changeWonStatus();
            }
        }

        private void addToTieScore()
        {
            // adds 1 to the tie score total if all the tile buttons have been played and no one is the winner.
            options.TieTotalWins = (int.Parse(options.TieTotalWins) + 1).ToString();
            tieGamesTotalLabel.Text = options.TieTotalWins;
        }

        private void changeWonStatus()
        {
            Won = true;  // flag to test if the game was won before adding a counter to the tied score
        }

        private void optionsButton_Click(object sender, EventArgs e)
        {
            GameOptions go = new GameOptions(options);
            go.ShowDialog();
            GameSetup();
        }

        private void updateColors()
        {
            //options.setThemeColors();
            switch (options.Theme)
            {
                case "Default":
                    updateDefaultColors();
                    break;
                case "Pastel":
                    updatePastelColors();
                    break;
                case "Superhero":
                    updateSuperheroColors();
                    break;
            }
        }

        private void updateDefaultColors()
        {
            this.BackColor = Color.Ivory;
            this.ForeColor = Color.Black;

            // button back color settings
            this.oneButton.BackColor = Color.Silver;
            this.twoButton.BackColor = Color.Silver;
            this.threeButton.BackColor = Color.Silver;
            this.fourButton.BackColor = Color.Silver;
            this.fiveButton.BackColor = Color.Silver;
            this.sixButton.BackColor = Color.Silver;
            this.sevenButton.BackColor = Color.Silver;
            this.eightButton.BackColor = Color.Silver;
            this.nineButton.BackColor = Color.Silver;

            // button fore color settings
            this.oneButton.ForeColor = Color.Black;
            this.twoButton.ForeColor = Color.Black;
            this.threeButton.ForeColor = Color.Black;
            this.fourButton.ForeColor = Color.Black;
            this.fiveButton.ForeColor = Color.Black;
            this.sixButton.ForeColor = Color.Black;
            this.sevenButton.ForeColor = Color.Black;
            this.eightButton.ForeColor = Color.Black;
            this.nineButton.ForeColor = Color.Black;

            // panel color setting
            this.ticTacToePanel.BackColor = Color.Black;

            // non game buttons
            this.startGameButton.ForeColor = Color.Black;
            this.endGameButton.ForeColor = Color.Black;
            this.exitButton.ForeColor = Color.Black;
            this.optionsButton.ForeColor = Color.Black;
        }

        private void updatePastelColors()
        {
            // form color settings
            this.BackColor = Color.LightCyan;
            this.ForeColor = Color.Blue;

            // button back color settings
            this.oneButton.BackColor = Color.LightYellow;
            this.twoButton.BackColor = Color.LightYellow;
            this.threeButton.BackColor = Color.LightYellow;
            this.fourButton.BackColor = Color.LightYellow;
            this.fiveButton.BackColor = Color.LightYellow;
            this.sixButton.BackColor = Color.LightYellow;
            this.sevenButton.BackColor = Color.LightYellow;
            this.eightButton.BackColor = Color.LightYellow;
            this.nineButton.BackColor = Color.LightYellow;

            // button fore color settings
            this.oneButton.ForeColor = Color.Blue;
            this.twoButton.ForeColor = Color.Blue;
            this.threeButton.ForeColor = Color.Blue;
            this.fourButton.ForeColor = Color.Blue;
            this.fiveButton.ForeColor = Color.Blue;
            this.sixButton.ForeColor = Color.Blue;
            this.sevenButton.ForeColor = Color.Blue;
            this.eightButton.ForeColor = Color.Blue;
            this.nineButton.ForeColor = Color.Blue;

            // panel color setting
            this.ticTacToePanel.BackColor = Color.LightPink;

            // non game buttons
            this.startGameButton.ForeColor = Color.Black;
            this.endGameButton.ForeColor = Color.Black;
            this.exitButton.ForeColor = Color.Black;
            this.optionsButton.ForeColor = Color.Black;
        }

        private void updateSuperheroColors()
        {
            // form color settings
            this.BackColor = Color.Blue;
            this.ForeColor = Color.White;

            // button back color settings
            this.oneButton.BackColor = Color.Red;
            this.twoButton.BackColor = Color.Red;
            this.threeButton.BackColor = Color.Red;
            this.fourButton.BackColor = Color.Red;
            this.fiveButton.BackColor = Color.Red;
            this.sixButton.BackColor = Color.Red;
            this.sevenButton.BackColor = Color.Red;
            this.eightButton.BackColor = Color.Red;
            this.nineButton.BackColor = Color.Red;

            // button fore color settings
            this.oneButton.ForeColor = Color.White;
            this.twoButton.ForeColor = Color.White;
            this.threeButton.ForeColor = Color.White;
            this.fourButton.ForeColor = Color.White;
            this.fiveButton.ForeColor = Color.White;
            this.sixButton.ForeColor = Color.White;
            this.sevenButton.ForeColor = Color.White;
            this.eightButton.ForeColor = Color.White;
            this.nineButton.ForeColor = Color.White;

            // panel color setting
            this.ticTacToePanel.BackColor = Color.Yellow;

            // non game buttons
            this.startGameButton.ForeColor = Color.Black;
            this.endGameButton.ForeColor = Color.Black;
            this.exitButton.ForeColor = Color.Black;
            this.optionsButton.ForeColor = Color.Black;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();  // close the game application
        }
    }
}
