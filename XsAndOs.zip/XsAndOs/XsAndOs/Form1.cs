﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class Form1 : Form
    {
        public const string PLAYER_1 = "X";  // used to change the current marker for player 1, whose turn it is to play
        public const string PLAYER_2 = "O";  // used to change the current marker for player 2, whose turn it is to play
        public string currentPlayer = "Player1";  // documents which player is the one who is playing
        public string currentMarker = "X"; // marker that is used to mark the playing board
        public int squares_played = 0;  // counter used to determine if all the blank tiles have been played
        public bool Won = false;  // indicates whether the game has been won or not.

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GameSetup();
            endGameButton.Visible = false;
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(oneButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                oneButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(twoButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                twoButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(threeButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                threeButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(fourButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                fourButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(fiveButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                fiveButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(sixButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                sixButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(sevenButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                sevenButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(eightButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                eightButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            // check to see if the tile button has been played yet
            if (IsEmpty(nineButton))
            {
                // since the tile button has not been played, mark it with the current players marker
                nineButton.Text = currentMarker;
                squares_played += 1; // add one to the number of tile buttons that have been played
                if (IsWinner())
                {
                    makeWinnerVisible();  // make the winner label visible
                    addToWinnersScore();  // add to the winners total wins count
                    changeWonStatus();  // indicate that someone won the game
                    endGame();  // end the game
                }

                // tests to see if all the tiles have been played
                if (hasAllSquaresBeenPlayed())
                {
                    if (!Won)
                    {
                        addToTieScore();  // if all the tiles have been played but no one won, add to the tied score
                    }
                    endGame();
                }
                else
                {
                    switchPlayer();  // not all tiles have been played so switch to the other player
                }
            }
        }

        private void switchPlayer()
        {
            // method for making all the switches changed to the next player
            if (currentPlayer == "Player1")
            {
                playerOneLabel.BackColor =  Color.Red;
                playerTwoLabel.BackColor = Color.Lime;
                currentPlayer = "Player2";
                currentMarker = PLAYER_2;
            }
            else
            {
                playerOneLabel.BackColor = Color.Lime;
                playerTwoLabel.BackColor = Color.Red;
                currentPlayer = "Player1";
                currentMarker = PLAYER_1;
            }
        }

        private bool IsEmpty(Control button)
        {
            // test to see if the tile button has already been played before making the play
            bool available = false;
            if (button.Text == "")
            {
                available = true;
            }

            return available;
        }

        private bool IsWinner()
        {
            bool winner = false;

            // test all the horizontal possibilities
            if (oneButton.Text == currentMarker && twoButton.Text == currentMarker && threeButton.Text == currentMarker) winner = true;
            if (fourButton.Text == currentMarker && fiveButton.Text == currentMarker && sixButton.Text == currentMarker) winner = true;
            if (sevenButton.Text == currentMarker && eightButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            // test all the vertical possibilities
            if (oneButton.Text == currentMarker && fourButton.Text == currentMarker && sevenButton.Text == currentMarker) winner = true;
            if (twoButton.Text == currentMarker && fiveButton.Text == currentMarker && eightButton.Text == currentMarker) winner = true;
            if (threeButton.Text == currentMarker && sixButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            // test all the diagonal possibilities
            if (oneButton.Text == currentMarker && fiveButton.Text == currentMarker && nineButton.Text == currentMarker) winner = true;
            if (sevenButton.Text == currentMarker && fiveButton.Text == currentMarker && threeButton.Text == currentMarker) winner = true;

            return winner;
        }

        private void makeWinnerVisible()
        {
            winnerLabel.Visible = true;  // shows the winner label
        }

        private void GameSetup()
        {
            // clears all the text in all the tile buttons
            oneButton.Text = "";
            twoButton.Text = "";
            threeButton.Text = "";
            fourButton.Text = "";
            fiveButton.Text = "";
            sixButton.Text = "";
            sevenButton.Text = "";
            eightButton.Text = "";
            nineButton.Text = "";

            winnerLabel.Visible = false;  // turns off the winner label
            endGame();
        }

        private void endGame()
        {
            // disables all the tile buttons so that they cannot be clicked
            oneButton.Enabled = false;
            twoButton.Enabled = false;
            threeButton.Enabled = false;
            fourButton.Enabled = false;
            fiveButton.Enabled = false;
            sixButton.Enabled = false;
            sevenButton.Enabled = false;
            eightButton.Enabled = false;
            nineButton.Enabled = false;
            
            // change the buttons around
            startGameButton.Visible = true;
            endGameButton.Visible = false;
        }

        private void startGameButton_Click(object sender, EventArgs e)
        {
            GameSetup();  // clears the tile buttons text

            // enables all the tile buttons so that play can begin
            oneButton.Enabled = true;
            twoButton.Enabled = true;
            threeButton.Enabled = true;
            fourButton.Enabled = true;
            fiveButton.Enabled = true;
            sixButton.Enabled = true;
            sevenButton.Enabled = true;
            eightButton.Enabled = true;
            nineButton.Enabled = true;
            startGameButton.Visible = false;
            endGameButton.Visible = true;

            squares_played = 0;  // restarts the counter for the number of tiles that have been played
            currentPlayer = "Player2";  // sets the current player to 2 so that when the switchPlayer method is called it can then be set to player 1
            switchPlayer();
        }

        private void endGameButton_Click(object sender, EventArgs e)
        {
            endGame();
        }

        private bool hasAllSquaresBeenPlayed()
        {
            return squares_played >= 9 ? true : false; // returns true or false if all the tile buttons have or have not been played
        }

        private void addToWinnersScore()
        {
            // method for adding 1 to the appropriate players win totals
            if (currentPlayer == "Player1")
            {
                int score = Convert.ToInt16(player1WinsTotalLabel.Text);
                player1WinsTotalLabel.Text = (score + 1).ToString();
            }
            else
            {
                int score = Convert.ToInt16(player2WinsTotalLabel.Text);
                player2WinsTotalLabel.Text = (score + 1).ToString();
            }
        }

        private void addToTieScore()
        {
            // adds 1 to the tie score total if all the tile buttons have been played and no one is the winner.
            int score = Convert.ToInt16(tieGamesTotalLabel.Text);
            tieGamesTotalLabel.Text = (score + 1).ToString();
        }

        private void changeWonStatus()
        {
            Won = true;  // flag to test if the game was won before adding a counter to the tied score
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
