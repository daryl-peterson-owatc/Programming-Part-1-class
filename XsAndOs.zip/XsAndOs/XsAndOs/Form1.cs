﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XsAndOs
{
    public partial class Form1 : Form
    {
        public const string PLAYER_1 = "X";
        public const string PLAYER_2 = "O";
        public string currentPlayer = "Player1";
        public string currentMarker = "X";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            oneButton.Text = "";
            twoButton.Text = "";
            threeButton.Text = "";
            fourButton.Text = "";
            fiveButton.Text = "";
            sixButton.Text = "";
            sevenButton.Text = "";
            eightButton.Text = "";
            nineButton.Text = "";
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            oneButton.Text = currentMarker;
            switchPlayer();
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            twoButton.Text = currentMarker;
            switchPlayer();
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            threeButton.Text = currentMarker;
            switchPlayer();
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            fourButton.Text = currentMarker;
            switchPlayer();
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            fiveButton.Text = currentMarker;
            switchPlayer();
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            sixButton.Text = currentMarker;
            switchPlayer();
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            sevenButton.Text = currentMarker;
            switchPlayer();
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            eightButton.Text = currentMarker;
            switchPlayer();
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            nineButton.Text = currentMarker;
            switchPlayer();
        }

        private void switchPlayer()
        {
            if (currentPlayer == "Player1")
            {
                playerOneLabel.BackColor =  Color.Red;
                playerTwoLabel.BackColor = Color.Lime;
                currentPlayer = "Player2";
                currentMarker = PLAYER_2;
            }
            else
            {
                playerOneLabel.BackColor = Color.Lime;
                playerTwoLabel.BackColor = Color.Red;
                currentPlayer = "Player1";
                currentMarker = PLAYER_1;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
