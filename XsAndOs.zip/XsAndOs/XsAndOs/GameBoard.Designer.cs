﻿namespace XsAndOs
{
    partial class GameBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ticTacToePanel = new System.Windows.Forms.Panel();
            this.nineButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.sevenButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.oneButton = new System.Windows.Forms.Button();
            this.playerOneLabel = new System.Windows.Forms.Label();
            this.playerTwoLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.winnerLabel = new System.Windows.Forms.Label();
            this.startGameButton = new System.Windows.Forms.Button();
            this.endGameButton = new System.Windows.Forms.Button();
            this.player1WinsLabel = new System.Windows.Forms.Label();
            this.player1WinsTotalLabel = new System.Windows.Forms.Label();
            this.player2WinsLabel = new System.Windows.Forms.Label();
            this.player2WinsTotalLabel = new System.Windows.Forms.Label();
            this.tieGamesLabel = new System.Windows.Forms.Label();
            this.tieGamesTotalLabel = new System.Windows.Forms.Label();
            this.optionsButton = new System.Windows.Forms.Button();
            this.ticTacToePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ticTacToePanel
            // 
            this.ticTacToePanel.BackColor = System.Drawing.Color.Black;
            this.ticTacToePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ticTacToePanel.Controls.Add(this.nineButton);
            this.ticTacToePanel.Controls.Add(this.eightButton);
            this.ticTacToePanel.Controls.Add(this.sevenButton);
            this.ticTacToePanel.Controls.Add(this.sixButton);
            this.ticTacToePanel.Controls.Add(this.fiveButton);
            this.ticTacToePanel.Controls.Add(this.fourButton);
            this.ticTacToePanel.Controls.Add(this.threeButton);
            this.ticTacToePanel.Controls.Add(this.twoButton);
            this.ticTacToePanel.Controls.Add(this.oneButton);
            this.ticTacToePanel.Location = new System.Drawing.Point(122, 126);
            this.ticTacToePanel.Name = "ticTacToePanel";
            this.ticTacToePanel.Size = new System.Drawing.Size(325, 323);
            this.ticTacToePanel.TabIndex = 0;
            // 
            // nineButton
            // 
            this.nineButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.nineButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineButton.Location = new System.Drawing.Point(217, 215);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(100, 100);
            this.nineButton.TabIndex = 8;
            this.nineButton.Text = "X";
            this.nineButton.UseVisualStyleBackColor = false;
            this.nineButton.Click += new System.EventHandler(this.nineButton_Click);
            // 
            // eightButton
            // 
            this.eightButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.eightButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightButton.Location = new System.Drawing.Point(111, 215);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(100, 100);
            this.eightButton.TabIndex = 7;
            this.eightButton.Text = "O";
            this.eightButton.UseVisualStyleBackColor = false;
            this.eightButton.Click += new System.EventHandler(this.eightButton_Click);
            // 
            // sevenButton
            // 
            this.sevenButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.sevenButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenButton.Location = new System.Drawing.Point(5, 215);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(100, 100);
            this.sevenButton.TabIndex = 6;
            this.sevenButton.Text = "X";
            this.sevenButton.UseVisualStyleBackColor = false;
            this.sevenButton.Click += new System.EventHandler(this.sevenButton_Click);
            // 
            // sixButton
            // 
            this.sixButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.sixButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixButton.Location = new System.Drawing.Point(218, 109);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(100, 100);
            this.sixButton.TabIndex = 5;
            this.sixButton.Text = "O";
            this.sixButton.UseVisualStyleBackColor = false;
            this.sixButton.Click += new System.EventHandler(this.sixButton_Click);
            // 
            // fiveButton
            // 
            this.fiveButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.fiveButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveButton.Location = new System.Drawing.Point(111, 109);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(100, 100);
            this.fiveButton.TabIndex = 4;
            this.fiveButton.Text = "X";
            this.fiveButton.UseVisualStyleBackColor = false;
            this.fiveButton.Click += new System.EventHandler(this.fiveButton_Click);
            // 
            // fourButton
            // 
            this.fourButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.fourButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourButton.Location = new System.Drawing.Point(3, 109);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(100, 100);
            this.fourButton.TabIndex = 3;
            this.fourButton.Text = "O";
            this.fourButton.UseVisualStyleBackColor = false;
            this.fourButton.Click += new System.EventHandler(this.fourButton_Click);
            // 
            // threeButton
            // 
            this.threeButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.threeButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeButton.Location = new System.Drawing.Point(217, 3);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(100, 100);
            this.threeButton.TabIndex = 2;
            this.threeButton.Text = "X";
            this.threeButton.UseVisualStyleBackColor = false;
            this.threeButton.Click += new System.EventHandler(this.threeButton_Click);
            // 
            // twoButton
            // 
            this.twoButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.twoButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoButton.Location = new System.Drawing.Point(111, 3);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(100, 100);
            this.twoButton.TabIndex = 1;
            this.twoButton.Text = "O";
            this.twoButton.UseVisualStyleBackColor = false;
            this.twoButton.Click += new System.EventHandler(this.twoButton_Click);
            // 
            // oneButton
            // 
            this.oneButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.oneButton.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneButton.Location = new System.Drawing.Point(3, 3);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(100, 100);
            this.oneButton.TabIndex = 0;
            this.oneButton.Text = "X";
            this.oneButton.UseVisualStyleBackColor = false;
            this.oneButton.Click += new System.EventHandler(this.oneButton_Click);
            // 
            // playerOneLabel
            // 
            this.playerOneLabel.BackColor = System.Drawing.Color.Lime;
            this.playerOneLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.playerOneLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerOneLabel.Location = new System.Drawing.Point(122, 73);
            this.playerOneLabel.Name = "playerOneLabel";
            this.playerOneLabel.Size = new System.Drawing.Size(154, 30);
            this.playerOneLabel.TabIndex = 1;
            this.playerOneLabel.Text = "Player 1";
            this.playerOneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playerTwoLabel
            // 
            this.playerTwoLabel.BackColor = System.Drawing.Color.Red;
            this.playerTwoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.playerTwoLabel.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerTwoLabel.Location = new System.Drawing.Point(293, 73);
            this.playerTwoLabel.Name = "playerTwoLabel";
            this.playerTwoLabel.Size = new System.Drawing.Size(154, 30);
            this.playerTwoLabel.TabIndex = 2;
            this.playerTwoLabel.Text = "Player 2";
            this.playerTwoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.exitButton.Location = new System.Drawing.Point(479, 489);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // winnerLabel
            // 
            this.winnerLabel.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winnerLabel.ForeColor = System.Drawing.Color.Lime;
            this.winnerLabel.Location = new System.Drawing.Point(122, 471);
            this.winnerLabel.Name = "winnerLabel";
            this.winnerLabel.Size = new System.Drawing.Size(325, 41);
            this.winnerLabel.TabIndex = 4;
            this.winnerLabel.Text = "Winner!";
            this.winnerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.winnerLabel.Visible = false;
            // 
            // startGameButton
            // 
            this.startGameButton.Location = new System.Drawing.Point(479, 451);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(75, 23);
            this.startGameButton.TabIndex = 5;
            this.startGameButton.Text = "Start Game";
            this.startGameButton.UseVisualStyleBackColor = true;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // endGameButton
            // 
            this.endGameButton.Location = new System.Drawing.Point(479, 451);
            this.endGameButton.Name = "endGameButton";
            this.endGameButton.Size = new System.Drawing.Size(75, 23);
            this.endGameButton.TabIndex = 6;
            this.endGameButton.Text = "End Game";
            this.endGameButton.UseVisualStyleBackColor = true;
            this.endGameButton.Click += new System.EventHandler(this.endGameButton_Click);
            // 
            // player1WinsLabel
            // 
            this.player1WinsLabel.Location = new System.Drawing.Point(12, 78);
            this.player1WinsLabel.Name = "player1WinsLabel";
            this.player1WinsLabel.Size = new System.Drawing.Size(100, 23);
            this.player1WinsLabel.TabIndex = 7;
            this.player1WinsLabel.Text = "WINS";
            this.player1WinsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player1WinsTotalLabel
            // 
            this.player1WinsTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.player1WinsTotalLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1WinsTotalLabel.Location = new System.Drawing.Point(15, 101);
            this.player1WinsTotalLabel.Name = "player1WinsTotalLabel";
            this.player1WinsTotalLabel.Size = new System.Drawing.Size(97, 23);
            this.player1WinsTotalLabel.TabIndex = 8;
            this.player1WinsTotalLabel.Text = "0";
            this.player1WinsTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player2WinsLabel
            // 
            this.player2WinsLabel.Location = new System.Drawing.Point(454, 73);
            this.player2WinsLabel.Name = "player2WinsLabel";
            this.player2WinsLabel.Size = new System.Drawing.Size(100, 23);
            this.player2WinsLabel.TabIndex = 9;
            this.player2WinsLabel.Text = "WINS";
            this.player2WinsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player2WinsTotalLabel
            // 
            this.player2WinsTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.player2WinsTotalLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2WinsTotalLabel.Location = new System.Drawing.Point(457, 101);
            this.player2WinsTotalLabel.Name = "player2WinsTotalLabel";
            this.player2WinsTotalLabel.Size = new System.Drawing.Size(97, 23);
            this.player2WinsTotalLabel.TabIndex = 10;
            this.player2WinsTotalLabel.Text = "0";
            this.player2WinsTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tieGamesLabel
            // 
            this.tieGamesLabel.Location = new System.Drawing.Point(235, 9);
            this.tieGamesLabel.Name = "tieGamesLabel";
            this.tieGamesLabel.Size = new System.Drawing.Size(100, 23);
            this.tieGamesLabel.TabIndex = 11;
            this.tieGamesLabel.Text = "TIE GAMES";
            this.tieGamesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tieGamesTotalLabel
            // 
            this.tieGamesTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tieGamesTotalLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tieGamesTotalLabel.Location = new System.Drawing.Point(238, 32);
            this.tieGamesTotalLabel.Name = "tieGamesTotalLabel";
            this.tieGamesTotalLabel.Size = new System.Drawing.Size(97, 23);
            this.tieGamesTotalLabel.TabIndex = 12;
            this.tieGamesTotalLabel.Text = "0";
            this.tieGamesTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // optionsButton
            // 
            this.optionsButton.Location = new System.Drawing.Point(15, 489);
            this.optionsButton.Name = "optionsButton";
            this.optionsButton.Size = new System.Drawing.Size(75, 23);
            this.optionsButton.TabIndex = 13;
            this.optionsButton.Text = "Options";
            this.optionsButton.UseVisualStyleBackColor = true;
            this.optionsButton.Click += new System.EventHandler(this.optionsButton_Click);
            // 
            // GameBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(566, 524);
            this.Controls.Add(this.optionsButton);
            this.Controls.Add(this.tieGamesTotalLabel);
            this.Controls.Add(this.tieGamesLabel);
            this.Controls.Add(this.player2WinsTotalLabel);
            this.Controls.Add(this.player2WinsLabel);
            this.Controls.Add(this.player1WinsTotalLabel);
            this.Controls.Add(this.player1WinsLabel);
            this.Controls.Add(this.endGameButton);
            this.Controls.Add(this.startGameButton);
            this.Controls.Add(this.winnerLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.playerTwoLabel);
            this.Controls.Add(this.playerOneLabel);
            this.Controls.Add(this.ticTacToePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "GameBoard";
            this.Text = "X\'s and O\'s";
            this.Load += new System.EventHandler(this.GameBoard_Load);
            this.ticTacToePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ticTacToePanel;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Label playerOneLabel;
        private System.Windows.Forms.Label playerTwoLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label winnerLabel;
        private System.Windows.Forms.Button startGameButton;
        private System.Windows.Forms.Button endGameButton;
        private System.Windows.Forms.Label player1WinsLabel;
        private System.Windows.Forms.Label player1WinsTotalLabel;
        private System.Windows.Forms.Label player2WinsLabel;
        private System.Windows.Forms.Label player2WinsTotalLabel;
        private System.Windows.Forms.Label tieGamesLabel;
        private System.Windows.Forms.Label tieGamesTotalLabel;
        private System.Windows.Forms.Button optionsButton;
    }
}

