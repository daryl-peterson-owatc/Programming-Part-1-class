﻿namespace Population_Database
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.cityBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cityDataGridView = new System.Windows.Forms.DataGridView();
            this.modifyDatabaseButton = new System.Windows.Forms.Button();
            this.sortPopulationAscendingButton = new System.Windows.Forms.Button();
            this.sortByPopuplationDescendingButton = new System.Windows.Forms.Button();
            this.sortCitiesByNameButton = new System.Windows.Forms.Button();
            this.totalPopulationButton = new System.Windows.Forms.Button();
            this.averagePopulationButton = new System.Windows.Forms.Button();
            this.highestPopulationButton = new System.Windows.Forms.Button();
            this.lowestPopulationButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.optionsPanel = new System.Windows.Forms.Panel();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.populationDataSet = new Population_Database.PopulationDataSet();
            this.cityTableAdapter = new Population_Database.PopulationDataSetTableAdapters.CityTableAdapter();
            this.tableAdapterManager = new Population_Database.PopulationDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingNavigator)).BeginInit();
            this.cityBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityDataGridView)).BeginInit();
            this.optionsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // cityBindingNavigator
            // 
            this.cityBindingNavigator.AddNewItem = null;
            this.cityBindingNavigator.BindingSource = this.cityBindingSource;
            this.cityBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cityBindingNavigator.DeleteItem = null;
            this.cityBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.cityBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cityBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cityBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cityBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cityBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cityBindingNavigator.Name = "cityBindingNavigator";
            this.cityBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cityBindingNavigator.Size = new System.Drawing.Size(636, 25);
            this.cityBindingNavigator.TabIndex = 0;
            this.cityBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // cityDataGridView
            // 
            this.cityDataGridView.AutoGenerateColumns = false;
            this.cityDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cityDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.cityDataGridView.DataSource = this.cityBindingSource;
            this.cityDataGridView.Location = new System.Drawing.Point(13, 29);
            this.cityDataGridView.Name = "cityDataGridView";
            this.cityDataGridView.Size = new System.Drawing.Size(261, 316);
            this.cityDataGridView.TabIndex = 1;
            // 
            // modifyDatabaseButton
            // 
            this.modifyDatabaseButton.Location = new System.Drawing.Point(14, 13);
            this.modifyDatabaseButton.Name = "modifyDatabaseButton";
            this.modifyDatabaseButton.Size = new System.Drawing.Size(109, 38);
            this.modifyDatabaseButton.TabIndex = 2;
            this.modifyDatabaseButton.Text = "Modify Cities";
            this.modifyDatabaseButton.UseVisualStyleBackColor = true;
            this.modifyDatabaseButton.Click += new System.EventHandler(this.modifyDatabaseButton_Click);
            // 
            // sortPopulationAscendingButton
            // 
            this.sortPopulationAscendingButton.Location = new System.Drawing.Point(14, 70);
            this.sortPopulationAscendingButton.Name = "sortPopulationAscendingButton";
            this.sortPopulationAscendingButton.Size = new System.Drawing.Size(109, 38);
            this.sortPopulationAscendingButton.TabIndex = 3;
            this.sortPopulationAscendingButton.Text = "Sort by Population Ascending";
            this.sortPopulationAscendingButton.UseVisualStyleBackColor = true;
            this.sortPopulationAscendingButton.Click += new System.EventHandler(this.sortPopulationAscendingButton_Click);
            // 
            // sortByPopuplationDescendingButton
            // 
            this.sortByPopuplationDescendingButton.Location = new System.Drawing.Point(14, 129);
            this.sortByPopuplationDescendingButton.Name = "sortByPopuplationDescendingButton";
            this.sortByPopuplationDescendingButton.Size = new System.Drawing.Size(109, 38);
            this.sortByPopuplationDescendingButton.TabIndex = 4;
            this.sortByPopuplationDescendingButton.Text = "Sort by Population Descending";
            this.sortByPopuplationDescendingButton.UseVisualStyleBackColor = true;
            this.sortByPopuplationDescendingButton.Click += new System.EventHandler(this.sortByPopuplationDescendingButton_Click);
            // 
            // sortCitiesByNameButton
            // 
            this.sortCitiesByNameButton.Location = new System.Drawing.Point(14, 189);
            this.sortCitiesByNameButton.Name = "sortCitiesByNameButton";
            this.sortCitiesByNameButton.Size = new System.Drawing.Size(109, 38);
            this.sortCitiesByNameButton.TabIndex = 5;
            this.sortCitiesByNameButton.Text = "Sort Cities by Name";
            this.sortCitiesByNameButton.UseVisualStyleBackColor = true;
            this.sortCitiesByNameButton.Click += new System.EventHandler(this.sortCitiesByNameButton_Click);
            // 
            // totalPopulationButton
            // 
            this.totalPopulationButton.Location = new System.Drawing.Point(157, 13);
            this.totalPopulationButton.Name = "totalPopulationButton";
            this.totalPopulationButton.Size = new System.Drawing.Size(109, 38);
            this.totalPopulationButton.TabIndex = 6;
            this.totalPopulationButton.Text = "Total Population of All Cities";
            this.totalPopulationButton.UseVisualStyleBackColor = true;
            this.totalPopulationButton.Click += new System.EventHandler(this.totalPopulationButton_Click);
            // 
            // averagePopulationButton
            // 
            this.averagePopulationButton.Location = new System.Drawing.Point(157, 70);
            this.averagePopulationButton.Name = "averagePopulationButton";
            this.averagePopulationButton.Size = new System.Drawing.Size(109, 38);
            this.averagePopulationButton.TabIndex = 7;
            this.averagePopulationButton.Text = "Average Population of All Cities";
            this.averagePopulationButton.UseVisualStyleBackColor = true;
            this.averagePopulationButton.Click += new System.EventHandler(this.averagePopulationButton_Click);
            // 
            // highestPopulationButton
            // 
            this.highestPopulationButton.Location = new System.Drawing.Point(157, 129);
            this.highestPopulationButton.Name = "highestPopulationButton";
            this.highestPopulationButton.Size = new System.Drawing.Size(109, 38);
            this.highestPopulationButton.TabIndex = 8;
            this.highestPopulationButton.Text = "Show Highest Population";
            this.highestPopulationButton.UseVisualStyleBackColor = true;
            this.highestPopulationButton.Click += new System.EventHandler(this.highestPopulationButton_Click);
            // 
            // lowestPopulationButton
            // 
            this.lowestPopulationButton.Location = new System.Drawing.Point(157, 189);
            this.lowestPopulationButton.Name = "lowestPopulationButton";
            this.lowestPopulationButton.Size = new System.Drawing.Size(109, 38);
            this.lowestPopulationButton.TabIndex = 9;
            this.lowestPopulationButton.Text = "Show Lowest Population";
            this.lowestPopulationButton.UseVisualStyleBackColor = true;
            this.lowestPopulationButton.Click += new System.EventHandler(this.lowestPopulationButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(411, 328);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // optionsPanel
            // 
            this.optionsPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.optionsPanel.Controls.Add(this.lowestPopulationButton);
            this.optionsPanel.Controls.Add(this.highestPopulationButton);
            this.optionsPanel.Controls.Add(this.averagePopulationButton);
            this.optionsPanel.Controls.Add(this.totalPopulationButton);
            this.optionsPanel.Controls.Add(this.sortCitiesByNameButton);
            this.optionsPanel.Controls.Add(this.sortByPopuplationDescendingButton);
            this.optionsPanel.Controls.Add(this.sortPopulationAscendingButton);
            this.optionsPanel.Controls.Add(this.modifyDatabaseButton);
            this.optionsPanel.Location = new System.Drawing.Point(312, 55);
            this.optionsPanel.Name = "optionsPanel";
            this.optionsPanel.Size = new System.Drawing.Size(285, 244);
            this.optionsPanel.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn1.HeaderText = "City";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Population";
            this.dataGridViewTextBoxColumn2.HeaderText = "Population";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.populationDataSet;
            // 
            // populationDataSet
            // 
            this.populationDataSet.DataSetName = "PopulationDataSet";
            this.populationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CityTableAdapter = this.cityTableAdapter;
            this.tableAdapterManager.UpdateOrder = Population_Database.PopulationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 372);
            this.Controls.Add(this.optionsPanel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cityDataGridView);
            this.Controls.Add(this.cityBindingNavigator);
            this.Name = "MainForm";
            this.Text = "Population Database";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingNavigator)).EndInit();
            this.cityBindingNavigator.ResumeLayout(false);
            this.cityBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityDataGridView)).EndInit();
            this.optionsPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PopulationDataSet populationDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private PopulationDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private PopulationDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cityBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView cityDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button modifyDatabaseButton;
        private System.Windows.Forms.Button sortPopulationAscendingButton;
        private System.Windows.Forms.Button sortByPopuplationDescendingButton;
        private System.Windows.Forms.Button sortCitiesByNameButton;
        private System.Windows.Forms.Button totalPopulationButton;
        private System.Windows.Forms.Button averagePopulationButton;
        private System.Windows.Forms.Button highestPopulationButton;
        private System.Windows.Forms.Button lowestPopulationButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel optionsPanel;
    }
}

