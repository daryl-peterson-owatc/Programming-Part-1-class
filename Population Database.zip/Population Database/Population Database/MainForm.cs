﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population_Database
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDataSet.City);

        }

        private void modifyDatabaseButton_Click(object sender, EventArgs e)
        {
            CityDetails details = new CityDetails();
            details.ShowDialog();
            this.cityTableAdapter.Fill(this.populationDataSet.City);
        }

        private void sortPopulationAscendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortByPopulationAscending(this.populationDataSet.City);
        }

        private void sortByPopuplationDescendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortByPopulationDescending(this.populationDataSet.City);

        }

        private void sortCitiesByNameButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortByCity(this.populationDataSet.City);

        }

        private void totalPopulationButton_Click(object sender, EventArgs e)
        {
            double totalPopulation;
            totalPopulation = (double)this.cityTableAdapter.TotalPopulation();
            MessageBox.Show("Total population for all Cities is: " + totalPopulation.ToString("n0"));
        }

        private void averagePopulationButton_Click(object sender, EventArgs e)
        {
            double averagePopulation;
            averagePopulation = (double)this.cityTableAdapter.AveragePopulation();
            MessageBox.Show("Average population for all Cities is: " + averagePopulation.ToString("n0"));
        }

        private void highestPopulationButton_Click(object sender, EventArgs e)
        {
            double highestPopulation;
            highestPopulation = (double)this.cityTableAdapter.HighestPopulation();
            MessageBox.Show("Highest population is: " + highestPopulation.ToString("n0"));
        }

        private void lowestPopulationButton_Click(object sender, EventArgs e)
        {
            double lowestPopulation;
            lowestPopulation = (double)this.cityTableAdapter.LowestPopulation();
            MessageBox.Show("Lowest population is: " + lowestPopulation.ToString("n0"));
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
