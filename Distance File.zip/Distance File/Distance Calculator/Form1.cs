﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Distance_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int mph, hours, distance, counter;
            string message;

            if (int.TryParse(vehicleSpeedTextBox.Text, out mph) && int.TryParse(hoursTraveledTextBox.Text, out hours))
            {
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.CreateText("Distances.txt");

                    for (counter = 1; counter <= hours; counter++)
                    {
                        distance = counter * mph;
                        message = "After hour " + counter + " the distance is " + distance.ToString("n");

                        outputFile.WriteLine(message);
                    }

                    outputFile.Close();

                    MessageBox.Show("All distances have been written to 'Distances.txt'");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter an integer value in both text boxes.");
            }
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
