﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SportsPro
{
    public partial class frmProductMaintenance : Form
    {
        // NOTES: When the textboxes are filled with data by the app, the TextChanged
        //        event fires, so you can't use that alone to see if text was changed
        //        by the user. When the user clicks into a textbox, the Click event
        //        fires, BUT that doesn't mean they changed anything. Therefore, if a
        //        Click event was recorded AND a TextChanged event occured, it's
        //        probable that the user changed something.
        //
        //        HOWEVER, this doesn't work when the user adds or deletes a row, so
        //        you need a separate flag for that.
        //        
        //        The DatasetSaveFlags class handles all three values.

        DatasetSaveFlags gFlags = new DatasetSaveFlags();

        #region Form events -----------------------------------------

        public frmProductMaintenance()
        {
            InitializeComponent();
        }

        private void frmProductMaintenance_Load(object sender, EventArgs e)
        {
            // NOTE: Form properties set so form always displays at location 0,0.

            try                                  // QUESTION: Is this overkill?
            {
                this.productsTableAdapter.Fill(this.techSupportDataSet.Products);
            }
            catch (SqlException ex)              // Data provider error of some sort.
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": \n" +
                                ex.Message, ex.GetType().ToString());
            }
        }

        private void frmProductMaintenance_FormClosing(object sender, FormClosingEventArgs e)
        {
            NoLossOfData();                      // Make sure nothing is accidentally lost.
        }

        #endregion

        #region All my class methods --------------------------------

        // In case user changed something but didn't save. Will return true if user
        // clicks Yes (save) or No (abandon), or false if Cancel (do nothing).
        private bool NoLossOfData()
        {
            bool booValue;

            // See giant note at top of file for explanation of flags.
            if (gFlags.DataChanged &&
                   (gFlags.UserClickedIn || gFlags.DeletionOrAddtion)
               )
            {
                DialogResult answer;

                answer = MessageBox.Show("Data has been changed, but not saved.\n" +
                                         "Do you want to save your changes?",
                                         "Warning", MessageBoxButtons.YesNoCancel);
                switch (answer)
                {
                    case DialogResult.Yes:      // Try committing changes to db.
                        if (SaveDataInDataSet())
                            booValue = true;
                        else // error saving changes.
                            booValue = false;
                        break;
                    case DialogResult.No:       // Abandon changes and close form.
                        booValue = true;
                        break;
                    default:                    // Do nothing and stay in form.
                        booValue = false;
                        break;
                }
            }
            else // no changes made.
            {
                booValue = true;
            }

            return booValue;
        }

        private bool SaveDataInDataSet()
        {
            bool success = false;                // Flags calling method.

            try
            {
                this.Validate();       // The author noted that this method is sketchy.

                // Commits data in grid to dataset.
                this.productsBindingSource.EndEdit();

                // Commits data in dataset to database.
                this.tableAdapterManager.UpdateAll(this.techSupportDataSet);

                // Flag success.
                success = true;
            }
            catch (DBConcurrencyException)       // Row changed by another user.
            {
                MessageBox.Show("A concurrency error occurred. " +
                                "The row was not updated.", "Concurrency Exception");
            }
            catch (DataException ex)             // Invalid data of some sort.
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
                this.productsBindingSource.CancelEdit();   // Cancel the edit.
            }
            catch (SqlException ex)              // Data provider error of some sort.
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": \n" +
                                ex.Message, ex.GetType().ToString());
            }

            return success;
        }

        #endregion

        #region Binding Navigator and Grid View events --------------

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            gFlags.DeletionOrAddtion = true;
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            gFlags.DeletionOrAddtion = true;
        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            SaveDataInDataSet();

            // Data was just saved, so no unsaved data.
            gFlags.DataChanged = false;
            gFlags.UserClickedIn = false;
            gFlags.DeletionOrAddtion = false;
        }

        private void productsDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            gFlags.UserClickedIn = true;         // User clicked in, but hasn't
            gFlags.DataChanged = false;          // changed anything yet.
        }

        private void productsDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            gFlags.DataChanged = true;           // Data was changed.
        }

        #endregion
    }
}
