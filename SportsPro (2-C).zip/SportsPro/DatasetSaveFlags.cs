﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsPro
{
    class DatasetSaveFlags
    {
        // Fields
        bool _DataChanged;             // True if user or dataset changed text box.
        bool _UserClickedIn;           // True if user clicked into a text box.
        bool _DeletionOrAddition;      // True if Delete or Add navigator button clicked.

        // Constructor
        public DatasetSaveFlags()
        {
            _DataChanged = false;
            _UserClickedIn = false;
            _DeletionOrAddition = false;
        }

        // Parameters
        public bool DataChanged
        {
            get { return _DataChanged; }
            set { _DataChanged = value; }
        }

        public bool UserClickedIn
        {
            get { return _UserClickedIn; }
            set { _UserClickedIn = value; }
        }

        public bool DeletionOrAddtion
        {
            get { return _DeletionOrAddition; }
            set { _DeletionOrAddition = value; }
        }
    }
}
