﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            Form frmLoginScreen = new frmLogin();
            frmLoginScreen.ShowDialog();
            if (frmLoginScreen.Tag == null)
            {
                this.Close();
            }
            else
            {
                toolStripStatusLabel1.Text = "Student Name: " + frmLoginScreen.Tag;
            }
            //toolStripStatusLabel1.Text = "Student Name: Inigo Montoya";
        }

        // Add error checking later!

        private void maintainProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form productMaintForm = new frmProductMaintenance();     // Create object.
            productMaintForm.MdiParent = this;             // Will be child form.
            productMaintForm.Show();                       // Show form, modeless.
        }

        private void maintainCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form customerMaintForm = new frmCustomerMaintenance();   // Create object.
            customerMaintForm.MdiParent = this;            // Will be child form.
            customerMaintForm.Show();                      // Show form, modeless.
        }

        private void displayIncidentsByProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form productIncidentsForm = new frmProductIncidents();   // Create object.
            productIncidentsForm.MdiParent = this;         // Will be child form.
            productIncidentsForm.Show();                   // Show form, modeless.
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
