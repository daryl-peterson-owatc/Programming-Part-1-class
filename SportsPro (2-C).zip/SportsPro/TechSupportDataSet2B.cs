﻿namespace SportsPro {
    
    
    public partial class TechSupportDataSet2B {
    }
}

