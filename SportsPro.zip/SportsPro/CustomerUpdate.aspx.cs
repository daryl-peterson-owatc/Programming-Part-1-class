﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CustomerUpdate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //protected void grdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName == "SelectCustomer")
    //    {
    //        int rowIndex = Convert.ToInt32(e.CommandArgument);
    //        int customerID = Convert.ToInt32(grdCustomers.DataKeys[rowIndex].Value);
    //        messageTextBox.Text = customerID.ToString();
    //    }
    //}
}