﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for TechnicianDB
/// </summary>
public class TechnicianDB
{
    public TechnicianDB()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //public static IEnumerable GetTechnicians()
    //{

    //    string statement = "SELECT TechID, Name, Email, Phone " +
    //        "FROM Technicians " +
    //        "ORDER BY Name";
    //}

    //public static int UpdateTechnician(string name, string email, string phone, 
    //    int original_TechID, string original_Name, string original_Email, string original_Phone)
    //{

    //    string statement = "UPDATE Technicians " +
    //        "SET Name = @Name, Email = @Email, Phone = @Phone " +
    //        "WHERE TechID = @original_TechID AND Name = @original_Name " +
    //        "AND Email = @original_Email AND Phone = @original_Phone";
    //}

    //public static int DeleteTechnician(int original_TechID, string original_Name, string original_Email, string original_Phone)
    //{

    //    string statement = "DELETE FROM Technicians " +
    //        "WHERE TechID = @original_TechID AND Name = @original_Name " +
    //        "AND Email = @original_Email AND Phone = @original_Phone";
    //}

    //public static void InsertTechnician(string name, string email, string phone)
    //{

    //    string statement = "INSERT INTO Technicians(Name, Email, Phone) " +
    //        "VALUES(@Name, @Email, @Phone)";
    //}
}