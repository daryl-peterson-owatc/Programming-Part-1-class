﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for TechSupportDB
/// </summary>
public class TechSupportDB
{
    public TechSupportDB()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}