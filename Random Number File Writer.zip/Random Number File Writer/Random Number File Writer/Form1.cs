﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Writer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveFileButton_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            int newNumber;
            int limit = 20;

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                Random rand = new Random((int)DateTime.Now.Ticks);
                outputFile = File.CreateText(saveFile.FileName);

                for(int count = 1; count <= limit; count++)
                {
                    newNumber = rand.Next(1000);
                    outputFile.WriteLine(newNumber);
                }

                outputFile.Close();

                MessageBox.Show("Your file has been written!");
            }
            else
            {
                MessageBox.Show("You clicked Cancel.");
            }
        }
    }
}
