﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class ProductDB
    {
        public static List<Product> GetProductList()
        {
            List<Product> productList = new List<Product>();

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectString =
                "SELECT ProductCode, Name " +
                "FROM Products " +
                "ORDER BY Name";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectString, connection);

            try
            {
                // Establish the connection.
                connection.Open();

                // Prepare to read first line.
                SqlDataReader reader = selectCommand.ExecuteReader();

                // Read a line (if there is one).
                while (reader.Read())
                {
                    // NOTE: Always cast or convert ro the type; even strings.

                    // Declare a new Product to store this line's data.
                    Product product = new Product();

                    // Read ProductCode, change to string, store in 'product'.
                    product.ProductCode = reader["ProductCode"].ToString();

                    // Read Name, change to string, store in 'product'.
                    product.Name = reader["Name"].ToString();

                    // Add 'product' data to 'productList'.
                    productList.Add(product);
                }

                // After all products have been read...
                reader.Close();
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetOpenIncidents is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return productList;
        }

        public static string GetProductName(string productID)
        {
            string productName = "";

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectString =
                "SELECT Name " +
                "FROM Products " +
                "WHERE ProductCode = @ProductCode";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectString, connection);
            selectCommand.Parameters.AddWithValue("@ProductCode", productID);

            try
            {
                // Establish the connection.
                connection.Open();

                // It's scalar because it's only returning one value.
                productName = (string)selectCommand.ExecuteScalar();

                // Give user a sign that there is no product name.
                if(productName == null)
                {
                    productName = "n/a";
                }
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetOpenIncidents is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return productName;
        }
    }
}
