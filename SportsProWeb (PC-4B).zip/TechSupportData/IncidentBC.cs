﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Incident
    {
        private int _incidentID;
        private int _customerID;
        private string _productCode;
        private int? _techID;
        private DateTime _dateOpened;
        private DateTime? _dateClosed;
        private string _title;
        private string _description;
        private string _customerName;
        private string _technicianName;
        private string _productName;

        public Incident() { }

        public int IncidentID
        {
            get { return _incidentID; }
            set { _incidentID = value; }
        }

        public int CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public string ProductCode
        {
            get { return _productCode; }
            set { _productCode = value; }
        }

        public int? TechID
        {
            get 
            {
                // TechID could be null. Check and return appropriate value.
                if (_techID.HasValue)
                    return _techID;
                else // value is null.
                    return null;
            }
            set { _techID = value; }
        }

        public DateTime DateOpened
        {
            get { return _dateOpened; }
            set { _dateOpened = value; }
        }

        public DateTime? DateClosed
        {
            get
            {
                // DateClosed could be null. Check and return appropriate value.
                if (_dateClosed.HasValue)
                    return _dateClosed;
                else // value is null.
                    return null;
            }
            set { _dateClosed = value; }
        }

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; }
        }

        public string TechnicianName
        {
            get { return _technicianName; }
            set { _technicianName = value; }
        }

        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; }
        }
    }
}
