﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Registration
    {
        private int _customerID;
        private string _productCode;

        public Registration() { }

        public int CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public string ProductCode
        {
            get { return _productCode; }
            set { _productCode = value; }
        }
    }
}
