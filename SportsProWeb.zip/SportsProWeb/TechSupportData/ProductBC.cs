﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Product
    {
        private string _productCode;
        private string _name;

        public void ProductBC() { }

        public string ProductCode
        {
            get { return _productCode; }
            set { _productCode = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }
}
