﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Customer
    {
        private int _customerID;
        private string _name;

        public Customer() { }

        public int CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }
}
