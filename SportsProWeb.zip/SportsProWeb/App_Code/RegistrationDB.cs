﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class RegistrationDB
    {
        public static bool ProductRegistered(int customerID, string productCode)
        {
            bool isRegistered = false;

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectString =
                "SELECT Count(*) " +
                "FROM Registrations " +
                "WHERE CustomerID = @customerID " +
                "AND ProductCode = @productCode";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectString, connection);

            // Add parameter values.
            selectCommand.Parameters.AddWithValue("@customerID", customerID);
            selectCommand.Parameters.AddWithValue("@productCode", productCode);

            try
            {
                // Establish the connection.
                connection.Open();

                // Perform the query.
                int rows = (int)selectCommand.ExecuteScalar();

                if (rows > 0)                    // If rows were returned,
                    isRegistered = true;         // product is registered,
                else                             // otherwise,
                    isRegistered = false;        // it's not.
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetOpenIncidents is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return isRegistered;
        }
    }
}
