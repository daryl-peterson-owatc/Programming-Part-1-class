﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace TechSupportData
{
    public class TechnicianDB
    {
        public static string GetTechnicianName(int techID)
        {
            // Declare a string to hold the name. Initialize here in case no data.
            string technicianName = "";

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectStatement =
                "SELECT Name FROM Technicians WHERE TechID = @techID";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            // SELECT statement has a parameter, so we need
            // to pass a value for it to the command.
            selectCommand.Parameters.AddWithValue("@techID", techID);

            try
            {
                // Open the connection.
                connection.Open();

                // Execute the query.
                technicianName = (string)selectCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method will evaluate and post message.
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return technicianName;
        }

        public static List<Technician> GetTechnicianList()
        {
            List<Technician> technicianList = new List<Technician>();
            SqlConnection connection = TechSupportDB.GetConnection();
            
            string selectString = "SELECT TechID, Name " +
                                  "FROM Technicians " +
                                  "ORDER BY Name";

            SqlCommand command = new SqlCommand(selectString, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Technician tech = new Technician();

                    tech.TechID = (int)reader["TechID"];
                    tech.Name = reader["Name"].ToString();

                    technicianList.Add(tech);
                }

                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return technicianList;
        }

        public static Technician GetTechnician(int techID)
        {
            Technician tech = new Technician();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = "SELECT TechID, Name, Email, Phone " +
                                     "FROM Technicians " +
                                     "WHERE TechID = @TechID";

            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            selectCommand.Parameters.AddWithValue("@techID", techID);

            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();

                if (reader.Read())
                {
                    tech.TechID = (int)reader["TechID"];
                    tech.Name = reader["Name"].ToString();
                    tech.Email = reader["Email"].ToString();
                    tech.Phone = reader["Phone"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return tech;
        }

        public static IEnumerable GetTechnicians()
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectTechnician = "SELECT TechID, Name, Email, Phone FROM Technicians Order By Name";
            SqlCommand cmdSelect = new SqlCommand(selectTechnician, connection);
            SqlDataReader rdr = null;
            try
            {
                connection.Open();
                rdr = cmdSelect.ExecuteReader(CommandBehavior.CloseConnection);
                return rdr;
            }
            catch (SqlException ex)
            {
                if(rdr != null)
                {
                    rdr.Close();
                }
                else
                {
                    connection.Close();
                }
                throw ex;
            }
        }

        public static int UpdateTechnician(string name, string email, string phone, 
            int original_TechID, string original_Name, string original_Email, string original_Phone)
        {

        }
    }
}
