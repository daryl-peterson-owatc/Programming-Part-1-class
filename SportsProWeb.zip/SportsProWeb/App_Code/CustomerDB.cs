﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class CustomerDB
    {
        // Always returns a string, whether it's a name or "".
        
        public static string GetCustomerName(int customerID)
        {
            // Declare a string to hold the name. Initialize here in case no data.
            string customerName = "";

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectStatement =
                "SELECT Name FROM Customers WHERE CustomerID = @custID";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            // SELECT statement has a parameter, so we need
            // to pass a value for it to the command.
            selectCommand.Parameters.AddWithValue("@custID", customerID);

            try
            {
                // Open the connection.
                connection.Open();

                // Execute the query. It's scalar because it's only returning a name.
                customerName = (string)selectCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method will evaluate and post message.
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return customerName;
        }

        public static List<Customer> GetCustomerList()
        {
            // Declare a list to hold the customer info as it's collected.
            List<Customer> customerNames = new List<Customer>();

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectStatement =
                "SELECT CustomerID, Name FROM Customers ORDER BY Name";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            try
            {
                // Establish the connection.
                connection.Open();

                // Prepare to read first line.
                SqlDataReader reader = selectCommand.ExecuteReader();

                // Read a line (if there is one).
                while (reader.Read())
                {
                    // NOTE: Always cast or convert ro the type; even strings.

                    // Declare a new Customer to store this line's data.
                    Customer customer = new Customer();

                    // Read CustomerID, store in 'product'.
                    customer.CustomerID = (int)reader["CustomerID"];

                    // Read Name, change to string, store in 'product'.
                    customer.Name = reader["Name"].ToString();

                    // Add 'product' data to 'productList'.
                    customerNames.Add(customer);
                }

                // After all products have been read...
                reader.Close();
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetCustomerList is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return customerNames;
        }
    }
}
