﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class IncidentDB
    {
        // NOTE: Most of the comments are for my own information.
        //       I would eliminate most of them in the real world.
        
        public static List<Incident> GetOpenIncidents()
        {        
            // Declare a new List to contain the data we collect.
            List<Incident> incidentList = new List<Incident>();

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string sqlString =
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " +
                "FROM Incidents " +
                "WHERE DateClosed IS NULL";

            // Set up a SQL command.
            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            try
            {
                // Establish the connection.
                connection.Open();

                // Prepare to read first line.
                SqlDataReader reader = sqlCommand.ExecuteReader();

                // Read a line (if there is one).
                while (reader.Read())
                {
                    // NOTE: Always cast or convert ro the type; even strings.

                    // Declare a new Incident to store this line's data.
                    Incident incident = new Incident();

                    // Get cus
                    incident.CustomerName = 
                        CustomerDB.GetCustomerName((int)reader["CustomerID"]);

                    // Read ProductCode, change to string, store in 'incident'.
                    incident.ProductCode = reader["ProductCode"].ToString();

                    // Since TechID's source is a database, you have to
                    // check it against DBNull.Value, not just 'null'.
                    if (reader["TechID"] != DBNull.Value)
                        // If TechID exists, then the technician's name exists too.
                        incident.TechnicianName = 
                            TechnicianDB.GetTechnicianName((int)reader["TechID"]);
                    else
                        incident.TechnicianName = "";

                    // Read the DateOpen column, cast it as 'datetime', store in 'incident'.
                    incident.DateOpened = (DateTime)reader["DateOpened"];

                    // Read Title, change to string, store in 'incident'.
                    incident.Title = reader["Title"].ToString();

                    // Add 'incident' data to 'incidentList'.
                    incidentList.Add(incident);
                }

                // After all incidents have been read...
                reader.Close();
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetOpenIncidents is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return incidentList;
        }

        public static void AddIncident(Incident newIncident)
        {

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL insert string.
            string sqlString =
                "INSERT Incidents (CustomerID, ProductCode, DateOpened, " +
                                   "Title, Description) " +
                "VALUES (@CustomerID, @ProductCode, " +
                "@DateOpened, @Title, @Description)";

            // Set up a SQL command.
            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            // Add values to parameters of command.
            sqlCommand.Parameters.AddWithValue("@CustomerID", newIncident.CustomerID);
            sqlCommand.Parameters.AddWithValue("@ProductCode", newIncident.ProductCode);
            sqlCommand.Parameters.AddWithValue("@DateOpened", newIncident.DateOpened);
            sqlCommand.Parameters.AddWithValue("@Title", newIncident.Title);
            sqlCommand.Parameters.AddWithValue("@Description", newIncident.Description);

            try
            {
                // Establish the connection.
                connection.Open();

                // Perform insert.
                sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public static Incident GetIncident(int incidentID)
        {
            Incident incident = new Incident();
            SqlConnection connection = TechSupportDB.GetConnection();

            string sqlString = 
                "SELECT IncidentID, CustomerID, ProductCode, TechID, " +
                       "DateOpened, DateClosed, Title, Description " +
                "FROM Incidents " +
                "WHERE IncidentID = @IncidentID";

            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            sqlCommand.Parameters.AddWithValue("@IncidentID", incidentID);

            try
            {
                connection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();

                if (reader.Read())
                {
                    incident.IncidentID = (int)reader["IncidentID"];
                    incident.CustomerID = (int)reader["CustomerID"];
                    incident.ProductCode = reader["ProductCode"].ToString();
                    if (reader["TechID"] == DBNull.Value)
                        incident.TechID = null;
                    else
                        incident.TechID = (int)reader["TechID"];
                    incident.DateOpened = (DateTime)reader["DateOpened"]; // This WILL be there.
                    if (reader["DateClosed"] == DBNull.Value)             // This might not.
                        incident.DateClosed = null;
                    else
                        incident.DateClosed = (DateTime)reader["DateClosed"];
                    incident.Title = reader["Title"].ToString();
                    incident.Description = reader["Description"].ToString();
                }
                else // no matching incident ID found.
                    incident = null;
                    
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return incident;
        }

        public static bool UpdateIncident(int indidentID, string oldDescription,
                                          string newDescription)
        {
            bool wasUpdated = false;

            // Declare incident object to store data.
            Incident incident = new Incident();

            // Get the connection info.
            SqlConnection connection = TechSupportDB.GetConnection();

            // The original description was grabbed by the calling method
            // when it filled out the form controls. That description needs
            // to be in global variable nDescription so we can check if
            // somebody else made changes in the meantime.

            // Build selection string.
            string sqlString = 
                "UPDATE Incidents " +
                "SET Description = @NewDescription " +
                "WHERE IncidentID = @IncidentID " + 
                    "AND Description = @OldDescription " +
                    "AND DateClosed IS NULL";

            // Initialize command.
            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            // Add parameter to command.
            sqlCommand.Parameters.AddWithValue("@OldDescription", oldDescription);
            sqlCommand.Parameters.AddWithValue("@IncidentID", indidentID);
            sqlCommand.Parameters.AddWithValue("@NewDescription", newDescription);

            try
            {
                // Establish the connection.
                connection.Open();

                // Perform Query.
                sqlCommand.ExecuteNonQuery();
                wasUpdated = true;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return wasUpdated;
        }

        public static bool CloseIncident(int indidentID, string description)
        {
            bool wasClosed = false;
            DateTime todaysDate = DateTime.Today;

            // Declare incident object to store data.
            Incident incident = new Incident();

            // Get the connection info.
            SqlConnection connection = TechSupportDB.GetConnection();

            // The original description was grabbed by the calling method
            // when it filled out the form controls. That description needs
            // to be in global variable nDescription so we can check if
            // somebody else made changes in the meantime.

            // Build selection string.
            string sqlString =
                "UPDATE Incidents " +
                "SET DateClosed = @DateClosed " +
                "WHERE IncidentID = @IncidentID " +
                      "AND Description = @Description " +  // We need this to make sure
                      "AND DateClosed IS NULL";            // the row wasn't changed by
                                                           // somebody else.
            // Initialize command.
            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            // Add parameter to command.
            sqlCommand.Parameters.AddWithValue("@DateClosed", todaysDate);
            sqlCommand.Parameters.AddWithValue("@Description", description);
            sqlCommand.Parameters.AddWithValue("@IncidentID", indidentID);
            
            try
            {
                // Establish the connection.
                connection.Open();

                // Perform Query.
                sqlCommand.ExecuteNonQuery();
                wasClosed = true;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return wasClosed;
        }

        public static Technician GetTechnician(int techID)
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            Technician technicianInfo = new Technician();

            string sqlString = "SELECT TechID, Name, Email, Phone " +
                               "FROM Technicians " + 
                               "WHERE TechID = @TechID";

            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                if (reader.Read())
                {
                    Technician tech = new Technician();
                    technicianInfo.Name = reader["Name"].ToString();
                    technicianInfo.TechID = (int)reader["TechID"];
                    technicianInfo.Email = reader["Email"].ToString();
                    technicianInfo.Phone = reader["Phone"].ToString();
                }

                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return technicianInfo;
        }

        public static List<Incident> GetOpenTechnicianIncidents(int techID)
        {
            List<Incident> incident = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();

            // I added IncidentID because it seems like the most 
            //  logical way toget the IncidentID into the grid.
            string sqlString =
                "SELECT IncidentID, CustomerID, ProductCode, DateOpened, Title, Description " +
                "FROM Incidents " +
                "WHERE TechID = @TechID " +
                "AND DateClosed IS NULL";

            SqlCommand sqlCommand = new SqlCommand(sqlString, connection);

            sqlCommand.Parameters.AddWithValue("@TechID", techID);

            try
            {
                connection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    Incident tempIncident = new Incident();
                    tempIncident.IncidentID = (int)reader["IncidentID"];
                    tempIncident.CustomerID = (int)reader["CustomerID"];

                    // You have to get CustomerName from the CustomerID data object.
                    tempIncident.CustomerName =
                        CustomerDB.GetCustomerName(tempIncident.CustomerID);

                    tempIncident.ProductCode = reader["ProductCode"].ToString();
                    tempIncident.ProductName = 
                        ProductDB.GetProductName(tempIncident.ProductCode).ToString();
                    tempIncident.DateOpened = (DateTime)reader["DateOpened"];
                    tempIncident.Title = reader["Title"].ToString();
                    tempIncident.Description = reader["Description"].ToString();
                    incident.Add(tempIncident);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return incident;
        }
    }
}
