﻿namespace Latin_Translator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSinister = new System.Windows.Forms.Button();
            this.btnDexter = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.lblSinister = new System.Windows.Forms.Label();
            this.lblDexter = new System.Windows.Forms.Label();
            this.lblMedium = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSinister
            // 
            this.btnSinister.Location = new System.Drawing.Point(73, 50);
            this.btnSinister.Name = "btnSinister";
            this.btnSinister.Size = new System.Drawing.Size(75, 23);
            this.btnSinister.TabIndex = 0;
            this.btnSinister.Text = "Sinister";
            this.btnSinister.UseVisualStyleBackColor = true;
            this.btnSinister.Click += new System.EventHandler(this.btnSinister_Click);
            // 
            // btnDexter
            // 
            this.btnDexter.Location = new System.Drawing.Point(73, 93);
            this.btnDexter.Name = "btnDexter";
            this.btnDexter.Size = new System.Drawing.Size(75, 23);
            this.btnDexter.TabIndex = 1;
            this.btnDexter.Text = "Dexter";
            this.btnDexter.UseVisualStyleBackColor = true;
            this.btnDexter.Click += new System.EventHandler(this.btnDexter_Click);
            // 
            // btnMedium
            // 
            this.btnMedium.Location = new System.Drawing.Point(73, 143);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(75, 23);
            this.btnMedium.TabIndex = 2;
            this.btnMedium.Text = "Medium";
            this.btnMedium.UseVisualStyleBackColor = true;
            this.btnMedium.Click += new System.EventHandler(this.btnMedium_Click);
            // 
            // lblSinister
            // 
            this.lblSinister.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSinister.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSinister.Location = new System.Drawing.Point(205, 50);
            this.lblSinister.Name = "lblSinister";
            this.lblSinister.Size = new System.Drawing.Size(100, 23);
            this.lblSinister.TabIndex = 3;
            this.lblSinister.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDexter
            // 
            this.lblDexter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDexter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDexter.Location = new System.Drawing.Point(205, 93);
            this.lblDexter.Name = "lblDexter";
            this.lblDexter.Size = new System.Drawing.Size(100, 23);
            this.lblDexter.TabIndex = 4;
            this.lblDexter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMedium
            // 
            this.lblMedium.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMedium.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedium.Location = new System.Drawing.Point(205, 143);
            this.lblMedium.Name = "lblMedium";
            this.lblMedium.Size = new System.Drawing.Size(100, 23);
            this.lblMedium.TabIndex = 5;
            this.lblMedium.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 224);
            this.Controls.Add(this.lblMedium);
            this.Controls.Add(this.lblDexter);
            this.Controls.Add(this.lblSinister);
            this.Controls.Add(this.btnMedium);
            this.Controls.Add(this.btnDexter);
            this.Controls.Add(this.btnSinister);
            this.Name = "Form1";
            this.Text = "Latin Translator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSinister;
        private System.Windows.Forms.Button btnDexter;
        private System.Windows.Forms.Button btnMedium;
        private System.Windows.Forms.Label lblSinister;
        private System.Windows.Forms.Label lblDexter;
        private System.Windows.Forms.Label lblMedium;
    }
}

