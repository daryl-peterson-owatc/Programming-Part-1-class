﻿namespace E_Mail_Address_Book
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namesGroupBox = new System.Windows.Forms.GroupBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.addressBookListBox = new System.Windows.Forms.ListBox();
            this.namesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // namesGroupBox
            // 
            this.namesGroupBox.Controls.Add(this.addressBookListBox);
            this.namesGroupBox.Location = new System.Drawing.Point(49, 18);
            this.namesGroupBox.Name = "namesGroupBox";
            this.namesGroupBox.Size = new System.Drawing.Size(186, 189);
            this.namesGroupBox.TabIndex = 0;
            this.namesGroupBox.TabStop = false;
            this.namesGroupBox.Text = "Address Book";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(103, 234);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // addressBookListBox
            // 
            this.addressBookListBox.FormattingEnabled = true;
            this.addressBookListBox.Location = new System.Drawing.Point(22, 24);
            this.addressBookListBox.Name = "addressBookListBox";
            this.addressBookListBox.Size = new System.Drawing.Size(143, 147);
            this.addressBookListBox.TabIndex = 0;
            this.addressBookListBox.SelectedIndexChanged += new System.EventHandler(this.addressBookListBox_SelectedIndexChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 281);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.namesGroupBox);
            this.Name = "MainForm";
            this.Text = "E-Mail Address Book";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.namesGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox namesGroupBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox addressBookListBox;
    }
}

