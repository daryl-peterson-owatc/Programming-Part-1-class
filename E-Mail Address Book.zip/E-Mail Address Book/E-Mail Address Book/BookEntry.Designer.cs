﻿namespace E_Mail_Address_Book
{
    partial class BookEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.nameDescriptionLabel = new System.Windows.Forms.Label();
            this.emailDescriptionLabel = new System.Windows.Forms.Label();
            this.phoneDescriptionLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLabel.Location = new System.Drawing.Point(96, 18);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(227, 23);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // emailLabel
            // 
            this.emailLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emailLabel.Location = new System.Drawing.Point(96, 51);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(227, 23);
            this.emailLabel.TabIndex = 1;
            this.emailLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // phoneLabel
            // 
            this.phoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneLabel.Location = new System.Drawing.Point(96, 85);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(100, 23);
            this.phoneLabel.TabIndex = 2;
            this.phoneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nameDescriptionLabel
            // 
            this.nameDescriptionLabel.AutoSize = true;
            this.nameDescriptionLabel.Location = new System.Drawing.Point(52, 23);
            this.nameDescriptionLabel.Name = "nameDescriptionLabel";
            this.nameDescriptionLabel.Size = new System.Drawing.Size(38, 13);
            this.nameDescriptionLabel.TabIndex = 3;
            this.nameDescriptionLabel.Text = "Name:";
            // 
            // emailDescriptionLabel
            // 
            this.emailDescriptionLabel.AutoSize = true;
            this.emailDescriptionLabel.Location = new System.Drawing.Point(14, 56);
            this.emailDescriptionLabel.Name = "emailDescriptionLabel";
            this.emailDescriptionLabel.Size = new System.Drawing.Size(76, 13);
            this.emailDescriptionLabel.TabIndex = 4;
            this.emailDescriptionLabel.Text = "Email Address:";
            // 
            // phoneDescriptionLabel
            // 
            this.phoneDescriptionLabel.AutoSize = true;
            this.phoneDescriptionLabel.Location = new System.Drawing.Point(49, 90);
            this.phoneDescriptionLabel.Name = "phoneDescriptionLabel";
            this.phoneDescriptionLabel.Size = new System.Drawing.Size(41, 13);
            this.phoneDescriptionLabel.TabIndex = 5;
            this.phoneDescriptionLabel.Text = "Phone:";
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(143, 128);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 6;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // BookEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 166);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.phoneDescriptionLabel);
            this.Controls.Add(this.emailDescriptionLabel);
            this.Controls.Add(this.nameDescriptionLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "BookEntry";
            this.Text = "Book Entry";
            this.Load += new System.EventHandler(this.BookEntry_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label nameDescriptionLabel;
        private System.Windows.Forms.Label emailDescriptionLabel;
        private System.Windows.Forms.Label phoneDescriptionLabel;
        private System.Windows.Forms.Button closeButton;
    }
}