﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace E_Mail_Address_Book
{
    public partial class MainForm : Form
    {
        List<PersonEntry> addressBookList = new List<PersonEntry>();

        private const char DELIMETER = ',';

        public string selectedName;
        public string selectedEmail;
        public string selectedPhone;

        public MainForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                string contact;
                string tmpName;
                string tmpEmail;
                string tmpPhone;
                string[] tokens;

                StreamReader inputFile;

                inputFile = File.OpenText("NamesList.txt");

                while (!inputFile.EndOfStream)
                {
                    contact = inputFile.ReadLine();
                    tokens = contact.Split(DELIMETER);
                    tmpName = tokens[0];
                    tmpEmail = tokens[1];
                    tmpPhone = tokens[2];
                    BuildAddressBook(tmpName, tmpEmail, tmpPhone);
                }

                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BuildAddressBook(string name, string email, string phone)
        {
            PersonEntry contact = new PersonEntry(name, email, phone);

            addressBookList.Add(contact);
            addressBookListBox.Items.Add(name);
        }

        private void addressBookListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            BookEntry be = new BookEntry();

            int index = addressBookListBox.SelectedIndex;

            be.selectedName = addressBookList[index].Name;
            be.selectedEmail = addressBookList[index].EmailAddress;
            be.selectedPhone = addressBookList[index].PhoneNumber;

            be.Show();
        }
    }
}
