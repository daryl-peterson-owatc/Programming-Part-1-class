﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Mail_Address_Book
{
    class PersonEntry
    {
        private string _name;
        private string _emailAddress;
        private string _phoneNumber;

        public PersonEntry()
        {
            _name = "";
            _emailAddress = "";
            _phoneNumber = "";
        }

        public PersonEntry(string name, string email, string phone)
        {
            _name = name;
            _emailAddress = email;
            _phoneNumber = phone;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string EmailAddress
        {
            get { return _emailAddress; }
            set { _emailAddress = value; }
        }

        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }
    }
}
