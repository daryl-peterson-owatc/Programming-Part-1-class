﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Mail_Address_Book
{
    public partial class BookEntry : Form
    {
        public string selectedName;
        public string selectedEmail;
        public string selectedPhone;

        public BookEntry()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BookEntry_Load(object sender, EventArgs e)
        {
            nameLabel.Text = selectedName;
            emailLabel.Text = selectedEmail;
            phoneLabel.Text = selectedPhone;
        }
    }
}
