﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class ProductDB
    {
        public static List<Product> GetProductList()
        {
            var productList = new List<Product>();

            SqlConnection sqlConn = TechSupportDB.GetConnection();
            string sqlStatement =
                "SELECT ProductCode, Name " +
                "FROM Products " +
                "ORDER BY Name";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConn);

            try
            {
                sqlConn.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Product product = new Product();
                    product.Productcode = reader["ProductCode"].ToString();
                    product.Name = reader["Name"].ToString();

                    productList.Add(product);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            return productList;
        }

        public static string GetProductName(string productID)
        {
            string name = "";

            SqlConnection sqlConnection = TechSupportDB.GetConnection();
            string sqlStatement =
                "SELECT Name " +
                "FROM Products " +
                "WHERE ProductCode = @ProductCode";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConnection);
            sqlCommand.Parameters.AddWithValue("@ProductCode", productID);

            try
            {
                sqlConnection.Open();
                name = sqlCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return name;
        }

        public static string GetProductName(string productCode)
        {
            string name = "";

            return name;
        }
    }
}
