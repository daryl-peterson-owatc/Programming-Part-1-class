﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    class Product
    {
        private string productCode;
        private string name;

        public string Productcode { get; set; }
        public string Name { get; set; }
    }
}
