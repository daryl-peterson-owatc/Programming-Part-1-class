﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class IncidentDB
    {
        public static List<Incident> GetOpenIncidents()
        {
            List<Incident> incidentList = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " +
                "FROM Incidents " +
                "WHERE DateClosed IS NULL";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Incident incident = new Incident();
                    incident.ProductCode = reader["ProductCode"].ToString();
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    incident.CustomerName = CustomerDB.GetCustomerName((int)reader["CustomerID"]);

                    if (reader["TechID"] == DBNull.Value)
                    {
                        incident.TechName = null;
                    }
                    else
                    {
                        incident.TechName = TechnicianDB.GetTechnicianName((int)reader["TechID"]);
                    }

                    incident.Title = reader["Title"].ToString();

                    incidentList.Add(incident);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return incidentList;
        }

        public static void AddIncident(Incident incident)
        {
            int customerID = incident.CustomerID;
            string productCode = incident.ProductCode;
            string dateOpened = DateTime.Now.ToString("MM-dd-yyyy");
            string title = incident.Title;
            string description = incident.Description;

            SqlConnection sqlConn = TechSupportDB.GetConnection();
            string sqlStatement =
                "INSERT Incidents " +
                "(CustomerID, ProductCode, DateOpened, Title, Description) " +
                "VALUES (@CustomerID, @ProductCode, @DateOpened, @Title, @Description)";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConn);

            sqlCommand.Parameters.AddWithValue("@CustomerID", customerID);
            sqlCommand.Parameters.AddWithValue("@ProductCode", productCode);
            sqlCommand.Parameters.AddWithValue("@DateOpened", dateOpened);
            sqlCommand.Parameters.AddWithValue("@Title", title);
            sqlCommand.Parameters.AddWithValue("@Description", description);

            try
            {
                sqlConn.Open();
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        public static Incident GetIncident(int incidentID)
        {
            Incident incident = new Incident();

            SqlConnection sqlConnection = TechSupportDB.GetConnection();
            string sqlStatement =
                "SELECT IncidentID, CustomerID, Productcode, TechID, DateOpened, DateClosed, Title, Description " +
                "FROM Incidents " +
                "WHERE IncidentID = @IncidentID";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConnection);
            sqlCommand.Parameters.AddWithValue("@IncidentID", incidentID);

            try
            {
                sqlConnection.Open();

                using (var reader = sqlCommand.ExecuteReader())
                {
                    reader.Read();
                    incident.IncidentID = (int)reader["IncidentID"];
                    incident.CustomerID = (int)reader["CustomerID"];
                    incident.ProductCode = reader["ProductCode"].ToString();
                    if (!(reader["TechID"] is DBNull))
                    {
                        incident.TechID = (int)reader["TechID"];
                    }
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    if (!(reader["DateClosed"] is DBNull))
                    {
                        incident.DateClosed = (DateTime)reader["DateClosed"];
                    }
                    incident.Title = reader["Title"].ToString();
                    incident.Description = reader["Description"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return incident;
        }

        public static UpdateIncidentDescription(Incident incident)
        {
            
        }

        public static CloseIncident(Incident incident)
        {

        }
    }
}
