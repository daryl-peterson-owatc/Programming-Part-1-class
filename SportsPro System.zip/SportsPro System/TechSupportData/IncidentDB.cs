﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class IncidentDB
    {
        public static List<Incident> GetOpenIncidents()
        {
            List<Incident> incidentList = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " +
                "FROM Incidents" +
                "WHERE DateClosed IS NULL";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            try
            {
                connection.Open();
                int customerID;
                int techID;

                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Incident incident = new Incident();
                    incident.ProductCode = reader["ProductCode"].ToString();
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    customerID = (int)reader["CustomerID"];
                    incident.CustomerName = CustomerDB.GetCustomerName(customerID);
                    
                    if (reader["TechID"] == DBNull.Value)
                    {
                        incident.TechID = null;
                    }
                    else
                    {
                        techID = (int)reader["TechID"];
                        incident.TechName = TechnicianDB.GetTechnicianName(techID);
                    }

                    incident.Title = reader["Title"].ToString();

                    incidentList.Add(incident);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return incidentList;
        }


    }
}
