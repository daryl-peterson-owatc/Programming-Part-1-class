﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class IncidentDB
    {
        public static List<Incident> GetOpenIncidents()
        {
            List<Incident> incidentList = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " +
                "FROM Incidents" +
                "WHERE DateClosed IS NULL";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Incident incident = new Incident();
                    incident.CustomerID = (int)reader["CustomerID"];
                    
                    incident.ProductCode = reader["ProductCode"].ToString();
                    if (reader["TechID"] == DBNull.Value)
                    {
                        incident.TechID = null;
                    }
                    else
                    {
                        incident.TechID = (int)reader["TechID"];
                        //incident.TechName = TechnicianDB.GetTechnicianName((int)incident.TechID);
                    }
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    incident.Title = reader["Title"].ToString();
                    incidentList.Add(incident);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return incidentList;
        }


    }
}
