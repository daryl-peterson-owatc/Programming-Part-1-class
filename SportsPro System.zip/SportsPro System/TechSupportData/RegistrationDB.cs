﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class RegistrationDB
    {
        public static bool ProductRegistered(int customerID, string productCode)
        {
            bool registared = false;

            SqlConnection sqlConn = TechSupportDB.GetConnection();
            string sqlStatement =
                "SELECT Count(*) " +
                "FROM Registrations " +
                "WHERE CustomerID = @CustomerID " +
                    "AND ProductCode = @ProductCode";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConn);

            sqlCommand.Parameters.AddWithValue("@CustomerID", customerID);
            sqlCommand.Parameters.AddWithValue("@Productcode", productCode);

            try
            {
                sqlConn.Open();
                int isRegistared = sqlCommand.ExecuteNonQuery();
                if (isRegistared > 0)
                {
                    registared = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }

            return registared;
        }
    }
}
