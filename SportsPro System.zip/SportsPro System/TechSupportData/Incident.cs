﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    class Incident
    {
        private int incidentID;
        private int customerID;
        private string productCode;
        private int? techID;
        private DateTime dateOpened;
        private DateTime dateClosed;
        private string title;
        private string description;

        public int IncidentID { get; set; }

        public int CustomerID { get; set; }

        public string ProductCode { get; set; }

        public int? TechId
        {
            get
            {
                if (techID.HasValue)
                {
                    return techID;
                }
                else
                {
                    return null;
                }
            }

            set
            {
                techID = value;
            }
        }

        public DateTime DateOpened { get; set; }

        public DateTime DateClosed { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }


    }
}
