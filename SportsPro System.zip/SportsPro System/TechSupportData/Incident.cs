﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Incident
    {
        private int incidentID;
        private int customerID;
        private string customerName;
        private int? techID;
        private string techName;
        private string description;
        private string productCode;
        private string title;
        private DateTime dateClosed;
        private DateTime dateOpened;

        public int IncidentID { get; set; }

        public int CustomerID { get; set; }

        public string ProductCode { get; set; }

        public int? TechID
        {
            get
            {
                if (techID.HasValue)
                {
                    return techID;
                }
                else
                {
                    return null;
                }
            }

            set
            {
                techID = value;
            }
        }

        public DateTime DateOpened { get; set; }

        public DateTime DateClosed { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public string CustomerName { get; set; }
        //public string CustomerName
        //{
        //    get
        //    {
        //        string name = "";
        //        if (customerID !=0)
        //        {
        //            try
        //            {
        //                name = CustomerDB.GetCustomerName(Convert.ToInt32(customerID));
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //        }
        //        return name;
        //    }
        //    set { this.CustomerName = value; }
        //}

        public string TechName { get; set; }
        //public string TechName
        //{
        //    get
        //    {
        //        string name = "";
        //        if (techID.HasValue)
        //        {
        //            try
        //            {
        //                name = TechnicianDB.GetTechnicianName(Convert.ToInt32(techID));
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //        }
        //        return name;
        //    }
        //    set { this.TechName = value; }
        //}
    }
}
