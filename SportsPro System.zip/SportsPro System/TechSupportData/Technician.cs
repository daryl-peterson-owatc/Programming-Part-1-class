﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Technician
    {
        private int TechID;
        private string Name;
        private string Email;
        private string Phone;

        public string name { get; set; }
    }
}
