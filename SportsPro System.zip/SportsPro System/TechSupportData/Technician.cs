﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    class Technician
    {
        private int TechID;
        private string Name;
        private string Email;
        private string Phone;
    }
}
