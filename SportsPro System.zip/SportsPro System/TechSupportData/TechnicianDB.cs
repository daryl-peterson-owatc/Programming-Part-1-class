﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace TechSupportData
{
    public class TechnicianDB
    {
        public static string GetTechnicianName(int techID)
        {
            string name = "";

            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT Name " +
                "FROM Technicians " +
                "WHERE TechID = @TechID";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@TechID", techID);

            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return name;
        }
    }
}
