﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace TechSupportData
{
    class TechnicianDB
    {
        public static string GetTechnicianName(int techID)
        {
            string name = "";

            return name;
        }
    }
}
