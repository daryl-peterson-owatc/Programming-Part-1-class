﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Customer
    {
        private int customerID;
        private string name;

        public int CustomerID { get; set; }
        public string Name { get; set; }
    }
}
