﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Customer
    {
        private int CustomerID;
        private string Name;
        private string Address;
        private string City;
        private string State;
        private string ZipCode;
        private string Phone;
        private string Email;

    }
}
