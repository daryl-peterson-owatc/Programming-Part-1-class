﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechSupportData
{
    public class Customer
    {
        private int CustomerID;
        private string Name;
        private string Address;
        private string City;
        private string State;
        private string ZipCode;
        private string Phone;
        private string Email;

        public int Customer()
        {
        }

        public int CustomerID
        {

        }

        public string Name
        {

        }

        public string Address
        {

        }

        public string City
        {

        }

        public string State
        {

        }

        public string ZipCode
        {

        }

        public string Phone
        {

        }

        public string Email
        {

        }
    }
}
