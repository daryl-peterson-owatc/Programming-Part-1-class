﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace TechSupportData
{
    public class CustomerDB
    {
        public static string GetCustomerName(int customerID)
        {
            string name = "";

            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT Name " +
                "FROM Customers " +
                "WHERE CustomerID = @CustomerID";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@CustomerID", customerID);

            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return name;
        }
    }
}
