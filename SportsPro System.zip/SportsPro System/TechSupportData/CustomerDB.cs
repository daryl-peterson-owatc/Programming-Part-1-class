﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace TechSupportData
{
    public class CustomerDB
    {
        public static string GetCustomerName(int customerID)
        {
            string name = "";

            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT Name " +
                "FROM Customers " +
                "WHERE CustomerID = @CustomerID";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@CustomerID", customerID);

            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return name;
        }

        public static List<Customer> GetCustomerList()
        {
            var customerList = new List<Customer>();

            SqlConnection sqlConn = TechSupportDB.GetConnection();
            string sqlStatement =
                "SELECT CustomerID, Name " +
                "FROM Customers " +
                "ORDER BY Name";
            SqlCommand sqlCommand = new SqlCommand(sqlStatement, sqlConn);

            try
            {
                sqlConn.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Customer customer = new Customer();
                    customer.CustomerID = (int)reader["CustomerID"];
                    customer.Name = reader["Name"].ToString();

                    customerList.Add(customer);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }

            return customerList;
        }
    }
}
