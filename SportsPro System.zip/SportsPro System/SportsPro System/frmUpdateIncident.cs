﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;


namespace SportsPro_System
{
    public partial class frmUpdateIncident : Form
    {

        public frmUpdateIncident()
        {
            InitializeComponent();
        }

        private void getIncidentButton_Click(object sender, EventArgs e)
        {
            int incidentID;
            if (incidentIDTextBox.Text != null)
            {
                if (int.TryParse(incidentIDTextBox.Text, out incidentID))
                {
                    try
                    {
                        Incident incident = IncidentDB.GetIncident(incidentID);
                        customerTextBox.Text = CustomerDB.GetCustomerName(incident.CustomerID).ToString();
                        productTextBox.Text = ProductDB.GetProductName(incident.ProductCode).ToString();
                        if (incident.TechID.HasValue)
                        {
                            technicianTextBox.Text = TechnicianDB.GetTechnicianName(Convert.ToInt32(incident.TechID)).ToString();
                        }
                        titleTextBox.Text = incident.Title.ToString();
                        dateOpenedTextBox.Text = formatDate(incident.DateOpened);
                        descriptionTextBox.Text = incident.Description.ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Incident is not an integer number.", "Invalid Incident number");
                }
            }
            else
            {
                MessageBox.Show("Incident ID is Empty.", "No Incident number");
            }
                
        }

        private static string formatDate(DateTime date)
        {
            string newDate = date.ToString("MM-dd-yyyy");
            return newDate;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
