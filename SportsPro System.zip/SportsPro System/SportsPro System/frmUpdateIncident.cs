﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmUpdateIncident : Form
    {
        public const int MAX_TEXT_LENGTH = 2000;

        // set public properties
        public int IncidentID { get; set; }
        public string Desciption { get; set; }
        public string Text2Add { get; set; }
        public DateTime? DateClosed { get; set; }

        public frmUpdateIncident()
        {
            InitializeComponent();
        }

        private void getIncidentButton_Click(object sender, EventArgs e)
        {
            int incidentID;
            if (incidentIDTextBox.Text != null)
            {
                if (int.TryParse(incidentIDTextBox.Text, out incidentID))
                {
                    try
                    {
                        Incident incident = IncidentDB.GetIncident(incidentID);
                        if (incident.DateClosed.HasValue)
                        {
                            MessageBox.Show("Incident has already been closed.");
                        }
                        else
                        {
                            IncidentID = incidentID;
                            customerTextBox.Text = CustomerDB.GetCustomerName(incident.CustomerID).ToString();
                            productTextBox.Text = ProductDB.GetProductName(incident.ProductCode).ToString();
                            if (incident.TechID.HasValue)
                            {
                                technicianTextBox.Text = TechnicianDB.GetTechnicianName(Convert.ToInt32(incident.TechID)).ToString();
                            }
                            titleTextBox.Text = incident.Title.ToString();
                            dateOpenedTextBox.Text = formatDate(incident.DateOpened);
                            Desciption = incident.Description;
                            descriptionTextBox.Text = Desciption;

                            // enable the update and close incident buttons
                            updateButton.Enabled = true;
                            closeIncidentButton.Enabled = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Incident is not an integer number.", "Invalid Incident number");
                }
            }
            else
            {
                MessageBox.Show("Incident ID is Empty.", "No Incident number");
            }
                
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            string oldText = descriptionTextBox.Text;
            Text2Add = addNewText();
            string updatedText = oldText + Text2Add;
            int lengthOfUpdatedText = Validator.GetTextLength(addNewText(), oldText);
            if (Validator.textTooLong(MAX_TEXT_LENGTH, lengthOfUpdatedText))
            {
                MessageBox.Show("The length of the Description text box exceeds " + MAX_TEXT_LENGTH + " characters");
            }
            else
            {
                // requery the record to compare the description text
                Incident incident = IncidentDB.GetIncident(IncidentID);
                // if the description text is the same then add the additional text and save the record
                if (string.Equals(incident.Description, oldText, StringComparison.OrdinalIgnoreCase))
                {
                    bool success = IncidentDB.UpdateIncidentDescription(incident, updatedText);
                    if (!success)
                    {
                        MessageBox.Show("Incident was not saved.");
                    }
                    else
                    {
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Description was changed prior to save.\r\nUnable to update the Description.");
                }

            }
            descriptionTextBox.Text = updatedText;
        }

        private void closeIncidentButton_Click(object sender, EventArgs e)
        {
            DateTime date = DateTime.Now;
            string oldText = descriptionTextBox.Text;

            Incident incident = IncidentDB.GetIncident(IncidentID);
            if (string.Equals(incident.Description, oldText, StringComparison.OrdinalIgnoreCase))
            {
                bool success = IncidentDB.CloseIncident(incident, date);
                if (!success)
                {
                    MessageBox.Show("Incident was not saved.");
                }
                else
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Description was changed prior to save.\r\nUnable to close the Incident.");
            }
        }

        private string addNewText()
        {
            string newText = "\r\n<" + formatDate(DateTime.Now) +  "> " + text2AddTextBox.Text;
            return newText;
        }

        private static string formatDate(DateTime date)
        {
            string newDate = date.ToString("MM-dd-yyyy");
            return newDate;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
