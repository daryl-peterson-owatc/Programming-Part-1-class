﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;


namespace SportsPro_System
{
    public partial class frmUpdateIncident : Form
    {
        public frmUpdateIncident()
        {
            InitializeComponent();
        }

        private void getIncidentButton_Click(object sender, EventArgs e)
        {
            Incident incident = new Incident();

            int incidentID;
            if (incidentIDTextBox.Text != null)
            {
                if (int.TryParse(incidentIDTextBox.Text, out incidentID))
                {
                    try
                    {
                        incident = IncidentDB.GetIncident(incidentID);
                        customerTextBox.Text = CustomerDB.GetCustomerName(incident.CustomerID);
                        productTextBox.Text = ProductDB.GetProductName(incident.ProductCode);
                        if (incident.TechID != null)
                        {
                            technicianTextBox.Text = TechnicianDB.GetTechnicianName(Convert.ToInt32(incident.TechID));
                        }
                        titleTextBox.Text = incident.Title;
                        dateOpenedTextBox.Text = incident.DateOpened.ToString();
                        descriptionTextBox.Text = incident.Description;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Incident is not an integer number.", "Invalid Incident number");
                }
            }
            else
            {
                MessageBox.Show("Incident ID is Empty.", "No Incident number");
            }
                
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
