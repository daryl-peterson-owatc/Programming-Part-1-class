﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SportsPro_System
{
    public partial class frmCustomerMaintenance : Form
    {
        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.techSupportDataSet2B);

        }

        private void frmCustomerMaintenance_Load(object sender, EventArgs e)
        {
            Binding b = phoneTextBox.DataBindings["Text"];
            b.Format += FormatPhoneNumber;

            // TODO: This line of code loads data into the 'techSupportDataSet2B.States' table. You can move, or remove it, as needed.
            this.statesTableAdapter.Fill(this.techSupportDataSet2B.States);
            // TODO: This line of code loads data into the 'techSupportDataSet2B.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.techSupportDataSet2B.Customers);

        }

        private void bindingNavigatorCancelItem_Click(object sender, EventArgs e)
        {
            this.customersBindingSource.CancelEdit();
        }

        private void FormatPhoneNumber(object sender, ConvertEventArgs e)
        {
            if (e.Value.GetType().ToString() == "System.String")
            {
                string s = e.Value.ToString();
                if (s.Length == 10)
                {
                    e.Value = "(" + s.Substring(0, 3) + ") " +
                        s.Substring(3, 3) + "-" +
                        s.Substring(6, 4);
                }
            }
        }

        private void UnformatPhoneNumber(object sender, ConvertEventArgs e)
        {
            string s = e.Value.ToString();
            e.Value = s.Replace("(", "");
            e.Value = s.Replace(")", "");
            e.Value = s.Replace("-", "");
        }

        private bool IsInt64(string s)
        {
            try
            {
                Convert.ToInt64(s);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private void fillByCustomerIDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                int customerID = Convert.ToInt32(customerIDToolStripTextBox.Text);
                this.customersTableAdapter.FillByCustomerID(this.techSupportDataSet2B.Customers, customerID);
                //this.customersTableAdapter.FillByCustomerID(this.techSupportDataSet2B.Customers, ((int)(System.Convert.ChangeType(customerIDToolStripTextBox.Text, typeof(int)))));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }

        }
    }
}
