﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SportsPro_System
{
    public partial class frmCustomerMaintenance : Form
    {
        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.techSupportDataSet2B);

        }

        private void frmCustomerMaintenance_Load(object sender, EventArgs e)
        {
            Binding b = phoneTextBox.DataBindings["Text"];
            b.Format += FormatZipCode;
            b.Parse += UnformatZipCode;

            try
            {
                this.customersTableAdapter.Fill(this.techSupportDataSet2B.Customers);
                this.statesTableAdapter.Fill(this.techSupportDataSet2B.States);
            }
            catch (DBConcurrencyException)
            {
                MessageBox.Show("A concurrency error occured. " +
                    "The row was not update.", "Concurrency Exception");
            }
            catch (DataException ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
                this.customersBindingSource.CancelEdit();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": " + ex.Message, ex.GetType().ToString());
            }
        }

        private void bindingNavigatorCancelItem_Click(object sender, EventArgs e)
        {
            this.customersBindingSource.CancelEdit();
        }

        private void FormatZipCode(object sender, ConvertEventArgs e)
        {
            if (e.GetType().ToString() == "System.String")
            {
                string s = e.Value.ToString();
                if (IsInt64(s))
                {
                    if (s.Length == 9)
                    {
                        e.Value = s.Substring(0, 5) + "-" + s.Substring(5, 4);
                    }
                }
            }
        }

        private void UnformatZipCode(object sender, ConvertEventArgs e)
        {
            string s = e.Value.ToString();
            e.Value = s.Replace("-", "");
        }

        private bool IsInt64(string s)
        {
            try
            {
                Convert.ToInt64(s);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private void fillByCustomerIDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                int customerID = Convert.ToInt32(customerIDToolStripTextBox.Text);
                this.customersTableAdapter.FillByCustomerID(this.techSupportDataSet2B.Customers, customerID);
                //this.customersTableAdapter.FillByCustomerID(this.techSupportDataSet2B.Customers, ((int)(System.Convert.ChangeType(customerIDToolStripTextBox.Text, typeof(int)))));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private bool IsValidData()
        {
            if (customersBindingSource.Count > 0)
            {
                return
                    IsPresent(nameTextBox, "Name") &&
                    IsPresent(addressTextBox, "Address") &&
                    IsPresent(cityTextBox, "City") &&
                    IsPresent(stateComboBox, "State") &&
                    IsPresent(zipCodeTextBox, "Zip Code") &&
                    IsPresent(phoneTextBox, "Phone") &&
                    IsPresent(emailTextBox, "Email");
            }
            else
            {
                return true;
            }
        }

        private bool IsPresent(Control control, string name)
        {
            if (control.GetType().ToString() == "System.Windows.Forms.TextBox")
            {
                TextBox textBox = (TextBox)control;
                if (textBox.Text == "")
                {
                    MessageBox.Show(name + " is a required field.", "Entry Error");
                    textBox.Focus();
                    return false;
                }
            }
            else if (control.GetType().ToString() == "System.Windows.Forms.ComboBox")
            {
                ComboBox comboBox = (ComboBox)control;
                if (comboBox.SelectedIndex == -1)
                {
                    MessageBox.Show(name + " is a required field.", "Entry Error");
                    comboBox.Focus();
                    return false;
                }
            }
            return true;
        }
    }
}
