﻿namespace SportsPro_System
{
    partial class frmUpdateIncident
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.incidentIDTextBox = new System.Windows.Forms.TextBox();
            this.customerTextBox = new System.Windows.Forms.TextBox();
            this.productTextBox = new System.Windows.Forms.TextBox();
            this.technicianTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.dateOpenedTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.text2AddTextBox = new System.Windows.Forms.TextBox();
            this.incidentIDLabel = new System.Windows.Forms.Label();
            this.customerLabel = new System.Windows.Forms.Label();
            this.productLabel = new System.Windows.Forms.Label();
            this.technicianLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.dateOpenedLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.text2AddLabel = new System.Windows.Forms.Label();
            this.getIncidentButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.closeIncidentButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // incidentIDTextBox
            // 
            this.incidentIDTextBox.Location = new System.Drawing.Point(96, 25);
            this.incidentIDTextBox.Name = "incidentIDTextBox";
            this.incidentIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.incidentIDTextBox.TabIndex = 0;
            // 
            // customerTextBox
            // 
            this.customerTextBox.Location = new System.Drawing.Point(96, 59);
            this.customerTextBox.Name = "customerTextBox";
            this.customerTextBox.ReadOnly = true;
            this.customerTextBox.Size = new System.Drawing.Size(247, 20);
            this.customerTextBox.TabIndex = 1;
            // 
            // productTextBox
            // 
            this.productTextBox.Location = new System.Drawing.Point(96, 85);
            this.productTextBox.Name = "productTextBox";
            this.productTextBox.ReadOnly = true;
            this.productTextBox.Size = new System.Drawing.Size(247, 20);
            this.productTextBox.TabIndex = 2;
            // 
            // technicianTextBox
            // 
            this.technicianTextBox.Location = new System.Drawing.Point(96, 111);
            this.technicianTextBox.Name = "technicianTextBox";
            this.technicianTextBox.ReadOnly = true;
            this.technicianTextBox.Size = new System.Drawing.Size(247, 20);
            this.technicianTextBox.TabIndex = 3;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(96, 137);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.ReadOnly = true;
            this.titleTextBox.Size = new System.Drawing.Size(247, 20);
            this.titleTextBox.TabIndex = 4;
            // 
            // dateOpenedTextBox
            // 
            this.dateOpenedTextBox.Location = new System.Drawing.Point(96, 163);
            this.dateOpenedTextBox.Name = "dateOpenedTextBox";
            this.dateOpenedTextBox.ReadOnly = true;
            this.dateOpenedTextBox.Size = new System.Drawing.Size(100, 20);
            this.dateOpenedTextBox.TabIndex = 5;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(96, 189);
            this.descriptionTextBox.Multiline = true;
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.ReadOnly = true;
            this.descriptionTextBox.Size = new System.Drawing.Size(247, 112);
            this.descriptionTextBox.TabIndex = 6;
            // 
            // text2AddTextBox
            // 
            this.text2AddTextBox.Location = new System.Drawing.Point(96, 307);
            this.text2AddTextBox.Multiline = true;
            this.text2AddTextBox.Name = "text2AddTextBox";
            this.text2AddTextBox.Size = new System.Drawing.Size(247, 112);
            this.text2AddTextBox.TabIndex = 7;
            // 
            // incidentIDLabel
            // 
            this.incidentIDLabel.AutoSize = true;
            this.incidentIDLabel.Location = new System.Drawing.Point(28, 28);
            this.incidentIDLabel.Name = "incidentIDLabel";
            this.incidentIDLabel.Size = new System.Drawing.Size(62, 13);
            this.incidentIDLabel.TabIndex = 8;
            this.incidentIDLabel.Text = "Incident ID:";
            // 
            // customerLabel
            // 
            this.customerLabel.AutoSize = true;
            this.customerLabel.Location = new System.Drawing.Point(36, 62);
            this.customerLabel.Name = "customerLabel";
            this.customerLabel.Size = new System.Drawing.Size(54, 13);
            this.customerLabel.TabIndex = 9;
            this.customerLabel.Text = "Customer:";
            // 
            // productLabel
            // 
            this.productLabel.AutoSize = true;
            this.productLabel.Location = new System.Drawing.Point(43, 88);
            this.productLabel.Name = "productLabel";
            this.productLabel.Size = new System.Drawing.Size(47, 13);
            this.productLabel.TabIndex = 10;
            this.productLabel.Text = "Product:";
            // 
            // technicianLabel
            // 
            this.technicianLabel.AutoSize = true;
            this.technicianLabel.Location = new System.Drawing.Point(27, 114);
            this.technicianLabel.Name = "technicianLabel";
            this.technicianLabel.Size = new System.Drawing.Size(63, 13);
            this.technicianLabel.TabIndex = 11;
            this.technicianLabel.Text = "Technician:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(60, 140);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 12;
            this.titleLabel.Text = "Title:";
            // 
            // dateOpenedLabel
            // 
            this.dateOpenedLabel.AutoSize = true;
            this.dateOpenedLabel.Location = new System.Drawing.Point(16, 166);
            this.dateOpenedLabel.Name = "dateOpenedLabel";
            this.dateOpenedLabel.Size = new System.Drawing.Size(74, 13);
            this.dateOpenedLabel.TabIndex = 13;
            this.dateOpenedLabel.Text = "Date Opened:";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(27, 192);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(63, 13);
            this.descriptionLabel.TabIndex = 14;
            this.descriptionLabel.Text = "Description:";
            // 
            // text2AddLabel
            // 
            this.text2AddLabel.AutoSize = true;
            this.text2AddLabel.Location = new System.Drawing.Point(26, 310);
            this.text2AddLabel.Name = "text2AddLabel";
            this.text2AddLabel.Size = new System.Drawing.Size(64, 13);
            this.text2AddLabel.TabIndex = 15;
            this.text2AddLabel.Text = "Text to add:";
            // 
            // getIncidentButton
            // 
            this.getIncidentButton.Location = new System.Drawing.Point(215, 23);
            this.getIncidentButton.Name = "getIncidentButton";
            this.getIncidentButton.Size = new System.Drawing.Size(75, 23);
            this.getIncidentButton.TabIndex = 16;
            this.getIncidentButton.Text = "Get Incident";
            this.getIncidentButton.UseVisualStyleBackColor = true;
            this.getIncidentButton.Click += new System.EventHandler(this.getIncidentButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.Enabled = false;
            this.updateButton.Location = new System.Drawing.Point(96, 438);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(75, 23);
            this.updateButton.TabIndex = 17;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            // 
            // closeIncidentButton
            // 
            this.closeIncidentButton.Enabled = false;
            this.closeIncidentButton.Location = new System.Drawing.Point(177, 438);
            this.closeIncidentButton.Name = "closeIncidentButton";
            this.closeIncidentButton.Size = new System.Drawing.Size(85, 23);
            this.closeIncidentButton.TabIndex = 18;
            this.closeIncidentButton.Text = "Close Incident";
            this.closeIncidentButton.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(268, 438);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 19;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // frmUpdateIncident
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 482);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.closeIncidentButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.getIncidentButton);
            this.Controls.Add(this.text2AddLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.dateOpenedLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.technicianLabel);
            this.Controls.Add(this.productLabel);
            this.Controls.Add(this.customerLabel);
            this.Controls.Add(this.incidentIDLabel);
            this.Controls.Add(this.text2AddTextBox);
            this.Controls.Add(this.descriptionTextBox);
            this.Controls.Add(this.dateOpenedTextBox);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.technicianTextBox);
            this.Controls.Add(this.productTextBox);
            this.Controls.Add(this.customerTextBox);
            this.Controls.Add(this.incidentIDTextBox);
            this.Name = "frmUpdateIncident";
            this.Text = "Update Incident";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox incidentIDTextBox;
        private System.Windows.Forms.TextBox customerTextBox;
        private System.Windows.Forms.TextBox productTextBox;
        private System.Windows.Forms.TextBox technicianTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox dateOpenedTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox text2AddTextBox;
        private System.Windows.Forms.Label incidentIDLabel;
        private System.Windows.Forms.Label customerLabel;
        private System.Windows.Forms.Label productLabel;
        private System.Windows.Forms.Label technicianLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label dateOpenedLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label text2AddLabel;
        private System.Windows.Forms.Button getIncidentButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button closeIncidentButton;
        private System.Windows.Forms.Button cancelButton;
    }
}