﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmOpenIncidents : Form
    {
        public frmOpenIncidents()
        {
            InitializeComponent();
        }

        private void frmOpenIncidents_Load(object sender, EventArgs e)
        {
            List<Incident> incidentList = new List<Incident>();

            try
            {
                incidentList = IncidentDB.GetOpenIncidents();

                if (incidentList.Count > 0)
                {
                    foreach (var incItem in incidentList)
                    {
                        ListViewItem incidentRow = new ListViewItem(incItem.ProductCode);
                        incidentRow.SubItems.Add(GetDateFromDatetime(incItem.DateOpened));
                        incidentRow.SubItems.Add(incItem.CustomerName);
                        incidentRow.SubItems.Add(incItem.TechName);
                        incidentRow.SubItems.Add(incItem.Title);
                        openIncidentsListView.Items.Add(incidentRow);
                    }
                }
                else
                {
                    MessageBox.Show("All Incidents have been closed.", "No Open Incidents");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private static string GetDateFromDatetime(DateTime datevalue)
        {
            return datevalue.ToShortDateString();
        }
    }
}
