﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmOpenIncidents : Form
    {
        public frmOpenIncidents()
        {
            InitializeComponent();
        }

        private Incident incident;
        private IncidentDB incidentDB;
        private List<Incident> incidentList;
        private CurrencyManager cm;

        private void frmOpenIncidents_Load(object sender, EventArgs e)
        {
            
        }
    }
}
