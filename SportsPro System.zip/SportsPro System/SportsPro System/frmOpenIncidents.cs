﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmOpenIncidents : Form
    {
        public frmOpenIncidents()
        {
            InitializeComponent();
        }

        private void frmOpenIncidents_Load(object sender, EventArgs e)
        {
            List<Incident> incidentList = new List<Incident>();

            try
            {
                incidentList = IncidentDB.GetOpenIncidents();

                if (incidentList.Count > 0)
                {
                    foreach (string incItem in incidentList)
                    {

                    }
                }
            }
            catch (Exception ex)
            {

            }


        }
    }
}
