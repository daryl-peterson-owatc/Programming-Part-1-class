﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmTechnicianIncidents : Form
    {
        public frmTechnicianIncidents()
        {
            InitializeComponent();
        }

        private void fillTechComboBox()
        {
            try
            {
                List<Technician> technicianList = TechnicianDB.GetTechnicianList();
                foreach (Technician) name in technicianList)
                {
                    ComboboxItem item = new ComboboxItem();
                    item.Text = name.Name;
                    item.Value = name.CustomerID;
                    customerComboBox.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Customer error: " + ex.Message);
            }
        }

        public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}
