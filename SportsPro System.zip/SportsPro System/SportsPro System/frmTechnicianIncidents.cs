﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmTechnicianIncidents : Form
    {
        public frmTechnicianIncidents()
        {
            InitializeComponent();
        }

        private void frmTechnicianIncidents_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'techSupportDataSet.Incidents' table. You can move, or remove it, as needed.
            this.incidentsTableAdapter.Fill(this.techSupportDataSet.Incidents);
            // TODO: This line of code loads data into the 'techSupportDataSet.Technicians' table. You can move, or remove it, as needed.
            this.techniciansTableAdapter.Fill(this.techSupportDataSet.Technicians);
            //fillTechComboBox();
        }

        //private void fillTechComboBox()
        //{
        //    try
        //    {
        //        List<Technician> technicianList = TechnicianDB.GetTechnicianList();
        //        foreach (Technician name in technicianList)
        //        {
        //            ComboboxItem item = new ComboboxItem();
        //            item.Text = name.Name;
        //            item.Value = name.TechID;
        //            technicianComboBox.Items.Add(item);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Technician error: " + ex.Message);
        //    }
        //}

        public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        //private void technicianComboBox_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    MessageBox.Show("Item value: " + technicianComboBox.SelectedItem);
        //}

        private void techniciansBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.techniciansBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.techSupportDataSet);

        }
    }
}
