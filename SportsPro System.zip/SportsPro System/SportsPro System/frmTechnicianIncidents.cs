﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmTechnicianIncidents : Form
    {
        private Technician technician;
        private List<Technician> technicianList;

        public frmTechnicianIncidents()
        {
            InitializeComponent();
        }

        private void frmTechnicianIncidents_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'techSupportDataSet.Incidents' table. You can move, or remove it, as needed.
            //this.incidentsTableAdapter.Fill(this.techSupportDataSet.Incidents);
            // TODO: This line of code loads data into the 'techSupportDataSet.Technicians' table. You can move, or remove it, as needed.
            //this.techniciansTableAdapter.Fill(this.techSupportDataSet.Technicians);
            fillTechComboBox();
            GetTechnicianData();
        }

        private void fillTechComboBox()
        {
            try
            {
                technicianList = TechnicianDB.GetTechnicianList();
                nameComboBox.DataSource = technicianList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        private void techniciansBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.techniciansBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.techSupportDataSet);

        }

        private void GetTechnicianData()
        {
            MessageBox.Show("Tech ID: " + nameComboBox.SelectedValue);
            try
            {
                int techID = (int)nameComboBox.SelectedValue;
                technician = TechnicianDB.GetTechnician(techID);
                techniciansBindingSource.Clear();
                techniciansBindingSource.Add(technician);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void nameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetTechnicianData();
        }
    }
}
