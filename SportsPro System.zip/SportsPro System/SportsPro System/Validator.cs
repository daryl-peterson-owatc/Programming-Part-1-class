﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsPro_System
{
    class Validator
    {
        public static bool IsPresent(frmCreateIncident frm)
        {
            bool valid = true;
            
            return valid;
        }
    }
}
