﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro_System
{
    class Validator
    {
        public static bool IsPresent(TextBox textBox, string name)
        {
            bool valid = false;
            return valid;
        }
    }
}
