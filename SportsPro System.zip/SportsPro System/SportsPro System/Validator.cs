﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsPro_System
{
    public class Validator
    {
        public static bool IsPresent(frmCreateIncident frm)
        {
            bool valid = true;

            if (frm.CustomerID == 0) { valid = false; }
            if (frm.ProductID == null) { valid = false; }
            if (frm.Title == null) { valid = false; }
            if (frm.Description == null) { valid = false; }

            return valid;
        }

        public static int GetTextLength(string newText, string oldText)
        {
            return (newText.Length + oldText.Length);
        }

        public static bool textTooLong(int maxLength, int currentLength)
        {
            bool tooLong = false;
            if (currentLength > maxLength) { tooLong = true; }
            return tooLong;
        }
    }
}
