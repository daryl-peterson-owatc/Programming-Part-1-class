﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsPro_System
{
    class Validator
    {
        public static bool IsPresent(frmCreateIncident frm)
        {
            bool valid = true;

            if (frm.CustomerID == 0) { valid = false; }
            if (frm.ProductID == null) { valid = false; }
            if (frm.Title == null) { valid = false; }
            if (frm.Description == null) { valid = false; }

            return valid;
        }
    }
}
