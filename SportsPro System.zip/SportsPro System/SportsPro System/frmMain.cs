﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro_System
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void maintainProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductMaintenance fpm = new frmProductMaintenance();
            fpm.ShowDialog();
        }

        private void maintainCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCustomerMaintenance fcm = new frmCustomerMaintenance();
                fcm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void displayIncidentsByProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductIncidents fpi = new frmProductIncidents();
            fpi.ShowDialog();
        }

        private void displayOpenIncidentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmOpenIncidents foi = new frmOpenIncidents();
            foi.ShowDialog();
        }

        private void createIncidentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCreateIncident cind = new frmCreateIncident();
            cind.ShowDialog();
        }
    }
}
