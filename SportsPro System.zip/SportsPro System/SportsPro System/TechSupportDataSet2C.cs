﻿namespace SportsPro_System
{


    partial class TechSupportDataSet2C
    {
    }
}

namespace SportsPro_System.TechSupportDataSet2CTableAdapters {
    
    
    public partial class IncidentsTableAdapter {
    }
}
