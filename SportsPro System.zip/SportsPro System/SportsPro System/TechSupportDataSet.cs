﻿namespace SportsPro_System
{


    partial class TechSupportDataSet
    {
    }
}
