﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmCreateIncident : Form
    {
        public string Title
        {
            get { return titleTextBox.Text.Trim(); }
            set { titleTextBox.Text = value; }
        }

        public string Description
        {
            get { return descriptionTextBox.Text.Trim(); }
            set { descriptionTextBox.Text = value; }
        }

        //public int CustomerID
        //{
        //    get { return customerComboBox.ValueMember }
        //}

        public frmCreateIncident()
        {
            InitializeComponent();
        }

        private void frmCreateIncident_Load(object sender, EventArgs e)
        {
            fillCustomerComboBox();
            fillProductComboBox();
        }

        private void fillCustomerComboBox()
        {
            try
            {
                MessageBox.Show("Attempting to load the Customer ComboBox.");
                List<Customer> customerList = CustomerDB.GetCustomerList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Customer error: " + ex.Message);
            }
        }

        private void fillProductComboBox()
        {
            try
            {
                MessageBox.Show("Attempting to load the Products ComboBox.");
                List<Product> productList = ProductDB.GetProductList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Product error: " + ex.Message);
            }
        }

        private void createIncidentButton_Click(object sender, EventArgs e)
        {
            bool isGood = Validator.IsPresent(this);
        }

        public static bool checkRequiredFields()
        {
            bool allFieldsAreGood = true;
            List<Control> controlList = new List<Control>() { };
            

            return allFieldsAreGood;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
