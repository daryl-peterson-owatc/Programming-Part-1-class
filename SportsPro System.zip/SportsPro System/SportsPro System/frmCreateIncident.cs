﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro_System
{
    public partial class frmCreateIncident : Form
    {
        public int CustomerID { get; set; }
        public string ProductID { get; set; }
        public string Title
        {
            get { return titleTextBox.Text.Trim(); }
            set { titleTextBox.Text = value; }
        }

        public string Description
        {
            get { return descriptionTextBox.Text.Trim(); }
            set { descriptionTextBox.Text = value; }
        }

        //public int CustomerID
        //{
        //    get { return customerComboBox.ValueMember }
        //}

        public frmCreateIncident()
        {
            InitializeComponent();
        }

        private void frmCreateIncident_Load(object sender, EventArgs e)
        {
            fillCustomerComboBox();
            fillProductComboBox();
        }

        private void fillCustomerComboBox()
        {
            try
            {
                List<Customer> customerList = CustomerDB.GetCustomerList();
                foreach (Customer name in customerList)
                {
                    ComboboxItem item = new ComboboxItem();
                    item.Text = name.Name;
                    item.Value = name.CustomerID;
                    customerComboBox.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Customer error: " + ex.Message);
            }
        }

        private void fillProductComboBox()
        {
            try
            {
                //MessageBox.Show("Attempting to load the Products ComboBox.");
                List<Product> productList = ProductDB.GetProductList();
                foreach (Product prod in productList)
                {
                    ComboboxItem item = new ComboboxItem();
                    item.Text = prod.Name;
                    item.Value = prod.Productcode;
                    productComboBox.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Product error: " + ex.Message);
            }
        }

        private void customerComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.CustomerID = (int)(customerComboBox.SelectedItem as ComboboxItem).Value;
        }

        private void productComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ProductID = (productComboBox.SelectedItem as ComboboxItem).Value.ToString();
        }

        private void createIncidentButton_Click(object sender, EventArgs e)
        {
            bool isGood = Validator.IsPresent(this);
            if (isGood)
            {
                Incident incident = new Incident();
                incident.CustomerID = this.CustomerID;
                incident.ProductCode = this.ProductID;
                incident.Title = this.Title;
                incident.Description = this.Description;

                try
                {
                    IncidentDB.AddIncident(incident);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("All fields are required.\nPlease try again.");
            }
        }

        public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
