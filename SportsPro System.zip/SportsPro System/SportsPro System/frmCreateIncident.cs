﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro_System
{
    public partial class frmCreateIncident : Form
    {
        public string Title
        {
            get { return titleTextBox.Text.Trim(); }
            set { titleTextBox.Text = value; }
        }

        public string Description { get; set; }

        public frmCreateIncident()
        {
            InitializeComponent();
        }

        private void fillCustomerComboBox()
        {

        }

        private void fillProductComboBox()
        {

        }

        private void createIncidentButton_Click(object sender, EventArgs e)
        {
            bool isGood = Validator.IsPresent(this);
        }

        public static bool checkRequiredFields()
        {
            bool allFieldsAreGood = true;
            List<Control> controlList = new List<Control>() { };
            

            return allFieldsAreGood;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
