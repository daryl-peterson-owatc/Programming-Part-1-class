﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro_System
{
    public partial class frmCustomerIncidents : Form
    {
        TechSupportDataContext support = new TechSupportDataContext();

        public frmCustomerIncidents()
        {
            InitializeComponent();
        }

        private void frmCustomerIncidents_Load(object sender, EventArgs e)
        {
            var customers = from customer in support.SQLCustomers
                            orderby customer.Name
                            select new { customer.CustomerID, customer.Name };

            nameComboBox.DataSource = customers;
        }

        private void nameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetCustomerIncidents();
        }

        private void GetCustomerIncidents()
        {
            var selectedCustomer =
                (from customer in support.SQLCustomers
                 where customer.CustomerID == (int)nameComboBox.SelectedValue
                 select customer).Single();

            sQLCustomerBindingSource.Clear();
            sQLCustomerBindingSource.Add(selectedCustomer);

            sQLIncidentBindingSource.DataSource = selectedCustomer.SQLIncidents;
        }
    }
}
