﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PayablesData;

namespace PaymentEntry
{
    public partial class frmVendorInvoices : Form
    {
        private Vendor vendor;
        private List<Vendor> vendorList;
        private List<Invoice> invoiceList;

        public frmVendorInvoices()
        {
            InitializeComponent();
        }

        private void frmVendorInvoices_Load(object sender, EventArgs e)
        {
            this.GetVendorList();
            this.GetVendorData();
        }

        private void GetVendorList()
        {
            try
            {
                // Get the list of Vendor objects
                // and bind the combo box to the list
                vendorList = VendorDB.GetVendorsWithBalanceDue();
                nameComboBox.DataSource = vendorList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void GetVendorData()
        {
            int vendorID = (int)nameComboBox.SelectedValue;
            try
            {
                // Get a Vendor object for the selected vendor
                // and bind the text boxes to theobject
                vendor = VendorDB.GetVendorNameAndAddress(vendorID);
                vendorBindingSource.Clear();
                vendorBindingSource.Add(vendor);

                // Get the list of INvoices objects
                // and bind the DataGridView control to the list
                invoiceList = InvoiceDB.GetUnpaidVendorInvoices(vendorID);
                invoiceDataGridView.DataSource = invoiceList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void nameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetVendorData();
        }
    }
}
