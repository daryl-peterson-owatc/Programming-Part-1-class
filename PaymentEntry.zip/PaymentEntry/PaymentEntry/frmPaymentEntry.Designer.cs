﻿namespace PaymentEntry
{
    partial class frmPaymentEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label balanceDueLabel;
            System.Windows.Forms.Label creditTotalLabel;
            System.Windows.Forms.Label dueDateLabel;
            System.Windows.Forms.Label invoiceDateLabel;
            System.Windows.Forms.Label invoiceIDLabel;
            System.Windows.Forms.Label invoiceNumberLabel;
            System.Windows.Forms.Label invoiceTotalLabel;
            System.Windows.Forms.Label paymentDateLabel;
            System.Windows.Forms.Label paymentTotalLabel;
            System.Windows.Forms.Label vendorIDLabel;
            System.Windows.Forms.Label termsIDLabel;
            System.Windows.Forms.Label vendorIDLabel1;
            this.invoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.balanceDueTextBox = new System.Windows.Forms.TextBox();
            this.creditTotalTextBox = new System.Windows.Forms.TextBox();
            this.dueDateTextBox = new System.Windows.Forms.TextBox();
            this.invoiceDateTextBox = new System.Windows.Forms.TextBox();
            this.invoiceIDTextBox = new System.Windows.Forms.TextBox();
            this.invoiceNumberTextBox = new System.Windows.Forms.TextBox();
            this.invoiceTotalTextBox = new System.Windows.Forms.TextBox();
            this.paymentDateTextBox = new System.Windows.Forms.TextBox();
            this.paymentTotalTextBox = new System.Windows.Forms.TextBox();
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.paymentLabel = new System.Windows.Forms.Label();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.termsIDTextBox = new System.Windows.Forms.TextBox();
            this.vendorIDTextBox = new System.Windows.Forms.TextBox();
            balanceDueLabel = new System.Windows.Forms.Label();
            creditTotalLabel = new System.Windows.Forms.Label();
            dueDateLabel = new System.Windows.Forms.Label();
            invoiceDateLabel = new System.Windows.Forms.Label();
            invoiceIDLabel = new System.Windows.Forms.Label();
            invoiceNumberLabel = new System.Windows.Forms.Label();
            invoiceTotalLabel = new System.Windows.Forms.Label();
            paymentDateLabel = new System.Windows.Forms.Label();
            paymentTotalLabel = new System.Windows.Forms.Label();
            vendorIDLabel = new System.Windows.Forms.Label();
            termsIDLabel = new System.Windows.Forms.Label();
            vendorIDLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // balanceDueLabel
            // 
            balanceDueLabel.AutoSize = true;
            balanceDueLabel.Location = new System.Drawing.Point(308, 95);
            balanceDueLabel.Name = "balanceDueLabel";
            balanceDueLabel.Size = new System.Drawing.Size(72, 13);
            balanceDueLabel.TabIndex = 0;
            balanceDueLabel.Text = "Balance Due:";
            // 
            // creditTotalLabel
            // 
            creditTotalLabel.AutoSize = true;
            creditTotalLabel.Location = new System.Drawing.Point(316, 69);
            creditTotalLabel.Name = "creditTotalLabel";
            creditTotalLabel.Size = new System.Drawing.Size(64, 13);
            creditTotalLabel.TabIndex = 2;
            creditTotalLabel.Text = "Credit Total:";
            // 
            // dueDateLabel
            // 
            dueDateLabel.AutoSize = true;
            dueDateLabel.Location = new System.Drawing.Point(324, 121);
            dueDateLabel.Name = "dueDateLabel";
            dueDateLabel.Size = new System.Drawing.Size(56, 13);
            dueDateLabel.TabIndex = 4;
            dueDateLabel.Text = "Due Date:";
            // 
            // invoiceDateLabel
            // 
            invoiceDateLabel.AutoSize = true;
            invoiceDateLabel.Location = new System.Drawing.Point(26, 95);
            invoiceDateLabel.Name = "invoiceDateLabel";
            invoiceDateLabel.Size = new System.Drawing.Size(71, 13);
            invoiceDateLabel.TabIndex = 6;
            invoiceDateLabel.Text = "Invoice Date:";
            // 
            // invoiceIDLabel
            // 
            invoiceIDLabel.AutoSize = true;
            invoiceIDLabel.Location = new System.Drawing.Point(321, 43);
            invoiceIDLabel.Name = "invoiceIDLabel";
            invoiceIDLabel.Size = new System.Drawing.Size(59, 13);
            invoiceIDLabel.TabIndex = 8;
            invoiceIDLabel.Text = "Invoice ID:";
            invoiceIDLabel.Visible = false;
            // 
            // invoiceNumberLabel
            // 
            invoiceNumberLabel.AutoSize = true;
            invoiceNumberLabel.Location = new System.Drawing.Point(12, 69);
            invoiceNumberLabel.Name = "invoiceNumberLabel";
            invoiceNumberLabel.Size = new System.Drawing.Size(85, 13);
            invoiceNumberLabel.TabIndex = 10;
            invoiceNumberLabel.Text = "Invoice Number:";
            // 
            // invoiceTotalLabel
            // 
            invoiceTotalLabel.AutoSize = true;
            invoiceTotalLabel.Location = new System.Drawing.Point(25, 121);
            invoiceTotalLabel.Name = "invoiceTotalLabel";
            invoiceTotalLabel.Size = new System.Drawing.Size(72, 13);
            invoiceTotalLabel.TabIndex = 12;
            invoiceTotalLabel.Text = "Invoice Total:";
            // 
            // paymentDateLabel
            // 
            paymentDateLabel.AutoSize = true;
            paymentDateLabel.Location = new System.Drawing.Point(280, 147);
            paymentDateLabel.Name = "paymentDateLabel";
            paymentDateLabel.Size = new System.Drawing.Size(100, 13);
            paymentDateLabel.TabIndex = 14;
            paymentDateLabel.Text = "Last Payment Date:";
            // 
            // paymentTotalLabel
            // 
            paymentTotalLabel.AutoSize = true;
            paymentTotalLabel.Location = new System.Drawing.Point(19, 147);
            paymentTotalLabel.Name = "paymentTotalLabel";
            paymentTotalLabel.Size = new System.Drawing.Size(78, 13);
            paymentTotalLabel.TabIndex = 16;
            paymentTotalLabel.Text = "Payment Total:";
            // 
            // vendorIDLabel
            // 
            vendorIDLabel.AutoSize = true;
            vendorIDLabel.Location = new System.Drawing.Point(53, 17);
            vendorIDLabel.Name = "vendorIDLabel";
            vendorIDLabel.Size = new System.Drawing.Size(44, 13);
            vendorIDLabel.TabIndex = 20;
            vendorIDLabel.Text = "Vendor:";
            // 
            // invoiceBindingSource
            // 
            this.invoiceBindingSource.DataSource = typeof(PayablesData.Invoice);
            // 
            // balanceDueTextBox
            // 
            this.balanceDueTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "BalanceDue", true));
            this.balanceDueTextBox.Location = new System.Drawing.Point(386, 92);
            this.balanceDueTextBox.Name = "balanceDueTextBox";
            this.balanceDueTextBox.ReadOnly = true;
            this.balanceDueTextBox.Size = new System.Drawing.Size(154, 20);
            this.balanceDueTextBox.TabIndex = 1;
            // 
            // creditTotalTextBox
            // 
            this.creditTotalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "CreditTotal", true));
            this.creditTotalTextBox.Location = new System.Drawing.Point(386, 66);
            this.creditTotalTextBox.Name = "creditTotalTextBox";
            this.creditTotalTextBox.ReadOnly = true;
            this.creditTotalTextBox.Size = new System.Drawing.Size(154, 20);
            this.creditTotalTextBox.TabIndex = 3;
            // 
            // dueDateTextBox
            // 
            this.dueDateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "DueDate", true));
            this.dueDateTextBox.Location = new System.Drawing.Point(386, 118);
            this.dueDateTextBox.Name = "dueDateTextBox";
            this.dueDateTextBox.ReadOnly = true;
            this.dueDateTextBox.Size = new System.Drawing.Size(154, 20);
            this.dueDateTextBox.TabIndex = 5;
            // 
            // invoiceDateTextBox
            // 
            this.invoiceDateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "InvoiceDate", true));
            this.invoiceDateTextBox.Location = new System.Drawing.Point(103, 92);
            this.invoiceDateTextBox.Name = "invoiceDateTextBox";
            this.invoiceDateTextBox.ReadOnly = true;
            this.invoiceDateTextBox.Size = new System.Drawing.Size(154, 20);
            this.invoiceDateTextBox.TabIndex = 7;
            // 
            // invoiceIDTextBox
            // 
            this.invoiceIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "InvoiceID", true));
            this.invoiceIDTextBox.Location = new System.Drawing.Point(386, 40);
            this.invoiceIDTextBox.Name = "invoiceIDTextBox";
            this.invoiceIDTextBox.ReadOnly = true;
            this.invoiceIDTextBox.Size = new System.Drawing.Size(154, 20);
            this.invoiceIDTextBox.TabIndex = 9;
            this.invoiceIDTextBox.Visible = false;
            // 
            // invoiceNumberTextBox
            // 
            this.invoiceNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "InvoiceNumber", true));
            this.invoiceNumberTextBox.Location = new System.Drawing.Point(103, 66);
            this.invoiceNumberTextBox.Name = "invoiceNumberTextBox";
            this.invoiceNumberTextBox.ReadOnly = true;
            this.invoiceNumberTextBox.Size = new System.Drawing.Size(154, 20);
            this.invoiceNumberTextBox.TabIndex = 11;
            // 
            // invoiceTotalTextBox
            // 
            this.invoiceTotalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "InvoiceTotal", true));
            this.invoiceTotalTextBox.Location = new System.Drawing.Point(103, 118);
            this.invoiceTotalTextBox.Name = "invoiceTotalTextBox";
            this.invoiceTotalTextBox.ReadOnly = true;
            this.invoiceTotalTextBox.Size = new System.Drawing.Size(154, 20);
            this.invoiceTotalTextBox.TabIndex = 13;
            // 
            // paymentDateTextBox
            // 
            this.paymentDateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "PaymentDate", true));
            this.paymentDateTextBox.Location = new System.Drawing.Point(386, 144);
            this.paymentDateTextBox.Name = "paymentDateTextBox";
            this.paymentDateTextBox.ReadOnly = true;
            this.paymentDateTextBox.Size = new System.Drawing.Size(154, 20);
            this.paymentDateTextBox.TabIndex = 15;
            // 
            // paymentTotalTextBox
            // 
            this.paymentTotalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "PaymentTotal", true));
            this.paymentTotalTextBox.Location = new System.Drawing.Point(103, 144);
            this.paymentTotalTextBox.Name = "paymentTotalTextBox";
            this.paymentTotalTextBox.ReadOnly = true;
            this.paymentTotalTextBox.Size = new System.Drawing.Size(154, 20);
            this.paymentTotalTextBox.TabIndex = 17;
            // 
            // txtVendor
            // 
            this.txtVendor.Location = new System.Drawing.Point(103, 14);
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.ReadOnly = true;
            this.txtVendor.Size = new System.Drawing.Size(437, 20);
            this.txtVendor.TabIndex = 21;
            // 
            // txtPayment
            // 
            this.txtPayment.Location = new System.Drawing.Point(256, 203);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(154, 20);
            this.txtPayment.TabIndex = 22;
            // 
            // paymentLabel
            // 
            this.paymentLabel.AutoSize = true;
            this.paymentLabel.Location = new System.Drawing.Point(160, 206);
            this.paymentLabel.Name = "paymentLabel";
            this.paymentLabel.Size = new System.Drawing.Size(90, 13);
            this.paymentLabel.TabIndex = 23;
            this.paymentLabel.Text = "Payment Amount:";
            // 
            // btnAccept
            // 
            this.btnAccept.Location = new System.Drawing.Point(103, 253);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(75, 23);
            this.btnAccept.TabIndex = 24;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(386, 253);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 25;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // termsIDLabel
            // 
            termsIDLabel.AutoSize = true;
            termsIDLabel.Location = new System.Drawing.Point(327, 173);
            termsIDLabel.Name = "termsIDLabel";
            termsIDLabel.Size = new System.Drawing.Size(53, 13);
            termsIDLabel.TabIndex = 25;
            termsIDLabel.Text = "Terms ID:";
            termsIDLabel.Visible = false;
            // 
            // termsIDTextBox
            // 
            this.termsIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "TermsID", true));
            this.termsIDTextBox.Location = new System.Drawing.Point(386, 170);
            this.termsIDTextBox.Name = "termsIDTextBox";
            this.termsIDTextBox.ReadOnly = true;
            this.termsIDTextBox.Size = new System.Drawing.Size(154, 20);
            this.termsIDTextBox.TabIndex = 26;
            this.termsIDTextBox.Visible = false;
            // 
            // vendorIDLabel1
            // 
            vendorIDLabel1.AutoSize = true;
            vendorIDLabel1.Location = new System.Drawing.Point(40, 43);
            vendorIDLabel1.Name = "vendorIDLabel1";
            vendorIDLabel1.Size = new System.Drawing.Size(58, 13);
            vendorIDLabel1.TabIndex = 26;
            vendorIDLabel1.Text = "Vendor ID:";
            vendorIDLabel1.Visible = false;
            // 
            // vendorIDTextBox
            // 
            this.vendorIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "VendorID", true));
            this.vendorIDTextBox.Location = new System.Drawing.Point(104, 40);
            this.vendorIDTextBox.Name = "vendorIDTextBox";
            this.vendorIDTextBox.ReadOnly = true;
            this.vendorIDTextBox.Size = new System.Drawing.Size(153, 20);
            this.vendorIDTextBox.TabIndex = 27;
            this.vendorIDTextBox.Visible = false;
            // 
            // frmPaymentEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 299);
            this.Controls.Add(vendorIDLabel1);
            this.Controls.Add(this.vendorIDTextBox);
            this.Controls.Add(termsIDLabel);
            this.Controls.Add(this.termsIDTextBox);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.paymentLabel);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(balanceDueLabel);
            this.Controls.Add(this.balanceDueTextBox);
            this.Controls.Add(creditTotalLabel);
            this.Controls.Add(this.creditTotalTextBox);
            this.Controls.Add(dueDateLabel);
            this.Controls.Add(this.dueDateTextBox);
            this.Controls.Add(invoiceDateLabel);
            this.Controls.Add(this.invoiceDateTextBox);
            this.Controls.Add(invoiceIDLabel);
            this.Controls.Add(this.invoiceIDTextBox);
            this.Controls.Add(invoiceNumberLabel);
            this.Controls.Add(this.invoiceNumberTextBox);
            this.Controls.Add(invoiceTotalLabel);
            this.Controls.Add(this.invoiceTotalTextBox);
            this.Controls.Add(paymentDateLabel);
            this.Controls.Add(this.paymentDateTextBox);
            this.Controls.Add(paymentTotalLabel);
            this.Controls.Add(this.paymentTotalTextBox);
            this.Controls.Add(vendorIDLabel);
            this.Controls.Add(this.txtVendor);
            this.Name = "frmPaymentEntry";
            this.Text = "Payment Entry";
            this.Load += new System.EventHandler(this.frmPaymentEntry_Load);
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource invoiceBindingSource;
        private System.Windows.Forms.TextBox balanceDueTextBox;
        private System.Windows.Forms.TextBox creditTotalTextBox;
        private System.Windows.Forms.TextBox dueDateTextBox;
        private System.Windows.Forms.TextBox invoiceDateTextBox;
        private System.Windows.Forms.TextBox invoiceIDTextBox;
        private System.Windows.Forms.TextBox invoiceNumberTextBox;
        private System.Windows.Forms.TextBox invoiceTotalTextBox;
        private System.Windows.Forms.TextBox paymentDateTextBox;
        private System.Windows.Forms.TextBox paymentTotalTextBox;
        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.Label paymentLabel;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox termsIDTextBox;
        private System.Windows.Forms.TextBox vendorIDTextBox;
    }
}