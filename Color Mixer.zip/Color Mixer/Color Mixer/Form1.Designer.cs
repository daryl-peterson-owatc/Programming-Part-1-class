﻿namespace Color_Mixer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxPrimaryColors = new System.Windows.Forms.GroupBox();
            this.gbxSecondaryColors = new System.Windows.Forms.GroupBox();
            this.radRed1st = new System.Windows.Forms.RadioButton();
            this.radBlue1st = new System.Windows.Forms.RadioButton();
            this.radYellow1st = new System.Windows.Forms.RadioButton();
            this.radRed2nd = new System.Windows.Forms.RadioButton();
            this.radBlue2nd = new System.Windows.Forms.RadioButton();
            this.radYellow2nd = new System.Windows.Forms.RadioButton();
            this.btnMix = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbxPrimaryColors.SuspendLayout();
            this.gbxSecondaryColors.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxPrimaryColors
            // 
            this.gbxPrimaryColors.Controls.Add(this.radYellow1st);
            this.gbxPrimaryColors.Controls.Add(this.radBlue1st);
            this.gbxPrimaryColors.Controls.Add(this.radRed1st);
            this.gbxPrimaryColors.Location = new System.Drawing.Point(12, 12);
            this.gbxPrimaryColors.Name = "gbxPrimaryColors";
            this.gbxPrimaryColors.Size = new System.Drawing.Size(139, 119);
            this.gbxPrimaryColors.TabIndex = 0;
            this.gbxPrimaryColors.TabStop = false;
            this.gbxPrimaryColors.Text = "Select the First Color";
            // 
            // gbxSecondaryColors
            // 
            this.gbxSecondaryColors.Controls.Add(this.radYellow2nd);
            this.gbxSecondaryColors.Controls.Add(this.radBlue2nd);
            this.gbxSecondaryColors.Controls.Add(this.radRed2nd);
            this.gbxSecondaryColors.Location = new System.Drawing.Point(182, 12);
            this.gbxSecondaryColors.Name = "gbxSecondaryColors";
            this.gbxSecondaryColors.Size = new System.Drawing.Size(139, 119);
            this.gbxSecondaryColors.TabIndex = 0;
            this.gbxSecondaryColors.TabStop = false;
            this.gbxSecondaryColors.Text = "Select the Second Color";
            // 
            // radRed1st
            // 
            this.radRed1st.AutoSize = true;
            this.radRed1st.Checked = true;
            this.radRed1st.Location = new System.Drawing.Point(40, 28);
            this.radRed1st.Name = "radRed1st";
            this.radRed1st.Size = new System.Drawing.Size(45, 17);
            this.radRed1st.TabIndex = 0;
            this.radRed1st.TabStop = true;
            this.radRed1st.Text = "Red";
            this.radRed1st.UseVisualStyleBackColor = true;
            // 
            // radBlue1st
            // 
            this.radBlue1st.AutoSize = true;
            this.radBlue1st.Location = new System.Drawing.Point(40, 60);
            this.radBlue1st.Name = "radBlue1st";
            this.radBlue1st.Size = new System.Drawing.Size(46, 17);
            this.radBlue1st.TabIndex = 1;
            this.radBlue1st.TabStop = true;
            this.radBlue1st.Text = "Blue";
            this.radBlue1st.UseVisualStyleBackColor = true;
            // 
            // radYellow1st
            // 
            this.radYellow1st.AutoSize = true;
            this.radYellow1st.Location = new System.Drawing.Point(43, 90);
            this.radYellow1st.Name = "radYellow1st";
            this.radYellow1st.Size = new System.Drawing.Size(56, 17);
            this.radYellow1st.TabIndex = 2;
            this.radYellow1st.TabStop = true;
            this.radYellow1st.Text = "Yellow";
            this.radYellow1st.UseVisualStyleBackColor = true;
            // 
            // radRed2nd
            // 
            this.radRed2nd.AutoSize = true;
            this.radRed2nd.Location = new System.Drawing.Point(44, 28);
            this.radRed2nd.Name = "radRed2nd";
            this.radRed2nd.Size = new System.Drawing.Size(45, 17);
            this.radRed2nd.TabIndex = 0;
            this.radRed2nd.TabStop = true;
            this.radRed2nd.Text = "Red";
            this.radRed2nd.UseVisualStyleBackColor = true;
            // 
            // radBlue2nd
            // 
            this.radBlue2nd.AutoSize = true;
            this.radBlue2nd.Location = new System.Drawing.Point(44, 60);
            this.radBlue2nd.Name = "radBlue2nd";
            this.radBlue2nd.Size = new System.Drawing.Size(46, 17);
            this.radBlue2nd.TabIndex = 1;
            this.radBlue2nd.TabStop = true;
            this.radBlue2nd.Text = "Blue";
            this.radBlue2nd.UseVisualStyleBackColor = true;
            // 
            // radYellow2nd
            // 
            this.radYellow2nd.AutoSize = true;
            this.radYellow2nd.Location = new System.Drawing.Point(44, 90);
            this.radYellow2nd.Name = "radYellow2nd";
            this.radYellow2nd.Size = new System.Drawing.Size(56, 17);
            this.radYellow2nd.TabIndex = 2;
            this.radYellow2nd.TabStop = true;
            this.radYellow2nd.Text = "Yellow";
            this.radYellow2nd.UseVisualStyleBackColor = true;
            // 
            // btnMix
            // 
            this.btnMix.Location = new System.Drawing.Point(76, 149);
            this.btnMix.Name = "btnMix";
            this.btnMix.Size = new System.Drawing.Size(75, 23);
            this.btnMix.TabIndex = 1;
            this.btnMix.Text = "Mix";
            this.btnMix.UseVisualStyleBackColor = true;
            this.btnMix.Click += new System.EventHandler(this.btnMix_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(182, 149);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 197);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMix);
            this.Controls.Add(this.gbxSecondaryColors);
            this.Controls.Add(this.gbxPrimaryColors);
            this.Name = "Form1";
            this.Text = "Color Mixer";
            this.gbxPrimaryColors.ResumeLayout(false);
            this.gbxPrimaryColors.PerformLayout();
            this.gbxSecondaryColors.ResumeLayout(false);
            this.gbxSecondaryColors.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxPrimaryColors;
        private System.Windows.Forms.RadioButton radYellow1st;
        private System.Windows.Forms.RadioButton radBlue1st;
        private System.Windows.Forms.RadioButton radRed1st;
        private System.Windows.Forms.GroupBox gbxSecondaryColors;
        private System.Windows.Forms.RadioButton radYellow2nd;
        private System.Windows.Forms.RadioButton radBlue2nd;
        private System.Windows.Forms.RadioButton radRed2nd;
        private System.Windows.Forms.Button btnMix;
        private System.Windows.Forms.Button btnExit;
    }
}

