﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblCardName = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.picBoxJokerRed = new System.Windows.Forms.PictureBox();
            this.picBoxAceSpades = new System.Windows.Forms.PictureBox();
            this.picBoxKingSpades = new System.Windows.Forms.PictureBox();
            this.picBoxTwoClubs = new System.Windows.Forms.PictureBox();
            this.picBoxEightDiamonds = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxJokerRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAceSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKingSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTwoClubs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEightDiamonds)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Location = new System.Drawing.Point(268, 29);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(143, 13);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "Click a Card to See Its Name";
            // 
            // lblCardName
            // 
            this.lblCardName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardName.Location = new System.Drawing.Point(24, 232);
            this.lblCardName.Name = "lblCardName";
            this.lblCardName.Size = new System.Drawing.Size(607, 23);
            this.lblCardName.TabIndex = 6;
            this.lblCardName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(294, 269);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // picBoxJokerRed
            // 
            this.picBoxJokerRed.Image = global::Card_Identifier.Properties.Resources.Joker_Red;
            this.picBoxJokerRed.Location = new System.Drawing.Point(531, 70);
            this.picBoxJokerRed.Name = "picBoxJokerRed";
            this.picBoxJokerRed.Size = new System.Drawing.Size(100, 136);
            this.picBoxJokerRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxJokerRed.TabIndex = 5;
            this.picBoxJokerRed.TabStop = false;
            this.picBoxJokerRed.Click += new System.EventHandler(this.picBoxJokerRed_Click);
            // 
            // picBoxAceSpades
            // 
            this.picBoxAceSpades.Image = global::Card_Identifier.Properties.Resources.Ace_Spades;
            this.picBoxAceSpades.Location = new System.Drawing.Point(405, 70);
            this.picBoxAceSpades.Name = "picBoxAceSpades";
            this.picBoxAceSpades.Size = new System.Drawing.Size(100, 136);
            this.picBoxAceSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxAceSpades.TabIndex = 4;
            this.picBoxAceSpades.TabStop = false;
            this.picBoxAceSpades.Click += new System.EventHandler(this.picBoxAceSpades_Click);
            // 
            // picBoxKingSpades
            // 
            this.picBoxKingSpades.Image = global::Card_Identifier.Properties.Resources.King_Spades;
            this.picBoxKingSpades.Location = new System.Drawing.Point(278, 70);
            this.picBoxKingSpades.Name = "picBoxKingSpades";
            this.picBoxKingSpades.Size = new System.Drawing.Size(100, 136);
            this.picBoxKingSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxKingSpades.TabIndex = 3;
            this.picBoxKingSpades.TabStop = false;
            this.picBoxKingSpades.Click += new System.EventHandler(this.picBoxKingSpades_Click);
            // 
            // picBoxTwoClubs
            // 
            this.picBoxTwoClubs.Image = global::Card_Identifier.Properties.Resources._2_Clubs;
            this.picBoxTwoClubs.Location = new System.Drawing.Point(150, 70);
            this.picBoxTwoClubs.Name = "picBoxTwoClubs";
            this.picBoxTwoClubs.Size = new System.Drawing.Size(100, 136);
            this.picBoxTwoClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxTwoClubs.TabIndex = 2;
            this.picBoxTwoClubs.TabStop = false;
            this.picBoxTwoClubs.Click += new System.EventHandler(this.picBoxTwoClubs_Click);
            // 
            // picBoxEightDiamonds
            // 
            this.picBoxEightDiamonds.Image = global::Card_Identifier.Properties.Resources._8_Diamonds;
            this.picBoxEightDiamonds.Location = new System.Drawing.Point(24, 70);
            this.picBoxEightDiamonds.Name = "picBoxEightDiamonds";
            this.picBoxEightDiamonds.Size = new System.Drawing.Size(100, 136);
            this.picBoxEightDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxEightDiamonds.TabIndex = 1;
            this.picBoxEightDiamonds.TabStop = false;
            this.picBoxEightDiamonds.Click += new System.EventHandler(this.picBoxEightDiamonds_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 311);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblCardName);
            this.Controls.Add(this.picBoxJokerRed);
            this.Controls.Add(this.picBoxAceSpades);
            this.Controls.Add(this.picBoxKingSpades);
            this.Controls.Add(this.picBoxTwoClubs);
            this.Controls.Add(this.picBoxEightDiamonds);
            this.Controls.Add(this.lblInstructions);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxJokerRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAceSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKingSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTwoClubs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEightDiamonds)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.PictureBox picBoxEightDiamonds;
        private System.Windows.Forms.PictureBox picBoxTwoClubs;
        private System.Windows.Forms.PictureBox picBoxKingSpades;
        private System.Windows.Forms.PictureBox picBoxAceSpades;
        private System.Windows.Forms.PictureBox picBoxJokerRed;
        private System.Windows.Forms.Label lblCardName;
        private System.Windows.Forms.Button btnExit;
    }
}

