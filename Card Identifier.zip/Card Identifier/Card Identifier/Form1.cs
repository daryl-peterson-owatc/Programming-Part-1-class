﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void picBoxEightDiamonds_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Eight of Diamonds";
        }

        private void picBoxTwoClubs_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Two of Clubs";
        }

        private void picBoxKingSpades_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "King of Spades";
        }

        private void picBoxAceSpades_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Ace of Spades";
        }

        private void picBoxJokerRed_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Red Joker";
        }
    }
}
