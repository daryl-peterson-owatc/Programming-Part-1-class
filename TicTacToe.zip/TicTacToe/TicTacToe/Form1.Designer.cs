﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameBox00Label = new System.Windows.Forms.Label();
            this.gameBox01Label = new System.Windows.Forms.Label();
            this.gameBox02Label = new System.Windows.Forms.Label();
            this.gameBox10Label = new System.Windows.Forms.Label();
            this.gameBox11Label = new System.Windows.Forms.Label();
            this.gameBox12Label = new System.Windows.Forms.Label();
            this.gameBox20Label = new System.Windows.Forms.Label();
            this.gameBox21Label = new System.Windows.Forms.Label();
            this.gameBox22Label = new System.Windows.Forms.Label();
            this.winResultsLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.newGameButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gameBox00Label
            // 
            this.gameBox00Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox00Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox00Label.Location = new System.Drawing.Point(18, 19);
            this.gameBox00Label.Name = "gameBox00Label";
            this.gameBox00Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox00Label.TabIndex = 0;
            this.gameBox00Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox01Label
            // 
            this.gameBox01Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox01Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox01Label.Location = new System.Drawing.Point(116, 19);
            this.gameBox01Label.Name = "gameBox01Label";
            this.gameBox01Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox01Label.TabIndex = 1;
            this.gameBox01Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox02Label
            // 
            this.gameBox02Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox02Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox02Label.Location = new System.Drawing.Point(212, 19);
            this.gameBox02Label.Name = "gameBox02Label";
            this.gameBox02Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox02Label.TabIndex = 2;
            this.gameBox02Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox10Label
            // 
            this.gameBox10Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox10Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox10Label.Location = new System.Drawing.Point(18, 114);
            this.gameBox10Label.Name = "gameBox10Label";
            this.gameBox10Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox10Label.TabIndex = 3;
            this.gameBox10Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox11Label
            // 
            this.gameBox11Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox11Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox11Label.Location = new System.Drawing.Point(116, 114);
            this.gameBox11Label.Name = "gameBox11Label";
            this.gameBox11Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox11Label.TabIndex = 4;
            this.gameBox11Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox12Label
            // 
            this.gameBox12Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox12Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox12Label.Location = new System.Drawing.Point(212, 114);
            this.gameBox12Label.Name = "gameBox12Label";
            this.gameBox12Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox12Label.TabIndex = 5;
            this.gameBox12Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox20Label
            // 
            this.gameBox20Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox20Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox20Label.Location = new System.Drawing.Point(18, 209);
            this.gameBox20Label.Name = "gameBox20Label";
            this.gameBox20Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox20Label.TabIndex = 6;
            this.gameBox20Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox21Label
            // 
            this.gameBox21Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox21Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox21Label.Location = new System.Drawing.Point(116, 209);
            this.gameBox21Label.Name = "gameBox21Label";
            this.gameBox21Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox21Label.TabIndex = 7;
            this.gameBox21Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gameBox22Label
            // 
            this.gameBox22Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gameBox22Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameBox22Label.Location = new System.Drawing.Point(212, 209);
            this.gameBox22Label.Name = "gameBox22Label";
            this.gameBox22Label.Size = new System.Drawing.Size(80, 80);
            this.gameBox22Label.TabIndex = 8;
            this.gameBox22Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winResultsLabel
            // 
            this.winResultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.winResultsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winResultsLabel.Location = new System.Drawing.Point(18, 302);
            this.winResultsLabel.Name = "winResultsLabel";
            this.winResultsLabel.Size = new System.Drawing.Size(274, 35);
            this.winResultsLabel.TabIndex = 9;
            this.winResultsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(168, 358);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(72, 358);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 23);
            this.newGameButton.TabIndex = 11;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 393);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.winResultsLabel);
            this.Controls.Add(this.gameBox22Label);
            this.Controls.Add(this.gameBox21Label);
            this.Controls.Add(this.gameBox20Label);
            this.Controls.Add(this.gameBox12Label);
            this.Controls.Add(this.gameBox11Label);
            this.Controls.Add(this.gameBox10Label);
            this.Controls.Add(this.gameBox02Label);
            this.Controls.Add(this.gameBox01Label);
            this.Controls.Add(this.gameBox00Label);
            this.Name = "Form1";
            this.Text = "Tic-Tac-Toe";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label gameBox00Label;
        private System.Windows.Forms.Label gameBox01Label;
        private System.Windows.Forms.Label gameBox02Label;
        private System.Windows.Forms.Label gameBox10Label;
        private System.Windows.Forms.Label gameBox11Label;
        private System.Windows.Forms.Label gameBox12Label;
        private System.Windows.Forms.Label gameBox20Label;
        private System.Windows.Forms.Label gameBox21Label;
        private System.Windows.Forms.Label gameBox22Label;
        private System.Windows.Forms.Label winResultsLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button newGameButton;
    }
}

