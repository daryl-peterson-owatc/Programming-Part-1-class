﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        private string[] XO = new string[2]{ "O", "X" };
        private int[,] gameBoard = new int[3, 3];

        public Form1()
        {
            InitializeComponent();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            string winnerMessage = "Both Lose";

            FillArray();
            DisplayGameBoard();
            string OStatus = DetermineWinner(0);
            string XStatus = DetermineWinner(1);

            if (OStatus == "Win" && XStatus == "Win")
            {
                winnerMessage = "Both X and O Wins";
            }
            else if (OStatus == "Win")
            {
                winnerMessage = "O Wins";
            }
            else if (XStatus == "Win")
            {
                winnerMessage = "X Wins";
            }

            winResultsLabel.Text = winnerMessage;
        }

        private void FillArray()
        {
            Random rnd = new Random((int)DateTime.Now.Ticks);

            for (int x = 0; x < 3; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    gameBoard[x, y] = rnd.Next(0, 2);
                }
            }
        }

        private void DisplayGameBoard()
        {
            gameBox00Label.Text = XO[gameBoard[0, 0]];
            gameBox01Label.Text = XO[gameBoard[0, 1]];
            gameBox02Label.Text = XO[gameBoard[0, 2]];
            gameBox10Label.Text = XO[gameBoard[1, 0]];
            gameBox11Label.Text = XO[gameBoard[1, 1]];
            gameBox12Label.Text = XO[gameBoard[1, 2]];
            gameBox20Label.Text = XO[gameBoard[2, 0]];
            gameBox21Label.Text = XO[gameBoard[2, 1]];
            gameBox22Label.Text = XO[gameBoard[2, 2]];
        }

        private string DetermineWinner(int player)
        {
            string winLose = "Lose";

            if (gameBoard[0,0] == player && gameBoard[0,1] == player && gameBoard[0,2] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[1, 0] == player && gameBoard[1, 1] == player && gameBoard[1, 2] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[2, 0] == player && gameBoard[2, 1] == player && gameBoard[2, 2] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[0, 0] == player && gameBoard[1, 0] == player && gameBoard[2, 0] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[0, 1] == player && gameBoard[1, 1] == player && gameBoard[2, 1] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[0, 2] == player && gameBoard[1, 2] == player && gameBoard[2, 2] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[0, 0] == player && gameBoard[1, 1] == player && gameBoard[2, 2] == player)
            {
                winLose = "Win";
            }
            else if (gameBoard[2, 0] == player && gameBoard[1, 1] == player && gameBoard[0, 2] == player)
            {
                winLose = "Win";
            }

            return winLose;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
