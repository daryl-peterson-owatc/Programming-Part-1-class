﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder
{
    public partial class Form1 : Form
    {
        private string sentence = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnBigA_Click(object sender, EventArgs e)
        {
            sentence += btnBigA.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSmallA_Click(object sender, EventArgs e)
        {
            sentence += btnSmallA.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnBigAn_Click(object sender, EventArgs e)
        {
            sentence += btnBigAn.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSmallAn_Click(object sender, EventArgs e)
        {
            sentence += btnSmallAn.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnBigThe_Click(object sender, EventArgs e)
        {
            sentence += btnBigThe.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSmallThe_Click(object sender, EventArgs e)
        {
            sentence += btnSmallThe.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnMan_Click(object sender, EventArgs e)
        {
            sentence += btnMan.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnWoman_Click(object sender, EventArgs e)
        {
            sentence += btnWoman.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnMonkey_Click(object sender, EventArgs e)
        {
            sentence += btnMonkey.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnHorse_Click(object sender, EventArgs e)
        {
            sentence += btnHorse.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnCow_Click(object sender, EventArgs e)
        {
            sentence += btnCow.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnTruck_Click(object sender, EventArgs e)
        {
            sentence += btnTruck.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnMotorcycle_Click(object sender, EventArgs e)
        {
            sentence += btnMotorcycle.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnBeautiful_Click(object sender, EventArgs e)
        {
            sentence += btnBeautiful.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnBig_Click(object sender, EventArgs e)
        {
            sentence += btnBig.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSmall_Click(object sender, EventArgs e)
        {
            sentence += btnSmall.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnStrange_Click(object sender, EventArgs e)
        {
            sentence += btnStrange.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnCool_Click(object sender, EventArgs e)
        {
            sentence += btnCool.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnLookedAt_Click(object sender, EventArgs e)
        {
            sentence += btnLookedAt.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnRode_Click(object sender, EventArgs e)
        {
            sentence += btnRode.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSpokeTo_Click(object sender, EventArgs e)
        {
            sentence += btnSpokeTo.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnLaughedAt_Click(object sender, EventArgs e)
        {
            sentence += btnLaughedAt.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnDrove_Click(object sender, EventArgs e)
        {
            sentence += btnDrove.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnBeeped_Click(object sender, EventArgs e)
        {
            sentence += btnBeeped.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnSpace_Click(object sender, EventArgs e)
        {
            sentence += " ";
            lblSentenceOutput.Text = sentence;
        }

        private void btnComma_Click(object sender, EventArgs e)
        {
            sentence += ",";
            lblSentenceOutput.Text = sentence;
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            sentence += ".";
            lblSentenceOutput.Text = sentence;
        }

        private void btnExclamation_Click(object sender, EventArgs e)
        {
            sentence += btnExclamation.Text;
            lblSentenceOutput.Text = sentence;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            sentence = "";
            lblSentenceOutput.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
