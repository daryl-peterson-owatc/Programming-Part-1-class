﻿namespace Sentence_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBigA = new System.Windows.Forms.Button();
            this.btnSmallA = new System.Windows.Forms.Button();
            this.btnBigAn = new System.Windows.Forms.Button();
            this.btnSmallAn = new System.Windows.Forms.Button();
            this.btnBigThe = new System.Windows.Forms.Button();
            this.btnSmallThe = new System.Windows.Forms.Button();
            this.btnMan = new System.Windows.Forms.Button();
            this.btnWoman = new System.Windows.Forms.Button();
            this.btnMonkey = new System.Windows.Forms.Button();
            this.btnHorse = new System.Windows.Forms.Button();
            this.btnCow = new System.Windows.Forms.Button();
            this.btnTruck = new System.Windows.Forms.Button();
            this.btnMotorcycle = new System.Windows.Forms.Button();
            this.btnBeautiful = new System.Windows.Forms.Button();
            this.btnBig = new System.Windows.Forms.Button();
            this.btnSmall = new System.Windows.Forms.Button();
            this.btnStrange = new System.Windows.Forms.Button();
            this.btnCool = new System.Windows.Forms.Button();
            this.btnLookedAt = new System.Windows.Forms.Button();
            this.btnRode = new System.Windows.Forms.Button();
            this.btnSpokeTo = new System.Windows.Forms.Button();
            this.btnLaughedAt = new System.Windows.Forms.Button();
            this.btnDrove = new System.Windows.Forms.Button();
            this.btnBeeped = new System.Windows.Forms.Button();
            this.btnSpace = new System.Windows.Forms.Button();
            this.btnComma = new System.Windows.Forms.Button();
            this.btnPeriod = new System.Windows.Forms.Button();
            this.btnExclamation = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblSentenceOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBigA
            // 
            this.btnBigA.Location = new System.Drawing.Point(175, 23);
            this.btnBigA.Name = "btnBigA";
            this.btnBigA.Size = new System.Drawing.Size(38, 23);
            this.btnBigA.TabIndex = 0;
            this.btnBigA.Text = "A";
            this.btnBigA.UseVisualStyleBackColor = true;
            this.btnBigA.Click += new System.EventHandler(this.btnBigA_Click);
            // 
            // btnSmallA
            // 
            this.btnSmallA.Location = new System.Drawing.Point(219, 23);
            this.btnSmallA.Name = "btnSmallA";
            this.btnSmallA.Size = new System.Drawing.Size(37, 23);
            this.btnSmallA.TabIndex = 1;
            this.btnSmallA.Text = "a";
            this.btnSmallA.UseVisualStyleBackColor = true;
            this.btnSmallA.Click += new System.EventHandler(this.btnSmallA_Click);
            // 
            // btnBigAn
            // 
            this.btnBigAn.Location = new System.Drawing.Point(262, 23);
            this.btnBigAn.Name = "btnBigAn";
            this.btnBigAn.Size = new System.Drawing.Size(44, 23);
            this.btnBigAn.TabIndex = 2;
            this.btnBigAn.Text = "An";
            this.btnBigAn.UseVisualStyleBackColor = true;
            this.btnBigAn.Click += new System.EventHandler(this.btnBigAn_Click);
            // 
            // btnSmallAn
            // 
            this.btnSmallAn.Location = new System.Drawing.Point(312, 23);
            this.btnSmallAn.Name = "btnSmallAn";
            this.btnSmallAn.Size = new System.Drawing.Size(39, 23);
            this.btnSmallAn.TabIndex = 3;
            this.btnSmallAn.Text = "an";
            this.btnSmallAn.UseVisualStyleBackColor = true;
            this.btnSmallAn.Click += new System.EventHandler(this.btnSmallAn_Click);
            // 
            // btnBigThe
            // 
            this.btnBigThe.Location = new System.Drawing.Point(357, 23);
            this.btnBigThe.Name = "btnBigThe";
            this.btnBigThe.Size = new System.Drawing.Size(42, 23);
            this.btnBigThe.TabIndex = 4;
            this.btnBigThe.Text = "The";
            this.btnBigThe.UseVisualStyleBackColor = true;
            this.btnBigThe.Click += new System.EventHandler(this.btnBigThe_Click);
            // 
            // btnSmallThe
            // 
            this.btnSmallThe.Location = new System.Drawing.Point(405, 23);
            this.btnSmallThe.Name = "btnSmallThe";
            this.btnSmallThe.Size = new System.Drawing.Size(39, 23);
            this.btnSmallThe.TabIndex = 5;
            this.btnSmallThe.Text = "the";
            this.btnSmallThe.UseVisualStyleBackColor = true;
            this.btnSmallThe.Click += new System.EventHandler(this.btnSmallThe_Click);
            // 
            // btnMan
            // 
            this.btnMan.Location = new System.Drawing.Point(109, 52);
            this.btnMan.Name = "btnMan";
            this.btnMan.Size = new System.Drawing.Size(47, 23);
            this.btnMan.TabIndex = 6;
            this.btnMan.Text = "man";
            this.btnMan.UseVisualStyleBackColor = true;
            this.btnMan.Click += new System.EventHandler(this.btnMan_Click);
            // 
            // btnWoman
            // 
            this.btnWoman.Location = new System.Drawing.Point(162, 52);
            this.btnWoman.Name = "btnWoman";
            this.btnWoman.Size = new System.Drawing.Size(54, 23);
            this.btnWoman.TabIndex = 7;
            this.btnWoman.Text = "woman";
            this.btnWoman.UseVisualStyleBackColor = true;
            this.btnWoman.Click += new System.EventHandler(this.btnWoman_Click);
            // 
            // btnMonkey
            // 
            this.btnMonkey.Location = new System.Drawing.Point(222, 52);
            this.btnMonkey.Name = "btnMonkey";
            this.btnMonkey.Size = new System.Drawing.Size(60, 23);
            this.btnMonkey.TabIndex = 8;
            this.btnMonkey.Text = "monkey";
            this.btnMonkey.UseVisualStyleBackColor = true;
            this.btnMonkey.Click += new System.EventHandler(this.btnMonkey_Click);
            // 
            // btnHorse
            // 
            this.btnHorse.Location = new System.Drawing.Point(288, 52);
            this.btnHorse.Name = "btnHorse";
            this.btnHorse.Size = new System.Drawing.Size(51, 23);
            this.btnHorse.TabIndex = 9;
            this.btnHorse.Text = "horse";
            this.btnHorse.UseVisualStyleBackColor = true;
            this.btnHorse.Click += new System.EventHandler(this.btnHorse_Click);
            // 
            // btnCow
            // 
            this.btnCow.Location = new System.Drawing.Point(345, 52);
            this.btnCow.Name = "btnCow";
            this.btnCow.Size = new System.Drawing.Size(50, 23);
            this.btnCow.TabIndex = 10;
            this.btnCow.Text = "cow";
            this.btnCow.UseVisualStyleBackColor = true;
            this.btnCow.Click += new System.EventHandler(this.btnCow_Click);
            // 
            // btnTruck
            // 
            this.btnTruck.Location = new System.Drawing.Point(401, 52);
            this.btnTruck.Name = "btnTruck";
            this.btnTruck.Size = new System.Drawing.Size(49, 23);
            this.btnTruck.TabIndex = 11;
            this.btnTruck.Text = "truck";
            this.btnTruck.UseVisualStyleBackColor = true;
            this.btnTruck.Click += new System.EventHandler(this.btnTruck_Click);
            // 
            // btnMotorcycle
            // 
            this.btnMotorcycle.Location = new System.Drawing.Point(456, 52);
            this.btnMotorcycle.Name = "btnMotorcycle";
            this.btnMotorcycle.Size = new System.Drawing.Size(75, 23);
            this.btnMotorcycle.TabIndex = 12;
            this.btnMotorcycle.Text = "motorcycle";
            this.btnMotorcycle.UseVisualStyleBackColor = true;
            this.btnMotorcycle.Click += new System.EventHandler(this.btnMotorcycle_Click);
            // 
            // btnBeautiful
            // 
            this.btnBeautiful.Location = new System.Drawing.Point(166, 81);
            this.btnBeautiful.Name = "btnBeautiful";
            this.btnBeautiful.Size = new System.Drawing.Size(59, 23);
            this.btnBeautiful.TabIndex = 13;
            this.btnBeautiful.Text = "beautiful";
            this.btnBeautiful.UseVisualStyleBackColor = true;
            this.btnBeautiful.Click += new System.EventHandler(this.btnBeautiful_Click);
            // 
            // btnBig
            // 
            this.btnBig.Location = new System.Drawing.Point(231, 81);
            this.btnBig.Name = "btnBig";
            this.btnBig.Size = new System.Drawing.Size(39, 23);
            this.btnBig.TabIndex = 14;
            this.btnBig.Text = "big";
            this.btnBig.UseVisualStyleBackColor = true;
            this.btnBig.Click += new System.EventHandler(this.btnBig_Click);
            // 
            // btnSmall
            // 
            this.btnSmall.Location = new System.Drawing.Point(276, 81);
            this.btnSmall.Name = "btnSmall";
            this.btnSmall.Size = new System.Drawing.Size(50, 23);
            this.btnSmall.TabIndex = 15;
            this.btnSmall.Text = "small";
            this.btnSmall.UseVisualStyleBackColor = true;
            this.btnSmall.Click += new System.EventHandler(this.btnSmall_Click);
            // 
            // btnStrange
            // 
            this.btnStrange.Location = new System.Drawing.Point(332, 81);
            this.btnStrange.Name = "btnStrange";
            this.btnStrange.Size = new System.Drawing.Size(62, 23);
            this.btnStrange.TabIndex = 16;
            this.btnStrange.Text = "strange";
            this.btnStrange.UseVisualStyleBackColor = true;
            this.btnStrange.Click += new System.EventHandler(this.btnStrange_Click);
            // 
            // btnCool
            // 
            this.btnCool.Location = new System.Drawing.Point(400, 81);
            this.btnCool.Name = "btnCool";
            this.btnCool.Size = new System.Drawing.Size(53, 23);
            this.btnCool.TabIndex = 17;
            this.btnCool.Text = "cool";
            this.btnCool.UseVisualStyleBackColor = true;
            this.btnCool.Click += new System.EventHandler(this.btnCool_Click);
            // 
            // btnLookedAt
            // 
            this.btnLookedAt.Location = new System.Drawing.Point(126, 110);
            this.btnLookedAt.Name = "btnLookedAt";
            this.btnLookedAt.Size = new System.Drawing.Size(63, 23);
            this.btnLookedAt.TabIndex = 18;
            this.btnLookedAt.Text = "looked at";
            this.btnLookedAt.UseVisualStyleBackColor = true;
            this.btnLookedAt.Click += new System.EventHandler(this.btnLookedAt_Click);
            // 
            // btnRode
            // 
            this.btnRode.Location = new System.Drawing.Point(195, 110);
            this.btnRode.Name = "btnRode";
            this.btnRode.Size = new System.Drawing.Size(49, 23);
            this.btnRode.TabIndex = 19;
            this.btnRode.Text = "rode";
            this.btnRode.UseVisualStyleBackColor = true;
            this.btnRode.Click += new System.EventHandler(this.btnRode_Click);
            // 
            // btnSpokeTo
            // 
            this.btnSpokeTo.Location = new System.Drawing.Point(250, 110);
            this.btnSpokeTo.Name = "btnSpokeTo";
            this.btnSpokeTo.Size = new System.Drawing.Size(60, 23);
            this.btnSpokeTo.TabIndex = 20;
            this.btnSpokeTo.Text = "spoke to";
            this.btnSpokeTo.UseVisualStyleBackColor = true;
            this.btnSpokeTo.Click += new System.EventHandler(this.btnSpokeTo_Click);
            // 
            // btnLaughedAt
            // 
            this.btnLaughedAt.Location = new System.Drawing.Point(316, 110);
            this.btnLaughedAt.Name = "btnLaughedAt";
            this.btnLaughedAt.Size = new System.Drawing.Size(75, 23);
            this.btnLaughedAt.TabIndex = 21;
            this.btnLaughedAt.Text = "laughed at";
            this.btnLaughedAt.UseVisualStyleBackColor = true;
            this.btnLaughedAt.Click += new System.EventHandler(this.btnLaughedAt_Click);
            // 
            // btnDrove
            // 
            this.btnDrove.Location = new System.Drawing.Point(397, 110);
            this.btnDrove.Name = "btnDrove";
            this.btnDrove.Size = new System.Drawing.Size(53, 23);
            this.btnDrove.TabIndex = 22;
            this.btnDrove.Text = "drove";
            this.btnDrove.UseVisualStyleBackColor = true;
            this.btnDrove.Click += new System.EventHandler(this.btnDrove_Click);
            // 
            // btnBeeped
            // 
            this.btnBeeped.Location = new System.Drawing.Point(456, 110);
            this.btnBeeped.Name = "btnBeeped";
            this.btnBeeped.Size = new System.Drawing.Size(60, 23);
            this.btnBeeped.TabIndex = 23;
            this.btnBeeped.Text = "beeped";
            this.btnBeeped.UseVisualStyleBackColor = true;
            this.btnBeeped.Click += new System.EventHandler(this.btnBeeped_Click);
            // 
            // btnSpace
            // 
            this.btnSpace.Location = new System.Drawing.Point(159, 139);
            this.btnSpace.Name = "btnSpace";
            this.btnSpace.Size = new System.Drawing.Size(75, 23);
            this.btnSpace.TabIndex = 24;
            this.btnSpace.Text = "(Space)";
            this.btnSpace.UseVisualStyleBackColor = true;
            this.btnSpace.Click += new System.EventHandler(this.btnSpace_Click);
            // 
            // btnComma
            // 
            this.btnComma.Location = new System.Drawing.Point(243, 139);
            this.btnComma.Name = "btnComma";
            this.btnComma.Size = new System.Drawing.Size(75, 23);
            this.btnComma.TabIndex = 25;
            this.btnComma.Text = "(Comma)";
            this.btnComma.UseVisualStyleBackColor = true;
            this.btnComma.Click += new System.EventHandler(this.btnComma_Click);
            // 
            // btnPeriod
            // 
            this.btnPeriod.Location = new System.Drawing.Point(324, 139);
            this.btnPeriod.Name = "btnPeriod";
            this.btnPeriod.Size = new System.Drawing.Size(75, 23);
            this.btnPeriod.TabIndex = 26;
            this.btnPeriod.Text = "(Period)";
            this.btnPeriod.UseVisualStyleBackColor = true;
            this.btnPeriod.Click += new System.EventHandler(this.btnPeriod_Click);
            // 
            // btnExclamation
            // 
            this.btnExclamation.Location = new System.Drawing.Point(405, 139);
            this.btnExclamation.Name = "btnExclamation";
            this.btnExclamation.Size = new System.Drawing.Size(75, 23);
            this.btnExclamation.TabIndex = 27;
            this.btnExclamation.Text = "!";
            this.btnExclamation.UseVisualStyleBackColor = true;
            this.btnExclamation.Click += new System.EventHandler(this.btnExclamation_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(207, 209);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 28;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(332, 209);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 29;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblSentenceOutput
            // 
            this.lblSentenceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSentenceOutput.Location = new System.Drawing.Point(12, 174);
            this.lblSentenceOutput.Name = "lblSentenceOutput";
            this.lblSentenceOutput.Size = new System.Drawing.Size(582, 19);
            this.lblSentenceOutput.TabIndex = 30;
            this.lblSentenceOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 251);
            this.Controls.Add(this.lblSentenceOutput);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExclamation);
            this.Controls.Add(this.btnPeriod);
            this.Controls.Add(this.btnComma);
            this.Controls.Add(this.btnSpace);
            this.Controls.Add(this.btnBeeped);
            this.Controls.Add(this.btnDrove);
            this.Controls.Add(this.btnLaughedAt);
            this.Controls.Add(this.btnSpokeTo);
            this.Controls.Add(this.btnRode);
            this.Controls.Add(this.btnLookedAt);
            this.Controls.Add(this.btnCool);
            this.Controls.Add(this.btnStrange);
            this.Controls.Add(this.btnSmall);
            this.Controls.Add(this.btnBig);
            this.Controls.Add(this.btnBeautiful);
            this.Controls.Add(this.btnMotorcycle);
            this.Controls.Add(this.btnTruck);
            this.Controls.Add(this.btnCow);
            this.Controls.Add(this.btnHorse);
            this.Controls.Add(this.btnMonkey);
            this.Controls.Add(this.btnWoman);
            this.Controls.Add(this.btnMan);
            this.Controls.Add(this.btnSmallThe);
            this.Controls.Add(this.btnBigThe);
            this.Controls.Add(this.btnSmallAn);
            this.Controls.Add(this.btnBigAn);
            this.Controls.Add(this.btnSmallA);
            this.Controls.Add(this.btnBigA);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBigA;
        private System.Windows.Forms.Button btnSmallA;
        private System.Windows.Forms.Button btnBigAn;
        private System.Windows.Forms.Button btnSmallAn;
        private System.Windows.Forms.Button btnBigThe;
        private System.Windows.Forms.Button btnSmallThe;
        private System.Windows.Forms.Button btnMan;
        private System.Windows.Forms.Button btnWoman;
        private System.Windows.Forms.Button btnMonkey;
        private System.Windows.Forms.Button btnHorse;
        private System.Windows.Forms.Button btnCow;
        private System.Windows.Forms.Button btnTruck;
        private System.Windows.Forms.Button btnMotorcycle;
        private System.Windows.Forms.Button btnBeautiful;
        private System.Windows.Forms.Button btnBig;
        private System.Windows.Forms.Button btnSmall;
        private System.Windows.Forms.Button btnStrange;
        private System.Windows.Forms.Button btnCool;
        private System.Windows.Forms.Button btnLookedAt;
        private System.Windows.Forms.Button btnRode;
        private System.Windows.Forms.Button btnSpokeTo;
        private System.Windows.Forms.Button btnLaughedAt;
        private System.Windows.Forms.Button btnDrove;
        private System.Windows.Forms.Button btnBeeped;
        private System.Windows.Forms.Button btnSpace;
        private System.Windows.Forms.Button btnComma;
        private System.Windows.Forms.Button btnPeriod;
        private System.Windows.Forms.Button btnExclamation;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblSentenceOutput;
    }
}

