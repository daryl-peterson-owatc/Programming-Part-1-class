﻿namespace Driver_License
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gradeTestButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.incorrectAnsweredQuestionsListBox = new System.Windows.Forms.ListBox();
            this.incorrectAnsweredQuestionsDescriptionLabel = new System.Windows.Forms.Label();
            this.correctAnswersTotalLabel = new System.Windows.Forms.Label();
            this.correctAnswersDescriptionLabel = new System.Windows.Forms.Label();
            this.incorrectAnswerTotalLabel = new System.Windows.Forms.Label();
            this.incorrectAnswersDescriptionLabel = new System.Windows.Forms.Label();
            this.passFailLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gradeTestButton
            // 
            this.gradeTestButton.Location = new System.Drawing.Point(51, 201);
            this.gradeTestButton.Name = "gradeTestButton";
            this.gradeTestButton.Size = new System.Drawing.Size(75, 23);
            this.gradeTestButton.TabIndex = 0;
            this.gradeTestButton.Text = "Grade Test";
            this.gradeTestButton.UseVisualStyleBackColor = true;
            this.gradeTestButton.Click += new System.EventHandler(this.gradeTestButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(247, 201);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // incorrectAnsweredQuestionsListBox
            // 
            this.incorrectAnsweredQuestionsListBox.FormattingEnabled = true;
            this.incorrectAnsweredQuestionsListBox.Location = new System.Drawing.Point(166, 27);
            this.incorrectAnsweredQuestionsListBox.Name = "incorrectAnsweredQuestionsListBox";
            this.incorrectAnsweredQuestionsListBox.Size = new System.Drawing.Size(156, 160);
            this.incorrectAnsweredQuestionsListBox.TabIndex = 2;
            // 
            // incorrectAnsweredQuestionsDescriptionLabel
            // 
            this.incorrectAnsweredQuestionsDescriptionLabel.AutoSize = true;
            this.incorrectAnsweredQuestionsDescriptionLabel.Location = new System.Drawing.Point(166, 6);
            this.incorrectAnsweredQuestionsDescriptionLabel.Name = "incorrectAnsweredQuestionsDescriptionLabel";
            this.incorrectAnsweredQuestionsDescriptionLabel.Size = new System.Drawing.Size(156, 13);
            this.incorrectAnsweredQuestionsDescriptionLabel.TabIndex = 3;
            this.incorrectAnsweredQuestionsDescriptionLabel.Text = "Incorrectly Answered Questions";
            // 
            // correctAnswersTotalLabel
            // 
            this.correctAnswersTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.correctAnswersTotalLabel.Location = new System.Drawing.Point(106, 71);
            this.correctAnswersTotalLabel.Name = "correctAnswersTotalLabel";
            this.correctAnswersTotalLabel.Size = new System.Drawing.Size(38, 23);
            this.correctAnswersTotalLabel.TabIndex = 4;
            this.correctAnswersTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // correctAnswersDescriptionLabel
            // 
            this.correctAnswersDescriptionLabel.AutoSize = true;
            this.correctAnswersDescriptionLabel.Location = new System.Drawing.Point(18, 76);
            this.correctAnswersDescriptionLabel.Name = "correctAnswersDescriptionLabel";
            this.correctAnswersDescriptionLabel.Size = new System.Drawing.Size(87, 13);
            this.correctAnswersDescriptionLabel.TabIndex = 5;
            this.correctAnswersDescriptionLabel.Text = "Correct Answers:";
            // 
            // incorrectAnswerTotalLabel
            // 
            this.incorrectAnswerTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.incorrectAnswerTotalLabel.Location = new System.Drawing.Point(106, 104);
            this.incorrectAnswerTotalLabel.Name = "incorrectAnswerTotalLabel";
            this.incorrectAnswerTotalLabel.Size = new System.Drawing.Size(38, 23);
            this.incorrectAnswerTotalLabel.TabIndex = 6;
            this.incorrectAnswerTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // incorrectAnswersDescriptionLabel
            // 
            this.incorrectAnswersDescriptionLabel.AutoSize = true;
            this.incorrectAnswersDescriptionLabel.Location = new System.Drawing.Point(5, 109);
            this.incorrectAnswersDescriptionLabel.Name = "incorrectAnswersDescriptionLabel";
            this.incorrectAnswersDescriptionLabel.Size = new System.Drawing.Size(95, 13);
            this.incorrectAnswersDescriptionLabel.TabIndex = 7;
            this.incorrectAnswersDescriptionLabel.Text = "Incorrect Answers:";
            // 
            // passFailLabel
            // 
            this.passFailLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passFailLabel.Location = new System.Drawing.Point(10, 27);
            this.passFailLabel.Name = "passFailLabel";
            this.passFailLabel.Size = new System.Drawing.Size(134, 23);
            this.passFailLabel.TabIndex = 8;
            this.passFailLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 242);
            this.Controls.Add(this.passFailLabel);
            this.Controls.Add(this.incorrectAnswersDescriptionLabel);
            this.Controls.Add(this.incorrectAnswerTotalLabel);
            this.Controls.Add(this.correctAnswersDescriptionLabel);
            this.Controls.Add(this.correctAnswersTotalLabel);
            this.Controls.Add(this.incorrectAnsweredQuestionsDescriptionLabel);
            this.Controls.Add(this.incorrectAnsweredQuestionsListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.gradeTestButton);
            this.Name = "Form1";
            this.Text = "Driver License";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button gradeTestButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.ListBox incorrectAnsweredQuestionsListBox;
        private System.Windows.Forms.Label incorrectAnsweredQuestionsDescriptionLabel;
        private System.Windows.Forms.Label correctAnswersTotalLabel;
        private System.Windows.Forms.Label correctAnswersDescriptionLabel;
        private System.Windows.Forms.Label incorrectAnswerTotalLabel;
        private System.Windows.Forms.Label incorrectAnswersDescriptionLabel;
        private System.Windows.Forms.Label passFailLabel;
    }
}

