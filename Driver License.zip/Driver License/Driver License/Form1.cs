﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Driver_License
{
    public partial class Form1 : Form
    {
        private const int SIZE = 20;
        StreamReader inputFile;
        private string[] inputTestArray = new string[SIZE];
        int correctAnswers;
        int incorrectAnswers;
        List<int> incorrectQuestions = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void gradeTestButton_Click(object sender, EventArgs e)
        {
            int index = 0;
            PrepareForNewTest();

            string[] testAnswersArray = new string[SIZE];
            testAnswersArray[0] = "B";
            testAnswersArray[1] = "D";
            testAnswersArray[2] = "A";
            testAnswersArray[3] = "A";
            testAnswersArray[4] = "C";
            testAnswersArray[5] = "A";
            testAnswersArray[6] = "B";
            testAnswersArray[7] = "A";
            testAnswersArray[8] = "C";
            testAnswersArray[9] = "D";
            testAnswersArray[10] = "B";
            testAnswersArray[11] = "C";
            testAnswersArray[12] = "D";
            testAnswersArray[13] = "A";
            testAnswersArray[14] = "D";
            testAnswersArray[15] = "C";
            testAnswersArray[16] = "C";
            testAnswersArray[17] = "B";
            testAnswersArray[18] = "D";
            testAnswersArray[19] = "A";

            try
            {
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(openFile.FileName);
                    
                    while (!inputFile.EndOfStream && index < SIZE)
                    {
                        inputTestArray[index] = inputFile.ReadLine();
                        index++;
                    }

                    inputFile.Close();

                    CorrectTest(testAnswersArray, inputTestArray);

                    if (correctAnswers < 15)
                    {
                        passFailLabel.Text = "Test Failed";
                    }
                    else
                    {
                        passFailLabel.Text = "Test Passed";
                    }

                    DisplayResults();
                }
                else
                {
                    MessageBox.Show("Please select a valide file.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CorrectTest(string[] testAnswersArray, string[] inputTestArray)
        {
            for (int index = 0; index < SIZE; index++)
            {
                if (testAnswersArray[index] == inputTestArray[index])
                {
                    correctAnswers += 1;
                }
                else
                {
                    incorrectAnswers += 1;
                    incorrectQuestions.Add(index + 1);
                }
            }
        }

        private void DisplayResults()
        {
            correctAnswersTotalLabel.Text = correctAnswers.ToString();
            incorrectAnswerTotalLabel.Text = incorrectAnswers.ToString();
            foreach (int number in incorrectQuestions)
            {
                incorrectAnsweredQuestionsListBox.Items.Add(number.ToString());
            }
        }

        private void PrepareForNewTest()
        {
            correctAnswers = 0;
            incorrectAnswers = 0;
            incorrectQuestions.Clear();
            incorrectAnsweredQuestionsListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
