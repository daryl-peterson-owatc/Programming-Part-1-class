﻿namespace Person
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enteryGroupBox = new System.Windows.Forms.GroupBox();
            this.customerNumberTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.inputMailingListCheckBox = new System.Windows.Forms.CheckBox();
            this.inputCustomerNumberLabel = new System.Windows.Forms.Label();
            this.inputNameLabel = new System.Windows.Forms.Label();
            this.inputAddressLabel = new System.Windows.Forms.Label();
            this.inputPhoneLabel = new System.Windows.Forms.Label();
            this.displayCustomerInfo = new System.Windows.Forms.Button();
            this.outputDisplayGroupBox = new System.Windows.Forms.GroupBox();
            this.outputCustomerNumberLabel = new System.Windows.Forms.Label();
            this.outputCustomerNameLabel = new System.Windows.Forms.Label();
            this.outputCustomerAddressLabel = new System.Windows.Forms.Label();
            this.outputCustomerPhoneLabel = new System.Windows.Forms.Label();
            this.outputMailingListCheckBox = new System.Windows.Forms.CheckBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.enteryGroupBox.SuspendLayout();
            this.outputDisplayGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // enteryGroupBox
            // 
            this.enteryGroupBox.Controls.Add(this.inputPhoneLabel);
            this.enteryGroupBox.Controls.Add(this.inputMailingListCheckBox);
            this.enteryGroupBox.Controls.Add(this.inputAddressLabel);
            this.enteryGroupBox.Controls.Add(this.phoneTextBox);
            this.enteryGroupBox.Controls.Add(this.inputNameLabel);
            this.enteryGroupBox.Controls.Add(this.addressTextBox);
            this.enteryGroupBox.Controls.Add(this.inputCustomerNumberLabel);
            this.enteryGroupBox.Controls.Add(this.nameTextBox);
            this.enteryGroupBox.Controls.Add(this.customerNumberTextBox);
            this.enteryGroupBox.Location = new System.Drawing.Point(13, 13);
            this.enteryGroupBox.Name = "enteryGroupBox";
            this.enteryGroupBox.Size = new System.Drawing.Size(254, 157);
            this.enteryGroupBox.TabIndex = 0;
            this.enteryGroupBox.TabStop = false;
            this.enteryGroupBox.Text = "Enter Customer Information";
            // 
            // customerNumberTextBox
            // 
            this.customerNumberTextBox.Location = new System.Drawing.Point(114, 20);
            this.customerNumberTextBox.Name = "customerNumberTextBox";
            this.customerNumberTextBox.Size = new System.Drawing.Size(68, 20);
            this.customerNumberTextBox.TabIndex = 0;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(113, 46);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(126, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(113, 72);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(126, 20);
            this.addressTextBox.TabIndex = 2;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(114, 98);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneTextBox.TabIndex = 3;
            // 
            // inputMailingListCheckBox
            // 
            this.inputMailingListCheckBox.AutoSize = true;
            this.inputMailingListCheckBox.Location = new System.Drawing.Point(48, 124);
            this.inputMailingListCheckBox.Name = "inputMailingListCheckBox";
            this.inputMailingListCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.inputMailingListCheckBox.Size = new System.Drawing.Size(81, 17);
            this.inputMailingListCheckBox.TabIndex = 4;
            this.inputMailingListCheckBox.Text = ":Mailing List";
            this.inputMailingListCheckBox.UseVisualStyleBackColor = true;
            // 
            // inputCustomerNumberLabel
            // 
            this.inputCustomerNumberLabel.AutoSize = true;
            this.inputCustomerNumberLabel.Location = new System.Drawing.Point(14, 23);
            this.inputCustomerNumberLabel.Name = "inputCustomerNumberLabel";
            this.inputCustomerNumberLabel.Size = new System.Drawing.Size(94, 13);
            this.inputCustomerNumberLabel.TabIndex = 1;
            this.inputCustomerNumberLabel.Text = "Customer Number:";
            // 
            // inputNameLabel
            // 
            this.inputNameLabel.AutoSize = true;
            this.inputNameLabel.Location = new System.Drawing.Point(69, 49);
            this.inputNameLabel.Name = "inputNameLabel";
            this.inputNameLabel.Size = new System.Drawing.Size(38, 13);
            this.inputNameLabel.TabIndex = 2;
            this.inputNameLabel.Text = "Name:";
            // 
            // inputAddressLabel
            // 
            this.inputAddressLabel.AutoSize = true;
            this.inputAddressLabel.Location = new System.Drawing.Point(59, 75);
            this.inputAddressLabel.Name = "inputAddressLabel";
            this.inputAddressLabel.Size = new System.Drawing.Size(48, 13);
            this.inputAddressLabel.TabIndex = 3;
            this.inputAddressLabel.Text = "Address:";
            // 
            // inputPhoneLabel
            // 
            this.inputPhoneLabel.AutoSize = true;
            this.inputPhoneLabel.Location = new System.Drawing.Point(66, 101);
            this.inputPhoneLabel.Name = "inputPhoneLabel";
            this.inputPhoneLabel.Size = new System.Drawing.Size(41, 13);
            this.inputPhoneLabel.TabIndex = 4;
            this.inputPhoneLabel.Text = "Phone:";
            // 
            // displayCustomerInfo
            // 
            this.displayCustomerInfo.Location = new System.Drawing.Point(53, 185);
            this.displayCustomerInfo.Name = "displayCustomerInfo";
            this.displayCustomerInfo.Size = new System.Drawing.Size(174, 23);
            this.displayCustomerInfo.TabIndex = 1;
            this.displayCustomerInfo.Text = "Display Customer Information";
            this.displayCustomerInfo.UseVisualStyleBackColor = true;
            this.displayCustomerInfo.Click += new System.EventHandler(this.displayCustomerInfo_Click);
            // 
            // outputDisplayGroupBox
            // 
            this.outputDisplayGroupBox.Controls.Add(this.outputMailingListCheckBox);
            this.outputDisplayGroupBox.Controls.Add(this.outputCustomerPhoneLabel);
            this.outputDisplayGroupBox.Controls.Add(this.outputCustomerNumberLabel);
            this.outputDisplayGroupBox.Controls.Add(this.outputCustomerAddressLabel);
            this.outputDisplayGroupBox.Controls.Add(this.outputCustomerNameLabel);
            this.outputDisplayGroupBox.Location = new System.Drawing.Point(13, 223);
            this.outputDisplayGroupBox.Name = "outputDisplayGroupBox";
            this.outputDisplayGroupBox.Size = new System.Drawing.Size(254, 183);
            this.outputDisplayGroupBox.TabIndex = 2;
            this.outputDisplayGroupBox.TabStop = false;
            this.outputDisplayGroupBox.Text = "Display Customer Information";
            // 
            // outputCustomerNumberLabel
            // 
            this.outputCustomerNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCustomerNumberLabel.Location = new System.Drawing.Point(14, 25);
            this.outputCustomerNumberLabel.Name = "outputCustomerNumberLabel";
            this.outputCustomerNumberLabel.Size = new System.Drawing.Size(225, 23);
            this.outputCustomerNumberLabel.TabIndex = 3;
            this.outputCustomerNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputCustomerNameLabel
            // 
            this.outputCustomerNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCustomerNameLabel.Location = new System.Drawing.Point(14, 58);
            this.outputCustomerNameLabel.Name = "outputCustomerNameLabel";
            this.outputCustomerNameLabel.Size = new System.Drawing.Size(225, 23);
            this.outputCustomerNameLabel.TabIndex = 4;
            this.outputCustomerNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputCustomerAddressLabel
            // 
            this.outputCustomerAddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCustomerAddressLabel.Location = new System.Drawing.Point(14, 90);
            this.outputCustomerAddressLabel.Name = "outputCustomerAddressLabel";
            this.outputCustomerAddressLabel.Size = new System.Drawing.Size(225, 23);
            this.outputCustomerAddressLabel.TabIndex = 5;
            this.outputCustomerAddressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputCustomerPhoneLabel
            // 
            this.outputCustomerPhoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCustomerPhoneLabel.Location = new System.Drawing.Point(14, 123);
            this.outputCustomerPhoneLabel.Name = "outputCustomerPhoneLabel";
            this.outputCustomerPhoneLabel.Size = new System.Drawing.Size(225, 23);
            this.outputCustomerPhoneLabel.TabIndex = 6;
            this.outputCustomerPhoneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputMailingListCheckBox
            // 
            this.outputMailingListCheckBox.AutoSize = true;
            this.outputMailingListCheckBox.Enabled = false;
            this.outputMailingListCheckBox.Location = new System.Drawing.Point(87, 155);
            this.outputMailingListCheckBox.Name = "outputMailingListCheckBox";
            this.outputMailingListCheckBox.Size = new System.Drawing.Size(81, 17);
            this.outputMailingListCheckBox.TabIndex = 7;
            this.outputMailingListCheckBox.Text = ":Mailing List";
            this.outputMailingListCheckBox.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(104, 423);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 458);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputDisplayGroupBox);
            this.Controls.Add(this.displayCustomerInfo);
            this.Controls.Add(this.enteryGroupBox);
            this.Name = "Form1";
            this.Text = "Person";
            this.enteryGroupBox.ResumeLayout(false);
            this.enteryGroupBox.PerformLayout();
            this.outputDisplayGroupBox.ResumeLayout(false);
            this.outputDisplayGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox enteryGroupBox;
        private System.Windows.Forms.Label inputPhoneLabel;
        private System.Windows.Forms.CheckBox inputMailingListCheckBox;
        private System.Windows.Forms.Label inputAddressLabel;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.Label inputNameLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label inputCustomerNumberLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox customerNumberTextBox;
        private System.Windows.Forms.Button displayCustomerInfo;
        private System.Windows.Forms.GroupBox outputDisplayGroupBox;
        private System.Windows.Forms.CheckBox outputMailingListCheckBox;
        private System.Windows.Forms.Label outputCustomerPhoneLabel;
        private System.Windows.Forms.Label outputCustomerNumberLabel;
        private System.Windows.Forms.Label outputCustomerAddressLabel;
        private System.Windows.Forms.Label outputCustomerNameLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

