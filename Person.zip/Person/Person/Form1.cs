﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Person
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ProcessCustomerData(Customer customer)
        {
            customer.CustomerNumber = customerNumberTextBox.Text;
            customer.Name = nameTextBox.Text;
            customer.Address = addressTextBox.Text;
            customer.Phone = phoneTextBox.Text;
            customer.MailingList = inputMailingListCheckBox.Checked;
        }

        private void displayCustomerInfo_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();

            ProcessCustomerData(customer);

            outputCustomerNumberLabel.Text = customer.CustomerNumber;
            outputCustomerNameLabel.Text = customer.Name;
            outputCustomerAddressLabel.Text = customer.Address;
            outputCustomerPhoneLabel.Text = customer.Phone;
            outputMailingListCheckBox.Checked = customer.MailingList;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
