﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    class Customer : Person
    {
        private string _customerNumber;
        private bool _mailingList;

        public Customer()
        {
            _customerNumber = "";
            _mailingList = false;
        }

        public Customer(string number, bool mailing)
        {
            _customerNumber = number;
            _mailingList = mailing;
        }

        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { _customerNumber = value; }
        }

        public bool MailingList
        {
            get { return _mailingList; }
            set { _mailingList = value; }
        }
    }
}
