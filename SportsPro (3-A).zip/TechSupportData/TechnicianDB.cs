﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class TechnicianDB
    {
        // NOTE: Always returns a string, whether it's a name or "".

        public static string GetTechnicianName(int techID)
        {
            // Declare a string to hold the name. Initialize here in case no data.
            string technicianName = "";

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectStatement =
                "SELECT Name FROM Technicians WHERE TechID = @techID";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);

            // SELECT statement has a parameter, so we need
            // to pass a value for it to the command.
            selectCommand.Parameters.AddWithValue("@techID", techID);

            try
            {
                // Open the connection.
                connection.Open();

                // Execute the query.
                technicianName = (string)selectCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method will evaluate and post message.
                throw;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return technicianName;
        }
    }
}
