﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TechSupportData
{
    public class IncidentDB
    {
        public static List<Incident> GetOpenIncidents()
        {        
            // Declare a new List to contain the data we collect.
            List<Incident> incidentList = new List<Incident>();

            // Set up a SQL connection. (Not actually connected yet.)
            SqlConnection connection = TechSupportDB.GetConnection();

            // SQL select string (per instructions).
            string selectString =
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " +
                "FROM Incidents " +
                "WHERE DateClosed IS NULL";

            // Set up a SQL command.
            SqlCommand selectCommand = new SqlCommand(selectString, connection);

            try
            {
                // Establish the connection.
                connection.Open();

                // Prepare to read first line.
                SqlDataReader reader = selectCommand.ExecuteReader();

                // Read a line (if there is one).
                while (reader.Read())
                {
                    // NOTE: Always cast or convert ro the type; even strings.

                    // Declare a new Incident to store this line's data.
                    Incident incident = new Incident();

                    // Get cus
                    incident.CustomerName = 
                        CustomerDB.GetCustomerName((int)reader["CustomerID"]);

                    // Read ProductCode, change to string, store in 'incident'.
                    incident.ProductCode = reader["ProductCode"].ToString();

                    // Since TechID's source is a database, you have to
                    // check it against DBNull.Value, not just 'null'.
                    if (reader["TechID"] != DBNull.Value)
                        // If TechID exists, then the technician's name exists too.
                        incident.TechnicianName = 
                            TechnicianDB.GetTechnicianName((int)reader["TechID"]);
                    else
                        incident.TechnicianName = "";

                    // Read the DateOpen column, cast it as 'datetime', store in 'incident'.
                    incident.DateOpened = (DateTime)reader["DateOpened"];

                    // Read Title, change to string, store in 'incident'.
                    incident.Title = reader["TitleX"].ToString();

                    // Add 'incident' data to 'incidentList'.
                    incidentList.Add(incident);
                }

                // After all incidents have been read...
                reader.Close();
            }
            catch (SqlException ex)
            {
                // Calling 'throw' without 'ex' preserves the stack trace information.
                // https://msdn.microsoft.com/en-us/library/ms182363.aspx
                // Calling method has to evaluate and post message because
                // GetOpenIncidents is a static method (they can't have MessageBoxes).
                throw ex;
            }
            finally
            {
                // Close the connection.
                connection.Close();
            }

            return incidentList;
        }
    }
}
