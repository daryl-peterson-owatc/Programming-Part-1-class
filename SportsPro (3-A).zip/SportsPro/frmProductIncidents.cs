﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SportsPro
{
    public partial class frmProductIncidents : Form
    {
        public frmProductIncidents()
        {
            InitializeComponent();
        }

        private void frmProductIncidents_Load(object sender, EventArgs e)
        {
            try                                  // QUESTION: Is this overkill?
            {
                this.incidentsTableAdapter.FillByCustAndTechIDs(this.techSupportDataSet2C.Incidents);
                this.productsTableAdapter.Fill(this.techSupportDataSet2C.Products);
            }
            catch (SqlException ex)              // Data provider error of some sort.
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": \n" +
                                ex.Message, ex.GetType().ToString());
            }
        }

        private void incidentsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // The Details button is in column 9. It counts column that aren't visible.
            if (e.ColumnIndex == 9)              
            {
                // Get index number of row that was clicked.
                int rowIndex = e.RowIndex;

                // Get the contents of the row.
                DataGridViewRow row = incidentsDataGridView.Rows[rowIndex];

                // Customer ID column is at index 1.
                DataGridViewCell cell = row.Cells[1];

                // Store cell's value.
                int customerID = (int)cell.Value;
                
                // Display Customer info form.
                Form customerInfoForm = new frmCustomer();
                customerInfoForm.Tag = customerID;
                customerInfoForm.ShowDialog();
            }
        }
    }
}
