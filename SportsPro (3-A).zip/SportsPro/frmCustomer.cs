﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmCustomer : Form
    {
        #region Form events -----------------------------------------

        public frmCustomer()
        {
            InitializeComponent();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            Binding bind = zipCodeTextBox.DataBindings["Text"];
            bind.Format += FormatZipCode;
            bind.Parse += UnformatZipCode;

            this.customersTableAdapter.FillByCustomerID
                (this.techSupportDataSet2C.Customers,(int)this.Tag);
        }

        #endregion

        #region All my class methods --------------------------------

        private void FormatZipCode(object sender, ConvertEventArgs e)
        {
            if (e.Value.GetType().ToString() == "System.String")     // Right data type?
            {
                string strValue = e.Value.ToString();                // Get data.
                if (IsInt64(strValue))                               // Can be converted?
                {
                    if (strValue.Length == 9)                        // 9 characters?
                    {
                        e.Value = strValue.Substring(0, 5) + "-" +   // Format.
                                      strValue.Substring(5, 4);
                    }
                }
            }
        }

        private bool IsInt64(string sValue)
        {
            try
            {
                Convert.ToInt64(sValue);         // If error, will go to 'catch'.
                return true;                     // Otherwise it can be converted.
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private void UnformatZipCode(object sender, ConvertEventArgs e)
        {
            if (e.Value.GetType().ToString() == "System.String")     // Right data type?
            {
                string strValue = e.Value.ToString();                // Get data.
                e.Value = strValue.Replace("-", "");                 // Remove periods.
            }
        }

        #endregion
    }
}
