﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TechSupportData;

namespace SportsPro
{
    public partial class frmOpenIncidents : Form
    {
        public frmOpenIncidents()
        {
            InitializeComponent();
        }

        private void frmOpenIncidents_Load(object sender, EventArgs e)
        {
            List<Incident> incidentList = new List<Incident>();

            try
            {
                // Get list of open incidents.
                incidentList = IncidentDB.GetOpenIncidents();

                if (incidentList.Count > 0)
                {
                    for (int idx = 0; idx < incidentList.Count; idx++)
                    {
                        // First column is an Item; all subsequent columns are SubItems.
                        ListViewItem newList = new ListViewItem(incidentList[idx].CustomerName);
                        newList.SubItems.Add(incidentList[idx].ProductCode);
                        newList.SubItems.Add(incidentList[idx].TechnicianName);
                        newList.SubItems.Add(incidentList[idx].DateOpened.ToString("d"));
                        newList.SubItems.Add(incidentList[idx].Title);
                        lsvIncidents.Items.Add(newList);
                    }

                }
                else
                {
                    MessageBox.Show("No open incidents.", "Congratulations");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went horribly wrong in\n" +
                                "IncidentDB.GetOpenIncidents.\n" + 
                                "This is all I know: " + ex.Message,
                                "Oh boy!");
            }
        }
    }
}
