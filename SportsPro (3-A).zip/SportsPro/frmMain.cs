﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SportsPro
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // I added a section to save the last login name
            // because I got tired of typing my name in.
            StreamReader loginInfoFile;
            string loginFileName = "PreviousLogin.txt";
            string lastLoginName = "";

            frmLogin frmLoginScreen = new frmLogin(); // Have to have an instance before
            if (File.Exists(loginFileName))           // nLastLoginName property can be used.
            {
                try                              // Get previous login name.
                {
                    loginInfoFile = File.OpenText(loginFileName);
                    lastLoginName = loginInfoFile.ReadLine();
                    frmLoginScreen.nLastLoginName = lastLoginName;
                    loginInfoFile.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                }
            }

            // Whether file existed or not, continue.
            frmLoginScreen.nLastLoginName = lastLoginName;
            frmLoginScreen.ShowDialog();     // Get login name.

            if ((string)frmLoginScreen.Tag != lastLoginName ||  // Only save if different
                File.Exists(loginFileName))                     // or file doesn't exist.
            {
                try                          // Save login name.
                {
                    StreamWriter loginInfoFile2;
                    loginInfoFile2 = File.CreateText(loginFileName); // Overwrite.
                    loginInfoFile2.WriteLine(frmLoginScreen.Tag);
                    loginInfoFile2.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                }
            }

            if (frmLoginScreen.Tag == null)
            {
                this.Close();
            }
            else
            {
                toolStripStatusLabel1.Text = "Student Name: " + frmLoginScreen.Tag;
            }
            //toolStripStatusLabel1.Text = "Student Name: Inigo Montoya";
        }

        // Add error checking later!

        private void maintainProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form productMaintForm = new frmProductMaintenance();     // Create object.
            productMaintForm.MdiParent = this;             // Will be child form.
            productMaintForm.Show();                       // Show form, modeless.
        }

        private void maintainCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form customerMaintForm = new frmCustomerMaintenance();   // Create object.
            customerMaintForm.MdiParent = this;            // Will be child form.
            customerMaintForm.Show();                      // Show form, modeless.
        }

        private void displayIncidentsByProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form productIncidentsForm = new frmProductIncidents();   // Create object.
            productIncidentsForm.MdiParent = this;         // Will be child form.
            productIncidentsForm.Show();                   // Show form, modeless.
        }

        private void displayOpenIncidentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form openIncidentsForm = new frmOpenIncidents();    // Create object.
            openIncidentsForm.MdiParent = this;                 // Will be child form.
            openIncidentsForm.Show();                           // Show form, modeless.
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
