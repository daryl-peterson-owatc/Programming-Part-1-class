﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

// NOTE TO MYSELF: The State combo doesn't work properly unless you
//                 set the DataBindings.Text poperty to 'none'.

namespace SportsPro
{
    public partial class frmCustomerMaintenance : Form
    {
        // NOTES: When the textboxes are filled with data by the app, the TextChanged
        //        event fires, so you can't use that alone to see if text was changed
        //        by the user. When the user clicks into a textbox, the Click event
        //        fires, BUT that doesn't mean they changed anything. Therefore, if a
        //        Click event was recorded AND a TextChanged event occured, it's
        //        probable that the user changed something.
        //
        //        HOWEVER, this doesn't work when the user adds or deletes a row, so
        //        you need a separate flag for that.
        //        
        //        The DatasetSaveFlags class handles all three values.

        DatasetSaveFlags gFlags = new DatasetSaveFlags();

        #region Form events -----------------------------------------

        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }

        private void frmCustomerMaintenance_Load(object sender, EventArgs e)
        {
            // NOTE: Form properties set so form always displays at location 0,0.

            try                                  // QUESTION: Is this overkill?
            {
                this.statesTableAdapter.Fill(this.techSupportDataSet2B.States);
                this.customersTableAdapter.Fill(this.techSupportDataSet2B.Customers);
            }
            catch (SqlException ex)              // Data provider error of some sort.
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": \n" +
                                ex.Message, ex.GetType().ToString());
            }

            Binding bind = zipCodeTextBox.DataBindings["Text"]; // This adds a number format
            bind.Format += FormatZipCode;                  // for incoming numbers and
            bind.Parse += UnformatZipCode;                 // unformat for saving.
        }

        private void frmCustomerMaintenance_FormClosing(object sender, FormClosingEventArgs e)
        {
            NoLossOfData();                      // Make sure nothing is accidentally lost.
        }

        #endregion

        #region All my class methods --------------------------------

        private void FormatZipCode(object sender, ConvertEventArgs eArgs)
        {
            if (eArgs.Value.GetType().ToString() == "System.String") // Right data type?
            {
                string strValue = eArgs.Value.ToString();            // Get data.
                if (IsInt64(strValue))                               // Can be converted?
                {
                    if (strValue.Length == 9)                        // 9 characters?
                    {
                        eArgs.Value = strValue.Substring(0, 5) + "-" +    // Format.
                                      strValue.Substring(5, 4);
                    }
                }
            }
        }

        private bool IsInt64(string sValue)
        {
            try
            {
                Convert.ToInt64(sValue);         // If error, will go to 'catch'.
                return true;                     // Otherwise it can be converted.
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private bool IsPresent(Control control, string strName)
        {
            // This figures out what kind of control has been passed through the
            // generic 'control' variable. Based on that, it creates a temporary
            // instance of the exact control in order to check for proper data.
            // TextBoxes must have anything but "" in them, and ComboBoxes must
            // have a positive SelectedItem number.
            if (control.GetType().ToString() == "System.Windows.Forms.TextBox")
            {
                TextBox txtBox = (TextBox)control;    // Cast generic control to TextBox.
                if (txtBox.Text == "")                // Check Text property, if empty...
                {
                    MessageBox.Show(strName + " is a required field.",
                                    "Entry error");
                    txtBox.Focus();                   // Leave user in failed box.
                    return false;
                }
            }
            else if (control.GetType().ToString() == "System.Windows.Forms.ComboBox")
            {
                ComboBox cboBox = (ComboBox)control;  // Cast generic control to ComboBox.
                if (cboBox.SelectedIndex == -1)       // If nothing selected...
                {
                    MessageBox.Show(strName + " is a required field.",
                                    "Entry error");
                    cboBox.Focus();                   // Leave user in failed combo box.
                    return false;
                }
            }

            // If neither of the previous two 'return' statements fire, it must be ok.
            return true;
        }

        private bool IsValidData()
        {
            if (customersBindingSource.Count > 0)
            {
                return                           // If all true they will return true.
                    IsPresent(nameTextBox, "Name") &&
                    IsPresent(addressTextBox, "Address 1") &&
                    IsPresent(cityTextBox, "City") &&
                    IsPresent(stateComboBox, "State") &&
                    IsPresent(zipCodeTextBox, "ZIP Code");
            }
            else // the only Vendor in the tables was deleted. No validation required.
                return true;
        }

        // In case user changed something but didn't save. Will return true if user
        // clicks Yes (save) or No (abandon), or false if Cancel (do nothing).
        private bool NoLossOfData()
        {
            bool booValue;

            // See giant note at top of file for explanation of flags.
            if (gFlags.DataChanged &&
                   (gFlags.UserClickedIn || gFlags.DeletionOrAddtion)
               )
            {
                DialogResult answer;

                answer = MessageBox.Show("Data has been changed, but not saved.\n" +
                                         "Do you want to save your changes?",
                                         "Warning", MessageBoxButtons.YesNoCancel);
                switch (answer)
                {
                    case DialogResult.Yes:      // Try committing changes to db.
                        if (SaveDataInDataSet())
                            booValue = true;
                        else // error saving changes.
                            booValue = false;
                        break;
                    case DialogResult.No:       // Abandon changes and close form.
                        booValue = true;
                        break;
                    default:                    // Do nothing and stay in form.
                        booValue = false;
                        break;
                }
            }
            else // no changes made.
            {
                booValue = true;
            }

            return booValue;
        }

        private bool SaveDataInDataSet()
        {
            bool success = false;                // Flags calling method.

            try
            {
                this.Validate();       // The author noted that this method is sketchy.

                // Commits data in grid to dataset.
                this.customersBindingSource.EndEdit();

                // Commits data in dataset to database.
                this.tableAdapterManager.UpdateAll(this.techSupportDataSet2B);

                // Flag success.
                success = true;
            }
            catch (DBConcurrencyException)       // Row changed by another user.
            {
                MessageBox.Show("A concurrency error occurred. " +
                                "The row was not updated.", "Concurrency Exception");
            }
            catch (DataException ex)             // Invalid data of some sort.
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
                this.customersBindingSource.CancelEdit();  // Cancel the edit.
            }
            catch (SqlException ex)              // Data provider error of some sort.
            {
                MessageBox.Show("SQL Server error # " + ex.Number + ": \n" +
                                ex.Message, ex.GetType().ToString());
            }

            return success;
        }

        private void UnformatZipCode(object sender, ConvertEventArgs eArgs)    // eArgs = ref.
        {
            if (eArgs.Value.GetType().ToString() == "System.String") // Right data type?
            {
                string strValue = eArgs.Value.ToString();            // Get data.
                eArgs.Value = strValue.Replace("-", "");             // Remove periods.
            }
        }

        #endregion

        #region Binding Navigator events ----------------------------

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            gFlags.DeletionOrAddtion = true;
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            gFlags.DeletionOrAddtion = true;
        }

        private void customersBindingNavigatorCancel_Click(object sender, EventArgs e)
        {
            if (gFlags.DataChanged)                   // Do nothing unless data changed.
            {
                this.customersBindingSource.CancelEdit();
                gFlags.DataChanged = false;
            }
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            // NOTE: All exceptions are handled in these two methods.
            if (IsValidData() && SaveDataInDataSet())
            {
                // Data was just saved, so no unsaved data.
                gFlags.DataChanged = false;
                gFlags.UserClickedIn = false;
                gFlags.DeletionOrAddtion = false;
            }
        }

        #endregion

        #region FillBy ToolStrip events ---------------------

        private void fillByCustomerIDToolStripButton_Click(object sender, EventArgs e)
        {
            int customerID;

            // See if legit number is supplied.
            if (int.TryParse(customerIDToolStripTextBox.Text, out customerID))
            {
                try
                {
                    this.customersTableAdapter.FillByCustomerID
                        (this.techSupportDataSet2B.Customers, customerID);
                }
                catch (System.Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Invalid number entered.\n" +
                                "Please try again.", "Input Error");
                customerIDToolStripTextBox.Focus();
                customerIDToolStripTextBox.SelectAll();
            }
        }

        #endregion

        #region All flag-setting events -----------------------------

        // Clicks...
        private void nameTextBox_Click(object sender, EventArgs e)
        {
            gFlags.UserClickedIn = true;
            gFlags.DataChanged = false;
        }

        private void addressTextBox_Click(object sender, EventArgs e)
        {
            gFlags.UserClickedIn = true;
            gFlags.DataChanged = false;
        }

        private void cityTextBox_Click(object sender, EventArgs e)
        {
            gFlags.UserClickedIn = true;
            gFlags.DataChanged = false;
        }

        private void emailTextBox_Click(object sender, EventArgs e)
        {
            gFlags.UserClickedIn = true;
            gFlags.DataChanged = false;
        }

        private void phoneTextBox_Click(object sender, EventArgs e)
        {
            gFlags.UserClickedIn = true;
            gFlags.DataChanged = false;
        }

        // TextChanges...
        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void cityTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void stateComboBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void zipCodeTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void emailTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        private void phoneTextBox_TextChanged(object sender, EventArgs e)
        {
            gFlags.DataChanged = true;
        }

        #endregion

    }
}
