﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;            // Required for ToTitleCase in btnOk_Click.

namespace SportsPro
{
    public partial class frmLogin : Form
    {
        public string nLastLoginName;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            // If Tag remains null after close, the user cancelled.
            this.Tag = null;
            txtName.Text = nLastLoginName;
        }

        private bool HasProperCharacters(string name)
        {
            bool isTrue = true;                  // Flag for character check, default = true.

            foreach (char ch in name)            // Cycle through each character.
            {
                if (!char.IsLetter(ch))          // It can only be a letter or <space>.
                {
                    if (!char.Equals(ch, ' '))
                    {
                        isTrue = false;          // If it's neither, flag error.
                    }
                }
            }

            return isTrue;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string strText = txtName.Text;

            if (strText != "")                        // Name can't be blank.
            {
                if (HasProperCharacters(strText))     // Simple character check.
                {
                    // I found this online.
                    // Creates a TextInfo based on the "en-US" culture.
                    TextInfo myTI = new CultureInfo("en-US", false).TextInfo;
                    strText = myTI.ToTitleCase(strText);

                    this.Tag = strText;          // Set Tag prop so calling
                    this.Close();                // form can get the name.
                }
                else // invalid character.
                {
                    MessageBox.Show("Invalid character in name.\n" +
                                    "Please try again.", "Input Error");
                    txtName.Focus();             // Leave user in text box.
                }
            }
            else // didn't enter anything.
            {
                MessageBox.Show("Please enter full name.", "Input Error");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
