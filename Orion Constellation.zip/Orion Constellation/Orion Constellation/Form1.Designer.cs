﻿namespace Orion_Constellation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBoxOrion = new System.Windows.Forms.PictureBox();
            this.btnShowStarNames = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnHideStarNames = new System.Windows.Forms.Button();
            this.lblBetelgeuse = new System.Windows.Forms.Label();
            this.lblMeissa = new System.Windows.Forms.Label();
            this.lblMintaka = new System.Windows.Forms.Label();
            this.lblAlnilam = new System.Windows.Forms.Label();
            this.lblAlnitak = new System.Windows.Forms.Label();
            this.lblSaiph = new System.Windows.Forms.Label();
            this.lblRigel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrion)).BeginInit();
            this.SuspendLayout();
            // 
            // picBoxOrion
            // 
            this.picBoxOrion.Image = global::Orion_Constellation.Properties.Resources.Orion;
            this.picBoxOrion.Location = new System.Drawing.Point(9, 9);
            this.picBoxOrion.Name = "picBoxOrion";
            this.picBoxOrion.Size = new System.Drawing.Size(399, 469);
            this.picBoxOrion.TabIndex = 0;
            this.picBoxOrion.TabStop = false;
            // 
            // btnShowStarNames
            // 
            this.btnShowStarNames.Location = new System.Drawing.Point(29, 484);
            this.btnShowStarNames.Name = "btnShowStarNames";
            this.btnShowStarNames.Size = new System.Drawing.Size(75, 37);
            this.btnShowStarNames.TabIndex = 1;
            this.btnShowStarNames.Text = "Show Star Names";
            this.btnShowStarNames.UseVisualStyleBackColor = true;
            this.btnShowStarNames.Click += new System.EventHandler(this.btnShowStarNames_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(317, 485);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 36);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnHideStarNames
            // 
            this.btnHideStarNames.Location = new System.Drawing.Point(176, 484);
            this.btnHideStarNames.Name = "btnHideStarNames";
            this.btnHideStarNames.Size = new System.Drawing.Size(75, 37);
            this.btnHideStarNames.TabIndex = 5;
            this.btnHideStarNames.Text = "Hide Star Names";
            this.btnHideStarNames.UseVisualStyleBackColor = true;
            this.btnHideStarNames.Click += new System.EventHandler(this.btnHideStarNames_Click);
            // 
            // lblBetelgeuse
            // 
            this.lblBetelgeuse.AutoSize = true;
            this.lblBetelgeuse.Location = new System.Drawing.Point(59, 39);
            this.lblBetelgeuse.Name = "lblBetelgeuse";
            this.lblBetelgeuse.Size = new System.Drawing.Size(60, 13);
            this.lblBetelgeuse.TabIndex = 6;
            this.lblBetelgeuse.Text = "Betelgeuse";
            this.lblBetelgeuse.Visible = false;
            // 
            // lblMeissa
            // 
            this.lblMeissa.AutoSize = true;
            this.lblMeissa.Location = new System.Drawing.Point(267, 76);
            this.lblMeissa.Name = "lblMeissa";
            this.lblMeissa.Size = new System.Drawing.Size(40, 13);
            this.lblMeissa.TabIndex = 7;
            this.lblMeissa.Text = "Meissa";
            this.lblMeissa.Visible = false;
            // 
            // lblMintaka
            // 
            this.lblMintaka.AutoSize = true;
            this.lblMintaka.Location = new System.Drawing.Point(245, 208);
            this.lblMintaka.Name = "lblMintaka";
            this.lblMintaka.Size = new System.Drawing.Size(45, 13);
            this.lblMintaka.TabIndex = 8;
            this.lblMintaka.Text = "Mintaka";
            this.lblMintaka.Visible = false;
            // 
            // lblAlnilam
            // 
            this.lblAlnilam.AutoSize = true;
            this.lblAlnilam.Location = new System.Drawing.Point(175, 249);
            this.lblAlnilam.Name = "lblAlnilam";
            this.lblAlnilam.Size = new System.Drawing.Size(40, 13);
            this.lblAlnilam.TabIndex = 9;
            this.lblAlnilam.Text = "Alnilam";
            this.lblAlnilam.Visible = false;
            // 
            // lblAlnitak
            // 
            this.lblAlnitak.AutoSize = true;
            this.lblAlnitak.Location = new System.Drawing.Point(89, 240);
            this.lblAlnitak.Name = "lblAlnitak";
            this.lblAlnitak.Size = new System.Drawing.Size(39, 13);
            this.lblAlnitak.TabIndex = 10;
            this.lblAlnitak.Text = "Alnitak";
            this.lblAlnitak.Visible = false;
            // 
            // lblSaiph
            // 
            this.lblSaiph.AutoSize = true;
            this.lblSaiph.Location = new System.Drawing.Point(85, 399);
            this.lblSaiph.Name = "lblSaiph";
            this.lblSaiph.Size = new System.Drawing.Size(34, 13);
            this.lblSaiph.TabIndex = 11;
            this.lblSaiph.Text = "Saiph";
            this.lblSaiph.Visible = false;
            // 
            // lblRigel
            // 
            this.lblRigel.AutoSize = true;
            this.lblRigel.Location = new System.Drawing.Point(276, 368);
            this.lblRigel.Name = "lblRigel";
            this.lblRigel.Size = new System.Drawing.Size(31, 13);
            this.lblRigel.TabIndex = 12;
            this.lblRigel.Text = "Rigel";
            this.lblRigel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 533);
            this.Controls.Add(this.lblRigel);
            this.Controls.Add(this.lblSaiph);
            this.Controls.Add(this.lblAlnitak);
            this.Controls.Add(this.lblAlnilam);
            this.Controls.Add(this.lblMintaka);
            this.Controls.Add(this.lblMeissa);
            this.Controls.Add(this.lblBetelgeuse);
            this.Controls.Add(this.btnHideStarNames);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnShowStarNames);
            this.Controls.Add(this.picBoxOrion);
            this.Name = "Form1";
            this.Text = "Orion Constellation";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxOrion;
        private System.Windows.Forms.Button btnShowStarNames;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnHideStarNames;
        private System.Windows.Forms.Label lblBetelgeuse;
        private System.Windows.Forms.Label lblMeissa;
        private System.Windows.Forms.Label lblMintaka;
        private System.Windows.Forms.Label lblAlnilam;
        private System.Windows.Forms.Label lblAlnitak;
        private System.Windows.Forms.Label lblSaiph;
        private System.Windows.Forms.Label lblRigel;
    }
}

