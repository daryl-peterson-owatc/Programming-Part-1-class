﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail_Item
{
    public partial class Form1 : Form
    {
        const int SIZE = 3;
        RetailItem[] items = {
            new RetailItem(),
            new RetailItem(),
            new RetailItem()
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string desc = "Jacket";
            int quantity = 12;
            decimal amount = 59.95m;
            addItem(0, desc, quantity, amount);

            desc = "Jeans";
            quantity = 40;
            amount = 34.95m;
            addItem(1, desc, quantity, amount);

            desc = "Shirt";
            quantity = 20;
            amount = 24.95m;
            addItem(2, desc, quantity, amount);

            populateListBoxes();
        }

        private void addItem(int index, string desc, int onHand, decimal price)
        {
            items[index].Description = desc;
            items[index].UnitsOnHand = onHand;
            items[index].Price = price;
        }

        private void populateListBoxes()
        {
            for (int index = 0; index < SIZE; index++)
            {
                descriptionListBox.Items.Add(items[index].Description);
                unitsOnHandListBox.Items.Add(items[index].UnitsOnHand);
                priceListbox.Items.Add(items[index].Price);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
