﻿namespace Retail_Item
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionListBox = new System.Windows.Forms.ListBox();
            this.unitsOnHandListBox = new System.Windows.Forms.ListBox();
            this.priceListbox = new System.Windows.Forms.ListBox();
            this.exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // descriptionListBox
            // 
            this.descriptionListBox.FormattingEnabled = true;
            this.descriptionListBox.Location = new System.Drawing.Point(24, 36);
            this.descriptionListBox.Name = "descriptionListBox";
            this.descriptionListBox.Size = new System.Drawing.Size(110, 82);
            this.descriptionListBox.TabIndex = 0;
            // 
            // unitsOnHandListBox
            // 
            this.unitsOnHandListBox.FormattingEnabled = true;
            this.unitsOnHandListBox.Location = new System.Drawing.Point(140, 36);
            this.unitsOnHandListBox.Name = "unitsOnHandListBox";
            this.unitsOnHandListBox.Size = new System.Drawing.Size(53, 82);
            this.unitsOnHandListBox.TabIndex = 1;
            // 
            // priceListbox
            // 
            this.priceListbox.FormattingEnabled = true;
            this.priceListbox.Location = new System.Drawing.Point(199, 36);
            this.priceListbox.Name = "priceListbox";
            this.priceListbox.Size = new System.Drawing.Size(57, 82);
            this.priceListbox.TabIndex = 2;
            // 
            // exitbutton
            // 
            this.exitbutton.Location = new System.Drawing.Point(109, 134);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(75, 23);
            this.exitbutton.TabIndex = 3;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 180);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.priceListbox);
            this.Controls.Add(this.unitsOnHandListBox);
            this.Controls.Add(this.descriptionListBox);
            this.Name = "Form1";
            this.Text = "Retail Item";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox descriptionListBox;
        private System.Windows.Forms.ListBox unitsOnHandListBox;
        private System.Windows.Forms.ListBox priceListbox;
        private System.Windows.Forms.Button exitbutton;
    }
}

