﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Team_Leader
{
    class Team_Leader : Employee.Employee
    {
        decimal _monthlyBonus;
        double _trainingHours;

        public Team_Leader()
        {
            _monthlyBonus = 0.00m;
            _trainingHours = 0.0;
        }

        public Team_Leader(decimal bonus, double hours)
        {
            _monthlyBonus = bonus;
            _trainingHours = hours;
        }

        public decimal MonthlyBonus
        {
            get { return _monthlyBonus; }
            set { _monthlyBonus = value; }
        }

        public double TrainingHours
        {
            get { return _trainingHours; }
            set { _trainingHours = value; }
        }
    }
}
