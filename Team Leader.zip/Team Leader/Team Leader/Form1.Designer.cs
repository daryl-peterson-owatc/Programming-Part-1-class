﻿namespace Team_Leader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputPanel = new System.Windows.Forms.Panel();
            this.inputTrainingHoursLabel = new System.Windows.Forms.Label();
            this.inputMonthlyBonusLabel = new System.Windows.Forms.Label();
            this.inputEmployeeNameLabel = new System.Windows.Forms.Label();
            this.inputEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.trainingHoursTextBox = new System.Windows.Forms.TextBox();
            this.monthlyBonusTextBox = new System.Windows.Forms.TextBox();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.outputPanel = new System.Windows.Forms.Panel();
            this.trainingHourlsLabel = new System.Windows.Forms.Label();
            this.monthlyBonusLabel = new System.Windows.Forms.Label();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.createObjectButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputPanel.SuspendLayout();
            this.outputPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // inputPanel
            // 
            this.inputPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.inputPanel.Controls.Add(this.inputTrainingHoursLabel);
            this.inputPanel.Controls.Add(this.inputMonthlyBonusLabel);
            this.inputPanel.Controls.Add(this.inputEmployeeNameLabel);
            this.inputPanel.Controls.Add(this.inputEmployeeNumberLabel);
            this.inputPanel.Controls.Add(this.trainingHoursTextBox);
            this.inputPanel.Controls.Add(this.monthlyBonusTextBox);
            this.inputPanel.Controls.Add(this.employeeNameTextBox);
            this.inputPanel.Controls.Add(this.employeeNumberTextBox);
            this.inputPanel.Location = new System.Drawing.Point(16, 15);
            this.inputPanel.Name = "inputPanel";
            this.inputPanel.Size = new System.Drawing.Size(256, 126);
            this.inputPanel.TabIndex = 0;
            // 
            // inputTrainingHoursLabel
            // 
            this.inputTrainingHoursLabel.AutoSize = true;
            this.inputTrainingHoursLabel.Location = new System.Drawing.Point(32, 95);
            this.inputTrainingHoursLabel.Name = "inputTrainingHoursLabel";
            this.inputTrainingHoursLabel.Size = new System.Drawing.Size(79, 13);
            this.inputTrainingHoursLabel.TabIndex = 7;
            this.inputTrainingHoursLabel.Text = "Training Hours:";
            // 
            // inputMonthlyBonusLabel
            // 
            this.inputMonthlyBonusLabel.AutoSize = true;
            this.inputMonthlyBonusLabel.Location = new System.Drawing.Point(31, 69);
            this.inputMonthlyBonusLabel.Name = "inputMonthlyBonusLabel";
            this.inputMonthlyBonusLabel.Size = new System.Drawing.Size(80, 13);
            this.inputMonthlyBonusLabel.TabIndex = 6;
            this.inputMonthlyBonusLabel.Text = "Monthly Bonus:";
            // 
            // inputEmployeeNameLabel
            // 
            this.inputEmployeeNameLabel.AutoSize = true;
            this.inputEmployeeNameLabel.Location = new System.Drawing.Point(73, 43);
            this.inputEmployeeNameLabel.Name = "inputEmployeeNameLabel";
            this.inputEmployeeNameLabel.Size = new System.Drawing.Size(38, 13);
            this.inputEmployeeNameLabel.TabIndex = 5;
            this.inputEmployeeNameLabel.Text = "Name:";
            // 
            // inputEmployeeNumberLabel
            // 
            this.inputEmployeeNumberLabel.AutoSize = true;
            this.inputEmployeeNumberLabel.Location = new System.Drawing.Point(15, 17);
            this.inputEmployeeNumberLabel.Name = "inputEmployeeNumberLabel";
            this.inputEmployeeNumberLabel.Size = new System.Drawing.Size(96, 13);
            this.inputEmployeeNumberLabel.TabIndex = 4;
            this.inputEmployeeNumberLabel.Text = "Employee Number:";
            // 
            // trainingHoursTextBox
            // 
            this.trainingHoursTextBox.Location = new System.Drawing.Point(117, 92);
            this.trainingHoursTextBox.Name = "trainingHoursTextBox";
            this.trainingHoursTextBox.Size = new System.Drawing.Size(35, 20);
            this.trainingHoursTextBox.TabIndex = 3;
            // 
            // monthlyBonusTextBox
            // 
            this.monthlyBonusTextBox.Location = new System.Drawing.Point(117, 66);
            this.monthlyBonusTextBox.Name = "monthlyBonusTextBox";
            this.monthlyBonusTextBox.Size = new System.Drawing.Size(74, 20);
            this.monthlyBonusTextBox.TabIndex = 2;
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(117, 40);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(122, 20);
            this.employeeNameTextBox.TabIndex = 1;
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(117, 14);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeNumberTextBox.TabIndex = 0;
            // 
            // outputPanel
            // 
            this.outputPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputPanel.Controls.Add(this.trainingHourlsLabel);
            this.outputPanel.Controls.Add(this.monthlyBonusLabel);
            this.outputPanel.Controls.Add(this.employeeNameLabel);
            this.outputPanel.Controls.Add(this.employeeNumberLabel);
            this.outputPanel.Location = new System.Drawing.Point(17, 196);
            this.outputPanel.Name = "outputPanel";
            this.outputPanel.Size = new System.Drawing.Size(255, 154);
            this.outputPanel.TabIndex = 1;
            // 
            // trainingHourlsLabel
            // 
            this.trainingHourlsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.trainingHourlsLabel.Location = new System.Drawing.Point(18, 116);
            this.trainingHourlsLabel.Name = "trainingHourlsLabel";
            this.trainingHourlsLabel.Size = new System.Drawing.Size(221, 23);
            this.trainingHourlsLabel.TabIndex = 3;
            this.trainingHourlsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthlyBonusLabel
            // 
            this.monthlyBonusLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthlyBonusLabel.Location = new System.Drawing.Point(18, 81);
            this.monthlyBonusLabel.Name = "monthlyBonusLabel";
            this.monthlyBonusLabel.Size = new System.Drawing.Size(221, 23);
            this.monthlyBonusLabel.TabIndex = 2;
            this.monthlyBonusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNameLabel.Location = new System.Drawing.Point(18, 47);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(221, 23);
            this.employeeNameLabel.TabIndex = 1;
            this.employeeNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeNumberLabel.Location = new System.Drawing.Point(18, 14);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(221, 23);
            this.employeeNumberLabel.TabIndex = 0;
            this.employeeNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createObjectButton
            // 
            this.createObjectButton.Location = new System.Drawing.Point(94, 156);
            this.createObjectButton.Name = "createObjectButton";
            this.createObjectButton.Size = new System.Drawing.Size(106, 23);
            this.createObjectButton.TabIndex = 2;
            this.createObjectButton.Text = "Create Object";
            this.createObjectButton.UseVisualStyleBackColor = true;
            this.createObjectButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(95, 365);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 404);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createObjectButton);
            this.Controls.Add(this.outputPanel);
            this.Controls.Add(this.inputPanel);
            this.Name = "Form1";
            this.Text = "Team Leader";
            this.inputPanel.ResumeLayout(false);
            this.inputPanel.PerformLayout();
            this.outputPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel inputPanel;
        private System.Windows.Forms.Label inputTrainingHoursLabel;
        private System.Windows.Forms.Label inputMonthlyBonusLabel;
        private System.Windows.Forms.Label inputEmployeeNameLabel;
        private System.Windows.Forms.Label inputEmployeeNumberLabel;
        private System.Windows.Forms.TextBox trainingHoursTextBox;
        private System.Windows.Forms.TextBox monthlyBonusTextBox;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.Panel outputPanel;
        private System.Windows.Forms.Label trainingHourlsLabel;
        private System.Windows.Forms.Label monthlyBonusLabel;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.Button createObjectButton;
        private System.Windows.Forms.Button exitButton;
    }
}

