﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Team_Leader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetTeamLeaderInfo(Team_Leader leader)
        {
            decimal bonus;
            double trainingHours;

            leader.Number = employeeNumberTextBox.Text;
            leader.Name = employeeNameTextBox.Text;

            if (decimal.TryParse(monthlyBonusTextBox.Text, out bonus))
            {
                leader.MonthlyBonus = bonus;
            }
            else
            {
                MessageBox.Show("Invalid number");
            }

            if (double.TryParse(trainingHoursTextBox.Text, out trainingHours))
            {
                leader.TrainingHours = trainingHours;
            }
            else
            {
                MessageBox.Show("Invalid number");
            }
        }
    }
}
