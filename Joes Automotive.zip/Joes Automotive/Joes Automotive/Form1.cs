﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joes_Automotive
{
    public partial class Form1 : Form
    {
        // define application constants
        const decimal HOURLY_RATE = 20.00m;
        const decimal OIL_CHANGE = 26.00m;
        const decimal LUBE_JOB = 18.00M;
        const decimal RADIATOR_FLUSH = 30.00m;
        const decimal TRANSMISSION_FLUSH = 80.00m;
        const decimal INSPECTION = 15.00m;
        const decimal MUFFLER_REPLACEMENT = 100.00m;
        const decimal TIRE_ROTATION = 20.00m;
        const decimal TAX_RATE = 0.06m;

        // other variable setups
        decimal oilAndLubeTotal = 0.0m;
        decimal flushesTotal = 0.0m;
        decimal miscTotal = 0.0m;
        decimal partsTotal = 0.0m;
        decimal serviceAndLaborTotal = 0.0m;
        decimal laborTotal = 0.0m;
        decimal taxAmount = 0.0m;
        decimal totalAmount = 0.0m;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateTotalButton_Click(object sender, EventArgs e)
        {
            oilAndLubeTotal = OilLubeCharges();
            flushesTotal = FlushCharges();
            miscTotal = MiscCharges();
            laborTotal = OtherCharges();
            serviceAndLaborTotal = ServiceAndLaborCharges();
            totalAmount = TotalCharges();

            DisplayTotals();
        }

        private decimal OilLubeCharges()
        {
            decimal value = 0;

            if (oilChangeCheckBox.Checked)
            {
                value += OIL_CHANGE;
            }

            if (lubeJobCheckBox.Checked)
            {
                value += LUBE_JOB;
            }

            return value;
        }

        private decimal FlushCharges()
        {
            decimal value = 0;

            if (radiatorFlushCheckBox.Checked)
            {
                value += RADIATOR_FLUSH;
            }

            if (transmissionFlushCheckBox.Checked)
            {
                value += TRANSMISSION_FLUSH;
            }

            return value;
        }

        private decimal MiscCharges()
        {
            decimal value = 0;

            if (inspectionCheckBox.Checked)
            {
                value += INSPECTION;
            }

            if (replaceMufflerCheckBox.Checked)
            {
                value += MUFFLER_REPLACEMENT;
            }

            if (tireRotationCheckBox.Checked)
            {
                value += TIRE_ROTATION;
            }

            return value;
        }

        private decimal OtherCharges()
        {
            decimal value = 0;
            decimal parts;
            decimal labor;

            if (decimal.TryParse(partsTextBox.Text, out parts))
            {
                taxAmount = TaxCharges(parts);
                partsTotal = parts;
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric value in the Parts field.");
            }

            if (decimal.TryParse(laborTextBox.Text, out labor))
            {
                value += labor * HOURLY_RATE;
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric value in the Labor field.");
            }

            return value;
        }

        private decimal TaxCharges(decimal parts)
        {
            return parts * TAX_RATE;
        }

        private decimal ServiceAndLaborCharges()
        {
            return oilAndLubeTotal + flushesTotal + laborTotal + miscTotal;
        }

        private decimal TotalCharges()
        {
            decimal value = 0;

            value += serviceAndLaborTotal;
            value += partsTotal;
            value += taxAmount;

            return value;
        }

        private void DisplayTotals()
        {
            totalServiceLaborLabel.Text = serviceAndLaborTotal.ToString("c");
            totalPartsLabel.Text = partsTotal.ToString("c");
            totalTaxLabel.Text = taxAmount.ToString("c");
            totalFeesLabel.Text = totalAmount.ToString("c");
        }

        private void ClearOilLube()
        {
            oilChangeCheckBox.Checked = false;
            lubeJobCheckBox.Checked = false;
        }

        private void ClearFlushes()
        {
            radiatorFlushCheckBox.Checked = false;
            transmissionFlushCheckBox.Checked = false;
        }

        private void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            replaceMufflerCheckBox.Checked = false;
            tireRotationCheckBox.Checked = false;
        }

        private void ClearOther()
        {
            partsTextBox.Text = "0.00";
            laborTextBox.Text = "0";
        }

        private void ClearFees()
        {
            totalServiceLaborLabel.Text = "";
            totalPartsLabel.Text = "";
            totalTaxLabel.Text = "";
            totalFeesLabel.Text = "";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }
    }
}
