﻿namespace SportsPro
{
    partial class frmProductCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            this.eFProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nameComboBox = new System.Windows.Forms.ComboBox();
            this.eFCustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.eFCustomerDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.eFProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eFCustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eFCustomerDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(16, 24);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(47, 13);
            nameLabel.TabIndex = 1;
            nameLabel.Text = "Product:";
            // 
            // eFProductBindingSource
            // 
            this.eFProductBindingSource.DataSource = typeof(SportsPro.EFProduct);
            // 
            // nameComboBox
            // 
            this.nameComboBox.DataSource = this.eFProductBindingSource;
            this.nameComboBox.DisplayMember = "Name";
            this.nameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.nameComboBox.FormattingEnabled = true;
            this.nameComboBox.Location = new System.Drawing.Point(69, 21);
            this.nameComboBox.Name = "nameComboBox";
            this.nameComboBox.Size = new System.Drawing.Size(200, 21);
            this.nameComboBox.TabIndex = 2;
            this.nameComboBox.ValueMember = "ProductCode";
            this.nameComboBox.SelectedIndexChanged += new System.EventHandler(this.nameComboBox_SelectedIndexChanged);
            // 
            // eFCustomerBindingSource
            // 
            this.eFCustomerBindingSource.DataSource = typeof(SportsPro.EFCustomer);
            // 
            // eFCustomerDataGridView
            // 
            this.eFCustomerDataGridView.AllowUserToAddRows = false;
            this.eFCustomerDataGridView.AllowUserToDeleteRows = false;
            this.eFCustomerDataGridView.AutoGenerateColumns = false;
            this.eFCustomerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.eFCustomerDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.eFCustomerDataGridView.DataSource = this.eFCustomerBindingSource;
            this.eFCustomerDataGridView.Location = new System.Drawing.Point(19, 61);
            this.eFCustomerDataGridView.Name = "eFCustomerDataGridView";
            this.eFCustomerDataGridView.ReadOnly = true;
            this.eFCustomerDataGridView.Size = new System.Drawing.Size(635, 512);
            this.eFCustomerDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn7.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn8.HeaderText = "Email";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 250;
            // 
            // frmProductCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 585);
            this.Controls.Add(this.eFCustomerDataGridView);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameComboBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmProductCustomers";
            this.Text = "Customers by Product";
            this.Load += new System.EventHandler(this.frmProductCustomers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.eFProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eFCustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eFCustomerDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource eFProductBindingSource;
        private System.Windows.Forms.ComboBox nameComboBox;
        private System.Windows.Forms.BindingSource eFCustomerBindingSource;
        private System.Windows.Forms.DataGridView eFCustomerDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    }
}