﻿using System;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

      
     
        //Section 5
        // 5-B Export to XML
        private void exportTechnicianIncidents5BToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form exportTechIncidentsForm = new frmExportIncidents();
            exportTechIncidentsForm.MdiParent = this;
            exportTechIncidentsForm.Show();
        
        }

        // 5-C Customer mailing list
        private void createMailingList5CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form customerMailingForm = new frmCustomerMailing();
            customerMailingForm.MdiParent = this;
            customerMailingForm.Show();
        }

        // 5-D Product incidents report
        private void displayIncidents5DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form incidentTechnicianForm = new frmIncidentTechnician();
            incidentTechnicianForm.MdiParent = this;
            incidentTechnicianForm.Show();

        }

                  

    // 5-E Display incidents by customer
        private void displayIncidentsByCustomer5EToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form customerIncidentsForm = new frmCustomerIncidents();
            customerIncidentsForm.MdiParent = this;
            customerIncidentsForm.Show();
           
        }


        // 5-F Display customers by product
        private void displayCustomersByProduct5FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form productCustomersForm = new frmProductCustomers();
            productCustomersForm.MdiParent = this;
            productCustomersForm.Show();
          
        }


      // 5-G Maintain technicians
        private void maintainTechnicians5GToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form technicianMaintenanceForm = new frmTechnicianMaintenance();
            technicianMaintenanceForm.MdiParent = this;
            technicianMaintenanceForm.Show();
          
        }

        
        // Exit
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }



         
    }
}
