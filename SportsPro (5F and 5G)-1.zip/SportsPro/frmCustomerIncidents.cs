﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmCustomerIncidents : Form
    {
        public frmCustomerIncidents()
        {
            InitializeComponent();
        }


        TechSupportDataContext techSupport = new TechSupportDataContext();

        private void frmCustomerIncidents_Load(object sender, EventArgs e)
        {
            nameComboBox.SelectedIndexChanged -= nameComboBox_SelectedIndexChanged;

            var customers = from customer in techSupport.SQLCustomers
                            orderby customer.Name
                            select new { customer.CustomerID, customer.Name };
		    nameComboBox.DataSource = customers;

		    this.GetCustomerIncidents();

            nameComboBox.SelectedIndexChanged += nameComboBox_SelectedIndexChanged; 
        }

        private void GetCustomerIncidents()
        {
            var selectedCustomer =
                (from customer in techSupport.SQLCustomers 
                 where customer.CustomerID == (int)nameComboBox.SelectedValue 
                 select customer).Single();

            sQLCustomerBindingSource.Clear();
            sQLCustomerBindingSource.Add(selectedCustomer);

            sQLIncidentBindingSource.DataSource = selectedCustomer.SQLIncidents;
        }

        private void nameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetCustomerIncidents();
        }

    }
}
