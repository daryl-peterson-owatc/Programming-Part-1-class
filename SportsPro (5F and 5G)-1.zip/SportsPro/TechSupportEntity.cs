﻿
namespace SportsPro
{
    public static class TechSupportEntity
    {
        public static TechSupportEntities techSupportEF = new TechSupportEntities();
    }
}
