﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SportsPro.TechSupportDataSet5BTableAdapters;
using System.Xml;



namespace SportsPro
{
    public partial class frmExportIncidents : Form
    {

        TechSupportDataSet5B techSupportDataSet = new TechSupportDataSet5B();
        IncidentsTableAdapter incidentsTableAdapter = new IncidentsTableAdapter();

        public frmExportIncidents()
        {
            InitializeComponent();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                techSupportDataSet.Clear();
                incidentsTableAdapter.Fill(techSupportDataSet.Incidents);

                string xmlData = null;
             
                techSupportDataSet.Incidents.IncidentIDColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.CustomerIDColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.ProductCodeColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.TechIDColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.DateOpenedColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.DateClosedColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.TitleColumn.ColumnMapping = MappingType.Attribute;
                techSupportDataSet.Incidents.DescriptionColumn.ColumnMapping = MappingType.Attribute;

                xmlData = techSupportDataSet.GetXml();

                techSupportDataSet.WriteXml(txtExportFile.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

       
    }
}
