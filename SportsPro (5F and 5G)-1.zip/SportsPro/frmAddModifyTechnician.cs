﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Objects;

namespace SportsPro
{
    public partial class frmAddModifyTechnician : Form
    {
        public frmAddModifyTechnician()
        {
            InitializeComponent();
        }

        // Flag set by calling method so this form knows its mode.
        public bool addTechnician;

        // Class filled by the calling form that is used to store
        // existing technician's info. Only used when in modify mode.
        public EFTechnician technician;          

        private void frmAddModifyTechnician_Load(object sender, EventArgs e)
        {
            if (addTechnician)                   // If we're adding somebody...
                this.Text = "Add Technician";
            else                                 // otherwise, we're changing something.
            {
                this.Text = "Modify Technician";
                this.DisplayTechnician();        // Show info for tech we're adding.
            }
        }

        private void DisplayTechnician()
        {
            txtName.Text = technician.Name;      // Duh.
            txtEmail.Text = technician.Email;
            txtPhone.Text = technician.Phone;
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (IsValidData())                   // Ensures that data in text boxes is provided and
            {                                    // provided and valid.
                if (addTechnician)               // If we're adding somebody...
                {
                    // Don't need EFTechnician as the first word because the
                    // field was already declared at the top of this file.
                    technician = new EFTechnician();

                    // Put all the data from the text boxes into 'technician'.
                    this.PutTechnicianData(technician);

                    // AddToEFTechnician is created by the EF mapping.
                    TechSupportEntity.techSupportEF.AddToEFTechnicians(technician);
                    try
                    {
                        // SaveChanges is created by the EF mapping.
                        TechSupportEntity.techSupportEF.SaveChanges(); // If this works...
                        this.DialogResult = DialogResult.OK;           // leave this form as OK.
                    }
                    catch (Exception ex)
                    {
                        // General exception handler.
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
                else // we're modifying a technician.
                {
                    // Put all the data from the text boxes into 'technician'.
                    this.PutTechnicianData(technician);
                    try
                    {
                        // SaveChanges is created by the EF mapping.
                        TechSupportEntity.techSupportEF.SaveChanges(); // If this works...
                        this.DialogResult = DialogResult.OK;           // leave this form as OK.
                    }

                    // This exception is thrown if the entry was deleted or modifed by someone else.
                    catch (OptimisticConcurrencyException)
                    {
                        // Refresh the data model so the change is loaded.
                        TechSupportEntity.techSupportEF.Refresh(RefreshMode.StoreWins, 
                            technician);

                        // If 'Detached', the technician was deleted.
                        if (technician.EntityState == EntityState.Detached)
                        {
                            MessageBox.Show("Another user has deleted that technician.", 
                                "Concurrency Error");
                            this.DialogResult = DialogResult.Abort;
                        }
                        else // technician was updated.
                        {
                            MessageBox.Show("Another user has updated that technician.", 
                                "Concurrency Error");
                            this.DialogResult = DialogResult.Retry;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
            }
        }

        private bool IsValidData()
        {
            // 'Validator' refers to the class that defines these validation
            //  methods. It is defined in the Validator.cs file.
            if (Validator.IsPresent(txtName, "Name") && 
                Validator.IsPresent(txtEmail, "Email") && 
                Validator.IsPresent(txtPhone, "Phone"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void PutTechnicianData(EFTechnician technician)
        {
            technician.Name = txtName.Text;      // Duh.
            technician.Email = txtEmail.Text;
            technician.Phone = txtPhone.Text;
        }

   
    }
}
