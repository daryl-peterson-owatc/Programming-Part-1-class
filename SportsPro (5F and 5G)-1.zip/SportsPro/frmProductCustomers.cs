﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmProductCustomers : Form
    {
        // All comments are by Jay Rennemeyer.

        public frmProductCustomers()
        {
            InitializeComponent();
        }

        private void frmProductCustomers_Load(object sender, EventArgs e)
        {
            // The SelectedIndexChanged event will be triggered by the DataSource
            // call below, so it needs to be temporarily turned off.
            // Good trick, as long as you remember to add the last line in this method (*):
            nameComboBox.SelectedIndexChanged -= nameComboBox_SelectedIndexChanged;

            // 'products' is a reference to the results of the data model.
            // 'product' represents each element of data (rows) retrieved. AKA 'Range Variable'.
            // 'TechSupportEntity.techSupportEF.EFProducts' is the
            //  representation of the  table it's getting data from.
            //  It's going to return the data sorted by the 'Name' column.
            //  The 'select new' creates an anonymous type with
            //  two columns, 'ProductCode' and 'Name'.
            var products = from product in TechSupportEntity.techSupportEF.EFProducts
                           orderby product.Name
                           select new { product.ProductCode, product.Name };

            nameComboBox.DataSource = products;  //Clears the grid and loads the current
                                                 // data from the data model.
            this.GetProductCustomers();          // Uses the method below to fill the grid.

            // (*) Combo box won't work if you don't re-enable the SelectedIndexChanged event.
            nameComboBox.SelectedIndexChanged += nameComboBox_SelectedIndexChanged;
        }

        private void GetProductCustomers()
        {
            // This grabs the current SelectedValue for the name that is selectedin the combo.
            string productCode = nameComboBox.SelectedValue.ToString();

            // That value is then used to find all customers who registered that product.
            var customers = from registration in TechSupportEntity.techSupportEF.EFRegistrations
                            where registration.ProductCode == productCode // From the combo box.
                            orderby registration.Customer.Name
                            select registration.Customer;  // Selects all columns from the Customer
                                                           // table that 'registration' points to.
            eFCustomerDataGridView.DataSource = customers; // Clears the grid and loads the current
                                                           // data from the data model.
        }

        private void nameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // When a different product is selected in the combo box, it
            // calls the 'GetProductCustomers' method to fill the grid.
            this.GetProductCustomers();
        }
    }
}
