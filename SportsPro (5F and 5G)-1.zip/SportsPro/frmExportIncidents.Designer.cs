﻿namespace SportsPro
{
    partial class frmExportIncidents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExport = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtExportFile = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(23, 97);
            this.btnExport.Margin = new System.Windows.Forms.Padding(2);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(106, 28);
            this.btnExport.TabIndex = 10;
            this.btnExport.Text = "Export Incidents";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(20, 24);
            this.Label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(206, 13);
            this.Label1.TabIndex = 9;
            this.Label1.Text = "Export File:  Enter Path and XML file name";
            // 
            // txtExportFile
            // 
            this.txtExportFile.Location = new System.Drawing.Point(23, 57);
            this.txtExportFile.Margin = new System.Windows.Forms.Padding(2);
            this.txtExportFile.Name = "txtExportFile";
            this.txtExportFile.Size = new System.Drawing.Size(292, 20);
            this.txtExportFile.TabIndex = 8;
            this.txtExportFile.Text = "C:\\Temp\\5B.xml";
            // 
            // frmExportIncidents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 171);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtExportFile);
            this.Name = "frmExportIncidents";
            this.Text = "Export Incidents to XML file";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnExport;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtExportFile;
    }
}