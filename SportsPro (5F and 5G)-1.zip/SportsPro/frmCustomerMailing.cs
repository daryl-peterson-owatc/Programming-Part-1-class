﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmCustomerMailing : Form
    {
        public frmCustomerMailing()
        {
            InitializeComponent();
        }

        private void frmCustomerMailing_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'TechSupportDataSet5C.CustomersWithIncidents' table. You can move, or remove it, as needed.
            this.CustomersWithIncidentsTableAdapter.FillByCustomersWithIncidents(this.TechSupportDataSet5C.CustomersWithIncidents);

            this.reportViewer1.RefreshReport();
        }
    }
}
