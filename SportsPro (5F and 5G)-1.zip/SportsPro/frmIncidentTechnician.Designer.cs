﻿namespace SportsPro
{
    partial class frmIncidentTechnician
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.TechSupportDataSet5D = new SportsPro.TechSupportDataSet5D();
            this.IncidentTechnicianDataTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.IncidentTechnicianDataTableTableAdapter = new SportsPro.TechSupportDataSet5DTableAdapters.IncidentTechnicianDataTableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.TechSupportDataSet5D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncidentTechnicianDataTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "ReportDataSet";
            reportDataSource1.Value = this.IncidentTechnicianDataTableBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "SportsPro.rptIncidentTechnician.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(745, 475);
            this.reportViewer1.TabIndex = 0;
            // 
            // TechSupportDataSet5D
            // 
            this.TechSupportDataSet5D.DataSetName = "TechSupportDataSet5D";
            this.TechSupportDataSet5D.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // IncidentTechnicianDataTableBindingSource
            // 
            this.IncidentTechnicianDataTableBindingSource.DataMember = "IncidentTechnicianDataTable";
            this.IncidentTechnicianDataTableBindingSource.DataSource = this.TechSupportDataSet5D;
            // 
            // IncidentTechnicianDataTableTableAdapter
            // 
            this.IncidentTechnicianDataTableTableAdapter.ClearBeforeFill = true;
            // 
            // frmIncidentTechnician
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 475);
            this.Controls.Add(this.reportViewer1);
            this.Name = "frmIncidentTechnician";
            this.Load += new System.EventHandler(this.frmIncidentTechnician_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TechSupportDataSet5D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncidentTechnicianDataTableBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource IncidentTechnicianDataTableBindingSource;
        private TechSupportDataSet5D TechSupportDataSet5D;
        private TechSupportDataSet5DTableAdapters.IncidentTechnicianDataTableTableAdapter IncidentTechnicianDataTableTableAdapter;
    }
}