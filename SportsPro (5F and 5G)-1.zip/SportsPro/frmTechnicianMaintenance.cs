﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Objects;

namespace SportsPro
{
    public partial class frmTechnicianMaintenance : Form
    {
        public frmTechnicianMaintenance()
        {
            InitializeComponent();
        }

        // Class-level field for storing technician info.
        private EFTechnician selectedTechnician;

        private void frmTechnicianMaintenance_Load(object sender, EventArgs e)
        {
            // (I'm not sure why this isn't in a 'try'.)

            this.LoadTechnicianComboBox();       // Does what it says. See method below.

            // Gets all data for the currently selected technician.
            // (SelectedValue is always 0 the first time.)
            this.GetTechnician((int)cboTechnicians.SelectedValue);   
        } 

        private void LoadTechnicianComboBox()
        {
            // The SelectedIndexChanged event will be triggered by the DataSource
            // call below, so it needs to be temporarily turned off.
            cboTechnicians.SelectedIndexChanged -= cboTechnicians_SelectedIndexChanged;

            // 'technicians' is a reference to the results of the data model.
            // 'technician' represents each element of data (rows) retrieved.
            // 'TechSupportEntity.techSupportEF.EFTechnicians' is the
            //  representation of the  table it's getting data from.
            //  It's going to return the data sorted by the 'Name' column.
            //  The 'select new' creates an anonymous type with
            //  two columns, 'TechID' and 'Name'.
            var technicians = from technician in TechSupportEntity.techSupportEF.EFTechnicians
                              orderby technician.Name
                              select new { technician.TechID, technician.Name };

            cboTechnicians.DataSource = technicians;  // Clears the combo and loads the
            cboTechnicians.DisplayMember = "Name";    // data from the data model.
            cboTechnicians.ValueMember = "TechID";    // Field that is returned when a new
                                                      // technician is selected from combo.

            // Re-enable SelectedIndexChanged event.
            cboTechnicians.SelectedIndexChanged += cboTechnicians_SelectedIndexChanged;
        }

        private void GetTechnician(int techID)
        {
            // 'selectedTechnician' is a field reference to the results of the data model.
            // (I'm not sure why 'var' wasn't used.)
            // 'technician' represents each element of data (rows) retrieved.
            // 'TechSupportEntity.techSupportEF.EFTechnicians' is the
            //  representation of the  table it's getting data from.
            //  It's only getting data for the technician specified by the parameter techID.
            // 'select' returns all columns.
            // .First is used because there will never be more than one result.
            selectedTechnician = (from technician in TechSupportEntity.techSupportEF.EFTechnicians
                                 where technician.TechID == techID
                                 select technician).First();

            this.DisplayTechnician();            // Does what it says.
        }

        private void DisplayTechnician()
        {
            // This is self-explanatory.
            txtName.Text = selectedTechnician.Name;        
            txtEmail.Text = selectedTechnician.Email;
            txtPhone.Text = selectedTechnician.Phone;
        }

        private void cboTechnicians_SelectedIndexChanged(object sender, EventArgs e)
        {
            // When a different technician is selected in the combo box, it
            // calls the 'GetTechnician' method to fill the text boxes.

            try // Watch for exceptions.
            {
                this.GetTechnician((int)cboTechnicians.SelectedValue); // Loads selectedTechnician.
            }
            catch (InvalidOperationException)    // Thrown if no technician was found.
            {
                MessageBox.Show("Another user has deleted this technician.", 
                    "Technician Deleted");
                this.LoadTechnicianComboBox();   // Reload so technician disappears from list.
                this.GetTechnician((int)cboTechnicians.SelectedValue);
            }
            catch (Exception ex)
            {
                // Generic exception handler.
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
            // A 'finally' isn't required because LINQ closes connections itself.
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Displays the Add/Modify form.
            frmAddModifyTechnician addModifyTechForm = new frmAddModifyTechnician();
            
            // Sets a public field called 'addTechnician' so add/modify form is in 'add' mode.
            addModifyTechForm.addTechnician = true;
            DialogResult result = addModifyTechForm.ShowDialog();

            // If all data was valid when the user clicked Accept...
            if (result == DialogResult.OK)
            {
                // addModifyTechForm.technician is a public field of the EFTechnician
                // type, so we can assign its data to the selectedTechnician field.
                selectedTechnician = addModifyTechForm.technician;

                // Reload the combo box so the new guy shows up.
                this.LoadTechnicianComboBox();

                // If for some bizarre reason, the combo happens to have the same selected value
                // as the technician ID _which was just uniquely created by the DB_, just get the
                // data for that technician without the SelectedIndexChanged triggering.
                // Correct me if I'm wrong, but this will NEVER happen, right???
                if ((int)cboTechnicians.SelectedValue == selectedTechnician.TechID)
                {
                    this.GetTechnician(selectedTechnician.TechID);
                }
                else // otherwise, this will trigger the SelectedIndexChanged.
                {
                    cboTechnicians.SelectedValue = selectedTechnician.TechID;
                }
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            // Displays the Add/Modify form.
            frmAddModifyTechnician addModifyTechForm = new frmAddModifyTechnician();

            // Sets a public field called 'addTechnician' so add/modify form is in 'modify' mode.
            addModifyTechForm.addTechnician = false;

            // Sets a public field called 'technician' that's declared in the add/modify form.
            addModifyTechForm.technician = selectedTechnician;

            DialogResult result = addModifyTechForm.ShowDialog();

            // If all data was valid when the user clicked Accept...
            if (result == DialogResult.OK)
            {
                // addModifyTechForm.technician is a public field of the EFTechnician
                // type, so we can assign its data to the selectedTechnician field.
                selectedTechnician = addModifyTechForm.technician;

                // This is only useful if Name was changed.
                this.LoadTechnicianComboBox();

                // If the combo has the same selected value as the technician ID,
                // _and it WILL because we were just modifying_ just get the
                // data for that technician without the SelectedIndexChanged triggering.
                if ((int)cboTechnicians.SelectedValue == selectedTechnician.TechID)
                {
                    this.GetTechnician(selectedTechnician.TechID);
                }
                else // Somehow either the selected value or the technician ID changed.
                     // I may be wrong, but this will NEVER happen, Right???
                {
                    cboTechnicians.SelectedValue = selectedTechnician.TechID;
                }
            }
            else if (result == DialogResult.Retry) // Retry means the row changed before this update.
            {
                // Reload everything. Similar to the body of the previous 'if' statement.
                this.LoadTechnicianComboBox();
                if ((int)cboTechnicians.SelectedValue == selectedTechnician.TechID)
                {
                    this.GetTechnician(selectedTechnician.TechID);
                }
                else
                {
                    cboTechnicians.SelectedValue = selectedTechnician.TechID;
                }
            }
            else if (result == DialogResult.Abort)    // Abort means user cancelled.
            {
                // This isn't necessary because nothing changed, right???
                this.LoadTechnicianComboBox();
                this.GetTechnician((int)cboTechnicians.SelectedValue);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Make sure the user didn't accidentally click the Delete button.
            DialogResult result = MessageBox.Show("Delete " + 
                selectedTechnician.Name + "?", "Confirm Delete", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try // Watch for exceptions.
                {
                    // DeleteObject is created by the EF mapping.
                    TechSupportEntity.techSupportEF.DeleteObject(selectedTechnician);
                    // SaveChanges is created by the EF mapping.
                    TechSupportEntity.techSupportEF.SaveChanges();

                    // Reload so deleted technician is gone.
                    this.LoadTechnicianComboBox();
                    this.GetTechnician((int)cboTechnicians.SelectedValue);
                }

                // This exception is thrown if the entry was deleted or modifed by someone else.
                catch (OptimisticConcurrencyException)
                {
                    // Refresh the data model so the change is loaded.
                    TechSupportEntity.techSupportEF.Refresh(RefreshMode.StoreWins, 
                        selectedTechnician);
                    // If 'Detached', the technician was deleted.
                    if (selectedTechnician.EntityState == EntityState.Detached)
                    {
                        MessageBox.Show("Another user has deleted that technician.", 
                            "Concurrency Error");
                        // Reload so deleted technician is gone.
                        this.LoadTechnicianComboBox();
                        this.GetTechnician((int)cboTechnicians.SelectedValue);
                    }
                    else // The only other concurrency error is when an update happens.
                    {
                        MessageBox.Show("Another user has updated that technician.", 
                            "Concurrency Error");

                        // I'm not sure the following line is required
                        // because the combo list doesn't change.
                        this.LoadTechnicianComboBox();

                        // This will update the text boxes with new data.
                        if ((int)cboTechnicians.SelectedValue == selectedTechnician.TechID)
                        {
                            this.GetTechnician(selectedTechnician.TechID);
                        }
                        else
                        {
                            cboTechnicians.SelectedValue = selectedTechnician.TechID;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Generic exception handler.
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                }
            }
        }

        
    }
}
