﻿namespace SportsPro
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportTechnicianIncidents5BToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintainTechnicians5GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.displayCustomersByProduct5FToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incidentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createMailingList5CCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.displayIncidents5DToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.displayIncidentsByCustomer5EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.maintenanceToolStripMenuItem,
            this.registrationToolStripMenuItem,
            this.incidentsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(927, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportTechnicianIncidents5BToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exportTechnicianIncidents5BToolStripMenuItem
            // 
            this.exportTechnicianIncidents5BToolStripMenuItem.Name = "exportTechnicianIncidents5BToolStripMenuItem";
            this.exportTechnicianIncidents5BToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.exportTechnicianIncidents5BToolStripMenuItem.Text = "Export Technician Incidents (5-B)";
            this.exportTechnicianIncidents5BToolStripMenuItem.Click += new System.EventHandler(this.exportTechnicianIncidents5BToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // maintenanceToolStripMenuItem
            // 
            this.maintenanceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.maintainTechnicians5GToolStripMenuItem});
            this.maintenanceToolStripMenuItem.Name = "maintenanceToolStripMenuItem";
            this.maintenanceToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.maintenanceToolStripMenuItem.Text = "Maintenance";
            // 
            // maintainTechnicians5GToolStripMenuItem
            // 
            this.maintainTechnicians5GToolStripMenuItem.Name = "maintainTechnicians5GToolStripMenuItem";
            this.maintainTechnicians5GToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.maintainTechnicians5GToolStripMenuItem.Text = "Maintain Technicians (5-G)";
            this.maintainTechnicians5GToolStripMenuItem.Click += new System.EventHandler(this.maintainTechnicians5GToolStripMenuItem_Click);
            // 
            // registrationToolStripMenuItem
            // 
            this.registrationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayCustomersByProduct5FToolStripMenuItem});
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.registrationToolStripMenuItem.Text = "Registration";
            // 
            // displayCustomersByProduct5FToolStripMenuItem
            // 
            this.displayCustomersByProduct5FToolStripMenuItem.Name = "displayCustomersByProduct5FToolStripMenuItem";
            this.displayCustomersByProduct5FToolStripMenuItem.Size = new System.Drawing.Size(261, 22);
            this.displayCustomersByProduct5FToolStripMenuItem.Text = "Display Customers by Product (5-F)";
            this.displayCustomersByProduct5FToolStripMenuItem.Click += new System.EventHandler(this.displayCustomersByProduct5FToolStripMenuItem_Click);
            // 
            // incidentsToolStripMenuItem
            // 
            this.incidentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createMailingList5CCToolStripMenuItem,
            this.displayIncidents5DToolStripMenuItem1,
            this.displayIncidentsByCustomer5EToolStripMenuItem});
            this.incidentsToolStripMenuItem.Name = "incidentsToolStripMenuItem";
            this.incidentsToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.incidentsToolStripMenuItem.Text = "Incidents";
            // 
            // createMailingList5CCToolStripMenuItem
            // 
            this.createMailingList5CCToolStripMenuItem.Name = "createMailingList5CCToolStripMenuItem";
            this.createMailingList5CCToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.createMailingList5CCToolStripMenuItem.Text = "Create Mailing List (5-C)";
            this.createMailingList5CCToolStripMenuItem.Click += new System.EventHandler(this.createMailingList5CToolStripMenuItem_Click);
            // 
            // displayIncidents5DToolStripMenuItem1
            // 
            this.displayIncidents5DToolStripMenuItem1.Name = "displayIncidents5DToolStripMenuItem1";
            this.displayIncidents5DToolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.displayIncidents5DToolStripMenuItem1.Text = "Display Incidents by Product and Technician (5-D)";
            this.displayIncidents5DToolStripMenuItem1.Click += new System.EventHandler(this.displayIncidents5DToolStripMenuItem_Click);
            // 
            // displayIncidentsByCustomer5EToolStripMenuItem
            // 
            this.displayIncidentsByCustomer5EToolStripMenuItem.Name = "displayIncidentsByCustomer5EToolStripMenuItem";
            this.displayIncidentsByCustomer5EToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.displayIncidentsByCustomer5EToolStripMenuItem.Text = "Display Incidents by Customer (5-E)";
            this.displayIncidentsByCustomer5EToolStripMenuItem.Click += new System.EventHandler(this.displayIncidentsByCustomer5EToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 645);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(927, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(158, 17);
            this.toolStripStatusLabel1.Text = "Student Name: Jack Pickford";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 667);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "SportsPro System";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportTechnicianIncidents5BToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem displayCustomersByProduct5FToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incidentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createMailingList5CCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem displayIncidentsByCustomer5EToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem maintainTechnicians5GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem displayIncidents5DToolStripMenuItem1;
    }
}

