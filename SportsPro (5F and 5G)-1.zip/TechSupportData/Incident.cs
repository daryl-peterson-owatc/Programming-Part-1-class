﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TechSupportData
{
    public class Incident
    {
        private int incidentID;
        private int customerID;
        private string productCode;
        private int? techID;
        private DateTime dateOpened;
        private DateTime? dateClosed;
        private string title;
        private string description;

        public Incident()
        {
        }

        public int IncidentID
        {
            get
            {
                return incidentID;
            }

            set
            {
                incidentID = value;
            }
        }

        public int CustomerID
        {
            get
            {
                return customerID;
            }
            set
            {
                customerID = value;
            }
        }

        public string ProductCode
        {
            get
            {
                return productCode;
            }
            set
            {
                productCode = value;
            }
        }

        public int? TechID
        {
            get
            {
                if (techID.HasValue)
                    return techID;
                else
                    return null;
            }
            set
            {
                techID = value;
            }
        }

        public DateTime DateOpened
        {
            get
            {
                return dateOpened;
            }
            set
            {
                dateOpened = value;
            }
        }

        public DateTime? DateClosed
        {
            get
            {
                if (dateClosed.HasValue)
                    return dateClosed;
                else
                    return null;
            }
            set
            {
                dateClosed = value;
            }
        }

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

        public string CustomerName
        {
            get
            {
                string name = "";
                if (customerID != 0)
                {
                    try
                    {
                        name = CustomerDB.GetCustomerName(customerID);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                return name;
            }
        }

        public string TechName
        {
            get
            {
                string name = "";
                if (techID.HasValue)
                {
                    try
                    {
                        name = TechnicianDB.GetTechnicianName(Convert.ToInt32(techID));
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                return name;
            }
        }

        public string ProductName
        {
            get
            {
                string name = "";
                if (productCode != "")
                {
                    try
                    {
                        name = ProductDB.GetProductName(productCode);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                return name;
            }
        }
    }
}
