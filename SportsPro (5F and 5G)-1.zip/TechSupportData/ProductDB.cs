﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TechSupportData
{
    public static class ProductDB
    {

        public static List<Product> GetProductList()
        {
            List<Product> productList = new List<Product>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT ProductCode, Name " +
                "FROM Products " +
                "ORDER BY Name";
            SqlCommand selectCommand =
                new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Product product = new Product();
                    product.ProductCode = reader["ProductCode"].ToString();
                    product.Name = reader["Name"].ToString();
                    productList.Add(product);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return productList;
        }

        public static string GetProductName(string productCode)
        {
            string name = null;
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT Name FROM Products " +
                "WHERE productCode = '" + productCode + "'";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return name;
        }
    }
}
