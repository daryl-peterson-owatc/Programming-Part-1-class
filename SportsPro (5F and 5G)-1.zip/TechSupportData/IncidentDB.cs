﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace TechSupportData
{
    public static class IncidentDB
    {
        public static List<Incident> GetOpenIncidents()
        {
            List<Incident> incidentList = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = 
                "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " + 
                "FROM Incidents " + 
                "WHERE DateClosed IS NULL";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Incident incident = new Incident();
                    incident.CustomerID = (int)reader["CustomerID"];
                    incident.ProductCode = reader["ProductCode"].ToString();
                    if (reader["TechID"] == DBNull.Value)
                    {
                        incident.TechID = null;
                    }
                    else
                    {
                        incident.TechID = (int)(reader["TechID"]);
                    }
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    incident.Title = reader["Title"].ToString();
                    incidentList.Add(incident);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return incidentList;
        }

        public static void AddIncident(Incident incident)
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            string insertStatement =
                "INSERT Incidents " +
                "    (CustomerID, ProductCode, DateOpened, Title, Description) " +
                "VALUES (@CustomerID, @ProductCode, @DateOpened, @Title, @Description)";
            SqlCommand insertCommand =
                new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@CustomerID", incident.CustomerID);
            insertCommand.Parameters.AddWithValue("@ProductCode", incident.ProductCode);
            insertCommand.Parameters.AddWithValue("@DateOpened", incident.DateOpened);
            insertCommand.Parameters.AddWithValue("@Title", incident.Title);
            insertCommand.Parameters.AddWithValue("@Description", incident.Description);
            try
            {
                connection.Open();
                insertCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static Incident GetIncident(int incidentID)
        {
            Incident incident = new Incident();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = 
                "SELECT IncidentID, CustomerID, ProductCode, TechID, " + 
                "DateOpened, DateClosed, Title, Description " + 
                "FROM Incidents " + 
                "WHERE IncidentID = @IncidentID";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@IncidentID", incidentID);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader(
                    CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    incident.IncidentID = (int)reader["IncidentID"];
                    incident.CustomerID = (int)reader["CustomerID"];
                    incident.ProductCode = reader["ProductCode"].ToString();
                    if (reader["TechID"] == DBNull.Value)
                    {
                        incident.TechID = null;
                    }
                    else
                    {
                        incident.TechID = (int)reader["TechID"];
                    }
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    if (reader["DateClosed"] == DBNull.Value)
                    {
                        incident.DateClosed = null;
                    }
                    else
                    {
                        incident.DateClosed = (DateTime)reader["DateClosed"];
                    }
                    incident.Title = reader["Title"].ToString();
                    incident.Description = reader["Description"].ToString();
                }
                else
                {
                    incident = null;
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return incident;
        }

        public static bool UpdateIncident(Incident incident, string description)
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            string updateStatement = 
                "UPDATE Incidents " + 
                "SET Description = @NewDescription " + 
                "WHERE IncidentID = @IncidentID " + 
                "  AND Description = @Description " + 
                "  AND DateClosed IS NULL";
            SqlCommand updateCommand = new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue("@NewDescription", description);
            updateCommand.Parameters.AddWithValue("@IncidentID", incident.IncidentID);
            updateCommand.Parameters.AddWithValue("@Description", incident.Description);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool CloseIncident(Incident incident)
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            string updateStatement = 
                "UPDATE Incidents " + 
                "SET DateClosed = @DateClosed " + 
                "WHERE IncidentID = @IncidentID " + 
                "  AND Description = @Description " + 
                "  AND DateClosed IS NULL";
            SqlCommand updateCommand = new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue("@DateClosed", DateTime.Today);
            updateCommand.Parameters.AddWithValue("@IncidentID", incident.IncidentID);
            updateCommand.Parameters.AddWithValue("@Description", incident.Description);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static List<Incident> GetOpenTechnicianIncidents(int techID)
        {
            List<Incident> incidentList = new List<Incident>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT CustomerID, ProductCode, DateOpened, Title " +
                "FROM Incidents " +
                "WHERE TechID = @TechID AND DateClosed IS NULL";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@TechID", techID);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Incident incident = new Incident();
                    incident.CustomerID = (int)reader["CustomerID"];
                    incident.ProductCode = reader["ProductCode"].ToString();
                    incident.DateOpened = (DateTime)reader["DateOpened"];
                    incident.Title = reader["Title"].ToString();
                    incidentList.Add(incident);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return incidentList;
        }
    }
}
