﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace TechSupportData
{
    public static class TechnicianDB
    {
        public static string GetTechnicianName(int techID)
        {
            string name = null;
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = 
                "SELECT Name FROM Technicians " + 
                "WHERE TechID = " + techID;
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return name;
        }

        public static List<Technician> GetTechnicianList()
        {
            List<Technician> technicianList = new List<Technician>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT TechID, Name " +
                "FROM Technicians " +
                "ORDER BY Name";
            SqlCommand selectCommand =
                new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Technician technician = new Technician();
                    technician.TechID = (int)reader["TechID"];
                    technician.Name = reader["Name"].ToString();
                    technicianList.Add(technician);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return technicianList;
        }

        public static Technician GetTechnician(int techID)
        {
            Technician technician = new Technician();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT TechID, Name, Email, Phone " +
                "FROM Technicians " +
                "WHERE TechID = @TechID";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@TechID", techID);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader(
                    CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    technician.TechID = (int)reader["TechID"];
                    technician.Name = reader["Name"].ToString();
                    technician.Email = reader["Email"].ToString();
                    technician.Phone = reader["Phone"].ToString();
                }
                else
                {
                    technician = null;
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return technician;
        }
    }
}
