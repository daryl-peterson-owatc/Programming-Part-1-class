﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TechSupportData
{
    public static class RegistrationDB
    {
        public static bool ProductRegistered(int customerID, string productCode)
        {
            int count = 0;
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = 
                "SELECT COUNT(*) FROM Registrations " + 
                "WHERE CustomerID = @CustomerID AND ProductCode = @ProductCode";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@CustomerID", customerID);
            selectCommand.Parameters.AddWithValue("@ProductCode", productCode);
            try
            {
                connection.Open();
                count = (int)selectCommand.ExecuteScalar();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static void AddRegistration(Registration registration)
        {
            SqlConnection connection = TechSupportDB.GetConnection();
            string insertStatement = "INSERT Registrations " + "(CustomerID, ProductCode, RegistrationDate) " + "VALUES (@CustomerID, @ProductCode, @RegistrationDate)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@CustomerID", registration.CustomerID);
            insertCommand.Parameters.AddWithValue("@ProductCode", registration.ProductCode);
            insertCommand.Parameters.AddWithValue("@RegistrationDate", registration.RegistrationDate);
            try
            {
                connection.Open();
                insertCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
