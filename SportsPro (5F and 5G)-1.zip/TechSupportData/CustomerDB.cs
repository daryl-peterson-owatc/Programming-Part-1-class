﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TechSupportData
{
    public static class CustomerDB
    {
        public static string GetCustomerName(int customerID)
        {
            string name = null;
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement = 
                "SELECT Name FROM Customers " + 
                "WHERE CustomerID = " + customerID;
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                name = selectCommand.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return name;
        }

        public static List<Customer> GetCustomerList()
        {
            List<Customer> customerList = new List<Customer>();
            SqlConnection connection = TechSupportDB.GetConnection();
            string selectStatement =
                "SELECT CustomerID, Name " +
                "FROM Customers " +
                "ORDER BY Name";
            SqlCommand selectCommand =
                new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Customer customer = new Customer();
                    customer.CustomerID = (int)reader["CustomerID"];
                    customer.Name = reader["Name"].ToString();
                    customerList.Add(customer);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return customerList;
        }
    }
}
