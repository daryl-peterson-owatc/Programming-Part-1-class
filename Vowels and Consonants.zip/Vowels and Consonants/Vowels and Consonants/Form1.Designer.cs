﻿namespace Vowels_and_Consonants
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.wordsTextBox = new System.Windows.Forms.TextBox();
            this.countVowelsAndConsonantsTextBox = new System.Windows.Forms.Button();
            this.vowelsDescriptionLabel = new System.Windows.Forms.Label();
            this.consonantsDescriptionLabel = new System.Windows.Forms.Label();
            this.vowelCountLabel = new System.Windows.Forms.Label();
            this.consonantsCountLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(77, 15);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(388, 13);
            this.instructionsLabel.TabIndex = 0;
            this.instructionsLabel.Text = "Enter several words and I will tell you how many Vowels and Consonants there is.";
            // 
            // wordsTextBox
            // 
            this.wordsTextBox.Location = new System.Drawing.Point(18, 42);
            this.wordsTextBox.Name = "wordsTextBox";
            this.wordsTextBox.Size = new System.Drawing.Size(509, 20);
            this.wordsTextBox.TabIndex = 1;
            // 
            // countVowelsAndConsonantsTextBox
            // 
            this.countVowelsAndConsonantsTextBox.Location = new System.Drawing.Point(180, 79);
            this.countVowelsAndConsonantsTextBox.Name = "countVowelsAndConsonantsTextBox";
            this.countVowelsAndConsonantsTextBox.Size = new System.Drawing.Size(176, 23);
            this.countVowelsAndConsonantsTextBox.TabIndex = 2;
            this.countVowelsAndConsonantsTextBox.Text = "Count Vowels and Consonants";
            this.countVowelsAndConsonantsTextBox.UseVisualStyleBackColor = true;
            this.countVowelsAndConsonantsTextBox.Click += new System.EventHandler(this.countVowelsAndConsonantsTextBox_Click);
            // 
            // vowelsDescriptionLabel
            // 
            this.vowelsDescriptionLabel.AutoSize = true;
            this.vowelsDescriptionLabel.Location = new System.Drawing.Point(76, 121);
            this.vowelsDescriptionLabel.Name = "vowelsDescriptionLabel";
            this.vowelsDescriptionLabel.Size = new System.Drawing.Size(93, 13);
            this.vowelsDescriptionLabel.TabIndex = 3;
            this.vowelsDescriptionLabel.Text = "Number of Vowels";
            // 
            // consonantsDescriptionLabel
            // 
            this.consonantsDescriptionLabel.AutoSize = true;
            this.consonantsDescriptionLabel.Location = new System.Drawing.Point(350, 121);
            this.consonantsDescriptionLabel.Name = "consonantsDescriptionLabel";
            this.consonantsDescriptionLabel.Size = new System.Drawing.Size(115, 13);
            this.consonantsDescriptionLabel.TabIndex = 4;
            this.consonantsDescriptionLabel.Text = "Number of Consonants";
            // 
            // vowelCountLabel
            // 
            this.vowelCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vowelCountLabel.Location = new System.Drawing.Point(74, 136);
            this.vowelCountLabel.Name = "vowelCountLabel";
            this.vowelCountLabel.Size = new System.Drawing.Size(100, 23);
            this.vowelCountLabel.TabIndex = 5;
            this.vowelCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // consonantsCountLabel
            // 
            this.consonantsCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.consonantsCountLabel.Location = new System.Drawing.Point(353, 136);
            this.consonantsCountLabel.Name = "consonantsCountLabel";
            this.consonantsCountLabel.Size = new System.Drawing.Size(100, 23);
            this.consonantsCountLabel.TabIndex = 6;
            this.consonantsCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(228, 183);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 221);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.consonantsCountLabel);
            this.Controls.Add(this.vowelCountLabel);
            this.Controls.Add(this.consonantsDescriptionLabel);
            this.Controls.Add(this.vowelsDescriptionLabel);
            this.Controls.Add(this.countVowelsAndConsonantsTextBox);
            this.Controls.Add(this.wordsTextBox);
            this.Controls.Add(this.instructionsLabel);
            this.Name = "Form1";
            this.Text = "Vowels and Consonants";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.TextBox wordsTextBox;
        private System.Windows.Forms.Button countVowelsAndConsonantsTextBox;
        private System.Windows.Forms.Label vowelsDescriptionLabel;
        private System.Windows.Forms.Label consonantsDescriptionLabel;
        private System.Windows.Forms.Label vowelCountLabel;
        private System.Windows.Forms.Label consonantsCountLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

