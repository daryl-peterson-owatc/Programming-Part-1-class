﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vowels_and_Consonants
{
    public partial class Form1 : Form
    {
        const string VOWELS = "AEIOU";
        const string CONSONANTS = "BCDFGHJKLMNPQRSTVWXYZ";

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void countVowelsAndConsonantsTextBox_Click(object sender, EventArgs e)
        {
            string words = wordsTextBox.Text;
            int numberOfVowels = CountVowels(words);
            int numberOfConsonants = CountConsonants(words);
            DisplayTotals(numberOfVowels, numberOfConsonants);
        }

        private int CountVowels(string words)
        {
            return words.ToUpper().Count(VOWELS.Contains);
            //int count = 0;
            //words = words.ToUpper();

            //foreach (char letter in words)
            //{
            //    if (VOWELS.Contains(letter))
            //    {
            //        count++;
            //    }
            //}

            //return count;
        }

        private int CountConsonants(string words)
        {
            return words.ToUpper().Count(CONSONANTS.Contains);
            //int count = 0;
            //words = words.ToUpper();

            //foreach (char letter in words)
            //{
            //    if (CONSONANTS.Contains(letter))
            //    {
            //        count++;
            //    }
            //}

            //return count;
        }

        private void DisplayTotals(int vowels, int consonants)
        {
            vowelCountLabel.Text = vowels.ToString();
            consonantsCountLabel.Text = consonants.ToString();
        }
    }
}
