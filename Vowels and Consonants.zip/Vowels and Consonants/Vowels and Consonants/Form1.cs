﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vowels_and_Consonants
{
    public partial class Form1 : Form
    {
        const string VOWELS = "AEIOU";
        const string CONSONANTS = "BCDFGHJKLMNPQRSTVWXYZ";

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void countVowelsAndConsonantsTextBox_Click(object sender, EventArgs e)
        {
            string words = wordsTextBox.Text;
        }

        private int countVowels(string words)
        {
            int count = 0;
            words = words.ToUpper();

            for (int index = 0; index < words.Length; index++)
            {

                count += VOWELS.Contains(words.Substring);
            }
        }
    }
}
