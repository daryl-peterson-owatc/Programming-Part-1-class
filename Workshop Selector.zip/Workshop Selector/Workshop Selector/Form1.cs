﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class Form1 : Form
    {
        const decimal HANDLING_STRESS_FEE = 1000.0m;
        const decimal TIME_MANAGEMENT_FEE = 800.0m;
        const decimal SUPERVISION_SKILLS_FEE = 1500.0m;
        const decimal NEGOTIATION_FEE = 1300.0m;
        const decimal HOW_TO_INTERVIEW_FEE = 500.0m;

        const int HANDLING_STRESS_DAYS = 3;
        const int TIME_MANAGEMENT_DAYS = 3;
        const int SUPERVISION_SKILLS_DAYS = 3;
        const int NEGOTIATION_DAYS = 5;
        const int HOW_TO_INTERVIEW_DAYS = 1;

        const decimal AUSTIN = 150.0m;
        const decimal CHICAGO = 225.0m;
        const decimal DALLAS = 175.0m;
        const decimal ORLANDO = 300.0m;
        const decimal PHOENIX = 175.0m;
        const decimal RALEIGH = 150.0m;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculateWorkshop_Click(object sender, EventArgs e)
        {
            if (!(lstBxWorkshops.SelectedIndex == -1) && !(lstBxLocations.SelectedIndex == -1))
            {
                decimal registrationAmount = 0.0m;
                int numberOfDays = 0;
                decimal locationLodgingAmount = 0.0m;
                decimal totalLodgingAmount = 0.0m;
                decimal totalWorkshopAmount = 0.0m;

                switch (lstBxWorkshops.SelectedIndex)
                {
                    case 0:
                        registrationAmount = HANDLING_STRESS_FEE;
                        numberOfDays = HANDLING_STRESS_DAYS;
                        break;
                    case 1:
                        registrationAmount = TIME_MANAGEMENT_FEE;
                        numberOfDays = TIME_MANAGEMENT_DAYS;
                        break;
                    case 2:
                        registrationAmount = SUPERVISION_SKILLS_FEE;
                        numberOfDays = SUPERVISION_SKILLS_DAYS;
                        break;
                    case 3:
                        registrationAmount = NEGOTIATION_FEE;
                        numberOfDays = NEGOTIATION_DAYS;
                        break;
                    case 4:
                        registrationAmount = HOW_TO_INTERVIEW_FEE;
                        numberOfDays = HOW_TO_INTERVIEW_DAYS;
                        break;
                }

                switch (lstBxLocations.SelectedIndex)
                {
                    case 0:
                        locationLodgingAmount = AUSTIN;
                        break;
                    case 1:
                        locationLodgingAmount = CHICAGO;
                        break;
                    case 2:
                        locationLodgingAmount = DALLAS;
                        break;
                    case 3:
                        locationLodgingAmount = ORLANDO;
                        break;
                    case 4:
                        locationLodgingAmount = PHOENIX;
                        break;
                    case 5:
                        locationLodgingAmount = RALEIGH;
                        break;
                }

                totalLodgingAmount = numberOfDays * locationLodgingAmount;
                totalWorkshopAmount = registrationAmount + totalLodgingAmount;

                lblRegistrationAmount.Text = registrationAmount.ToString("c");
                lblLodgingAmount.Text = totalLodgingAmount.ToString("c");
                lblTotalAmount.Text = totalWorkshopAmount.ToString("c");
            }
            else
            {
                MessageBox.Show("Please select an item from both list boxes.");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
