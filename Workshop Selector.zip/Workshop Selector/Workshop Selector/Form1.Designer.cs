﻿namespace Workshop_Selector
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWorkshopsDescription = new System.Windows.Forms.Label();
            this.lblLodgingPerDayDescription = new System.Windows.Forms.Label();
            this.lstBxWorkshops = new System.Windows.Forms.ListBox();
            this.lstBxLocations = new System.Windows.Forms.ListBox();
            this.lblBillingInformation = new System.Windows.Forms.Label();
            this.lblRegistrationDescription = new System.Windows.Forms.Label();
            this.lblRegistrationAmount = new System.Windows.Forms.Label();
            this.lblLodgingDesciption = new System.Windows.Forms.Label();
            this.lblLodgingAmount = new System.Windows.Forms.Label();
            this.lblTotalDescription = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.btnCalculateWorkshop = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWorkshopsDescription
            // 
            this.lblWorkshopsDescription.AutoSize = true;
            this.lblWorkshopsDescription.Location = new System.Drawing.Point(25, 19);
            this.lblWorkshopsDescription.Name = "lblWorkshopsDescription";
            this.lblWorkshopsDescription.Size = new System.Drawing.Size(156, 13);
            this.lblWorkshopsDescription.TabIndex = 0;
            this.lblWorkshopsDescription.Text = "Available Workshops and days.";
            // 
            // lblLodgingPerDayDescription
            // 
            this.lblLodgingPerDayDescription.AutoSize = true;
            this.lblLodgingPerDayDescription.Location = new System.Drawing.Point(225, 22);
            this.lblLodgingPerDayDescription.Name = "lblLodgingPerDayDescription";
            this.lblLodgingPerDayDescription.Size = new System.Drawing.Size(195, 13);
            this.lblLodgingPerDayDescription.TabIndex = 1;
            this.lblLodgingPerDayDescription.Text = "Workshop location and lodging per day.";
            // 
            // lstBxWorkshops
            // 
            this.lstBxWorkshops.FormattingEnabled = true;
            this.lstBxWorkshops.Items.AddRange(new object[] {
            "Handling Stress $1,000 - 3 days",
            "Time Managerment $800 - 3 days",
            "Supervision Skills $1,500 - 3 days",
            "Negotiation $1,300 - 5 days",
            "How to Interview $500 - 1 day"});
            this.lstBxWorkshops.Location = new System.Drawing.Point(28, 52);
            this.lstBxWorkshops.Name = "lstBxWorkshops";
            this.lstBxWorkshops.Size = new System.Drawing.Size(178, 69);
            this.lstBxWorkshops.TabIndex = 2;
            // 
            // lstBxLocations
            // 
            this.lstBxLocations.FormattingEnabled = true;
            this.lstBxLocations.Items.AddRange(new object[] {
            "Austin - $150",
            "Chicago - $225",
            "Dallas - $175",
            "Orlando $300",
            "Phoenix $175",
            "Raleigh $150"});
            this.lstBxLocations.Location = new System.Drawing.Point(228, 52);
            this.lstBxLocations.Name = "lstBxLocations";
            this.lstBxLocations.Size = new System.Drawing.Size(92, 82);
            this.lstBxLocations.TabIndex = 3;
            // 
            // lblBillingInformation
            // 
            this.lblBillingInformation.AutoSize = true;
            this.lblBillingInformation.Location = new System.Drawing.Point(125, 144);
            this.lblBillingInformation.Name = "lblBillingInformation";
            this.lblBillingInformation.Size = new System.Drawing.Size(89, 13);
            this.lblBillingInformation.TabIndex = 4;
            this.lblBillingInformation.Text = "Billing Information";
            // 
            // lblRegistrationDescription
            // 
            this.lblRegistrationDescription.AutoSize = true;
            this.lblRegistrationDescription.Location = new System.Drawing.Point(148, 171);
            this.lblRegistrationDescription.Name = "lblRegistrationDescription";
            this.lblRegistrationDescription.Size = new System.Drawing.Size(66, 13);
            this.lblRegistrationDescription.TabIndex = 5;
            this.lblRegistrationDescription.Text = "Registration:";
            // 
            // lblRegistrationAmount
            // 
            this.lblRegistrationAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRegistrationAmount.Location = new System.Drawing.Point(220, 166);
            this.lblRegistrationAmount.Name = "lblRegistrationAmount";
            this.lblRegistrationAmount.Size = new System.Drawing.Size(100, 23);
            this.lblRegistrationAmount.TabIndex = 6;
            this.lblRegistrationAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLodgingDesciption
            // 
            this.lblLodgingDesciption.AutoSize = true;
            this.lblLodgingDesciption.Location = new System.Drawing.Point(166, 205);
            this.lblLodgingDesciption.Name = "lblLodgingDesciption";
            this.lblLodgingDesciption.Size = new System.Drawing.Size(48, 13);
            this.lblLodgingDesciption.TabIndex = 7;
            this.lblLodgingDesciption.Text = "Lodging:";
            // 
            // lblLodgingAmount
            // 
            this.lblLodgingAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLodgingAmount.Location = new System.Drawing.Point(220, 200);
            this.lblLodgingAmount.Name = "lblLodgingAmount";
            this.lblLodgingAmount.Size = new System.Drawing.Size(100, 23);
            this.lblLodgingAmount.TabIndex = 8;
            this.lblLodgingAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalDescription
            // 
            this.lblTotalDescription.AutoSize = true;
            this.lblTotalDescription.Location = new System.Drawing.Point(141, 237);
            this.lblTotalDescription.Name = "lblTotalDescription";
            this.lblTotalDescription.Size = new System.Drawing.Size(73, 13);
            this.lblTotalDescription.TabIndex = 9;
            this.lblTotalDescription.Text = "Total Amount:";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalAmount.Location = new System.Drawing.Point(220, 232);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(100, 23);
            this.lblTotalAmount.TabIndex = 10;
            this.lblTotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCalculateWorkshop
            // 
            this.btnCalculateWorkshop.Location = new System.Drawing.Point(129, 277);
            this.btnCalculateWorkshop.Name = "btnCalculateWorkshop";
            this.btnCalculateWorkshop.Size = new System.Drawing.Size(75, 43);
            this.btnCalculateWorkshop.TabIndex = 11;
            this.btnCalculateWorkshop.Text = "Calculate Workstop";
            this.btnCalculateWorkshop.UseVisualStyleBackColor = true;
            this.btnCalculateWorkshop.Click += new System.EventHandler(this.btnCalculateWorkshop_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(222, 278);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 42);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 336);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculateWorkshop);
            this.Controls.Add(this.lblTotalAmount);
            this.Controls.Add(this.lblTotalDescription);
            this.Controls.Add(this.lblLodgingAmount);
            this.Controls.Add(this.lblLodgingDesciption);
            this.Controls.Add(this.lblRegistrationAmount);
            this.Controls.Add(this.lblRegistrationDescription);
            this.Controls.Add(this.lblBillingInformation);
            this.Controls.Add(this.lstBxLocations);
            this.Controls.Add(this.lstBxWorkshops);
            this.Controls.Add(this.lblLodgingPerDayDescription);
            this.Controls.Add(this.lblWorkshopsDescription);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWorkshopsDescription;
        private System.Windows.Forms.Label lblLodgingPerDayDescription;
        private System.Windows.Forms.ListBox lstBxWorkshops;
        private System.Windows.Forms.ListBox lstBxLocations;
        private System.Windows.Forms.Label lblBillingInformation;
        private System.Windows.Forms.Label lblRegistrationDescription;
        private System.Windows.Forms.Label lblRegistrationAmount;
        private System.Windows.Forms.Label lblLodgingDesciption;
        private System.Windows.Forms.Label lblLodgingAmount;
        private System.Windows.Forms.Label lblTotalDescription;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Button btnCalculateWorkshop;
        private System.Windows.Forms.Button btnExit;
    }
}

