﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int days;
            int currentDay = 1;
            double organisms;
            //double newOrganisms;
            double increaseRate;
            double totalPopulation;

            if (int.TryParse(daysToMultiplyTextBox.Text, out days) && 
                double.TryParse(organismsTextBox.Text, out organisms) && 
                double.TryParse(percentIncreaseTextBox.Text, out increaseRate))
            {
                // initialize the total population to the starting number of organisms
                totalPopulation = organisms;
                populationListBox.Items.Add("Day " + currentDay.ToString() + " = approximate" +
                        organisms + " population.");

                for (currentDay = 2; currentDay <= days; currentDay++)
                {
                    organisms = totalPopulation * (increaseRate / 100);
                    totalPopulation += organisms;

                    populationListBox.Items.Add("Day " + currentDay.ToString() + " = approximate " +
                        totalPopulation + " population.");
                }
            }
            else
            {
                MessageBox.Show("Please enter the text boxes with the appropriate numeric values.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
