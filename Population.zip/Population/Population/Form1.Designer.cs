﻿namespace Population
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startingOrganismsLabel = new System.Windows.Forms.Label();
            this.percentIncreaseLabel = new System.Windows.Forms.Label();
            this.daysToMultiplyLabel = new System.Windows.Forms.Label();
            this.organismsTextBox = new System.Windows.Forms.TextBox();
            this.percentIncreaseTextBox = new System.Windows.Forms.TextBox();
            this.daysToMultiplyTextBox = new System.Windows.Forms.TextBox();
            this.populationListBox = new System.Windows.Forms.ListBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startingOrganismsLabel
            // 
            this.startingOrganismsLabel.AutoSize = true;
            this.startingOrganismsLabel.Location = new System.Drawing.Point(36, 15);
            this.startingOrganismsLabel.Name = "startingOrganismsLabel";
            this.startingOrganismsLabel.Size = new System.Drawing.Size(146, 13);
            this.startingOrganismsLabel.TabIndex = 0;
            this.startingOrganismsLabel.Text = "Starting number of organisms:";
            // 
            // percentIncreaseLabel
            // 
            this.percentIncreaseLabel.AutoSize = true;
            this.percentIncreaseLabel.Location = new System.Drawing.Point(65, 41);
            this.percentIncreaseLabel.Name = "percentIncreaseLabel";
            this.percentIncreaseLabel.Size = new System.Drawing.Size(117, 13);
            this.percentIncreaseLabel.TabIndex = 1;
            this.percentIncreaseLabel.Text = "Average daily increase:";
            // 
            // daysToMultiplyLabel
            // 
            this.daysToMultiplyLabel.AutoSize = true;
            this.daysToMultiplyLabel.Location = new System.Drawing.Point(49, 67);
            this.daysToMultiplyLabel.Name = "daysToMultiplyLabel";
            this.daysToMultiplyLabel.Size = new System.Drawing.Size(133, 13);
            this.daysToMultiplyLabel.TabIndex = 2;
            this.daysToMultiplyLabel.Text = "Number of days to multiply:";
            // 
            // organismsTextBox
            // 
            this.organismsTextBox.Location = new System.Drawing.Point(188, 12);
            this.organismsTextBox.Name = "organismsTextBox";
            this.organismsTextBox.Size = new System.Drawing.Size(100, 20);
            this.organismsTextBox.TabIndex = 3;
            // 
            // percentIncreaseTextBox
            // 
            this.percentIncreaseTextBox.Location = new System.Drawing.Point(188, 38);
            this.percentIncreaseTextBox.Name = "percentIncreaseTextBox";
            this.percentIncreaseTextBox.Size = new System.Drawing.Size(100, 20);
            this.percentIncreaseTextBox.TabIndex = 4;
            // 
            // daysToMultiplyTextBox
            // 
            this.daysToMultiplyTextBox.Location = new System.Drawing.Point(188, 64);
            this.daysToMultiplyTextBox.Name = "daysToMultiplyTextBox";
            this.daysToMultiplyTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysToMultiplyTextBox.TabIndex = 5;
            // 
            // populationListBox
            // 
            this.populationListBox.FormattingEnabled = true;
            this.populationListBox.Location = new System.Drawing.Point(39, 97);
            this.populationListBox.Name = "populationListBox";
            this.populationListBox.Size = new System.Drawing.Size(249, 160);
            this.populationListBox.TabIndex = 6;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(68, 266);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 7;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(188, 266);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 301);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.populationListBox);
            this.Controls.Add(this.daysToMultiplyTextBox);
            this.Controls.Add(this.percentIncreaseTextBox);
            this.Controls.Add(this.organismsTextBox);
            this.Controls.Add(this.daysToMultiplyLabel);
            this.Controls.Add(this.percentIncreaseLabel);
            this.Controls.Add(this.startingOrganismsLabel);
            this.Name = "Form1";
            this.Text = "Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label startingOrganismsLabel;
        private System.Windows.Forms.Label percentIncreaseLabel;
        private System.Windows.Forms.Label daysToMultiplyLabel;
        private System.Windows.Forms.TextBox organismsTextBox;
        private System.Windows.Forms.TextBox percentIncreaseTextBox;
        private System.Windows.Forms.TextBox daysToMultiplyTextBox;
        private System.Windows.Forms.ListBox populationListBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

