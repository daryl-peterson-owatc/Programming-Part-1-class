﻿namespace Staff_Patient_Tracking
{
    partial class PersonUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonUpdate));
            System.Windows.Forms.Label idLabel;
            System.Windows.Forms.Label firstNameLabel;
            System.Windows.Forms.Label lastNameLabel;
            System.Windows.Forms.Label staffLabel;
            System.Windows.Forms.Label employmentDateLabel;
            System.Windows.Forms.Label licenseDateLabel;
            System.Windows.Forms.Label skillsDateLabel;
            System.Windows.Forms.Label cPRDateLabel;
            System.Windows.Forms.Label tBDateLabel;
            System.Windows.Forms.Label hEPBDateLabel;
            System.Windows.Forms.Label fluDateLabel;
            System.Windows.Forms.Label terminationDateLabel;
            this.trackingInfoDataSet = new Staff_Patient_Tracking.TrackingInfoDataSet();
            this.trackingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trackingTableAdapter = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TrackingTableAdapter();
            this.tableAdapterManager = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager();
            this.trackingBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.trackingBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.idLabel1 = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.staffCheckBox = new System.Windows.Forms.CheckBox();
            this.employmentDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.licenseDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.skillsDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cPRDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tBDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hEPBDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.fluDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.terminationDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.closeButton = new System.Windows.Forms.Button();
            idLabel = new System.Windows.Forms.Label();
            firstNameLabel = new System.Windows.Forms.Label();
            lastNameLabel = new System.Windows.Forms.Label();
            staffLabel = new System.Windows.Forms.Label();
            employmentDateLabel = new System.Windows.Forms.Label();
            licenseDateLabel = new System.Windows.Forms.Label();
            skillsDateLabel = new System.Windows.Forms.Label();
            cPRDateLabel = new System.Windows.Forms.Label();
            tBDateLabel = new System.Windows.Forms.Label();
            hEPBDateLabel = new System.Windows.Forms.Label();
            fluDateLabel = new System.Windows.Forms.Label();
            terminationDateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingNavigator)).BeginInit();
            this.trackingBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // trackingInfoDataSet
            // 
            this.trackingInfoDataSet.DataSetName = "TrackingInfoDataSet";
            this.trackingInfoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trackingBindingSource
            // 
            this.trackingBindingSource.DataMember = "Tracking";
            this.trackingBindingSource.DataSource = this.trackingInfoDataSet;
            // 
            // trackingTableAdapter
            // 
            this.trackingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TrackingTableAdapter = this.trackingTableAdapter;
            this.tableAdapterManager.UpdateOrder = Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // trackingBindingNavigator
            // 
            this.trackingBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.trackingBindingNavigator.BindingSource = this.trackingBindingSource;
            this.trackingBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.trackingBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.trackingBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.trackingBindingNavigatorSaveItem});
            this.trackingBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.trackingBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.trackingBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.trackingBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.trackingBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.trackingBindingNavigator.Name = "trackingBindingNavigator";
            this.trackingBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.trackingBindingNavigator.Size = new System.Drawing.Size(336, 25);
            this.trackingBindingNavigator.TabIndex = 0;
            this.trackingBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // trackingBindingNavigatorSaveItem
            // 
            this.trackingBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.trackingBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("trackingBindingNavigatorSaveItem.Image")));
            this.trackingBindingNavigatorSaveItem.Name = "trackingBindingNavigatorSaveItem";
            this.trackingBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.trackingBindingNavigatorSaveItem.Text = "Save Data";
            this.trackingBindingNavigatorSaveItem.Click += new System.EventHandler(this.trackingBindingNavigatorSaveItem_Click);
            // 
            // idLabel
            // 
            idLabel.AutoSize = true;
            idLabel.Location = new System.Drawing.Point(91, 43);
            idLabel.Name = "idLabel";
            idLabel.Size = new System.Drawing.Size(19, 13);
            idLabel.TabIndex = 1;
            idLabel.Text = "Id:";
            // 
            // idLabel1
            // 
            this.idLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trackingBindingSource, "Id", true));
            this.idLabel1.Location = new System.Drawing.Point(116, 43);
            this.idLabel1.Name = "idLabel1";
            this.idLabel1.Size = new System.Drawing.Size(200, 23);
            this.idLabel1.TabIndex = 2;
            this.idLabel1.Text = "label1";
            // 
            // firstNameLabel
            // 
            firstNameLabel.AutoSize = true;
            firstNameLabel.Location = new System.Drawing.Point(50, 72);
            firstNameLabel.Name = "firstNameLabel";
            firstNameLabel.Size = new System.Drawing.Size(60, 13);
            firstNameLabel.TabIndex = 3;
            firstNameLabel.Text = "First Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trackingBindingSource, "FirstName", true));
            this.firstNameTextBox.Location = new System.Drawing.Point(116, 69);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.firstNameTextBox.TabIndex = 4;
            // 
            // lastNameLabel
            // 
            lastNameLabel.AutoSize = true;
            lastNameLabel.Location = new System.Drawing.Point(49, 98);
            lastNameLabel.Name = "lastNameLabel";
            lastNameLabel.Size = new System.Drawing.Size(61, 13);
            lastNameLabel.TabIndex = 5;
            lastNameLabel.Text = "Last Name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trackingBindingSource, "LastName", true));
            this.lastNameTextBox.Location = new System.Drawing.Point(116, 95);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // staffLabel
            // 
            staffLabel.AutoSize = true;
            staffLabel.Location = new System.Drawing.Point(37, 126);
            staffLabel.Name = "staffLabel";
            staffLabel.Size = new System.Drawing.Size(73, 13);
            staffLabel.TabIndex = 7;
            staffLabel.Text = "Staff Member:";
            // 
            // staffCheckBox
            // 
            this.staffCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.trackingBindingSource, "Staff", true));
            this.staffCheckBox.Location = new System.Drawing.Point(116, 121);
            this.staffCheckBox.Name = "staffCheckBox";
            this.staffCheckBox.Size = new System.Drawing.Size(200, 24);
            this.staffCheckBox.TabIndex = 8;
            this.staffCheckBox.UseVisualStyleBackColor = true;
            // 
            // employmentDateLabel
            // 
            employmentDateLabel.AutoSize = true;
            employmentDateLabel.Location = new System.Drawing.Point(17, 157);
            employmentDateLabel.Name = "employmentDateLabel";
            employmentDateLabel.Size = new System.Drawing.Size(93, 13);
            employmentDateLabel.TabIndex = 9;
            employmentDateLabel.Text = "Employment Date:";
            // 
            // employmentDateDateTimePicker
            // 
            this.employmentDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "EmploymentDate", true));
            this.employmentDateDateTimePicker.Location = new System.Drawing.Point(116, 151);
            this.employmentDateDateTimePicker.Name = "employmentDateDateTimePicker";
            this.employmentDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.employmentDateDateTimePicker.TabIndex = 10;
            // 
            // licenseDateLabel
            // 
            licenseDateLabel.AutoSize = true;
            licenseDateLabel.Location = new System.Drawing.Point(37, 183);
            licenseDateLabel.Name = "licenseDateLabel";
            licenseDateLabel.Size = new System.Drawing.Size(73, 13);
            licenseDateLabel.TabIndex = 11;
            licenseDateLabel.Text = "License Date:";
            // 
            // licenseDateDateTimePicker
            // 
            this.licenseDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "LicenseDate", true));
            this.licenseDateDateTimePicker.Location = new System.Drawing.Point(116, 177);
            this.licenseDateDateTimePicker.Name = "licenseDateDateTimePicker";
            this.licenseDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.licenseDateDateTimePicker.TabIndex = 12;
            // 
            // skillsDateLabel
            // 
            skillsDateLabel.AutoSize = true;
            skillsDateLabel.Location = new System.Drawing.Point(50, 209);
            skillsDateLabel.Name = "skillsDateLabel";
            skillsDateLabel.Size = new System.Drawing.Size(60, 13);
            skillsDateLabel.TabIndex = 13;
            skillsDateLabel.Text = "Skills Date:";
            // 
            // skillsDateDateTimePicker
            // 
            this.skillsDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "SkillsDate", true));
            this.skillsDateDateTimePicker.Location = new System.Drawing.Point(116, 203);
            this.skillsDateDateTimePicker.Name = "skillsDateDateTimePicker";
            this.skillsDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.skillsDateDateTimePicker.TabIndex = 14;
            // 
            // cPRDateLabel
            // 
            cPRDateLabel.AutoSize = true;
            cPRDateLabel.Location = new System.Drawing.Point(52, 235);
            cPRDateLabel.Name = "cPRDateLabel";
            cPRDateLabel.Size = new System.Drawing.Size(58, 13);
            cPRDateLabel.TabIndex = 15;
            cPRDateLabel.Text = "CPR Date:";
            // 
            // cPRDateDateTimePicker
            // 
            this.cPRDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "CPRDate", true));
            this.cPRDateDateTimePicker.Location = new System.Drawing.Point(116, 229);
            this.cPRDateDateTimePicker.Name = "cPRDateDateTimePicker";
            this.cPRDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.cPRDateDateTimePicker.TabIndex = 16;
            // 
            // tBDateLabel
            // 
            tBDateLabel.AutoSize = true;
            tBDateLabel.Location = new System.Drawing.Point(60, 261);
            tBDateLabel.Name = "tBDateLabel";
            tBDateLabel.Size = new System.Drawing.Size(50, 13);
            tBDateLabel.TabIndex = 17;
            tBDateLabel.Text = "TB Date:";
            // 
            // tBDateDateTimePicker
            // 
            this.tBDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "TBDate", true));
            this.tBDateDateTimePicker.Location = new System.Drawing.Point(116, 255);
            this.tBDateDateTimePicker.Name = "tBDateDateTimePicker";
            this.tBDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.tBDateDateTimePicker.TabIndex = 18;
            // 
            // hEPBDateLabel
            // 
            hEPBDateLabel.AutoSize = true;
            hEPBDateLabel.Location = new System.Drawing.Point(42, 287);
            hEPBDateLabel.Name = "hEPBDateLabel";
            hEPBDateLabel.Size = new System.Drawing.Size(68, 13);
            hEPBDateLabel.TabIndex = 19;
            hEPBDateLabel.Text = "HEP-B Date:";
            // 
            // hEPBDateDateTimePicker
            // 
            this.hEPBDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "HEPBDate", true));
            this.hEPBDateDateTimePicker.Location = new System.Drawing.Point(116, 281);
            this.hEPBDateDateTimePicker.Name = "hEPBDateDateTimePicker";
            this.hEPBDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.hEPBDateDateTimePicker.TabIndex = 20;
            // 
            // fluDateLabel
            // 
            fluDateLabel.AutoSize = true;
            fluDateLabel.Location = new System.Drawing.Point(60, 313);
            fluDateLabel.Name = "fluDateLabel";
            fluDateLabel.Size = new System.Drawing.Size(50, 13);
            fluDateLabel.TabIndex = 21;
            fluDateLabel.Text = "Flu Date:";
            // 
            // fluDateDateTimePicker
            // 
            this.fluDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "FluDate", true));
            this.fluDateDateTimePicker.Location = new System.Drawing.Point(116, 307);
            this.fluDateDateTimePicker.Name = "fluDateDateTimePicker";
            this.fluDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fluDateDateTimePicker.TabIndex = 22;
            // 
            // terminationDateLabel
            // 
            terminationDateLabel.AutoSize = true;
            terminationDateLabel.Location = new System.Drawing.Point(19, 339);
            terminationDateLabel.Name = "terminationDateLabel";
            terminationDateLabel.Size = new System.Drawing.Size(91, 13);
            terminationDateLabel.TabIndex = 23;
            terminationDateLabel.Text = "Termination Date:";
            // 
            // terminationDateDateTimePicker
            // 
            this.terminationDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.trackingBindingSource, "TerminationDate", true));
            this.terminationDateDateTimePicker.Location = new System.Drawing.Point(116, 333);
            this.terminationDateDateTimePicker.Name = "terminationDateDateTimePicker";
            this.terminationDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.terminationDateDateTimePicker.TabIndex = 24;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(241, 372);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 25;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // PersonUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 409);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(idLabel);
            this.Controls.Add(this.idLabel1);
            this.Controls.Add(firstNameLabel);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(lastNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(staffLabel);
            this.Controls.Add(this.staffCheckBox);
            this.Controls.Add(employmentDateLabel);
            this.Controls.Add(this.employmentDateDateTimePicker);
            this.Controls.Add(licenseDateLabel);
            this.Controls.Add(this.licenseDateDateTimePicker);
            this.Controls.Add(skillsDateLabel);
            this.Controls.Add(this.skillsDateDateTimePicker);
            this.Controls.Add(cPRDateLabel);
            this.Controls.Add(this.cPRDateDateTimePicker);
            this.Controls.Add(tBDateLabel);
            this.Controls.Add(this.tBDateDateTimePicker);
            this.Controls.Add(hEPBDateLabel);
            this.Controls.Add(this.hEPBDateDateTimePicker);
            this.Controls.Add(fluDateLabel);
            this.Controls.Add(this.fluDateDateTimePicker);
            this.Controls.Add(terminationDateLabel);
            this.Controls.Add(this.terminationDateDateTimePicker);
            this.Controls.Add(this.trackingBindingNavigator);
            this.Name = "PersonUpdate";
            this.Text = "PersonUpdate";
            this.Load += new System.EventHandler(this.PersonUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingNavigator)).EndInit();
            this.trackingBindingNavigator.ResumeLayout(false);
            this.trackingBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TrackingInfoDataSet trackingInfoDataSet;
        private System.Windows.Forms.BindingSource trackingBindingSource;
        private TrackingInfoDataSetTableAdapters.TrackingTableAdapter trackingTableAdapter;
        private TrackingInfoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator trackingBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton trackingBindingNavigatorSaveItem;
        private System.Windows.Forms.Label idLabel1;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.CheckBox staffCheckBox;
        private System.Windows.Forms.DateTimePicker employmentDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker licenseDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker skillsDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker cPRDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker tBDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker hEPBDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker fluDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker terminationDateDateTimePicker;
        private System.Windows.Forms.Button closeButton;
    }
}