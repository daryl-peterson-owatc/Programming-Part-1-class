﻿namespace Staff_Patient_Tracking
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.trackingInfoDataSet = new Staff_Patient_Tracking.TrackingInfoDataSet();
            this.trackingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trackingTableAdapter = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TrackingTableAdapter();
            this.tableAdapterManager = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // trackingInfoDataSet
            // 
            this.trackingInfoDataSet.DataSetName = "TrackingInfoDataSet";
            this.trackingInfoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trackingBindingSource
            // 
            this.trackingBindingSource.DataMember = "Tracking";
            this.trackingBindingSource.DataSource = this.trackingInfoDataSet;
            // 
            // trackingTableAdapter
            // 
            this.trackingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TrackingTableAdapter = this.trackingTableAdapter;
            this.tableAdapterManager.UpdateOrder = Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 375);
            this.Name = "MainForm";
            this.Text = "Staff Patient Tracking";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TrackingInfoDataSet trackingInfoDataSet;
        private System.Windows.Forms.BindingSource trackingBindingSource;
        private TrackingInfoDataSetTableAdapters.TrackingTableAdapter trackingTableAdapter;
        private TrackingInfoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}

