﻿namespace Staff_Patient_Tracking
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.exitButton = new System.Windows.Forms.Button();
            this.monthExpiringComboBox = new System.Windows.Forms.ComboBox();
            this.yearExpiringComboBox = new System.Windows.Forms.ComboBox();
            this.monthExpiringLabel = new System.Windows.Forms.Label();
            this.yearExpiring = new System.Windows.Forms.Label();
            this.staffAndPatientsGroupBox = new System.Windows.Forms.GroupBox();
            this.fluQueryButton = new System.Windows.Forms.Button();
            this.tbQueryButton = new System.Windows.Forms.Button();
            this.hepBQueryButton = new System.Windows.Forms.Button();
            this.CPRQueryButton = new System.Windows.Forms.Button();
            this.skillsQueryButton = new System.Windows.Forms.Button();
            this.licenseQueryButton = new System.Windows.Forms.Button();
            this.staffCheckBox = new System.Windows.Forms.CheckBox();
            this.addPersonButton = new System.Windows.Forms.Button();
            this.trackingDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trackingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trackingInfoDataSet = new Staff_Patient_Tracking.TrackingInfoDataSet();
            this.trackingBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.trackingBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.staffOnlyGroupBox = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.trackingTableAdapter = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TrackingTableAdapter();
            this.tableAdapterManager = new Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager();
            this.editPersonButton = new System.Windows.Forms.Button();
            this.staffAndPatientsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackingDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingNavigator)).BeginInit();
            this.trackingBindingNavigator.SuspendLayout();
            this.staffOnlyGroupBox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(722, 137);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // monthExpiringComboBox
            // 
            this.monthExpiringComboBox.FormattingEnabled = true;
            this.monthExpiringComboBox.Location = new System.Drawing.Point(89, 13);
            this.monthExpiringComboBox.Name = "monthExpiringComboBox";
            this.monthExpiringComboBox.Size = new System.Drawing.Size(121, 21);
            this.monthExpiringComboBox.TabIndex = 2;
            // 
            // yearExpiringComboBox
            // 
            this.yearExpiringComboBox.FormattingEnabled = true;
            this.yearExpiringComboBox.Location = new System.Drawing.Point(89, 49);
            this.yearExpiringComboBox.Name = "yearExpiringComboBox";
            this.yearExpiringComboBox.Size = new System.Drawing.Size(121, 21);
            this.yearExpiringComboBox.TabIndex = 3;
            // 
            // monthExpiringLabel
            // 
            this.monthExpiringLabel.AutoSize = true;
            this.monthExpiringLabel.Location = new System.Drawing.Point(3, 16);
            this.monthExpiringLabel.Name = "monthExpiringLabel";
            this.monthExpiringLabel.Size = new System.Drawing.Size(80, 13);
            this.monthExpiringLabel.TabIndex = 4;
            this.monthExpiringLabel.Text = "Month Expiring:";
            // 
            // yearExpiring
            // 
            this.yearExpiring.AutoSize = true;
            this.yearExpiring.Location = new System.Drawing.Point(11, 52);
            this.yearExpiring.Name = "yearExpiring";
            this.yearExpiring.Size = new System.Drawing.Size(72, 13);
            this.yearExpiring.TabIndex = 5;
            this.yearExpiring.Text = "Year Expiring:";
            // 
            // staffAndPatientsGroupBox
            // 
            this.staffAndPatientsGroupBox.Controls.Add(this.fluQueryButton);
            this.staffAndPatientsGroupBox.Controls.Add(this.tbQueryButton);
            this.staffAndPatientsGroupBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.staffAndPatientsGroupBox.Location = new System.Drawing.Point(239, 13);
            this.staffAndPatientsGroupBox.Name = "staffAndPatientsGroupBox";
            this.staffAndPatientsGroupBox.Size = new System.Drawing.Size(448, 58);
            this.staffAndPatientsGroupBox.TabIndex = 6;
            this.staffAndPatientsGroupBox.TabStop = false;
            this.staffAndPatientsGroupBox.Text = "Staff and Patient Queries";
            // 
            // fluQueryButton
            // 
            this.fluQueryButton.Location = new System.Drawing.Point(242, 19);
            this.fluQueryButton.Name = "fluQueryButton";
            this.fluQueryButton.Size = new System.Drawing.Size(180, 23);
            this.fluQueryButton.TabIndex = 5;
            this.fluQueryButton.Text = "Expiring Flu Query";
            this.fluQueryButton.UseVisualStyleBackColor = true;
            // 
            // tbQueryButton
            // 
            this.tbQueryButton.Location = new System.Drawing.Point(22, 19);
            this.tbQueryButton.Name = "tbQueryButton";
            this.tbQueryButton.Size = new System.Drawing.Size(180, 23);
            this.tbQueryButton.TabIndex = 3;
            this.tbQueryButton.Text = "Expiring TB Test Query";
            this.tbQueryButton.UseVisualStyleBackColor = true;
            // 
            // hepBQueryButton
            // 
            this.hepBQueryButton.Location = new System.Drawing.Point(242, 53);
            this.hepBQueryButton.Name = "hepBQueryButton";
            this.hepBQueryButton.Size = new System.Drawing.Size(180, 23);
            this.hepBQueryButton.TabIndex = 4;
            this.hepBQueryButton.Text = "Expiring Hep B Query";
            this.hepBQueryButton.UseVisualStyleBackColor = true;
            // 
            // CPRQueryButton
            // 
            this.CPRQueryButton.Location = new System.Drawing.Point(242, 19);
            this.CPRQueryButton.Name = "CPRQueryButton";
            this.CPRQueryButton.Size = new System.Drawing.Size(180, 23);
            this.CPRQueryButton.TabIndex = 2;
            this.CPRQueryButton.Text = "Expiring CPR Query";
            this.CPRQueryButton.UseVisualStyleBackColor = true;
            // 
            // skillsQueryButton
            // 
            this.skillsQueryButton.Location = new System.Drawing.Point(22, 53);
            this.skillsQueryButton.Name = "skillsQueryButton";
            this.skillsQueryButton.Size = new System.Drawing.Size(180, 23);
            this.skillsQueryButton.TabIndex = 1;
            this.skillsQueryButton.Text = "Expiring Skills Query";
            this.skillsQueryButton.UseVisualStyleBackColor = true;
            // 
            // licenseQueryButton
            // 
            this.licenseQueryButton.Location = new System.Drawing.Point(22, 19);
            this.licenseQueryButton.Name = "licenseQueryButton";
            this.licenseQueryButton.Size = new System.Drawing.Size(180, 23);
            this.licenseQueryButton.TabIndex = 0;
            this.licenseQueryButton.Text = "Expiring License Query";
            this.licenseQueryButton.UseVisualStyleBackColor = true;
            // 
            // staffCheckBox
            // 
            this.staffCheckBox.AutoSize = true;
            this.staffCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.staffCheckBox.Location = new System.Drawing.Point(12, 84);
            this.staffCheckBox.Name = "staffCheckBox";
            this.staffCheckBox.Size = new System.Drawing.Size(92, 17);
            this.staffCheckBox.TabIndex = 7;
            this.staffCheckBox.Text = "Staff Member:";
            this.staffCheckBox.UseVisualStyleBackColor = true;
            this.staffCheckBox.CheckedChanged += new System.EventHandler(this.staffCheckBox_CheckedChanged);
            // 
            // addPersonButton
            // 
            this.addPersonButton.Location = new System.Drawing.Point(722, 64);
            this.addPersonButton.Name = "addPersonButton";
            this.addPersonButton.Size = new System.Drawing.Size(75, 23);
            this.addPersonButton.TabIndex = 8;
            this.addPersonButton.Text = "Add Person";
            this.addPersonButton.UseVisualStyleBackColor = true;
            this.addPersonButton.Click += new System.EventHandler(this.addPersonButton_Click);
            // 
            // trackingDataGridView
            // 
            this.trackingDataGridView.AutoGenerateColumns = false;
            this.trackingDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.trackingDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.trackingDataGridView.DataSource = this.trackingBindingSource;
            this.trackingDataGridView.Location = new System.Drawing.Point(12, 28);
            this.trackingDataGridView.Name = "trackingDataGridView";
            this.trackingDataGridView.Size = new System.Drawing.Size(815, 306);
            this.trackingDataGridView.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn2.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn3.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "Staff";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Staff";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "EmploymentDate";
            this.dataGridViewTextBoxColumn4.HeaderText = "EmploymentDate";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "LicenseDate";
            this.dataGridViewTextBoxColumn5.HeaderText = "LicenseDate";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "SkillsDate";
            this.dataGridViewTextBoxColumn6.HeaderText = "SkillsDate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CPRDate";
            this.dataGridViewTextBoxColumn7.HeaderText = "CPRDate";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "TBDate";
            this.dataGridViewTextBoxColumn8.HeaderText = "TBDate";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "HEPBDate";
            this.dataGridViewTextBoxColumn9.HeaderText = "HEPBDate";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "FluDate";
            this.dataGridViewTextBoxColumn10.HeaderText = "FluDate";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "TerminationDate";
            this.dataGridViewTextBoxColumn11.HeaderText = "TerminationDate";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // trackingBindingSource
            // 
            this.trackingBindingSource.DataMember = "Tracking";
            this.trackingBindingSource.DataSource = this.trackingInfoDataSet;
            // 
            // trackingInfoDataSet
            // 
            this.trackingInfoDataSet.DataSetName = "TrackingInfoDataSet";
            this.trackingInfoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trackingBindingNavigator
            // 
            this.trackingBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.trackingBindingNavigator.BindingSource = this.trackingBindingSource;
            this.trackingBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.trackingBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.trackingBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.trackingBindingNavigatorSaveItem});
            this.trackingBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.trackingBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.trackingBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.trackingBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.trackingBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.trackingBindingNavigator.Name = "trackingBindingNavigator";
            this.trackingBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.trackingBindingNavigator.Size = new System.Drawing.Size(856, 25);
            this.trackingBindingNavigator.TabIndex = 9;
            this.trackingBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // trackingBindingNavigatorSaveItem
            // 
            this.trackingBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.trackingBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("trackingBindingNavigatorSaveItem.Image")));
            this.trackingBindingNavigatorSaveItem.Name = "trackingBindingNavigatorSaveItem";
            this.trackingBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.trackingBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // staffOnlyGroupBox
            // 
            this.staffOnlyGroupBox.Controls.Add(this.licenseQueryButton);
            this.staffOnlyGroupBox.Controls.Add(this.hepBQueryButton);
            this.staffOnlyGroupBox.Controls.Add(this.skillsQueryButton);
            this.staffOnlyGroupBox.Controls.Add(this.CPRQueryButton);
            this.staffOnlyGroupBox.Location = new System.Drawing.Point(239, 84);
            this.staffOnlyGroupBox.Name = "staffOnlyGroupBox";
            this.staffOnlyGroupBox.Size = new System.Drawing.Size(448, 82);
            this.staffOnlyGroupBox.TabIndex = 10;
            this.staffOnlyGroupBox.TabStop = false;
            this.staffOnlyGroupBox.Text = "Staff Only Queries";
            this.staffOnlyGroupBox.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.editPersonButton);
            this.panel1.Controls.Add(this.staffOnlyGroupBox);
            this.panel1.Controls.Add(this.addPersonButton);
            this.panel1.Controls.Add(this.staffCheckBox);
            this.panel1.Controls.Add(this.staffAndPatientsGroupBox);
            this.panel1.Controls.Add(this.yearExpiring);
            this.panel1.Controls.Add(this.monthExpiringLabel);
            this.panel1.Controls.Add(this.yearExpiringComboBox);
            this.panel1.Controls.Add(this.monthExpiringComboBox);
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Location = new System.Drawing.Point(12, 353);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(815, 178);
            this.panel1.TabIndex = 11;
            // 
            // trackingTableAdapter
            // 
            this.trackingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TrackingTableAdapter = this.trackingTableAdapter;
            this.tableAdapterManager.UpdateOrder = Staff_Patient_Tracking.TrackingInfoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // editPersonButton
            // 
            this.editPersonButton.Location = new System.Drawing.Point(722, 16);
            this.editPersonButton.Name = "editPersonButton";
            this.editPersonButton.Size = new System.Drawing.Size(75, 23);
            this.editPersonButton.TabIndex = 11;
            this.editPersonButton.Text = "Edit Person";
            this.editPersonButton.UseVisualStyleBackColor = true;
            this.editPersonButton.Click += new System.EventHandler(this.editPersonButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 541);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.trackingBindingNavigator);
            this.Controls.Add(this.trackingDataGridView);
            this.Name = "MainForm";
            this.Text = "Staff Patient Tracking";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.staffAndPatientsGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackingDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingInfoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackingBindingNavigator)).EndInit();
            this.trackingBindingNavigator.ResumeLayout(false);
            this.trackingBindingNavigator.PerformLayout();
            this.staffOnlyGroupBox.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TrackingInfoDataSet trackingInfoDataSet;
        private System.Windows.Forms.BindingSource trackingBindingSource;
        private TrackingInfoDataSetTableAdapters.TrackingTableAdapter trackingTableAdapter;
        private TrackingInfoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ComboBox monthExpiringComboBox;
        private System.Windows.Forms.ComboBox yearExpiringComboBox;
        private System.Windows.Forms.Label monthExpiringLabel;
        private System.Windows.Forms.Label yearExpiring;
        private System.Windows.Forms.GroupBox staffAndPatientsGroupBox;
        private System.Windows.Forms.Button fluQueryButton;
        private System.Windows.Forms.Button hepBQueryButton;
        private System.Windows.Forms.Button tbQueryButton;
        private System.Windows.Forms.Button CPRQueryButton;
        private System.Windows.Forms.Button skillsQueryButton;
        private System.Windows.Forms.Button licenseQueryButton;
        private System.Windows.Forms.CheckBox staffCheckBox;
        private System.Windows.Forms.Button addPersonButton;
        private System.Windows.Forms.DataGridView trackingDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.BindingNavigator trackingBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton trackingBindingNavigatorSaveItem;
        private System.Windows.Forms.GroupBox staffOnlyGroupBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button editPersonButton;
    }
}

