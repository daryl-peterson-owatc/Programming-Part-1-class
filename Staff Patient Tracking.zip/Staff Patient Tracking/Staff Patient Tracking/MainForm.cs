﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Staff_Patient_Tracking
{
    public partial class MainForm : Form
    {
        public const int MAX_YEARS = 5;
        public int currentMonth;
        public int currentYear;

        public MainForm()
        {
            InitializeComponent();
        }

        private void trackingBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           
            this.Validate();
            this.trackingBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.trackingInfoDataSet);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'trackingInfoDataSet.Tracking' table. You can move, or remove it, as needed.
            this.trackingTableAdapter.Fill(this.trackingInfoDataSet.Tracking);
            SetCurrentMonthYear();
            PopulateMonthExpiringComboBox();
            PopulateYeasExpiringComboBox();
            monthExpiringComboBox.SelectedIndex = currentMonth;
            yearExpiringComboBox.SelectedIndex = 1;
        }

        private void PopulateMonthExpiringComboBox()
        {
            monthExpiringComboBox.Items.Add("");
            monthExpiringComboBox.Items.Add("January");
            monthExpiringComboBox.Items.Add("February");
            monthExpiringComboBox.Items.Add("March");
            monthExpiringComboBox.Items.Add("April");
            monthExpiringComboBox.Items.Add("May");
            monthExpiringComboBox.Items.Add("June");
            monthExpiringComboBox.Items.Add("July");
            monthExpiringComboBox.Items.Add("August");
            monthExpiringComboBox.Items.Add("September");
            monthExpiringComboBox.Items.Add("October");
            monthExpiringComboBox.Items.Add("November");
            monthExpiringComboBox.Items.Add("December");
        }

        private void PopulateYeasExpiringComboBox()
        {
            yearExpiringComboBox.Items.Add("");
            for(int index = 0; index < MAX_YEARS; index++)
            {
                yearExpiringComboBox.Items.Add(currentYear + index);
            }
        }

        private void SetCurrentMonthYear()
        {
            DateTime todaysDate = DateTime.Now.Date;
            currentMonth = todaysDate.Month;
            currentYear = todaysDate.Year;
        }

        private void addPersonButton_Click(object sender, EventArgs e)
        {
            PersonUpdate pu = new PersonUpdate();
            pu.ShowDialog();
            this.trackingTableAdapter.Fill(this.trackingInfoDataSet.Tracking);
        }

        private void staffCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (staffCheckBox.Checked)
            {
                staffOnlyGroupBox.Visible = true;
            }
            else
            {
                staffOnlyGroupBox.Visible = false;
            }
        }

        private void editPersonButton_Click(object sender, EventArgs e)
        {
            int index;
            string firstName;
            string lastName;

            index = (trackingDataGridView.CurrentCell.RowIndex);
            if (index >= 0)
            {
                DataGridViewRow row = this.trackingDataGridView.Rows[index];
                firstName = row.Cells["FirstName"].Value.ToString();
                lastName = row.Cells[2].Value.ToString();
            }
            else
            {
                firstName = "";
                lastName = "";
            }
            MessageBox.Show("Selected row: " + index + " First name: " + firstName + " Last name: " + lastName);
        }
    }
}
