﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Staff_Patient_Tracking
{
    public partial class PersonUpdate : Form
    {
        public DataGridViewRow dgvr;
        public PersonUpdate()
        {
            InitializeComponent();
        }

        private void trackingBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.trackingBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.trackingInfoDataSet);

        }

        private void PersonUpdate_Load(object sender, EventArgs e)
        {

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
