﻿namespace Staff_Patient_Tracking
{
}

namespace Staff_Patient_Tracking
{


    public partial class TrackingInfoDataSet
    {
    }
}
