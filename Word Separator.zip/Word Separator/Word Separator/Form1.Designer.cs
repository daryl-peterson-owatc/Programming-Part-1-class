﻿namespace Word_Separator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputSentenceTextBox = new System.Windows.Forms.TextBox();
            this.outputSentenceLabel = new System.Windows.Forms.Label();
            this.outputInstructionsLabel = new System.Windows.Forms.Label();
            this.fixSentenceButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.Location = new System.Drawing.Point(12, 17);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(539, 23);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(476, 159);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputSentenceTextBox
            // 
            this.inputSentenceTextBox.Location = new System.Drawing.Point(12, 47);
            this.inputSentenceTextBox.Name = "inputSentenceTextBox";
            this.inputSentenceTextBox.Size = new System.Drawing.Size(539, 20);
            this.inputSentenceTextBox.TabIndex = 2;
            // 
            // outputSentenceLabel
            // 
            this.outputSentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputSentenceLabel.Location = new System.Drawing.Point(12, 97);
            this.outputSentenceLabel.Name = "outputSentenceLabel";
            this.outputSentenceLabel.Size = new System.Drawing.Size(539, 23);
            this.outputSentenceLabel.TabIndex = 3;
            this.outputSentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // outputInstructionsLabel
            // 
            this.outputInstructionsLabel.Location = new System.Drawing.Point(12, 75);
            this.outputInstructionsLabel.Name = "outputInstructionsLabel";
            this.outputInstructionsLabel.Size = new System.Drawing.Size(539, 22);
            this.outputInstructionsLabel.TabIndex = 4;
            this.outputInstructionsLabel.Text = "Your sentence transformed";
            this.outputInstructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fixSentenceButton
            // 
            this.fixSentenceButton.Location = new System.Drawing.Point(241, 133);
            this.fixSentenceButton.Name = "fixSentenceButton";
            this.fixSentenceButton.Size = new System.Drawing.Size(82, 23);
            this.fixSentenceButton.TabIndex = 5;
            this.fixSentenceButton.Text = "Fix Sentence";
            this.fixSentenceButton.UseVisualStyleBackColor = true;
            this.fixSentenceButton.Click += new System.EventHandler(this.fixSentenceButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 197);
            this.Controls.Add(this.fixSentenceButton);
            this.Controls.Add(this.outputInstructionsLabel);
            this.Controls.Add(this.outputSentenceLabel);
            this.Controls.Add(this.inputSentenceTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.instructionLabel);
            this.Name = "Form1";
            this.Text = "Word Separator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox inputSentenceTextBox;
        private System.Windows.Forms.Label outputSentenceLabel;
        private System.Windows.Forms.Label outputInstructionsLabel;
        private System.Windows.Forms.Button fixSentenceButton;
    }
}

