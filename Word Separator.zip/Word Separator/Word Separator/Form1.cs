﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Separator
{
    public partial class Form1 : Form
    {
        private const char SPACE = ' ';
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            instructionLabel.Text = "Enter a sentence with no spaces.  Capitalize the first letter of each word.";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fixSentenceButton_Click(object sender, EventArgs e)
        {
            outputSentenceLabel.Text = RebuildTheSentence(inputSentenceTextBox.Text);
        }

        private string RebuildTheSentence(string inputSentence)
        {
            int index = 0;
            string newSentence = "";

            foreach (char letter in inputSentence)
            {
                if(index != 0)
                {
                    if (char.IsUpper(letter))
                    {
                        newSentence = AddLetterToSentence(SPACE, newSentence);
                        newSentence = AddLetterToSentence(char.ToLower(letter), newSentence);
                    }
                    else
                    {
                        newSentence = AddLetterToSentence(letter, newSentence);
                    }
                }
                else
                {
                    newSentence = AddLetterToSentence(letter, newSentence);
                }

                index++;
            }

            return newSentence;
        }

        private string AddLetterToSentence(char letter, string sentence)
        {
            sentence += letter.ToString();
            return sentence;
        }
    }
}
