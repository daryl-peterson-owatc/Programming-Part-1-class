﻿namespace Distance_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInputInstruction = new System.Windows.Forms.Label();
            this.txtInputDistance = new System.Windows.Forms.TextBox();
            this.gbxFromUnits = new System.Windows.Forms.GroupBox();
            this.gbxToUnits = new System.Windows.Forms.GroupBox();
            this.listFromUnit = new System.Windows.Forms.ListBox();
            this.listToUnits = new System.Windows.Forms.ListBox();
            this.lblConvertedDescription = new System.Windows.Forms.Label();
            this.lblConvertedDistance = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbxFromUnits.SuspendLayout();
            this.gbxToUnits.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblInputInstruction
            // 
            this.lblInputInstruction.AutoSize = true;
            this.lblInputInstruction.Location = new System.Drawing.Point(23, 18);
            this.lblInputInstruction.Name = "lblInputInstruction";
            this.lblInputInstruction.Size = new System.Drawing.Size(138, 13);
            this.lblInputInstruction.TabIndex = 0;
            this.lblInputInstruction.Text = "Enter a distance to convert:";
            // 
            // txtInputDistance
            // 
            this.txtInputDistance.Location = new System.Drawing.Point(167, 15);
            this.txtInputDistance.Name = "txtInputDistance";
            this.txtInputDistance.Size = new System.Drawing.Size(100, 20);
            this.txtInputDistance.TabIndex = 1;
            // 
            // gbxFromUnits
            // 
            this.gbxFromUnits.Controls.Add(this.listFromUnit);
            this.gbxFromUnits.Location = new System.Drawing.Point(28, 56);
            this.gbxFromUnits.Name = "gbxFromUnits";
            this.gbxFromUnits.Size = new System.Drawing.Size(106, 76);
            this.gbxFromUnits.TabIndex = 2;
            this.gbxFromUnits.TabStop = false;
            this.gbxFromUnits.Text = "From";
            // 
            // gbxToUnits
            // 
            this.gbxToUnits.Controls.Add(this.listToUnits);
            this.gbxToUnits.Location = new System.Drawing.Point(167, 56);
            this.gbxToUnits.Name = "gbxToUnits";
            this.gbxToUnits.Size = new System.Drawing.Size(106, 76);
            this.gbxToUnits.TabIndex = 3;
            this.gbxToUnits.TabStop = false;
            this.gbxToUnits.Text = "To";
            // 
            // listFromUnit
            // 
            this.listFromUnit.FormattingEnabled = true;
            this.listFromUnit.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listFromUnit.Location = new System.Drawing.Point(10, 19);
            this.listFromUnit.Name = "listFromUnit";
            this.listFromUnit.Size = new System.Drawing.Size(86, 43);
            this.listFromUnit.TabIndex = 0;
            // 
            // listToUnits
            // 
            this.listToUnits.FormattingEnabled = true;
            this.listToUnits.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listToUnits.Location = new System.Drawing.Point(13, 19);
            this.listToUnits.Name = "listToUnits";
            this.listToUnits.Size = new System.Drawing.Size(86, 43);
            this.listToUnits.TabIndex = 0;
            // 
            // lblConvertedDescription
            // 
            this.lblConvertedDescription.AutoSize = true;
            this.lblConvertedDescription.Location = new System.Drawing.Point(57, 159);
            this.lblConvertedDescription.Name = "lblConvertedDescription";
            this.lblConvertedDescription.Size = new System.Drawing.Size(104, 13);
            this.lblConvertedDescription.TabIndex = 4;
            this.lblConvertedDescription.Text = "Converted Distance:";
            // 
            // lblConvertedDistance
            // 
            this.lblConvertedDistance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConvertedDistance.Location = new System.Drawing.Point(167, 154);
            this.lblConvertedDistance.Name = "lblConvertedDistance";
            this.lblConvertedDistance.Size = new System.Drawing.Size(100, 23);
            this.lblConvertedDistance.TabIndex = 5;
            this.lblConvertedDistance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(86, 205);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 6;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(167, 205);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 247);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.lblConvertedDistance);
            this.Controls.Add(this.lblConvertedDescription);
            this.Controls.Add(this.gbxToUnits);
            this.Controls.Add(this.gbxFromUnits);
            this.Controls.Add(this.txtInputDistance);
            this.Controls.Add(this.lblInputInstruction);
            this.Name = "Form1";
            this.Text = "Distance converter";
            this.gbxFromUnits.ResumeLayout(false);
            this.gbxToUnits.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInputInstruction;
        private System.Windows.Forms.TextBox txtInputDistance;
        private System.Windows.Forms.GroupBox gbxFromUnits;
        private System.Windows.Forms.ListBox listFromUnit;
        private System.Windows.Forms.GroupBox gbxToUnits;
        private System.Windows.Forms.ListBox listToUnits;
        private System.Windows.Forms.Label lblConvertedDescription;
        private System.Windows.Forms.Label lblConvertedDistance;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnExit;
    }
}

