﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Converter
{
    public partial class Form1 : Form
    {
        const double INCHES_IN_FOOT = 12.0;
        const double FEET_IN_YARDS = 3.0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double unitInput;
            double unitOutput = 0.0;

            if (double.TryParse(txtInputDistance.Text, out unitInput))
            {
                if (!(listFromUnit.SelectedItem == listToUnits.SelectedItem) && (listFromUnit.SelectedIndex >= 0 && listToUnits.SelectedIndex >= 0))
                {
                    if (listFromUnit.SelectedIndex == 0 && listToUnits.SelectedIndex == 1)
                    {
                        unitOutput = unitInput / INCHES_IN_FOOT;
                    }
                    else if (listFromUnit.SelectedIndex == 0 && listToUnits.SelectedIndex == 2)
                    {
                        unitOutput = (unitInput / INCHES_IN_FOOT) / FEET_IN_YARDS;
                    }
                    else if (listFromUnit.SelectedIndex == 1 && listToUnits.SelectedIndex == 0)
                    {
                        unitOutput = unitInput * INCHES_IN_FOOT;
                    }
                    else if (listFromUnit.SelectedIndex == 1 && listToUnits.SelectedIndex == 2)
                    {
                        unitOutput = unitInput / FEET_IN_YARDS;
                    }
                    else if (listFromUnit.SelectedIndex == 2 && listToUnits.SelectedIndex == 0)
                    {
                        unitOutput = unitInput * FEET_IN_YARDS * INCHES_IN_FOOT;
                    }
                    else if (listFromUnit.SelectedIndex == 2 && listToUnits.SelectedIndex == 1)
                    {
                        unitOutput = unitInput * FEET_IN_YARDS;
                    }

                    lblConvertedDistance.Text = unitOutput.ToString();
                }
                else
                {
                    MessageBox.Show("Select different conversion units each list.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a numeric value.");
                txtInputDistance.Focus();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
