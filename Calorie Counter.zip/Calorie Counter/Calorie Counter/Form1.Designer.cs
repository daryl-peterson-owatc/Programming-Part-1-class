﻿namespace Calorie_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTotalCaloriesDescription = new System.Windows.Forms.Label();
            this.lblTotalCalories = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picBanana = new System.Windows.Forms.PictureBox();
            this.picOrange = new System.Windows.Forms.PictureBox();
            this.picPear = new System.Windows.Forms.PictureBox();
            this.picApple = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBanana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picApple)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTotalCaloriesDescription
            // 
            this.lblTotalCaloriesDescription.AutoSize = true;
            this.lblTotalCaloriesDescription.Location = new System.Drawing.Point(357, 12);
            this.lblTotalCaloriesDescription.Name = "lblTotalCaloriesDescription";
            this.lblTotalCaloriesDescription.Size = new System.Drawing.Size(71, 13);
            this.lblTotalCaloriesDescription.TabIndex = 4;
            this.lblTotalCaloriesDescription.Text = "Total Calories";
            // 
            // lblTotalCalories
            // 
            this.lblTotalCalories.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCalories.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCalories.Location = new System.Drawing.Point(346, 28);
            this.lblTotalCalories.Name = "lblTotalCalories";
            this.lblTotalCalories.Size = new System.Drawing.Size(100, 20);
            this.lblTotalCalories.TabIndex = 5;
            this.lblTotalCalories.Text = "0";
            this.lblTotalCalories.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(353, 280);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(353, 323);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.picBanana);
            this.panel1.Controls.Add(this.picOrange);
            this.panel1.Controls.Add(this.picPear);
            this.panel1.Controls.Add(this.picApple);
            this.panel1.Location = new System.Drawing.Point(8, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(303, 348);
            this.panel1.TabIndex = 8;
            // 
            // picBanana
            // 
            this.picBanana.Image = global::Calorie_Counter.Properties.Resources.BananaCalories;
            this.picBanana.Location = new System.Drawing.Point(14, 12);
            this.picBanana.Name = "picBanana";
            this.picBanana.Size = new System.Drawing.Size(124, 154);
            this.picBanana.TabIndex = 3;
            this.picBanana.TabStop = false;
            this.picBanana.Click += new System.EventHandler(this.picBanana_Click);
            // 
            // picOrange
            // 
            this.picOrange.Image = global::Calorie_Counter.Properties.Resources.OrangeCalories;
            this.picOrange.Location = new System.Drawing.Point(14, 181);
            this.picOrange.Name = "picOrange";
            this.picOrange.Size = new System.Drawing.Size(124, 153);
            this.picOrange.TabIndex = 2;
            this.picOrange.TabStop = false;
            this.picOrange.Click += new System.EventHandler(this.picOrange_Click);
            // 
            // picPear
            // 
            this.picPear.Image = global::Calorie_Counter.Properties.Resources.PearCalories;
            this.picPear.Location = new System.Drawing.Point(165, 181);
            this.picPear.Name = "picPear";
            this.picPear.Size = new System.Drawing.Size(124, 153);
            this.picPear.TabIndex = 1;
            this.picPear.TabStop = false;
            this.picPear.Click += new System.EventHandler(this.picPear_Click);
            // 
            // picApple
            // 
            this.picApple.Image = global::Calorie_Counter.Properties.Resources.AppleCalories;
            this.picApple.Location = new System.Drawing.Point(165, 12);
            this.picApple.Name = "picApple";
            this.picApple.Size = new System.Drawing.Size(124, 154);
            this.picApple.TabIndex = 0;
            this.picApple.TabStop = false;
            this.picApple.Click += new System.EventHandler(this.picApple_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 379);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblTotalCalories);
            this.Controls.Add(this.lblTotalCaloriesDescription);
            this.Name = "Form1";
            this.Text = "Calorie Counter";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBanana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picApple)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picApple;
        private System.Windows.Forms.PictureBox picPear;
        private System.Windows.Forms.PictureBox picOrange;
        private System.Windows.Forms.PictureBox picBanana;
        private System.Windows.Forms.Label lblTotalCaloriesDescription;
        private System.Windows.Forms.Label lblTotalCalories;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panel1;
    }
}

