﻿namespace Calories_from_Fat_and_Carbs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fatGramsLabel = new System.Windows.Forms.Label();
            this.carbGramLabel = new System.Windows.Forms.Label();
            this.fatGramsTextBox = new System.Windows.Forms.TextBox();
            this.carbGramsTextBox = new System.Windows.Forms.TextBox();
            this.caloriesFromFatDescription = new System.Windows.Forms.Label();
            this.caloriesFromCarbsDescription = new System.Windows.Forms.Label();
            this.totalFatCaloriesLabel = new System.Windows.Forms.Label();
            this.totalCarbCaloriesLabel = new System.Windows.Forms.Label();
            this.totalCaloriesDescription = new System.Windows.Forms.Label();
            this.totalCaloriesLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fatGramsLabel
            // 
            this.fatGramsLabel.AutoSize = true;
            this.fatGramsLabel.Location = new System.Drawing.Point(67, 15);
            this.fatGramsLabel.Name = "fatGramsLabel";
            this.fatGramsLabel.Size = new System.Drawing.Size(81, 13);
            this.fatGramsLabel.TabIndex = 0;
            this.fatGramsLabel.Text = "Enter fat grams:";
            // 
            // carbGramLabel
            // 
            this.carbGramLabel.AutoSize = true;
            this.carbGramLabel.Location = new System.Drawing.Point(58, 41);
            this.carbGramLabel.Name = "carbGramLabel";
            this.carbGramLabel.Size = new System.Drawing.Size(90, 13);
            this.carbGramLabel.TabIndex = 1;
            this.carbGramLabel.Text = "Enter carb grams:";
            // 
            // fatGramsTextBox
            // 
            this.fatGramsTextBox.Location = new System.Drawing.Point(154, 12);
            this.fatGramsTextBox.Name = "fatGramsTextBox";
            this.fatGramsTextBox.Size = new System.Drawing.Size(100, 20);
            this.fatGramsTextBox.TabIndex = 2;
            // 
            // carbGramsTextBox
            // 
            this.carbGramsTextBox.Location = new System.Drawing.Point(154, 38);
            this.carbGramsTextBox.Name = "carbGramsTextBox";
            this.carbGramsTextBox.Size = new System.Drawing.Size(100, 20);
            this.carbGramsTextBox.TabIndex = 3;
            // 
            // caloriesFromFatDescription
            // 
            this.caloriesFromFatDescription.AutoSize = true;
            this.caloriesFromFatDescription.Location = new System.Drawing.Point(37, 78);
            this.caloriesFromFatDescription.Name = "caloriesFromFatDescription";
            this.caloriesFromFatDescription.Size = new System.Drawing.Size(111, 13);
            this.caloriesFromFatDescription.TabIndex = 4;
            this.caloriesFromFatDescription.Text = "Total calories from fat:";
            // 
            // caloriesFromCarbsDescription
            // 
            this.caloriesFromCarbsDescription.AutoSize = true;
            this.caloriesFromCarbsDescription.Location = new System.Drawing.Point(23, 112);
            this.caloriesFromCarbsDescription.Name = "caloriesFromCarbsDescription";
            this.caloriesFromCarbsDescription.Size = new System.Drawing.Size(125, 13);
            this.caloriesFromCarbsDescription.TabIndex = 5;
            this.caloriesFromCarbsDescription.Text = "Total calories from carbs:";
            // 
            // totalFatCaloriesLabel
            // 
            this.totalFatCaloriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalFatCaloriesLabel.Location = new System.Drawing.Point(154, 73);
            this.totalFatCaloriesLabel.Name = "totalFatCaloriesLabel";
            this.totalFatCaloriesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalFatCaloriesLabel.TabIndex = 6;
            this.totalFatCaloriesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalCarbCaloriesLabel
            // 
            this.totalCarbCaloriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCarbCaloriesLabel.Location = new System.Drawing.Point(154, 107);
            this.totalCarbCaloriesLabel.Name = "totalCarbCaloriesLabel";
            this.totalCarbCaloriesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCarbCaloriesLabel.TabIndex = 10;
            this.totalCarbCaloriesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalCaloriesDescription
            // 
            this.totalCaloriesDescription.AutoSize = true;
            this.totalCaloriesDescription.Location = new System.Drawing.Point(74, 147);
            this.totalCaloriesDescription.Name = "totalCaloriesDescription";
            this.totalCaloriesDescription.Size = new System.Drawing.Size(74, 13);
            this.totalCaloriesDescription.TabIndex = 8;
            this.totalCaloriesDescription.Text = "Total Calories:";
            // 
            // totalCaloriesLabel
            // 
            this.totalCaloriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCaloriesLabel.Location = new System.Drawing.Point(154, 142);
            this.totalCaloriesLabel.Name = "totalCaloriesLabel";
            this.totalCaloriesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCaloriesLabel.TabIndex = 9;
            this.totalCaloriesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(70, 179);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 11;
            this.calculateButton.Text = "Calculate Calories";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(154, 179);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 218);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalCaloriesLabel);
            this.Controls.Add(this.totalCaloriesDescription);
            this.Controls.Add(this.totalCarbCaloriesLabel);
            this.Controls.Add(this.totalFatCaloriesLabel);
            this.Controls.Add(this.caloriesFromCarbsDescription);
            this.Controls.Add(this.caloriesFromFatDescription);
            this.Controls.Add(this.carbGramsTextBox);
            this.Controls.Add(this.fatGramsTextBox);
            this.Controls.Add(this.carbGramLabel);
            this.Controls.Add(this.fatGramsLabel);
            this.Name = "Form1";
            this.Text = "Calories from Fat and Carbs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fatGramsLabel;
        private System.Windows.Forms.Label carbGramLabel;
        private System.Windows.Forms.TextBox fatGramsTextBox;
        private System.Windows.Forms.TextBox carbGramsTextBox;
        private System.Windows.Forms.Label caloriesFromFatDescription;
        private System.Windows.Forms.Label caloriesFromCarbsDescription;
        private System.Windows.Forms.Label totalFatCaloriesLabel;
        private System.Windows.Forms.Label totalCarbCaloriesLabel;
        private System.Windows.Forms.Label totalCaloriesDescription;
        private System.Windows.Forms.Label totalCaloriesLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

