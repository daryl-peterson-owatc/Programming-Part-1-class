﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calories_from_Fat_and_Carbs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double fatGrams, carbGrams, totalFatCalories, totalCarbCalories, totalCalories;

            if (double.TryParse(fatGramsTextBox.Text, out fatGrams))
            {
                if (double.TryParse(carbGramsTextBox.Text, out carbGrams))
                {
                    totalFatCalories = FatCalories(fatGrams);
                    totalCarbCalories = CarbCalories(carbGrams);
                    totalCalories = totalCarbCalories + totalFatCalories;

                    totalFatCaloriesLabel.Text = totalFatCalories.ToString("n1");
                    totalCarbCaloriesLabel.Text = totalCarbCalories.ToString("n1");
                    totalCaloriesLabel.Text = totalCalories.ToString("n1");
                }
                else
                {
                    MessageBox.Show("Enter a valid number.");
                }
            }
            else
            {
                MessageBox.Show("Enter a valid number.");
            }
        }

        private double FatCalories(double grams)
        {
            return grams * 9;
        }

        private double CarbCalories(double grams)
        {
            return grams * 4;
        }
    }
}
