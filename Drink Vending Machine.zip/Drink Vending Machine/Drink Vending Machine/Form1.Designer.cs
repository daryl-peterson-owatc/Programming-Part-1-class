﻿namespace Drink_Vending_Machine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.drinkImages = new System.Windows.Forms.ImageList(this.components);
            this.colaPanel = new System.Windows.Forms.Panel();
            this.colaPictureBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.rootBeerPanel = new System.Windows.Forms.Panel();
            this.lemonLimePanel = new System.Windows.Forms.Panel();
            this.grapeSodePanel = new System.Windows.Forms.Panel();
            this.creamSodePanel = new System.Windows.Forms.Panel();
            this.totalSalesPanel = new System.Windows.Forms.Panel();
            this.rootBeerPictureBox = new System.Windows.Forms.PictureBox();
            this.lemonLimePictureBox = new System.Windows.Forms.PictureBox();
            this.grapeSodePictureBox = new System.Windows.Forms.PictureBox();
            this.creamSodaPictureBox = new System.Windows.Forms.PictureBox();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.colaCostLabel = new System.Windows.Forms.Label();
            this.colaDescriptionLabel = new System.Windows.Forms.Label();
            this.rootBeerDescriptionLabel = new System.Windows.Forms.Label();
            this.lemonLimeDescriptionLabel = new System.Windows.Forms.Label();
            this.creamSodeDescriptionLabel = new System.Windows.Forms.Label();
            this.grapeSodeDescriptionLabel = new System.Windows.Forms.Label();
            this.rootBeerCostLabel = new System.Windows.Forms.Label();
            this.grapeSodeCostLabel = new System.Windows.Forms.Label();
            this.lemonLimeCostLabel = new System.Windows.Forms.Label();
            this.creamSodeCostLabel = new System.Windows.Forms.Label();
            this.colaLeftLabel = new System.Windows.Forms.Label();
            this.rootBeerLeftLabel = new System.Windows.Forms.Label();
            this.lemonLimeLeftLabel = new System.Windows.Forms.Label();
            this.grapeSodeLeftLabel = new System.Windows.Forms.Label();
            this.creamSodeLeftLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.totalSalesLabel = new System.Windows.Forms.Label();
            this.colaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).BeginInit();
            this.rootBeerPanel.SuspendLayout();
            this.lemonLimePanel.SuspendLayout();
            this.grapeSodePanel.SuspendLayout();
            this.creamSodePanel.SuspendLayout();
            this.totalSalesPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grapeSodePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // drinkImages
            // 
            this.drinkImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("drinkImages.ImageStream")));
            this.drinkImages.TransparentColor = System.Drawing.Color.Transparent;
            this.drinkImages.Images.SetKeyName(0, "Cola.bmp");
            this.drinkImages.Images.SetKeyName(1, "CreamSoda.bmp");
            this.drinkImages.Images.SetKeyName(2, "GrapeSoda.bmp");
            this.drinkImages.Images.SetKeyName(3, "LemonLime.bmp");
            this.drinkImages.Images.SetKeyName(4, "RootBeer.bmp");
            // 
            // colaPanel
            // 
            this.colaPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.colaPanel.Controls.Add(this.colaLeftLabel);
            this.colaPanel.Controls.Add(this.colaDescriptionLabel);
            this.colaPanel.Controls.Add(this.colaCostLabel);
            this.colaPanel.Controls.Add(this.colaPictureBox);
            this.colaPanel.Location = new System.Drawing.Point(15, 46);
            this.colaPanel.Name = "colaPanel";
            this.colaPanel.Size = new System.Drawing.Size(148, 75);
            this.colaPanel.TabIndex = 0;
            // 
            // colaPictureBox
            // 
            this.colaPictureBox.Location = new System.Drawing.Point(3, 3);
            this.colaPictureBox.Name = "colaPictureBox";
            this.colaPictureBox.Size = new System.Drawing.Size(64, 64);
            this.colaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.colaPictureBox.TabIndex = 0;
            this.colaPictureBox.TabStop = false;
            this.colaPictureBox.Click += new System.EventHandler(this.colaPictureBox_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(130, 298);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // rootBeerPanel
            // 
            this.rootBeerPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rootBeerPanel.Controls.Add(this.rootBeerLeftLabel);
            this.rootBeerPanel.Controls.Add(this.rootBeerCostLabel);
            this.rootBeerPanel.Controls.Add(this.rootBeerDescriptionLabel);
            this.rootBeerPanel.Controls.Add(this.rootBeerPictureBox);
            this.rootBeerPanel.Location = new System.Drawing.Point(169, 46);
            this.rootBeerPanel.Name = "rootBeerPanel";
            this.rootBeerPanel.Size = new System.Drawing.Size(145, 75);
            this.rootBeerPanel.TabIndex = 2;
            // 
            // lemonLimePanel
            // 
            this.lemonLimePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lemonLimePanel.Controls.Add(this.lemonLimeLeftLabel);
            this.lemonLimePanel.Controls.Add(this.lemonLimeCostLabel);
            this.lemonLimePanel.Controls.Add(this.lemonLimeDescriptionLabel);
            this.lemonLimePanel.Controls.Add(this.lemonLimePictureBox);
            this.lemonLimePanel.Location = new System.Drawing.Point(15, 127);
            this.lemonLimePanel.Name = "lemonLimePanel";
            this.lemonLimePanel.Size = new System.Drawing.Size(148, 75);
            this.lemonLimePanel.TabIndex = 3;
            // 
            // grapeSodePanel
            // 
            this.grapeSodePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grapeSodePanel.Controls.Add(this.grapeSodeLeftLabel);
            this.grapeSodePanel.Controls.Add(this.grapeSodeCostLabel);
            this.grapeSodePanel.Controls.Add(this.grapeSodeDescriptionLabel);
            this.grapeSodePanel.Controls.Add(this.grapeSodePictureBox);
            this.grapeSodePanel.Location = new System.Drawing.Point(169, 127);
            this.grapeSodePanel.Name = "grapeSodePanel";
            this.grapeSodePanel.Size = new System.Drawing.Size(145, 75);
            this.grapeSodePanel.TabIndex = 4;
            // 
            // creamSodePanel
            // 
            this.creamSodePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.creamSodePanel.Controls.Add(this.creamSodeLeftLabel);
            this.creamSodePanel.Controls.Add(this.creamSodeCostLabel);
            this.creamSodePanel.Controls.Add(this.creamSodeDescriptionLabel);
            this.creamSodePanel.Controls.Add(this.creamSodaPictureBox);
            this.creamSodePanel.Location = new System.Drawing.Point(15, 208);
            this.creamSodePanel.Name = "creamSodePanel";
            this.creamSodePanel.Size = new System.Drawing.Size(148, 75);
            this.creamSodePanel.TabIndex = 5;
            // 
            // totalSalesPanel
            // 
            this.totalSalesPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalSalesPanel.Controls.Add(this.totalSalesLabel);
            this.totalSalesPanel.Controls.Add(this.label1);
            this.totalSalesPanel.Location = new System.Drawing.Point(169, 208);
            this.totalSalesPanel.Name = "totalSalesPanel";
            this.totalSalesPanel.Size = new System.Drawing.Size(145, 75);
            this.totalSalesPanel.TabIndex = 6;
            // 
            // rootBeerPictureBox
            // 
            this.rootBeerPictureBox.Location = new System.Drawing.Point(3, 3);
            this.rootBeerPictureBox.Name = "rootBeerPictureBox";
            this.rootBeerPictureBox.Size = new System.Drawing.Size(64, 64);
            this.rootBeerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rootBeerPictureBox.TabIndex = 0;
            this.rootBeerPictureBox.TabStop = false;
            this.rootBeerPictureBox.Click += new System.EventHandler(this.rootBeerPictureBox_Click);
            // 
            // lemonLimePictureBox
            // 
            this.lemonLimePictureBox.Location = new System.Drawing.Point(3, 3);
            this.lemonLimePictureBox.Name = "lemonLimePictureBox";
            this.lemonLimePictureBox.Size = new System.Drawing.Size(64, 64);
            this.lemonLimePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lemonLimePictureBox.TabIndex = 0;
            this.lemonLimePictureBox.TabStop = false;
            this.lemonLimePictureBox.Click += new System.EventHandler(this.lemonLimePictureBox_Click);
            // 
            // grapeSodePictureBox
            // 
            this.grapeSodePictureBox.Location = new System.Drawing.Point(3, 3);
            this.grapeSodePictureBox.Name = "grapeSodePictureBox";
            this.grapeSodePictureBox.Size = new System.Drawing.Size(64, 64);
            this.grapeSodePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.grapeSodePictureBox.TabIndex = 0;
            this.grapeSodePictureBox.TabStop = false;
            this.grapeSodePictureBox.Click += new System.EventHandler(this.grapeSodePictureBox_Click);
            // 
            // creamSodaPictureBox
            // 
            this.creamSodaPictureBox.Location = new System.Drawing.Point(3, 3);
            this.creamSodaPictureBox.Name = "creamSodaPictureBox";
            this.creamSodaPictureBox.Size = new System.Drawing.Size(64, 64);
            this.creamSodaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.creamSodaPictureBox.TabIndex = 0;
            this.creamSodaPictureBox.TabStop = false;
            this.creamSodaPictureBox.Click += new System.EventHandler(this.creamSodaPictureBox_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLabel.Location = new System.Drawing.Point(121, 16);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(105, 16);
            this.instructionLabel.TabIndex = 7;
            this.instructionLabel.Text = "Select a Drink";
            // 
            // colaCostLabel
            // 
            this.colaCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colaCostLabel.Location = new System.Drawing.Point(73, 8);
            this.colaCostLabel.Name = "colaCostLabel";
            this.colaCostLabel.Size = new System.Drawing.Size(61, 18);
            this.colaCostLabel.TabIndex = 1;
            this.colaCostLabel.Text = "Cola";
            this.colaCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // colaDescriptionLabel
            // 
            this.colaDescriptionLabel.AutoSize = true;
            this.colaDescriptionLabel.Location = new System.Drawing.Point(73, 26);
            this.colaDescriptionLabel.Name = "colaDescriptionLabel";
            this.colaDescriptionLabel.Size = new System.Drawing.Size(61, 13);
            this.colaDescriptionLabel.TabIndex = 2;
            this.colaDescriptionLabel.Text = "Drinks Left:";
            // 
            // rootBeerDescriptionLabel
            // 
            this.rootBeerDescriptionLabel.AutoSize = true;
            this.rootBeerDescriptionLabel.Location = new System.Drawing.Point(73, 26);
            this.rootBeerDescriptionLabel.Name = "rootBeerDescriptionLabel";
            this.rootBeerDescriptionLabel.Size = new System.Drawing.Size(61, 13);
            this.rootBeerDescriptionLabel.TabIndex = 3;
            this.rootBeerDescriptionLabel.Text = "Drinks Left:";
            // 
            // lemonLimeDescriptionLabel
            // 
            this.lemonLimeDescriptionLabel.AutoSize = true;
            this.lemonLimeDescriptionLabel.Location = new System.Drawing.Point(73, 29);
            this.lemonLimeDescriptionLabel.Name = "lemonLimeDescriptionLabel";
            this.lemonLimeDescriptionLabel.Size = new System.Drawing.Size(61, 13);
            this.lemonLimeDescriptionLabel.TabIndex = 3;
            this.lemonLimeDescriptionLabel.Text = "Drinks Left:";
            // 
            // creamSodeDescriptionLabel
            // 
            this.creamSodeDescriptionLabel.AutoSize = true;
            this.creamSodeDescriptionLabel.Location = new System.Drawing.Point(73, 28);
            this.creamSodeDescriptionLabel.Name = "creamSodeDescriptionLabel";
            this.creamSodeDescriptionLabel.Size = new System.Drawing.Size(61, 13);
            this.creamSodeDescriptionLabel.TabIndex = 3;
            this.creamSodeDescriptionLabel.Text = "Drinks Left:";
            // 
            // grapeSodeDescriptionLabel
            // 
            this.grapeSodeDescriptionLabel.AutoSize = true;
            this.grapeSodeDescriptionLabel.Location = new System.Drawing.Point(73, 29);
            this.grapeSodeDescriptionLabel.Name = "grapeSodeDescriptionLabel";
            this.grapeSodeDescriptionLabel.Size = new System.Drawing.Size(61, 13);
            this.grapeSodeDescriptionLabel.TabIndex = 3;
            this.grapeSodeDescriptionLabel.Text = "Drinks Left:";
            // 
            // rootBeerCostLabel
            // 
            this.rootBeerCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rootBeerCostLabel.Location = new System.Drawing.Point(73, 8);
            this.rootBeerCostLabel.Name = "rootBeerCostLabel";
            this.rootBeerCostLabel.Size = new System.Drawing.Size(61, 18);
            this.rootBeerCostLabel.TabIndex = 4;
            this.rootBeerCostLabel.Text = "Root";
            this.rootBeerCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grapeSodeCostLabel
            // 
            this.grapeSodeCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grapeSodeCostLabel.Location = new System.Drawing.Point(73, 11);
            this.grapeSodeCostLabel.Name = "grapeSodeCostLabel";
            this.grapeSodeCostLabel.Size = new System.Drawing.Size(61, 18);
            this.grapeSodeCostLabel.TabIndex = 4;
            this.grapeSodeCostLabel.Text = "Grape";
            this.grapeSodeCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lemonLimeCostLabel
            // 
            this.lemonLimeCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lemonLimeCostLabel.Location = new System.Drawing.Point(73, 11);
            this.lemonLimeCostLabel.Name = "lemonLimeCostLabel";
            this.lemonLimeCostLabel.Size = new System.Drawing.Size(61, 18);
            this.lemonLimeCostLabel.TabIndex = 4;
            this.lemonLimeCostLabel.Text = "Lemon";
            this.lemonLimeCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // creamSodeCostLabel
            // 
            this.creamSodeCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creamSodeCostLabel.Location = new System.Drawing.Point(73, 10);
            this.creamSodeCostLabel.Name = "creamSodeCostLabel";
            this.creamSodeCostLabel.Size = new System.Drawing.Size(61, 18);
            this.creamSodeCostLabel.TabIndex = 4;
            this.creamSodeCostLabel.Text = "Cream";
            this.creamSodeCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // colaLeftLabel
            // 
            this.colaLeftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.colaLeftLabel.Location = new System.Drawing.Point(73, 39);
            this.colaLeftLabel.Name = "colaLeftLabel";
            this.colaLeftLabel.Size = new System.Drawing.Size(61, 23);
            this.colaLeftLabel.TabIndex = 3;
            this.colaLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rootBeerLeftLabel
            // 
            this.rootBeerLeftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rootBeerLeftLabel.Location = new System.Drawing.Point(73, 39);
            this.rootBeerLeftLabel.Name = "rootBeerLeftLabel";
            this.rootBeerLeftLabel.Size = new System.Drawing.Size(61, 23);
            this.rootBeerLeftLabel.TabIndex = 5;
            this.rootBeerLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lemonLimeLeftLabel
            // 
            this.lemonLimeLeftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lemonLimeLeftLabel.Location = new System.Drawing.Point(73, 42);
            this.lemonLimeLeftLabel.Name = "lemonLimeLeftLabel";
            this.lemonLimeLeftLabel.Size = new System.Drawing.Size(61, 23);
            this.lemonLimeLeftLabel.TabIndex = 5;
            this.lemonLimeLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grapeSodeLeftLabel
            // 
            this.grapeSodeLeftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grapeSodeLeftLabel.Location = new System.Drawing.Point(73, 42);
            this.grapeSodeLeftLabel.Name = "grapeSodeLeftLabel";
            this.grapeSodeLeftLabel.Size = new System.Drawing.Size(61, 23);
            this.grapeSodeLeftLabel.TabIndex = 5;
            this.grapeSodeLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // creamSodeLeftLabel
            // 
            this.creamSodeLeftLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.creamSodeLeftLabel.Location = new System.Drawing.Point(73, 41);
            this.creamSodeLeftLabel.Name = "creamSodeLeftLabel";
            this.creamSodeLeftLabel.Size = new System.Drawing.Size(61, 23);
            this.creamSodeLeftLabel.TabIndex = 5;
            this.creamSodeLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Total Sales";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalSalesLabel
            // 
            this.totalSalesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSalesLabel.Location = new System.Drawing.Point(33, 35);
            this.totalSalesLabel.Name = "totalSalesLabel";
            this.totalSalesLabel.Size = new System.Drawing.Size(72, 23);
            this.totalSalesLabel.TabIndex = 6;
            this.totalSalesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 338);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.totalSalesPanel);
            this.Controls.Add(this.creamSodePanel);
            this.Controls.Add(this.grapeSodePanel);
            this.Controls.Add(this.lemonLimePanel);
            this.Controls.Add(this.rootBeerPanel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.colaPanel);
            this.Name = "Form1";
            this.Text = "Drink Vending Machine";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.colaPanel.ResumeLayout(false);
            this.colaPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).EndInit();
            this.rootBeerPanel.ResumeLayout(false);
            this.rootBeerPanel.PerformLayout();
            this.lemonLimePanel.ResumeLayout(false);
            this.lemonLimePanel.PerformLayout();
            this.grapeSodePanel.ResumeLayout(false);
            this.grapeSodePanel.PerformLayout();
            this.creamSodePanel.ResumeLayout(false);
            this.creamSodePanel.PerformLayout();
            this.totalSalesPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grapeSodePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList drinkImages;
        private System.Windows.Forms.Panel colaPanel;
        private System.Windows.Forms.PictureBox colaPictureBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel rootBeerPanel;
        private System.Windows.Forms.Panel lemonLimePanel;
        private System.Windows.Forms.Panel grapeSodePanel;
        private System.Windows.Forms.Panel creamSodePanel;
        private System.Windows.Forms.Panel totalSalesPanel;
        private System.Windows.Forms.PictureBox rootBeerPictureBox;
        private System.Windows.Forms.PictureBox lemonLimePictureBox;
        private System.Windows.Forms.PictureBox grapeSodePictureBox;
        private System.Windows.Forms.PictureBox creamSodaPictureBox;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label colaLeftLabel;
        private System.Windows.Forms.Label colaDescriptionLabel;
        private System.Windows.Forms.Label colaCostLabel;
        private System.Windows.Forms.Label rootBeerLeftLabel;
        private System.Windows.Forms.Label rootBeerCostLabel;
        private System.Windows.Forms.Label rootBeerDescriptionLabel;
        private System.Windows.Forms.Label lemonLimeLeftLabel;
        private System.Windows.Forms.Label lemonLimeCostLabel;
        private System.Windows.Forms.Label lemonLimeDescriptionLabel;
        private System.Windows.Forms.Label grapeSodeLeftLabel;
        private System.Windows.Forms.Label grapeSodeCostLabel;
        private System.Windows.Forms.Label grapeSodeDescriptionLabel;
        private System.Windows.Forms.Label creamSodeLeftLabel;
        private System.Windows.Forms.Label creamSodeCostLabel;
        private System.Windows.Forms.Label creamSodeDescriptionLabel;
        private System.Windows.Forms.Label totalSalesLabel;
        private System.Windows.Forms.Label label1;
    }
}

