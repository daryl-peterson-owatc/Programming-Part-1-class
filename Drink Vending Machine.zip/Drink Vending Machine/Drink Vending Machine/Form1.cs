﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drink_Vending_Machine
{
    struct Drink
    {
        public string name;
        public decimal cost;
        public int remaining;
    }

    public partial class Form1 : Form
    {
        const int SIZE = 5;
        Drink[] drinks = new Drink[SIZE];
        enum Soda { Cola, CreamSoda, GrapeSode, LemonLime, RootBeer }
        decimal totalSales = 0.0m;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            colaPictureBox.Image = drinkImages.Images[0];
            creamSodaPictureBox.Image = drinkImages.Images[1];
            grapeSodePictureBox.Image = drinkImages.Images[2];
            lemonLimePictureBox.Image = drinkImages.Images[3];
            rootBeerPictureBox.Image = drinkImages.Images[4];

            drinks[0].name = "Cola";
            drinks[0].cost = 1.00m;
            drinks[0].remaining = 20;
            colaCostLabel.Text = drinks[0].cost.ToString("c");
            colaLeftLabel.Text = drinks[0].remaining.ToString();

            drinks[1].name = "CreamSode";
            drinks[1].cost = 1.50m;
            drinks[1].remaining = 20;
            creamSodeCostLabel.Text = drinks[1].cost.ToString("c");
            creamSodeLeftLabel.Text = drinks[1].remaining.ToString();

            drinks[2].name = "GrapeSoda";
            drinks[2].cost = 1.50m;
            drinks[2].remaining = 20;
            grapeSodeCostLabel.Text = drinks[2].cost.ToString("c");
            grapeSodeLeftLabel.Text = drinks[2].remaining.ToString();

            drinks[3].name = "LemonLime";
            drinks[3].cost = 1.00m;
            drinks[3].remaining = 20;
            lemonLimeCostLabel.Text = drinks[3].cost.ToString("c");
            lemonLimeLeftLabel.Text = drinks[3].remaining.ToString();

            drinks[4].name = "RootBeer";
            drinks[4].cost = 1.00m;
            drinks[4].remaining = 20;
            rootBeerCostLabel.Text = drinks[4].cost.ToString("c");
            rootBeerLeftLabel.Text = drinks[4].remaining.ToString();

            totalSalesLabel.Text = totalSales.ToString("c");
        }

        private void colaPictureBox_Click(object sender, EventArgs e)
        {
            int index = (int)Soda.Cola;
            colaLeftLabel.Text = calculateTotals(index).ToString();
        }

        private void rootBeerPictureBox_Click(object sender, EventArgs e)
        {
            int index = (int)Soda.RootBeer;
            rootBeerLeftLabel.Text = calculateTotals(index).ToString();
        }

        private void lemonLimePictureBox_Click(object sender, EventArgs e)
        {
            int index = (int)Soda.LemonLime;
            lemonLimeLeftLabel.Text = calculateTotals(index).ToString();
        }

        private void grapeSodePictureBox_Click(object sender, EventArgs e)
        {
            int index = (int)Soda.GrapeSode;
            grapeSodeLeftLabel.Text = calculateTotals(index).ToString();
        }

        private void creamSodaPictureBox_Click(object sender, EventArgs e)
        {
            int index = (int)Soda.CreamSoda;
            creamSodeLeftLabel.Text = calculateTotals(index).ToString();
        }

        private int calculateTotals(int index)
        {
            totalSales += drinks[index].cost;
            drinks[index].remaining -= 1;
            totalSalesLabel.Text = totalSales.ToString("c");

            return drinks[index].remaining;
        }
    }
}
