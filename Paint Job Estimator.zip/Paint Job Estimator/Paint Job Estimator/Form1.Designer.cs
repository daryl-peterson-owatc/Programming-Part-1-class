﻿namespace Paint_Job_Estimator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtSquareFeet = new System.Windows.Forms.TextBox();
            this.txtCostPerGallon = new System.Windows.Forms.TextBox();
            this.lblWallSurfaceDescription = new System.Windows.Forms.Label();
            this.lblCostPerGallonDescription = new System.Windows.Forms.Label();
            this.lblGallonsNeededDescription = new System.Windows.Forms.Label();
            this.lblTotalGallons = new System.Windows.Forms.Label();
            this.lblGallonsCostDescription = new System.Windows.Forms.Label();
            this.lblPaintCosts = new System.Windows.Forms.Label();
            this.lblLaborHoursDescription = new System.Windows.Forms.Label();
            this.lblLaborHours = new System.Windows.Forms.Label();
            this.lblLaborCostsDescription = new System.Windows.Forms.Label();
            this.lblLaborCosts = new System.Windows.Forms.Label();
            this.lblTotalCostDescription = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(35, 214);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 36);
            this.btnCalculate.TabIndex = 2;
            this.btnCalculate.Text = "Calculate Paint Job";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(132, 214);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 36);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(226, 214);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 36);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtSquareFeet
            // 
            this.txtSquareFeet.Location = new System.Drawing.Point(201, 11);
            this.txtSquareFeet.Name = "txtSquareFeet";
            this.txtSquareFeet.Size = new System.Drawing.Size(100, 20);
            this.txtSquareFeet.TabIndex = 0;
            this.txtSquareFeet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCostPerGallon
            // 
            this.txtCostPerGallon.Location = new System.Drawing.Point(201, 37);
            this.txtCostPerGallon.Name = "txtCostPerGallon";
            this.txtCostPerGallon.Size = new System.Drawing.Size(100, 20);
            this.txtCostPerGallon.TabIndex = 1;
            this.txtCostPerGallon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblWallSurfaceDescription
            // 
            this.lblWallSurfaceDescription.AutoSize = true;
            this.lblWallSurfaceDescription.Location = new System.Drawing.Point(10, 14);
            this.lblWallSurfaceDescription.Name = "lblWallSurfaceDescription";
            this.lblWallSurfaceDescription.Size = new System.Drawing.Size(185, 13);
            this.lblWallSurfaceDescription.TabIndex = 5;
            this.lblWallSurfaceDescription.Text = "Enter the wall surface (in square feet):";
            // 
            // lblCostPerGallonDescription
            // 
            this.lblCostPerGallonDescription.AutoSize = true;
            this.lblCostPerGallonDescription.Location = new System.Drawing.Point(32, 40);
            this.lblCostPerGallonDescription.Name = "lblCostPerGallonDescription";
            this.lblCostPerGallonDescription.Size = new System.Drawing.Size(163, 13);
            this.lblCostPerGallonDescription.TabIndex = 6;
            this.lblCostPerGallonDescription.Text = "Enter the cost per gallon of paint:";
            // 
            // lblGallonsNeededDescription
            // 
            this.lblGallonsNeededDescription.AutoSize = true;
            this.lblGallonsNeededDescription.Location = new System.Drawing.Point(61, 65);
            this.lblGallonsNeededDescription.Name = "lblGallonsNeededDescription";
            this.lblGallonsNeededDescription.Size = new System.Drawing.Size(134, 13);
            this.lblGallonsNeededDescription.TabIndex = 7;
            this.lblGallonsNeededDescription.Text = "Number of gallons needed:";
            this.lblGallonsNeededDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalGallons
            // 
            this.lblTotalGallons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalGallons.Location = new System.Drawing.Point(201, 64);
            this.lblTotalGallons.Name = "lblTotalGallons";
            this.lblTotalGallons.Size = new System.Drawing.Size(100, 20);
            this.lblTotalGallons.TabIndex = 8;
            this.lblTotalGallons.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblGallonsCostDescription
            // 
            this.lblGallonsCostDescription.AutoSize = true;
            this.lblGallonsCostDescription.Location = new System.Drawing.Point(121, 94);
            this.lblGallonsCostDescription.Name = "lblGallonsCostDescription";
            this.lblGallonsCostDescription.Size = new System.Drawing.Size(74, 13);
            this.lblGallonsCostDescription.TabIndex = 9;
            this.lblGallonsCostDescription.Text = "Gallons Costs:";
            // 
            // lblPaintCosts
            // 
            this.lblPaintCosts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPaintCosts.Location = new System.Drawing.Point(201, 93);
            this.lblPaintCosts.Name = "lblPaintCosts";
            this.lblPaintCosts.Size = new System.Drawing.Size(100, 19);
            this.lblPaintCosts.TabIndex = 10;
            this.lblPaintCosts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLaborHoursDescription
            // 
            this.lblLaborHoursDescription.AutoSize = true;
            this.lblLaborHoursDescription.Location = new System.Drawing.Point(45, 118);
            this.lblLaborHoursDescription.Name = "lblLaborHoursDescription";
            this.lblLaborHoursDescription.Size = new System.Drawing.Size(150, 13);
            this.lblLaborHoursDescription.TabIndex = 17;
            this.lblLaborHoursDescription.Text = "Number of hours to do the job:";
            // 
            // lblLaborHours
            // 
            this.lblLaborHours.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLaborHours.Location = new System.Drawing.Point(201, 117);
            this.lblLaborHours.Name = "lblLaborHours";
            this.lblLaborHours.Size = new System.Drawing.Size(100, 19);
            this.lblLaborHours.TabIndex = 12;
            this.lblLaborHours.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLaborCostsDescription
            // 
            this.lblLaborCostsDescription.AutoSize = true;
            this.lblLaborCostsDescription.Location = new System.Drawing.Point(129, 144);
            this.lblLaborCostsDescription.Name = "lblLaborCostsDescription";
            this.lblLaborCostsDescription.Size = new System.Drawing.Size(66, 13);
            this.lblLaborCostsDescription.TabIndex = 13;
            this.lblLaborCostsDescription.Text = "Labor Costs:";
            // 
            // lblLaborCosts
            // 
            this.lblLaborCosts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLaborCosts.Location = new System.Drawing.Point(201, 143);
            this.lblLaborCosts.Name = "lblLaborCosts";
            this.lblLaborCosts.Size = new System.Drawing.Size(100, 19);
            this.lblLaborCosts.TabIndex = 14;
            this.lblLaborCosts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalCostDescription
            // 
            this.lblTotalCostDescription.AutoSize = true;
            this.lblTotalCostDescription.Location = new System.Drawing.Point(117, 172);
            this.lblTotalCostDescription.Name = "lblTotalCostDescription";
            this.lblTotalCostDescription.Size = new System.Drawing.Size(78, 13);
            this.lblTotalCostDescription.TabIndex = 15;
            this.lblTotalCostDescription.Text = "Total Job Cost:";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCost.Location = new System.Drawing.Point(201, 171);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(100, 19);
            this.lblTotalCost.TabIndex = 16;
            this.lblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 262);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.lblTotalCostDescription);
            this.Controls.Add(this.lblLaborCosts);
            this.Controls.Add(this.lblLaborCostsDescription);
            this.Controls.Add(this.lblLaborHours);
            this.Controls.Add(this.lblLaborHoursDescription);
            this.Controls.Add(this.lblPaintCosts);
            this.Controls.Add(this.lblGallonsCostDescription);
            this.Controls.Add(this.lblTotalGallons);
            this.Controls.Add(this.lblGallonsNeededDescription);
            this.Controls.Add(this.lblCostPerGallonDescription);
            this.Controls.Add(this.lblWallSurfaceDescription);
            this.Controls.Add(this.txtCostPerGallon);
            this.Controls.Add(this.txtSquareFeet);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Name = "Form1";
            this.Text = "Paint Job Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtSquareFeet;
        private System.Windows.Forms.TextBox txtCostPerGallon;
        private System.Windows.Forms.Label lblWallSurfaceDescription;
        private System.Windows.Forms.Label lblCostPerGallonDescription;
        private System.Windows.Forms.Label lblGallonsNeededDescription;
        private System.Windows.Forms.Label lblTotalGallons;
        private System.Windows.Forms.Label lblGallonsCostDescription;
        private System.Windows.Forms.Label lblPaintCosts;
        private System.Windows.Forms.Label lblLaborHoursDescription;
        private System.Windows.Forms.Label lblLaborHours;
        private System.Windows.Forms.Label lblLaborCostsDescription;
        private System.Windows.Forms.Label lblLaborCosts;
        private System.Windows.Forms.Label lblTotalCostDescription;
        private System.Windows.Forms.Label lblTotalCost;
    }
}

