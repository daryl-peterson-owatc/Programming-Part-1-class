﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_Job_Estimator
{
    public partial class Form1 : Form
    {
        const decimal CORE_FOOTAGE = 115;
        const decimal CORE_GALLONS = 1;
        const decimal CORE_HOURS = 8;
        const decimal HOURLY_RATE = 20;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCostPerGallon.Text = "";
            txtSquareFeet.Text = "";
            lblLaborCosts.Text = "";
            lblLaborHours.Text = "";
            lblPaintCosts.Text = "";
            lblTotalGallons.Text = "";
            lblTotalCost.Text = "";
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal squareFeet = decimal.Parse(txtSquareFeet.Text);
            decimal pricePerGallon = decimal.Parse(txtCostPerGallon.Text);
            decimal numberOfGallons = (squareFeet / CORE_FOOTAGE) * CORE_GALLONS;
            decimal paintCost = numberOfGallons * pricePerGallon;
            decimal numberOfHours = (squareFeet / CORE_FOOTAGE) * CORE_HOURS;
            decimal laborCost = numberOfHours * HOURLY_RATE;
            decimal jobCost = paintCost + laborCost;

            lblTotalGallons.Text = numberOfGallons.ToString("n2");
            lblPaintCosts.Text = paintCost.ToString("c2");
            lblLaborHours.Text = numberOfHours.ToString("n2");
            lblLaborCosts.Text = laborCost.ToString("c2");
            lblTotalCost.Text = jobCost.ToString("c2");
        }
    }
}
