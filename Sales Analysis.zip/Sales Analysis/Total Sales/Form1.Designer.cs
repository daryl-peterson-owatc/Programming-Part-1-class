﻿namespace Total_Sales
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.salesListBox = new System.Windows.Forms.ListBox();
            this.totalSalesLabel = new System.Windows.Forms.Label();
            this.salesTotalDescriptionLabel = new System.Windows.Forms.Label();
            this.getSalesReportButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.averageAmountLabel = new System.Windows.Forms.Label();
            this.averageDescriptionLabel = new System.Windows.Forms.Label();
            this.highestAmountLabel = new System.Windows.Forms.Label();
            this.highestDescriptionLabel = new System.Windows.Forms.Label();
            this.lowestAmountLabel = new System.Windows.Forms.Label();
            this.lowestDescriptionLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // salesListBox
            // 
            this.salesListBox.FormattingEnabled = true;
            this.salesListBox.Location = new System.Drawing.Point(15, 12);
            this.salesListBox.Name = "salesListBox";
            this.salesListBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.salesListBox.Size = new System.Drawing.Size(143, 147);
            this.salesListBox.TabIndex = 0;
            // 
            // totalSalesLabel
            // 
            this.totalSalesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSalesLabel.Location = new System.Drawing.Point(287, 12);
            this.totalSalesLabel.Name = "totalSalesLabel";
            this.totalSalesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalSalesLabel.TabIndex = 1;
            this.totalSalesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTotalDescriptionLabel
            // 
            this.salesTotalDescriptionLabel.AutoSize = true;
            this.salesTotalDescriptionLabel.Location = new System.Drawing.Point(221, 17);
            this.salesTotalDescriptionLabel.Name = "salesTotalDescriptionLabel";
            this.salesTotalDescriptionLabel.Size = new System.Drawing.Size(60, 13);
            this.salesTotalDescriptionLabel.TabIndex = 2;
            this.salesTotalDescriptionLabel.Text = "SalesTotal:";
            // 
            // getSalesReportButton
            // 
            this.getSalesReportButton.Location = new System.Drawing.Point(206, 176);
            this.getSalesReportButton.Name = "getSalesReportButton";
            this.getSalesReportButton.Size = new System.Drawing.Size(75, 23);
            this.getSalesReportButton.TabIndex = 3;
            this.getSalesReportButton.Text = "Get Report";
            this.getSalesReportButton.UseVisualStyleBackColor = true;
            this.getSalesReportButton.Click += new System.EventHandler(this.getSalesReportButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(312, 176);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // averageAmountLabel
            // 
            this.averageAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averageAmountLabel.Location = new System.Drawing.Point(287, 46);
            this.averageAmountLabel.Name = "averageAmountLabel";
            this.averageAmountLabel.Size = new System.Drawing.Size(100, 23);
            this.averageAmountLabel.TabIndex = 5;
            this.averageAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // averageDescriptionLabel
            // 
            this.averageDescriptionLabel.AutoSize = true;
            this.averageDescriptionLabel.Location = new System.Drawing.Point(192, 51);
            this.averageDescriptionLabel.Name = "averageDescriptionLabel";
            this.averageDescriptionLabel.Size = new System.Drawing.Size(89, 13);
            this.averageDescriptionLabel.TabIndex = 6;
            this.averageDescriptionLabel.Text = "Average Amount:";
            // 
            // highestAmountLabel
            // 
            this.highestAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highestAmountLabel.Location = new System.Drawing.Point(287, 80);
            this.highestAmountLabel.Name = "highestAmountLabel";
            this.highestAmountLabel.Size = new System.Drawing.Size(100, 23);
            this.highestAmountLabel.TabIndex = 7;
            this.highestAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // highestDescriptionLabel
            // 
            this.highestDescriptionLabel.AutoSize = true;
            this.highestDescriptionLabel.Location = new System.Drawing.Point(196, 85);
            this.highestDescriptionLabel.Name = "highestDescriptionLabel";
            this.highestDescriptionLabel.Size = new System.Drawing.Size(85, 13);
            this.highestDescriptionLabel.TabIndex = 8;
            this.highestDescriptionLabel.Text = "Highest Amount:";
            // 
            // lowestAmountLabel
            // 
            this.lowestAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowestAmountLabel.Location = new System.Drawing.Point(287, 113);
            this.lowestAmountLabel.Name = "lowestAmountLabel";
            this.lowestAmountLabel.Size = new System.Drawing.Size(100, 23);
            this.lowestAmountLabel.TabIndex = 9;
            this.lowestAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lowestDescriptionLabel
            // 
            this.lowestDescriptionLabel.AutoSize = true;
            this.lowestDescriptionLabel.Location = new System.Drawing.Point(198, 118);
            this.lowestDescriptionLabel.Name = "lowestDescriptionLabel";
            this.lowestDescriptionLabel.Size = new System.Drawing.Size(83, 13);
            this.lowestDescriptionLabel.TabIndex = 10;
            this.lowestDescriptionLabel.Text = "Lowest Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 217);
            this.Controls.Add(this.lowestDescriptionLabel);
            this.Controls.Add(this.lowestAmountLabel);
            this.Controls.Add(this.highestDescriptionLabel);
            this.Controls.Add(this.highestAmountLabel);
            this.Controls.Add(this.averageDescriptionLabel);
            this.Controls.Add(this.averageAmountLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.getSalesReportButton);
            this.Controls.Add(this.salesTotalDescriptionLabel);
            this.Controls.Add(this.totalSalesLabel);
            this.Controls.Add(this.salesListBox);
            this.Name = "Form1";
            this.Text = "Sales Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox salesListBox;
        private System.Windows.Forms.Label totalSalesLabel;
        private System.Windows.Forms.Label salesTotalDescriptionLabel;
        private System.Windows.Forms.Button getSalesReportButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Label averageAmountLabel;
        private System.Windows.Forms.Label averageDescriptionLabel;
        private System.Windows.Forms.Label highestAmountLabel;
        private System.Windows.Forms.Label highestDescriptionLabel;
        private System.Windows.Forms.Label lowestAmountLabel;
        private System.Windows.Forms.Label lowestDescriptionLabel;
    }
}

