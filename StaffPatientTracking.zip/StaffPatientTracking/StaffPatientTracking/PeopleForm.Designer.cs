﻿namespace StaffPatientTracking
{
    partial class PeopleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.peopleIDTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.staffCheckBox = new System.Windows.Forms.CheckBox();
            this.activatedDateTextBox = new System.Windows.Forms.TextBox();
            this.inactivatedTextBox = new System.Windows.Forms.TextBox();
            this.peopleIDLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.activatedDateLabel = new System.Windows.Forms.Label();
            this.inactivatedDateLabel = new System.Windows.Forms.Label();
            this.staffLabel = new System.Windows.Forms.Label();
            this.saveAndNewButton = new System.Windows.Forms.Button();
            this.saveAndCloseButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // peopleIDTextBox
            // 
            this.peopleIDTextBox.Location = new System.Drawing.Point(126, 16);
            this.peopleIDTextBox.Name = "peopleIDTextBox";
            this.peopleIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.peopleIDTextBox.TabIndex = 0;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(126, 42);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(174, 20);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(126, 68);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(174, 20);
            this.middleNameTextBox.TabIndex = 2;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(126, 94);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(174, 20);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // staffCheckBox
            // 
            this.staffCheckBox.AutoSize = true;
            this.staffCheckBox.Location = new System.Drawing.Point(126, 120);
            this.staffCheckBox.Name = "staffCheckBox";
            this.staffCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.staffCheckBox.Size = new System.Drawing.Size(15, 14);
            this.staffCheckBox.TabIndex = 4;
            this.staffCheckBox.UseVisualStyleBackColor = true;
            // 
            // activatedDateTextBox
            // 
            this.activatedDateTextBox.Location = new System.Drawing.Point(126, 140);
            this.activatedDateTextBox.Name = "activatedDateTextBox";
            this.activatedDateTextBox.Size = new System.Drawing.Size(100, 20);
            this.activatedDateTextBox.TabIndex = 5;
            // 
            // inactivatedTextBox
            // 
            this.inactivatedTextBox.Location = new System.Drawing.Point(126, 166);
            this.inactivatedTextBox.Name = "inactivatedTextBox";
            this.inactivatedTextBox.Size = new System.Drawing.Size(100, 20);
            this.inactivatedTextBox.TabIndex = 6;
            // 
            // peopleIDLabel
            // 
            this.peopleIDLabel.AutoSize = true;
            this.peopleIDLabel.Location = new System.Drawing.Point(63, 19);
            this.peopleIDLabel.Name = "peopleIDLabel";
            this.peopleIDLabel.Size = new System.Drawing.Size(57, 13);
            this.peopleIDLabel.TabIndex = 7;
            this.peopleIDLabel.Text = "Person ID:";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(60, 45);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 8;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(48, 71);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 9;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(59, 97);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 10;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // activatedDateLabel
            // 
            this.activatedDateLabel.AutoSize = true;
            this.activatedDateLabel.Location = new System.Drawing.Point(39, 143);
            this.activatedDateLabel.Name = "activatedDateLabel";
            this.activatedDateLabel.Size = new System.Drawing.Size(81, 13);
            this.activatedDateLabel.TabIndex = 11;
            this.activatedDateLabel.Text = "Activated Date:";
            // 
            // inactivatedDateLabel
            // 
            this.inactivatedDateLabel.AutoSize = true;
            this.inactivatedDateLabel.Location = new System.Drawing.Point(31, 169);
            this.inactivatedDateLabel.Name = "inactivatedDateLabel";
            this.inactivatedDateLabel.Size = new System.Drawing.Size(89, 13);
            this.inactivatedDateLabel.TabIndex = 12;
            this.inactivatedDateLabel.Text = "Inactivated Date:";
            // 
            // staffLabel
            // 
            this.staffLabel.AutoSize = true;
            this.staffLabel.Location = new System.Drawing.Point(88, 120);
            this.staffLabel.Name = "staffLabel";
            this.staffLabel.Size = new System.Drawing.Size(32, 13);
            this.staffLabel.TabIndex = 13;
            this.staffLabel.Text = "Staff:";
            // 
            // saveAndNewButton
            // 
            this.saveAndNewButton.Location = new System.Drawing.Point(34, 202);
            this.saveAndNewButton.Name = "saveAndNewButton";
            this.saveAndNewButton.Size = new System.Drawing.Size(84, 23);
            this.saveAndNewButton.TabIndex = 14;
            this.saveAndNewButton.Text = "Save && New";
            this.saveAndNewButton.UseVisualStyleBackColor = true;
            // 
            // saveAndCloseButton
            // 
            this.saveAndCloseButton.Location = new System.Drawing.Point(126, 202);
            this.saveAndCloseButton.Name = "saveAndCloseButton";
            this.saveAndCloseButton.Size = new System.Drawing.Size(84, 23);
            this.saveAndCloseButton.TabIndex = 15;
            this.saveAndCloseButton.Text = "Save && Close";
            this.saveAndCloseButton.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(216, 202);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(84, 23);
            this.cancelButton.TabIndex = 16;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // PeopleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 250);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveAndCloseButton);
            this.Controls.Add(this.saveAndNewButton);
            this.Controls.Add(this.staffLabel);
            this.Controls.Add(this.inactivatedDateLabel);
            this.Controls.Add(this.activatedDateLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.peopleIDLabel);
            this.Controls.Add(this.inactivatedTextBox);
            this.Controls.Add(this.activatedDateTextBox);
            this.Controls.Add(this.staffCheckBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.peopleIDTextBox);
            this.Name = "PeopleForm";
            this.Text = "People";
            this.Load += new System.EventHandler(this.PeopleForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox peopleIDTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.CheckBox staffCheckBox;
        private System.Windows.Forms.TextBox activatedDateTextBox;
        private System.Windows.Forms.TextBox inactivatedTextBox;
        private System.Windows.Forms.Label peopleIDLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label activatedDateLabel;
        private System.Windows.Forms.Label inactivatedDateLabel;
        private System.Windows.Forms.Label staffLabel;
        private System.Windows.Forms.Button saveAndNewButton;
        private System.Windows.Forms.Button saveAndCloseButton;
        private System.Windows.Forms.Button cancelButton;
    }
}