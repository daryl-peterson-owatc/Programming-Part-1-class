﻿namespace StaffPatientTracking
{
    partial class PeopleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.peopleIDTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.staffCheckBox = new System.Windows.Forms.CheckBox();
            this.activatedDateTextBox = new System.Windows.Forms.TextBox();
            this.inactivatedDateTextBox = new System.Windows.Forms.TextBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.activatedDateLabel = new System.Windows.Forms.Label();
            this.inactivatedDateLabel = new System.Windows.Forms.Label();
            this.staffLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.addProgramButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.programsGroupBox = new System.Windows.Forms.GroupBox();
            this.nameLookupComboBox = new System.Windows.Forms.ComboBox();
            this.nameLookupLabel = new System.Windows.Forms.Label();
            this.addPersonButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.programsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // peopleIDTextBox
            // 
            this.peopleIDTextBox.Location = new System.Drawing.Point(126, 237);
            this.peopleIDTextBox.Name = "peopleIDTextBox";
            this.peopleIDTextBox.ReadOnly = true;
            this.peopleIDTextBox.Size = new System.Drawing.Size(225, 20);
            this.peopleIDTextBox.TabIndex = 0;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(126, 51);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(225, 20);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(126, 77);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(225, 20);
            this.middleNameTextBox.TabIndex = 2;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(126, 103);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(225, 20);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // staffCheckBox
            // 
            this.staffCheckBox.AutoSize = true;
            this.staffCheckBox.Location = new System.Drawing.Point(126, 129);
            this.staffCheckBox.Name = "staffCheckBox";
            this.staffCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.staffCheckBox.Size = new System.Drawing.Size(15, 14);
            this.staffCheckBox.TabIndex = 4;
            this.staffCheckBox.UseVisualStyleBackColor = true;
            // 
            // activatedDateTextBox
            // 
            this.activatedDateTextBox.Location = new System.Drawing.Point(126, 149);
            this.activatedDateTextBox.Name = "activatedDateTextBox";
            this.activatedDateTextBox.Size = new System.Drawing.Size(100, 20);
            this.activatedDateTextBox.TabIndex = 5;
            // 
            // inactivatedDateTextBox
            // 
            this.inactivatedDateTextBox.Location = new System.Drawing.Point(126, 175);
            this.inactivatedDateTextBox.Name = "inactivatedDateTextBox";
            this.inactivatedDateTextBox.Size = new System.Drawing.Size(100, 20);
            this.inactivatedDateTextBox.TabIndex = 6;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(60, 54);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 8;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(48, 80);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 9;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(59, 106);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 10;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // activatedDateLabel
            // 
            this.activatedDateLabel.AutoSize = true;
            this.activatedDateLabel.Location = new System.Drawing.Point(39, 152);
            this.activatedDateLabel.Name = "activatedDateLabel";
            this.activatedDateLabel.Size = new System.Drawing.Size(81, 13);
            this.activatedDateLabel.TabIndex = 11;
            this.activatedDateLabel.Text = "Activated Date:";
            // 
            // inactivatedDateLabel
            // 
            this.inactivatedDateLabel.AutoSize = true;
            this.inactivatedDateLabel.Location = new System.Drawing.Point(31, 178);
            this.inactivatedDateLabel.Name = "inactivatedDateLabel";
            this.inactivatedDateLabel.Size = new System.Drawing.Size(89, 13);
            this.inactivatedDateLabel.TabIndex = 12;
            this.inactivatedDateLabel.Text = "Inactivated Date:";
            // 
            // staffLabel
            // 
            this.staffLabel.AutoSize = true;
            this.staffLabel.Location = new System.Drawing.Point(88, 129);
            this.staffLabel.Name = "staffLabel";
            this.staffLabel.Size = new System.Drawing.Size(32, 13);
            this.staffLabel.TabIndex = 13;
            this.staffLabel.Text = "Staff:";
            // 
            // saveButton
            // 
            this.saveButton.Enabled = false;
            this.saveButton.Location = new System.Drawing.Point(126, 208);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(84, 23);
            this.saveButton.TabIndex = 14;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // addProgramButton
            // 
            this.addProgramButton.Location = new System.Drawing.Point(172, 19);
            this.addProgramButton.Name = "addProgramButton";
            this.addProgramButton.Size = new System.Drawing.Size(88, 23);
            this.addProgramButton.TabIndex = 15;
            this.addProgramButton.Text = "Add Program";
            this.addProgramButton.UseVisualStyleBackColor = true;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(563, 291);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(88, 23);
            this.closeButton.TabIndex = 16;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // programsGroupBox
            // 
            this.programsGroupBox.Controls.Add(this.addProgramButton);
            this.programsGroupBox.Location = new System.Drawing.Point(385, 51);
            this.programsGroupBox.Name = "programsGroupBox";
            this.programsGroupBox.Size = new System.Drawing.Size(266, 220);
            this.programsGroupBox.TabIndex = 17;
            this.programsGroupBox.TabStop = false;
            this.programsGroupBox.Text = "Action Programs";
            // 
            // nameLookupComboBox
            // 
            this.nameLookupComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.nameLookupComboBox.FormattingEnabled = true;
            this.nameLookupComboBox.Location = new System.Drawing.Point(126, 13);
            this.nameLookupComboBox.Name = "nameLookupComboBox";
            this.nameLookupComboBox.Size = new System.Drawing.Size(225, 21);
            this.nameLookupComboBox.TabIndex = 18;
            this.nameLookupComboBox.SelectedIndexChanged += new System.EventHandler(this.nameLookupComboBox_SelectedIndexChanged);
            // 
            // nameLookupLabel
            // 
            this.nameLookupLabel.AutoSize = true;
            this.nameLookupLabel.Location = new System.Drawing.Point(43, 16);
            this.nameLookupLabel.Name = "nameLookupLabel";
            this.nameLookupLabel.Size = new System.Drawing.Size(77, 13);
            this.nameLookupLabel.TabIndex = 19;
            this.nameLookupLabel.Text = "Name Lookup:";
            // 
            // addPersonButton
            // 
            this.addPersonButton.Location = new System.Drawing.Point(385, 11);
            this.addPersonButton.Name = "addPersonButton";
            this.addPersonButton.Size = new System.Drawing.Size(75, 23);
            this.addPersonButton.TabIndex = 20;
            this.addPersonButton.Text = "Add Person";
            this.addPersonButton.UseVisualStyleBackColor = true;
            this.addPersonButton.Click += new System.EventHandler(this.addPersonButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(126, 208);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(84, 23);
            this.updateButton.TabIndex = 21;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(267, 208);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(84, 23);
            this.deleteButton.TabIndex = 22;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            // 
            // PeopleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 326);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.addPersonButton);
            this.Controls.Add(this.nameLookupLabel);
            this.Controls.Add(this.nameLookupComboBox);
            this.Controls.Add(this.programsGroupBox);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.staffLabel);
            this.Controls.Add(this.inactivatedDateLabel);
            this.Controls.Add(this.activatedDateLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.inactivatedDateTextBox);
            this.Controls.Add(this.activatedDateTextBox);
            this.Controls.Add(this.staffCheckBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.peopleIDTextBox);
            this.Name = "PeopleForm";
            this.Text = "New Person";
            this.Load += new System.EventHandler(this.PeopleForm_Load);
            this.programsGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox peopleIDTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.CheckBox staffCheckBox;
        private System.Windows.Forms.TextBox activatedDateTextBox;
        private System.Windows.Forms.TextBox inactivatedDateTextBox;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label activatedDateLabel;
        private System.Windows.Forms.Label inactivatedDateLabel;
        private System.Windows.Forms.Label staffLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button addProgramButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.GroupBox programsGroupBox;
        private System.Windows.Forms.ComboBox nameLookupComboBox;
        private System.Windows.Forms.Label nameLookupLabel;
        private System.Windows.Forms.Button addPersonButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button deleteButton;
    }
}