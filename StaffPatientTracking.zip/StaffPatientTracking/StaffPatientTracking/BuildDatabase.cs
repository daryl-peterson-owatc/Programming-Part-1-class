﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using StaffPatientTracking.Data.Contract;

namespace StaffPatientTracking
{
    class BuildDatabase
    {

        public void BuildTables()
        {
            string createSQL =
                "CREATE TABLE " + ActionCodesTbl.Name + "(" +
                ActionCodesTbl.Cols.ActionCodeID + " UNIQUEIDENTIFIER PRIMARY KEY, " +
                ActionCodesTbl.Cols.Code + " TEXT NOT NULL, " +
                ActionCodesTbl.Cols.Description + " TEXT NOT NULL, " +
                ActionCodesTbl.Cols.ExpirationMonths + " INTEGER NOT NULL);";


            createSQL =
                "CREATE TABLE " + ExpirationsTbl.Name + "(" +
                ExpirationsTbl.Cols.ExpirationID + " UNIQUEIDENTIFIER PRIMARY KEY, " +
                ExpirationsTbl.Cols.PersonID + " TEXT NOT NULL, " +
                ExpirationsTbl.Cols.ActionCodeID + " TEXT NOT NULL, " +
                ExpirationsTbl.Cols.DateUpdated + " DATETIME NULL, " +
                ExpirationsTbl.Cols.DateExpires + " DATETIME NULL);";


            createSQL =
                "CREATE TABEL " + PeopleTbl.Name + "(" +
                PeopleTbl.Cols.PersonID + "  UNIQUEIDENTIFIER PRIMARY KEY, " +
                PeopleTbl.Cols.FirstName + " TEXT NOT NULL, " +
                PeopleTbl.Cols.MiddleName + " TEXT NULL, " +
                PeopleTbl.Cols.LastName + " TEXT NULL, " +
                PeopleTbl.Cols.ActiveDate + " DATETIME NOT NULL, " +
                PeopleTbl.Cols.InactiveDate + " DATETIME NULL);";
        }
    }
}
