﻿using StaffPatientTracking.Data;
using StaffPatientTracking.Data.Contract;
using System;

namespace StaffPatientTracking
{
    class BuildDatabase
    {
        private readonly Database db;

        public BuildDatabase(Database db)
        {
            this.db = db;
        }

        public void BuildTables()
        {
            db.InTransaction<Object>(cmd =>
            {
                string createSQL =
                    "CREATE TABLE " + ActionCodesTbl.Name + "(" +
                    ActionCodesTbl.Cols.ActionCodeID + " UNIQUEIDENTIFIER PRIMARY KEY, " +
                    ActionCodesTbl.Cols.Code + " TEXT NOT NULL, " +
                    ActionCodesTbl.Cols.Description + " TEXT NOT NULL, " +
                    ActionCodesTbl.Cols.ExpirationMonths + " INTEGER NOT NULL);" +

                    "CREATE TABLE " + ExpirationsTbl.Name + "(" +
                    ExpirationsTbl.Cols.ExpirationID + " UNIQUEIDENTIFIER PRIMARY KEY, " +
                    ExpirationsTbl.Cols.PersonID + " TEXT NOT NULL, " +
                    ExpirationsTbl.Cols.ActionCodeID + " TEXT NOT NULL, " +
                    ExpirationsTbl.Cols.DateUpdated + " DATETIME NULL, " +
                    ExpirationsTbl.Cols.DateExpires + " DATETIME NULL);" +

                    "CREATE TABLE " + PeopleTbl.Name + "(" +
                    PeopleTbl.Cols.PersonID + "  UNIQUEIDENTIFIER PRIMARY KEY, " +
                    PeopleTbl.Cols.FirstName + " TEXT NOT NULL, " +
                    PeopleTbl.Cols.MiddleName + " TEXT NULL, " +
                    PeopleTbl.Cols.LastName + " TEXT NULL, " +
                    PeopleTbl.Cols.ActiveDate + " DATETIME NOT NULL, " +
                    PeopleTbl.Cols.InactiveDate + " DATETIME NULL);";

                cmd.CommandText = createSQL;
                cmd.ExecuteNonQuery();
                return null;
            });

        }
    }
}
