﻿namespace StaffPatientTracking
{
    partial class ExpirationLookupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lookupMonthComboBox = new System.Windows.Forms.ComboBox();
            this.lookupYearComboBox = new System.Windows.Forms.ComboBox();
            this.lookupStaffCheckBox = new System.Windows.Forms.CheckBox();
            this.lookupMonthLabel = new System.Windows.Forms.Label();
            this.lookupYearLabel = new System.Windows.Forms.Label();
            this.lookupsGroupBox = new System.Windows.Forms.GroupBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.lookupFoundListBox = new System.Windows.Forms.ListBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.lookupsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // lookupMonthComboBox
            // 
            this.lookupMonthComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lookupMonthComboBox.FormattingEnabled = true;
            this.lookupMonthComboBox.Location = new System.Drawing.Point(62, 19);
            this.lookupMonthComboBox.Name = "lookupMonthComboBox";
            this.lookupMonthComboBox.Size = new System.Drawing.Size(121, 21);
            this.lookupMonthComboBox.TabIndex = 0;
            // 
            // lookupYearComboBox
            // 
            this.lookupYearComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lookupYearComboBox.FormattingEnabled = true;
            this.lookupYearComboBox.Location = new System.Drawing.Point(248, 19);
            this.lookupYearComboBox.Name = "lookupYearComboBox";
            this.lookupYearComboBox.Size = new System.Drawing.Size(121, 21);
            this.lookupYearComboBox.TabIndex = 1;
            // 
            // lookupStaffCheckBox
            // 
            this.lookupStaffCheckBox.AutoSize = true;
            this.lookupStaffCheckBox.Location = new System.Drawing.Point(400, 21);
            this.lookupStaffCheckBox.Name = "lookupStaffCheckBox";
            this.lookupStaffCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lookupStaffCheckBox.Size = new System.Drawing.Size(51, 17);
            this.lookupStaffCheckBox.TabIndex = 2;
            this.lookupStaffCheckBox.Text = ":Staff";
            this.lookupStaffCheckBox.UseVisualStyleBackColor = true;
            // 
            // lookupMonthLabel
            // 
            this.lookupMonthLabel.AutoSize = true;
            this.lookupMonthLabel.Location = new System.Drawing.Point(16, 22);
            this.lookupMonthLabel.Name = "lookupMonthLabel";
            this.lookupMonthLabel.Size = new System.Drawing.Size(40, 13);
            this.lookupMonthLabel.TabIndex = 3;
            this.lookupMonthLabel.Text = "Month:";
            // 
            // lookupYearLabel
            // 
            this.lookupYearLabel.AutoSize = true;
            this.lookupYearLabel.Location = new System.Drawing.Point(210, 22);
            this.lookupYearLabel.Name = "lookupYearLabel";
            this.lookupYearLabel.Size = new System.Drawing.Size(32, 13);
            this.lookupYearLabel.TabIndex = 4;
            this.lookupYearLabel.Text = "Year:";
            // 
            // lookupsGroupBox
            // 
            this.lookupsGroupBox.Controls.Add(this.searchButton);
            this.lookupsGroupBox.Controls.Add(this.lookupYearComboBox);
            this.lookupsGroupBox.Controls.Add(this.lookupYearLabel);
            this.lookupsGroupBox.Controls.Add(this.lookupMonthComboBox);
            this.lookupsGroupBox.Controls.Add(this.lookupMonthLabel);
            this.lookupsGroupBox.Controls.Add(this.lookupStaffCheckBox);
            this.lookupsGroupBox.Location = new System.Drawing.Point(19, 20);
            this.lookupsGroupBox.Name = "lookupsGroupBox";
            this.lookupsGroupBox.Size = new System.Drawing.Size(478, 95);
            this.lookupsGroupBox.TabIndex = 5;
            this.lookupsGroupBox.TabStop = false;
            this.lookupsGroupBox.Text = "Lookup Parameters";
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(62, 56);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(75, 23);
            this.searchButton.TabIndex = 5;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            // 
            // lookupFoundListBox
            // 
            this.lookupFoundListBox.FormattingEnabled = true;
            this.lookupFoundListBox.Location = new System.Drawing.Point(21, 128);
            this.lookupFoundListBox.Name = "lookupFoundListBox";
            this.lookupFoundListBox.Size = new System.Drawing.Size(475, 186);
            this.lookupFoundListBox.TabIndex = 6;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(422, 331);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 7;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // ExpirationLookupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 370);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.lookupFoundListBox);
            this.Controls.Add(this.lookupsGroupBox);
            this.Name = "ExpirationLookupForm";
            this.Text = "Expiration Lookups";
            this.Load += new System.EventHandler(this.ExpirationLookupForm_Load);
            this.lookupsGroupBox.ResumeLayout(false);
            this.lookupsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox lookupMonthComboBox;
        private System.Windows.Forms.ComboBox lookupYearComboBox;
        private System.Windows.Forms.CheckBox lookupStaffCheckBox;
        private System.Windows.Forms.Label lookupMonthLabel;
        private System.Windows.Forms.Label lookupYearLabel;
        private System.Windows.Forms.GroupBox lookupsGroupBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.ListBox lookupFoundListBox;
        private System.Windows.Forms.Button closeButton;
    }
}