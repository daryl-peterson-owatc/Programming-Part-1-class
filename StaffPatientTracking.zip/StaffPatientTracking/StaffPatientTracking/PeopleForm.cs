﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class PeopleForm : Form
    {
        private readonly DatabaseManager dm;
        public Person pe;
        public List<Person> personList;

        public PeopleForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
        }

        private void PeopleForm_Load(object sender, EventArgs e)
        {
            clearPeopleFormFields();
        }

        private void loadPeopleList()
        {
            personList = dm.DAO.People.GetPeopleList();
            nameLookupComboBox.Items.Clear();
            foreach (var person in personList)
            {
                nameLookupComboBox.Items.Add(person);
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addPersonButton_Click(object sender, EventArgs e)
        {
            clearPeopleFormFields();
            peopleIDTextBox.Text = Guid.NewGuid().ToString();
            saveButton.Visible = true;
        }

        private void populateModel()
        {
            pe = new Person();
            pe.PersonID = Guid.Parse(peopleIDTextBox.Text);
            pe.FirstName = firstNameTextBox.Text;
            pe.MiddleName = !(string.IsNullOrEmpty(middleNameTextBox.Text)) ? middleNameTextBox.Text : null;
            pe.LastName = lastNameTextBox.Text;
            pe.Staff = (staffCheckBox.Checked) ? true : false;
            pe.ActiveDate = DateTime.Parse(activatedDateTextBox.Text);
        }

        private void clearPeopleFormFields()
        {
            peopleIDTextBox.Text = "";
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            staffCheckBox.Checked = false;
            activatedDateTextBox.Text = "";
            inactivatedDateTextBox.Text = "";
            saveButton.Visible = false;
            updateButton.Visible = false;
            deleteButton.Visible = false;
        }

        private void nameLookupComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // get the person from the combo box
            updateButton.Visible = true;
            deleteButton.Visible = true;
        }
    }
}
