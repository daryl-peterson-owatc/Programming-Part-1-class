﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class PeopleForm : Form
    {
        private readonly DatabaseManager dm;
        public List<Person> personList;

        public PeopleForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
        }

        private void PeopleForm_Load(object sender, EventArgs e)
        {
            
        }

        private void loadPeopleList()
        {

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addPersonButton_Click(object sender, EventArgs e)
        {

        }
    }
}
