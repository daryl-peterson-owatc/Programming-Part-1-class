﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffPatientTracking
{
    public partial class ExpirationLookupForm : Form
    {
        public ExpirationLookupForm()
        {
            InitializeComponent();
        }

        private void ExpirationLookupForm_Load(object sender, EventArgs e)
        {
            string currentDate = DateTime.Now.ToString("MM-dd-yyyy");
            var parsedDate = currentDate.Split('-');
            string month = parsedDate[0];
            string year = parsedDate[2];

            // load the month combobox and select the current month
            getMonthsList();
            lookupMonthComboBox.Text = month;

            // load the year combobox and select the current year
            // only add 5 years from the current year
            getYearList(year);
            lookupYearComboBox.Text = year;
        }

        private void getMonthsList()
        {
            for (int i = 1; i < 13; i++)
            {
                lookupMonthComboBox.Items.Add(i.ToString());
            }
        }

        private void getYearList(string year)
        {
            int numYear = Int32.Parse(year);
            for (int i = 0; i < 6; i++)
            {
                lookupYearComboBox.Items.Add((numYear + i).ToString());
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
