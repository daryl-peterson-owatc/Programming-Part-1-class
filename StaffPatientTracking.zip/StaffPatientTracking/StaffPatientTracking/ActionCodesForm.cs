﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffPatientTracking
{
    public partial class ActionCodesForm : Form
    {
        public Models.ActionCode ac;

        public ActionCodesForm()
        {
            InitializeComponent();
        }

        private void saveAndNewButton_Click(object sender, EventArgs e)
        {
            processSave();
            clearForm();
        }

        private void saveAndCloseButton_Click(object sender, EventArgs e)
        {
            processSave();
            this.Close();
        }

        private void processSave()
        {
            populateModel();
            Data.ActionCodesDAO.InsertActionCode(ac);
        }

        private void populateModel()
        {
            ac = new Models.ActionCode();
            ac.ActionCodeID = (Guid)actionCodeIDTextBox.Text;
            ac.Code = codeTextBox.Text;
            ac.Description = descriptionTextBox.Text;
            ac.ExpirationMonths = Convert.ToInt32(expirationMonthsTextBox.Text);
        }

        private void clearForm()
        {
            actionCodeIDTextBox.Text = "";
            codeTextBox.Text = "";
            descriptionTextBox.Text = "";
            expirationMonthsTextBox.Text = "";
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
