﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class ActionCodesForm : Form
    {
        private readonly DatabaseManager dm;

        public ActionCode ac;

        public ActionCodesForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
            loadActionCodesList();
        }

        private void loadActionCodesList()
        {
            var codesList = dm.DAO.ActionCodes.GetActionCodesList();
            lookupCodeComboBox.Items.Clear();
            lookupCodeComboBox.Items.AddRange(codesList.ToArray());
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            processSave();
            clearForm();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            processSave();
            this.Close();
        }

        private void processSave()
        {
            populateModel();
            
        }

        private void populateModel()
        {
            ac = new ActionCode();
            ac.ActionCodeID = Guid.Parse(actionCodeIDTextBox.Text);
            ac.Code = codeTextBox.Text;
            ac.Description = descriptionTextBox.Text;
            ac.ExpirationMonths = Convert.ToInt32(expirationMonthsTextBox.Text);
        }

        private void clearForm()
        {
            actionCodeIDTextBox.Text = "";
            codeTextBox.Text = "";
            descriptionTextBox.Text = "";
            expirationMonthsTextBox.Text = "";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
