﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class ActionCodesForm : Form
    {
        private readonly DatabaseManager dm;
        public ActionCode ac;
        public List<ActionCode> codesList;

        public ActionCodesForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
            loadActionCodesList();
        }

        private void loadActionCodesList()
        {
            codesList = dm.DAO.ActionCodes.GetActionCodesList();
            lookupCodeComboBox.Items.Clear();
            foreach (var code in codesList)
            {
                lookupCodeComboBox.Items.Add(code.Code);
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            populateModel();
            dm.DAO.ActionCodes.InsertActionCode(ac);
            setupForm();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            populateModel();
            dm.DAO.ActionCodes.UpdateActionCode(ac);
            setupForm();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            populateModel();
            dm.DAO.ActionCodes.DeleteActionCode(ac);
            setupForm();
        }

        private void addNewButton_Click(object sender, EventArgs e)
        {
            actionCodeIDTextBox.Text = Guid.NewGuid().ToString();
            updateButton.Visible = false;
            updateButton.Enabled = false;
            saveButton.Visible = true;
            saveButton.Enabled = true;
            codeTextBox.Focus();
        }

        private void populateModel()
        {
            ac = new ActionCode();
            ac.ActionCodeID = Guid.Parse(actionCodeIDTextBox.Text);
            ac.Code = codeTextBox.Text;
            ac.Description = descriptionTextBox.Text;
            ac.ExpirationMonths = Convert.ToInt32(expirationMonthsTextBox.Text);
        }

        private void setupForm()
        {
            setButtonDefaults();
            clearForm();
            loadActionCodesList();
        }

        private void clearForm()
        {
            actionCodeIDTextBox.Text = "";
            codeTextBox.Text = "";
            descriptionTextBox.Text = "";
            expirationMonthsTextBox.Text = "";
        }

        private void setButtonDefaults()
        {
            updateButton.Visible = true;
            saveButton.Visible = false;
            saveButton.Enabled = false;
            deleteButton.Enabled = false;
            deleteButton.Visible = false;
        }

        private void lookupCodeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lookupCodeComboBox.SelectedIndex;
            populateFields(i);
            updateButton.Enabled = true;
            updateButton.Visible = true;
            deleteButton.Enabled = true;
            deleteButton.Visible = true;
        }

        private void populateFields(int i)
        {
            actionCodeIDTextBox.Text = codesList[i].ActionCodeID.ToString();
            codeTextBox.Text = codesList[i].Code;
            descriptionTextBox.Text = codesList[i].Description;
            expirationMonthsTextBox.Text = codesList[i].ExpirationMonths.ToString();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
