﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;

namespace StaffPatientTracking
{
    public partial class ActionCodesForm : Form
    {
        public ActionCode ac;

        public ActionCodesForm()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            processSave();
            clearForm();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            processSave();
            this.Close();
        }

        private void processSave()
        {
            populateModel();
            
        }

        private void populateModel()
        {
            ac = new ActionCode();
            ac.ActionCodeID = Guid.Parse(actionCodeIDTextBox.Text);
            ac.Code = codeTextBox.Text;
            ac.Description = descriptionTextBox.Text;
            ac.ExpirationMonths = Convert.ToInt32(expirationMonthsTextBox.Text);
        }

        private void clearForm()
        {
            actionCodeIDTextBox.Text = "";
            codeTextBox.Text = "";
            descriptionTextBox.Text = "";
            expirationMonthsTextBox.Text = "";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
