﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Models;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class ActionCodesForm : Form
    {
        private readonly DatabaseManager dm;

        public ActionCode ac;

        public ActionCodesForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
            loadActionCodesList();
        }

        private void loadActionCodesList()
        {
            var codesList = dm.DAO.ActionCodes.GetActionCodesList();
            lookupCodeComboBox.Items.Clear();
            MessageBox.Show(codesList.ToArray().ToString());
            lookupCodeComboBox.Items.AddRange(codesList.ToArray());
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            processSave();
            clearForm();
            loadActionCodesList();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            processSave();
            this.Close();
        }

        private void processSave()
        {
            populateModel();
            //MessageBox.Show(ac.Code);
            dm.DAO.ActionCodes.InsertActionCode(ac);
        }

        private void populateModel()
        {
            ac = new ActionCode();
            ac.ActionCodeID = Guid.Parse(actionCodeIDTextBox.Text);
            ac.Code = codeTextBox.Text;
            ac.Description = descriptionTextBox.Text;
            ac.ExpirationMonths = Convert.ToInt32(expirationMonthsTextBox.Text);
        }

        private void clearForm()
        {
            actionCodeIDTextBox.Text = "";
            codeTextBox.Text = "";
            descriptionTextBox.Text = "";
            expirationMonthsTextBox.Text = "";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addNewButton_Click(object sender, EventArgs e)
        {
            actionCodeIDTextBox.Text = dm.GetGuid().ToString();
            codeTextBox.Focus();
        }
    }
}
