﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            DatabaseManager dm = new DatabaseManager();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            CheckForDatabase(dm);
            Application.Run(new MainForm(dm));
        }

        public static void ConnectToDatabase()
        {

        }

        public static bool CheckForDatabase(DatabaseManager dm)
        {
            bool doesExist = false;
            string systemDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string companyDirectory = "\\RedCastleSoftware\\StaffPatientTracking\\DataFiles";
            string completePath = systemDirectory + companyDirectory;
            
            string databaseName = "\\SPTracking.db";
            string pathAndFileName = completePath + databaseName;
            System.IO.Directory.CreateDirectory(completePath);
            dm.CreateNewDatabase(pathAndFileName);
            //MessageBox.Show(completePath);

            return doesExist;
        }
    }
}
