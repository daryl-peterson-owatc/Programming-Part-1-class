﻿namespace StaffPatientTracking
{
    partial class ActionCodesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.actionCodeIDTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.expirationMonthsTextBox = new System.Windows.Forms.TextBox();
            this.actionCodeIDLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.expirationMonthsLabel = new System.Windows.Forms.Label();
            this.saveAndCloseButton = new System.Windows.Forms.Button();
            this.saveAndNewButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.codeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // actionCodeIDTextBox
            // 
            this.actionCodeIDTextBox.Location = new System.Drawing.Point(103, 26);
            this.actionCodeIDTextBox.Name = "actionCodeIDTextBox";
            this.actionCodeIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.actionCodeIDTextBox.TabIndex = 0;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(103, 79);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(187, 20);
            this.descriptionTextBox.TabIndex = 1;
            // 
            // expirationMonthsTextBox
            // 
            this.expirationMonthsTextBox.Location = new System.Drawing.Point(103, 105);
            this.expirationMonthsTextBox.Name = "expirationMonthsTextBox";
            this.expirationMonthsTextBox.Size = new System.Drawing.Size(47, 20);
            this.expirationMonthsTextBox.TabIndex = 2;
            // 
            // actionCodeIDLabel
            // 
            this.actionCodeIDLabel.AutoSize = true;
            this.actionCodeIDLabel.Location = new System.Drawing.Point(15, 29);
            this.actionCodeIDLabel.Name = "actionCodeIDLabel";
            this.actionCodeIDLabel.Size = new System.Drawing.Size(82, 13);
            this.actionCodeIDLabel.TabIndex = 3;
            this.actionCodeIDLabel.Text = "Action Code ID:";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(34, 82);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(63, 13);
            this.descriptionLabel.TabIndex = 4;
            this.descriptionLabel.Text = "Description:";
            // 
            // expirationMonthsLabel
            // 
            this.expirationMonthsLabel.AutoSize = true;
            this.expirationMonthsLabel.Location = new System.Drawing.Point(3, 108);
            this.expirationMonthsLabel.Name = "expirationMonthsLabel";
            this.expirationMonthsLabel.Size = new System.Drawing.Size(94, 13);
            this.expirationMonthsLabel.TabIndex = 5;
            this.expirationMonthsLabel.Text = "Expiration Months:";
            // 
            // saveAndCloseButton
            // 
            this.saveAndCloseButton.Location = new System.Drawing.Point(107, 135);
            this.saveAndCloseButton.Name = "saveAndCloseButton";
            this.saveAndCloseButton.Size = new System.Drawing.Size(82, 23);
            this.saveAndCloseButton.TabIndex = 6;
            this.saveAndCloseButton.Text = "Save && Close";
            this.saveAndCloseButton.UseVisualStyleBackColor = true;
            // 
            // saveAndNewButton
            // 
            this.saveAndNewButton.Location = new System.Drawing.Point(19, 135);
            this.saveAndNewButton.Name = "saveAndNewButton";
            this.saveAndNewButton.Size = new System.Drawing.Size(82, 23);
            this.saveAndNewButton.TabIndex = 7;
            this.saveAndNewButton.Text = "Save && New";
            this.saveAndNewButton.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(195, 135);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(82, 23);
            this.cancelButton.TabIndex = 8;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(103, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(99, 20);
            this.textBox1.TabIndex = 9;
            // 
            // codeLabel
            // 
            this.codeLabel.AutoSize = true;
            this.codeLabel.Location = new System.Drawing.Point(62, 56);
            this.codeLabel.Name = "codeLabel";
            this.codeLabel.Size = new System.Drawing.Size(35, 13);
            this.codeLabel.TabIndex = 10;
            this.codeLabel.Text = "Code:";
            // 
            // ActionCodesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 182);
            this.Controls.Add(this.codeLabel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveAndNewButton);
            this.Controls.Add(this.saveAndCloseButton);
            this.Controls.Add(this.expirationMonthsLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.actionCodeIDLabel);
            this.Controls.Add(this.expirationMonthsTextBox);
            this.Controls.Add(this.descriptionTextBox);
            this.Controls.Add(this.actionCodeIDTextBox);
            this.Name = "ActionCodesForm";
            this.Text = "Action Codes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox actionCodeIDTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox expirationMonthsTextBox;
        private System.Windows.Forms.Label actionCodeIDLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label expirationMonthsLabel;
        private System.Windows.Forms.Button saveAndCloseButton;
        private System.Windows.Forms.Button saveAndNewButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label codeLabel;
    }
}