﻿namespace StaffPatientTracking
{
    partial class ActionCodesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.expirationMonthsTextBox = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.expirationMonthsLabel = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.codeTextBox = new System.Windows.Forms.TextBox();
            this.codeLabel = new System.Windows.Forms.Label();
            this.lookupCodeComboBox = new System.Windows.Forms.ComboBox();
            this.lookupCodeLabel = new System.Windows.Forms.Label();
            this.addNewButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.actionCodeIDTextBox = new System.Windows.Forms.TextBox();
            this.deleteButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(120, 68);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(187, 20);
            this.descriptionTextBox.TabIndex = 3;
            // 
            // expirationMonthsTextBox
            // 
            this.expirationMonthsTextBox.Location = new System.Drawing.Point(120, 94);
            this.expirationMonthsTextBox.Name = "expirationMonthsTextBox";
            this.expirationMonthsTextBox.Size = new System.Drawing.Size(47, 20);
            this.expirationMonthsTextBox.TabIndex = 4;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(51, 71);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(63, 13);
            this.descriptionLabel.TabIndex = 12;
            this.descriptionLabel.Text = "Description:";
            // 
            // expirationMonthsLabel
            // 
            this.expirationMonthsLabel.AutoSize = true;
            this.expirationMonthsLabel.Location = new System.Drawing.Point(20, 97);
            this.expirationMonthsLabel.Name = "expirationMonthsLabel";
            this.expirationMonthsLabel.Size = new System.Drawing.Size(94, 13);
            this.expirationMonthsLabel.TabIndex = 13;
            this.expirationMonthsLabel.Text = "Expiration Months:";
            // 
            // updateButton
            // 
            this.updateButton.Enabled = false;
            this.updateButton.Location = new System.Drawing.Point(256, 102);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(82, 23);
            this.updateButton.TabIndex = 6;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Enabled = false;
            this.saveButton.Location = new System.Drawing.Point(256, 102);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(82, 23);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Visible = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(272, 205);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(100, 23);
            this.closeButton.TabIndex = 7;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // codeTextBox
            // 
            this.codeTextBox.Location = new System.Drawing.Point(120, 42);
            this.codeTextBox.Name = "codeTextBox";
            this.codeTextBox.Size = new System.Drawing.Size(99, 20);
            this.codeTextBox.TabIndex = 2;
            // 
            // codeLabel
            // 
            this.codeLabel.AutoSize = true;
            this.codeLabel.Location = new System.Drawing.Point(79, 45);
            this.codeLabel.Name = "codeLabel";
            this.codeLabel.Size = new System.Drawing.Size(35, 13);
            this.codeLabel.TabIndex = 10;
            this.codeLabel.Text = "Code:";
            // 
            // lookupCodeComboBox
            // 
            this.lookupCodeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lookupCodeComboBox.FormattingEnabled = true;
            this.lookupCodeComboBox.Location = new System.Drawing.Point(154, 16);
            this.lookupCodeComboBox.Name = "lookupCodeComboBox";
            this.lookupCodeComboBox.Size = new System.Drawing.Size(186, 21);
            this.lookupCodeComboBox.TabIndex = 1;
            this.lookupCodeComboBox.SelectedIndexChanged += new System.EventHandler(this.lookupCodeComboBox_SelectedIndexChanged);
            // 
            // lookupCodeLabel
            // 
            this.lookupCodeLabel.AutoSize = true;
            this.lookupCodeLabel.Location = new System.Drawing.Point(66, 19);
            this.lookupCodeLabel.Name = "lookupCodeLabel";
            this.lookupCodeLabel.Size = new System.Drawing.Size(79, 13);
            this.lookupCodeLabel.TabIndex = 12;
            this.lookupCodeLabel.Text = "Lookup Codes:";
            // 
            // addNewButton
            // 
            this.addNewButton.Location = new System.Drawing.Point(11, 10);
            this.addNewButton.Name = "addNewButton";
            this.addNewButton.Size = new System.Drawing.Size(100, 23);
            this.addNewButton.TabIndex = 8;
            this.addNewButton.Text = "Create New Code";
            this.addNewButton.UseVisualStyleBackColor = true;
            this.addNewButton.Click += new System.EventHandler(this.addNewButton_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.deleteButton);
            this.panel1.Controls.Add(this.actionCodeIDTextBox);
            this.panel1.Controls.Add(this.addNewButton);
            this.panel1.Controls.Add(this.codeLabel);
            this.panel1.Controls.Add(this.codeTextBox);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.updateButton);
            this.panel1.Controls.Add(this.expirationMonthsLabel);
            this.panel1.Controls.Add(this.descriptionLabel);
            this.panel1.Controls.Add(this.expirationMonthsTextBox);
            this.panel1.Controls.Add(this.descriptionTextBox);
            this.panel1.Location = new System.Drawing.Point(33, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 138);
            this.panel1.TabIndex = 14;
            // 
            // actionCodeIDTextBox
            // 
            this.actionCodeIDTextBox.Location = new System.Drawing.Point(120, 12);
            this.actionCodeIDTextBox.Name = "actionCodeIDTextBox";
            this.actionCodeIDTextBox.Size = new System.Drawing.Size(218, 20);
            this.actionCodeIDTextBox.TabIndex = 11;
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(256, 10);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(82, 23);
            this.deleteButton.TabIndex = 14;
            this.deleteButton.Text = "Delete Code";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // ActionCodesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 240);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lookupCodeLabel);
            this.Controls.Add(this.lookupCodeComboBox);
            this.Controls.Add(this.closeButton);
            this.Name = "ActionCodesForm";
            this.Text = "Action Codes";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox expirationMonthsTextBox;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label expirationMonthsLabel;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.TextBox codeTextBox;
        private System.Windows.Forms.Label codeLabel;
        private System.Windows.Forms.ComboBox lookupCodeComboBox;
        private System.Windows.Forms.Label lookupCodeLabel;
        private System.Windows.Forms.Button addNewButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox actionCodeIDTextBox;
        private System.Windows.Forms.Button deleteButton;
    }
}