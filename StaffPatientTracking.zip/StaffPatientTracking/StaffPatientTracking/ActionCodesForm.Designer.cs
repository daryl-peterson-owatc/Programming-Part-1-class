﻿namespace StaffPatientTracking
{
    partial class ActionCodesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.expirationMonthsTextBox = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.expirationMonthsLabel = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.codeTextBox = new System.Windows.Forms.TextBox();
            this.codeLabel = new System.Windows.Forms.Label();
            this.lookupCodeComboBox = new System.Windows.Forms.ComboBox();
            this.lookupCodeLabel = new System.Windows.Forms.Label();
            this.addNewButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.actionCodeIDTextBox = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(120, 43);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(187, 20);
            this.descriptionTextBox.TabIndex = 1;
            // 
            // expirationMonthsTextBox
            // 
            this.expirationMonthsTextBox.Location = new System.Drawing.Point(120, 69);
            this.expirationMonthsTextBox.Name = "expirationMonthsTextBox";
            this.expirationMonthsTextBox.Size = new System.Drawing.Size(47, 20);
            this.expirationMonthsTextBox.TabIndex = 2;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(51, 46);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(63, 13);
            this.descriptionLabel.TabIndex = 4;
            this.descriptionLabel.Text = "Description:";
            // 
            // expirationMonthsLabel
            // 
            this.expirationMonthsLabel.AutoSize = true;
            this.expirationMonthsLabel.Location = new System.Drawing.Point(20, 72);
            this.expirationMonthsLabel.Name = "expirationMonthsLabel";
            this.expirationMonthsLabel.Size = new System.Drawing.Size(94, 13);
            this.expirationMonthsLabel.TabIndex = 5;
            this.expirationMonthsLabel.Text = "Expiration Months:";
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(126, 106);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(82, 23);
            this.updateButton.TabIndex = 6;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(38, 106);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(82, 23);
            this.saveButton.TabIndex = 7;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(214, 106);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(82, 23);
            this.closeButton.TabIndex = 8;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // codeTextBox
            // 
            this.codeTextBox.Location = new System.Drawing.Point(120, 17);
            this.codeTextBox.Name = "codeTextBox";
            this.codeTextBox.Size = new System.Drawing.Size(99, 20);
            this.codeTextBox.TabIndex = 9;
            // 
            // codeLabel
            // 
            this.codeLabel.AutoSize = true;
            this.codeLabel.Location = new System.Drawing.Point(79, 20);
            this.codeLabel.Name = "codeLabel";
            this.codeLabel.Size = new System.Drawing.Size(35, 13);
            this.codeLabel.TabIndex = 10;
            this.codeLabel.Text = "Code:";
            // 
            // lookupCodeComboBox
            // 
            this.lookupCodeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lookupCodeComboBox.FormattingEnabled = true;
            this.lookupCodeComboBox.Location = new System.Drawing.Point(104, 15);
            this.lookupCodeComboBox.Name = "lookupCodeComboBox";
            this.lookupCodeComboBox.Size = new System.Drawing.Size(186, 21);
            this.lookupCodeComboBox.TabIndex = 11;
            // 
            // lookupCodeLabel
            // 
            this.lookupCodeLabel.AutoSize = true;
            this.lookupCodeLabel.Location = new System.Drawing.Point(18, 18);
            this.lookupCodeLabel.Name = "lookupCodeLabel";
            this.lookupCodeLabel.Size = new System.Drawing.Size(79, 13);
            this.lookupCodeLabel.TabIndex = 12;
            this.lookupCodeLabel.Text = "Lookup Codes:";
            // 
            // addNewButton
            // 
            this.addNewButton.Location = new System.Drawing.Point(314, 13);
            this.addNewButton.Name = "addNewButton";
            this.addNewButton.Size = new System.Drawing.Size(75, 23);
            this.addNewButton.TabIndex = 13;
            this.addNewButton.Text = "Add Code";
            this.addNewButton.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.actionCodeIDTextBox);
            this.panel1.Controls.Add(this.codeLabel);
            this.panel1.Controls.Add(this.codeTextBox);
            this.panel1.Controls.Add(this.closeButton);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.updateButton);
            this.panel1.Controls.Add(this.expirationMonthsLabel);
            this.panel1.Controls.Add(this.descriptionLabel);
            this.panel1.Controls.Add(this.expirationMonthsTextBox);
            this.panel1.Controls.Add(this.descriptionTextBox);
            this.panel1.Location = new System.Drawing.Point(33, 54);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 145);
            this.panel1.TabIndex = 14;
            // 
            // actionCodeIDTextBox
            // 
            this.actionCodeIDTextBox.Location = new System.Drawing.Point(225, 17);
            this.actionCodeIDTextBox.Name = "actionCodeIDTextBox";
            this.actionCodeIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.actionCodeIDTextBox.TabIndex = 11;
            this.actionCodeIDTextBox.Visible = false;
            // 
            // ActionCodesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 222);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.addNewButton);
            this.Controls.Add(this.lookupCodeLabel);
            this.Controls.Add(this.lookupCodeComboBox);
            this.Name = "ActionCodesForm";
            this.Text = "Action Codes";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox expirationMonthsTextBox;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label expirationMonthsLabel;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.TextBox codeTextBox;
        private System.Windows.Forms.Label codeLabel;
        private System.Windows.Forms.ComboBox lookupCodeComboBox;
        private System.Windows.Forms.Label lookupCodeLabel;
        private System.Windows.Forms.Button addNewButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox actionCodeIDTextBox;
    }
}