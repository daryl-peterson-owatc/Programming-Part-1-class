﻿namespace StaffPatientTracking
{
    partial class AddProgramToPersonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.actionCodesComboBox = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.programLabel = new System.Windows.Forms.Label();
            this.startDateLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.expirationIDLabel = new System.Windows.Forms.Label();
            this.personIDLabel = new System.Windows.Forms.Label();
            this.actionCodeID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // actionCodesComboBox
            // 
            this.actionCodesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.actionCodesComboBox.FormattingEnabled = true;
            this.actionCodesComboBox.Location = new System.Drawing.Point(100, 52);
            this.actionCodesComboBox.Name = "actionCodesComboBox";
            this.actionCodesComboBox.Size = new System.Drawing.Size(198, 21);
            this.actionCodesComboBox.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(100, 79);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(47, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Persons Name label";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // programLabel
            // 
            this.programLabel.AutoSize = true;
            this.programLabel.Location = new System.Drawing.Point(12, 55);
            this.programLabel.Name = "programLabel";
            this.programLabel.Size = new System.Drawing.Size(82, 13);
            this.programLabel.TabIndex = 3;
            this.programLabel.Text = "Select Program:";
            // 
            // startDateLabel
            // 
            this.startDateLabel.AutoSize = true;
            this.startDateLabel.Location = new System.Drawing.Point(36, 82);
            this.startDateLabel.Name = "startDateLabel";
            this.startDateLabel.Size = new System.Drawing.Size(58, 13);
            this.startDateLabel.TabIndex = 4;
            this.startDateLabel.Text = "Start Date:";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(100, 105);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(223, 141);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 6;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            // 
            // expirationIDLabel
            // 
            this.expirationIDLabel.AutoSize = true;
            this.expirationIDLabel.Location = new System.Drawing.Point(15, 105);
            this.expirationIDLabel.Name = "expirationIDLabel";
            this.expirationIDLabel.Size = new System.Drawing.Size(63, 13);
            this.expirationIDLabel.TabIndex = 7;
            this.expirationIDLabel.Text = "expirationID";
            this.expirationIDLabel.Visible = false;
            // 
            // personIDLabel
            // 
            this.personIDLabel.AutoSize = true;
            this.personIDLabel.Location = new System.Drawing.Point(15, 118);
            this.personIDLabel.Name = "personIDLabel";
            this.personIDLabel.Size = new System.Drawing.Size(50, 13);
            this.personIDLabel.TabIndex = 8;
            this.personIDLabel.Text = "personID";
            this.personIDLabel.Visible = false;
            // 
            // actionCodeID
            // 
            this.actionCodeID.AutoSize = true;
            this.actionCodeID.Location = new System.Drawing.Point(15, 131);
            this.actionCodeID.Name = "actionCodeID";
            this.actionCodeID.Size = new System.Drawing.Size(72, 13);
            this.actionCodeID.TabIndex = 9;
            this.actionCodeID.Text = "actionCodeID";
            this.actionCodeID.Visible = false;
            // 
            // AddProgramToPersonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 179);
            this.Controls.Add(this.actionCodeID);
            this.Controls.Add(this.personIDLabel);
            this.Controls.Add(this.expirationIDLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.startDateLabel);
            this.Controls.Add(this.programLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.actionCodesComboBox);
            this.Name = "AddProgramToPersonForm";
            this.Text = "Add a Program";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox actionCodesComboBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label programLabel;
        private System.Windows.Forms.Label startDateLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label expirationIDLabel;
        private System.Windows.Forms.Label personIDLabel;
        private System.Windows.Forms.Label actionCodeID;
    }
}