﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffPatientTracking.Models
{
    public class Expiration
    {
        public Guid ExpirationID { get; set; }
        public Person Person { get; set; }
        public ActionCode ActionCode { get; set; }
        public DateTime DateUpdated { get; set; }
        public DateTime DateExpires { get; set; }
    }
}
