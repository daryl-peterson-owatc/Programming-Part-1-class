﻿namespace StaffPatientTracking
{
    partial class PersonUpdateActionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.actionDescriptionLabel = new System.Windows.Forms.Label();
            this.ExpirationDateTextBox = new System.Windows.Forms.TextBox();
            this.newExpirationDateTextBox = new System.Windows.Forms.TextBox();
            this.expirationDateLabel = new System.Windows.Forms.Label();
            this.newExpirationDateLabel = new System.Windows.Forms.Label();
            this.expirationMonthsLabel = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameLabel.Location = new System.Drawing.Point(13, 13);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(371, 23);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "full name goes here";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // actionDescriptionLabel
            // 
            this.actionDescriptionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.actionDescriptionLabel.Location = new System.Drawing.Point(12, 45);
            this.actionDescriptionLabel.Name = "actionDescriptionLabel";
            this.actionDescriptionLabel.Size = new System.Drawing.Size(372, 24);
            this.actionDescriptionLabel.TabIndex = 1;
            this.actionDescriptionLabel.Text = "action description goes here";
            this.actionDescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ExpirationDateTextBox
            // 
            this.ExpirationDateTextBox.Location = new System.Drawing.Point(53, 97);
            this.ExpirationDateTextBox.Name = "ExpirationDateTextBox";
            this.ExpirationDateTextBox.Size = new System.Drawing.Size(100, 20);
            this.ExpirationDateTextBox.TabIndex = 2;
            this.ExpirationDateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // newExpirationDateTextBox
            // 
            this.newExpirationDateTextBox.Location = new System.Drawing.Point(245, 97);
            this.newExpirationDateTextBox.Name = "newExpirationDateTextBox";
            this.newExpirationDateTextBox.Size = new System.Drawing.Size(100, 20);
            this.newExpirationDateTextBox.TabIndex = 3;
            this.newExpirationDateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // expirationDateLabel
            // 
            this.expirationDateLabel.AutoSize = true;
            this.expirationDateLabel.Location = new System.Drawing.Point(50, 81);
            this.expirationDateLabel.Name = "expirationDateLabel";
            this.expirationDateLabel.Size = new System.Drawing.Size(79, 13);
            this.expirationDateLabel.TabIndex = 4;
            this.expirationDateLabel.Text = "Expiration Date";
            // 
            // newExpirationDateLabel
            // 
            this.newExpirationDateLabel.AutoSize = true;
            this.newExpirationDateLabel.Location = new System.Drawing.Point(242, 81);
            this.newExpirationDateLabel.Name = "newExpirationDateLabel";
            this.newExpirationDateLabel.Size = new System.Drawing.Size(104, 13);
            this.newExpirationDateLabel.TabIndex = 5;
            this.newExpirationDateLabel.Text = "New Expiration Date";
            // 
            // expirationMonthsLabel
            // 
            this.expirationMonthsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.expirationMonthsLabel.Location = new System.Drawing.Point(159, 97);
            this.expirationMonthsLabel.Name = "expirationMonthsLabel";
            this.expirationMonthsLabel.Size = new System.Drawing.Size(80, 20);
            this.expirationMonthsLabel.TabIndex = 6;
            this.expirationMonthsLabel.Text = "Months: ";
            this.expirationMonthsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expirationMonthsLabel.Visible = false;
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(64, 141);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(75, 23);
            this.updateButton.TabIndex = 7;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(259, 141);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 8;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // PersonUpdateActionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 182);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.expirationMonthsLabel);
            this.Controls.Add(this.newExpirationDateLabel);
            this.Controls.Add(this.expirationDateLabel);
            this.Controls.Add(this.newExpirationDateTextBox);
            this.Controls.Add(this.ExpirationDateTextBox);
            this.Controls.Add(this.actionDescriptionLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "PersonUpdateActionForm";
            this.Text = "Person Update";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label actionDescriptionLabel;
        private System.Windows.Forms.TextBox ExpirationDateTextBox;
        private System.Windows.Forms.TextBox newExpirationDateTextBox;
        private System.Windows.Forms.Label expirationDateLabel;
        private System.Windows.Forms.Label newExpirationDateLabel;
        private System.Windows.Forms.Label expirationMonthsLabel;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button cancelButton;
    }
}