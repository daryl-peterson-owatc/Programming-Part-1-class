﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StaffPatientTracking.Data;

namespace StaffPatientTracking
{
    public partial class MainForm : Form
    {
        private readonly DatabaseManager dm;

        public MainForm(DatabaseManager dm)
        {
            InitializeComponent();
            this.dm = dm;
        }

        private void addModifyPeopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PeopleForm peopleForm = new PeopleForm();
            peopleForm.ShowDialog();
        }

        private void actionCodesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ActionCodesForm actionCodesForm = new ActionCodesForm(dm);
            actionCodesForm.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExpirationLookupForm expirationLookupForm = new ExpirationLookupForm();
            expirationLookupForm.ShowDialog();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
