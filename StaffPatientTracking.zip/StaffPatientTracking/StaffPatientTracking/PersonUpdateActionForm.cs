﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffPatientTracking
{
    public partial class PersonUpdateActionForm : Form
    {
        public Models.Expiration act;

        public PersonUpdateActionForm()
        {
            InitializeComponent();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {

        }

        private void setModel()
        {

        }
    }
}
