﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffPatientTracking.Data.Contract
{
    static class PeopleTbl
    {
        public static string Name = "People";

        public static class Cols
        {
            public static string PersonID = "PersonID";
            public static string FirstName = "FirstName";
            public static string MiddleName = "MiddleName";
            public static string LastName = "LastName";
            public static string ActiveDate = "ActiveDate";
            public static string InactiveDate = "InactiveDate";
        }
    }
}
