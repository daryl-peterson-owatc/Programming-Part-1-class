﻿namespace StaffPatientTracking.Data.Contract
{
    static class ExpirationsTbl
    {
        public static string Name = "Expirations";
        public static string PeoplePersonFK = "Expirations__Person_FK";
        public static string ActionCodesActionCodeFK = "Expirations__ActionCode_FK";

        public static class Cols
        {
            public static string ExpirationID = "ExpirationID";
            public static string PersonID = "PersonID";
            public static string ActionCodeID = "ActionCodeID";
            public static string DateUpdated = "DateUpdated";
            public static string DateExpires = "DateExpires";
        }
    }
}
