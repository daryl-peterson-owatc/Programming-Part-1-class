﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffPatientTracking.Data.Contract
{
    static class ActionCodesTbl
    {
        public static string Name = "ActionCodes";

        public static class Cols 
        {
            public static string ActionCodeID = "ActionCodeID";
            public static string Code = "Code";
            public static string Decription = "Description";
            public static string ExpirationMonths = "ExpirationMonths";
        }
    }
}
