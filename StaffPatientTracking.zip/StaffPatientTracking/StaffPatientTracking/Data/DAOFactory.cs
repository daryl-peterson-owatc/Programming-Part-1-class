﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffPatientTracking.Data
{
    class DAOFactory
    {
        private readonly Database db;

        public DAOFactory(Database db)
        {
            this.db = db;
        }

        public ActionCodesDAO ActionCodes => new ActionCodesDAO(db);
        public ActionsDAO Actions => new ActionsDAO(db);
        public PeopleDAO People => new PeopleDAO(db);
    }
}
