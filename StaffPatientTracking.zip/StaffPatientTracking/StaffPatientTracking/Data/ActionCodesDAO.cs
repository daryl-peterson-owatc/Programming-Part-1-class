﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.SQLite;

namespace StaffPatientTracking.Data
{
    class ActionCodesDAO
    {
        private readonly DatabaseManager dm;

        public ActionCodesDAO(DatabaseManager dm)
        {
            this.dm = dm;
        }

        public List<Models.ActionCode> GetActionCodesList()
        {

            dm.Database.WithConnection<List<Models.ActionCode>>(Function()
            {
                List<Models.ActionCode> ACList = new List<Models.ActionCode>();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Models.ActionCode code = new Models.ActionCode();
                    code.ActionCodeID = (Guid)reader["ActionCodeID"];
                    code.Description = reader["Description"].ToString();

                    ACList.Add(code);
                }
                return List;
            });

            List<Models.ActionCode> ACList = new List<Models.ActionCode>();

            // need to finish the connection string
            SqlConnection cn = null;

            string selectSQL = "SELECT * FROM ActionCodes ORDER BY Description";

            SqlCommand cmd = new SqlCommand(selectSQL, cn);

            try
            {
                cn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Models.ActionCode code = new Models.ActionCode();
                    code.ActionCodeID = (Guid)reader["ActionCodeID"];
                    code.Description = reader["Description"].ToString();

                    ACList.Add(code);
                }
            }   
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }

            return ACList;
        }

        public static Models.ActionCode GetActionCodeInfo(Guid actionCodeID)
        {
            Models.ActionCode code = new Models.ActionCode();

            SqlConnection cn = null;

            string selectSQL = "SELECT * FROM ActionCodes WHERE ActionCodeID = @ActionCodeID";
            SqlCommand cmd = new SqlCommand(selectSQL, cn);
            cmd.Parameters.AddWithValue("@ActionCodeID", actionCodeID);

            try
            {
                cn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                code.ActionCodeID = (Guid)reader["ActionCodeID"];
                code.Code = (string)reader["Code"];
                code.Description = (string)reader["Description"];
                code.ExpirationMonths = (int)reader["Expirationmonths"];
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }

            return code;
        }

        public static void InsertActionCode(Models.ActionCode ac)
        {
            SqlConnection cn = null;
            string insertSQL =
                "INSERT INTO ActionCode " +
                "(Code, Description, ExpirationMonths) " +
                "VALUES (@Code, @Description, @ExpirationMonths)";
            SqlCommand cmd = new SqlCommand(insertSQL, cn);
            cmd.Parameters.AddWithValue("@Code", ac.Code);
            cmd.Parameters.AddWithValue("@Description", ac.Description);
            cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);

            try
            {
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }

        public static int UpdateActionCode(Models.ActionCode ac)
        {
            SqlConnection cn = null;
            string upSQL =
                "UPDATE ActionCode SET " +
                "Code = @Code " +
                "Description = @Description " +
                "ExpirationMonths = @ExpirationMonths " +
                "WHERE ActionCodeID = @ActionCodeID";
            SqlCommand cmd = new SqlCommand(upSQL, cn);
            cmd.Parameters.AddWithValue("@ActionCodeID", ac.ActionCodeID);
            cmd.Parameters.AddWithValue("@Code", ac.Code);
            cmd.Parameters.AddWithValue("@Description", ac.Description);
            cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);

            try
            {
                cn.Open();
                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
