﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;

namespace StaffPatientTracking.Data
{
    class ActionCodesDAO
    {
        private readonly Database db;

        public ActionCodesDAO(Database db)
        {
            this.db = db;
        }

        public List<ActionCode> GetActionCodesList()
        {
            return
                db.WithConnection(cmd =>
                {
                    var actionList = new List<ActionCode>();
                    var selectSQL = "SELECT * FROM ActionCodes ORDER BY Description";
                    cmd.CommandText = selectSQL;
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var code = new ActionCode();
                            code.ActionCodeID = (Guid)reader["ActionCodeID"];
                            code.Description = reader["Description"].ToString();

                            actionList.Add(code);
                        }
                        return actionList;
                    }

                });
        }

        public ActionCode GetActionCodeInfo(Guid actionCodeID)
        {
            return
                db.WithConnection(cmd =>
                {
                    var code = new ActionCode();
                    var selectSQL = "SELECT * FROM ActionCodes WHERE ActionCodeID = @ActionCodeID";
                    cmd.CommandText = selectSQL;
                    cmd.Parameters.AddWithValue("@ActionCodeID", actionCodeID);

                    using (var reader = cmd.ExecuteReader())
                    {
                        code.ActionCodeID = (Guid)reader["ActionCodeID"];
                        code.Code = (string)reader["Code"];
                        code.Description = (string)reader["Description"];
                        code.ExpirationMonths = (int)reader["Expirationmonths"];
                    }
                    return code;
                });
        }

        public void InsertActionCode(ActionCode ac)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO ActionCode " +
                    "(ActionCodeID, Code, Description, ExpirationMonths) " +
                    "VALUES (@ActionCodeID, @Code, @Description, @ExpirationMonths)";
                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@ActionCodeID", ac.ActionCodeID);
                cmd.Parameters.AddWithValue("@Code", ac.Code);
                cmd.Parameters.AddWithValue("@Description", ac.Description);
                cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);
                return null;
            });
        }

        public void UpdateActionCode(ActionCode ac)
        {
            db.InTransaction<Object>(cmd =>
            {
                var updateSQL =
                    "UPDATE ActionCode SET " +
                    "Code = @Code " +
                    "Description = @Description " +
                    "ExpirationMonths = @ExpirationMonths " +
                    "WHERE ActionCodeID = @ActionCodeID";
                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@ActionCodeID", ac.ActionCodeID);
                cmd.Parameters.AddWithValue("@Code", ac.Code);
                cmd.Parameters.AddWithValue("@Description", ac.Description);
                cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);
                return null;
            });
        }
    }
}
