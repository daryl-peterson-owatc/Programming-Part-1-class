﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace StaffPatientTracking.Data
{
    class ActionCodesDAO
    {
        private readonly DatabaseManager dm;

        public ActionCodesDAO(DatabaseManager dm)
        {
            this.dm = dm;
        }

        public List<Models.ActionCode> GetActionCodesList()
        {

            dm.Database.WithConnection<List<Models.ActionCode>>(Function()
            {
                List<Models.ActionCode> ACList = new List<Models.ActionCode>();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Models.ActionCode code = new Models.ActionCode();
                    code.ActionCodeID = (Guid)reader["ActionCodeID"];
                    code.Description = reader["Description"].ToString();

                    ACList.Add(code);
                }
                return List;
            });

            List<Models.ActionCode> ACList = new List<Models.ActionCode>();

            // need to finish the connection string
            SqlConnection connection = null;

            string selectSQL = "SELECT * FROM ActionCodes ORDER BY Description";

            SqlCommand command = new SqlCommand(selectSQL, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Models.ActionCode code = new Models.ActionCode();
                    code.ActionCodeID = (Guid)reader["ActionCodeID"];
                    code.Description = reader["Description"].ToString();

                    ACList.Add(code);
                }
            }   
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return ACList;
        }

        public static Models.ActionCode GetActionCodeInfo(Guid actionCodeID)
        {
            Models.ActionCode code = new Models.ActionCode();

            SqlConnection connection = null;

            string selectSQL = "SELECT * FROM ActionCodes WHERE ActionCodeID = @ActionCodeID";
            SqlCommand command = new SqlCommand(selectSQL, connection);
            command.Parameters.AddWithValue("@ActionCodeID", actionCodeID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                code.ActionCodeID = (Guid)reader["ActionCodeID"];
                code.Code = (string)reader["Code"];
                code.Description = (string)reader["Description"];
                code.ExpirationMonths = (int)reader["Expirationmonths"];
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return code;
        }
    }
}
