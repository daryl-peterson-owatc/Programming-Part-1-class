﻿using StaffPatientTracking.Data.Contract;
using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;

namespace StaffPatientTracking.Data
{
    class ActionCodesDAO
    {
        private readonly Database db;

        public ActionCodesDAO(Database db)
        {
            this.db = db;
        }

        public List<ActionCode> GetActionCodesList()
        {
            return
                db.WithConnection(cmd =>
                {
                    var actionList = new List<ActionCode>();
                    var selectSQL = "SELECT * FROM " + ActionCodesTbl.Name + " ORDER BY " + ActionCodesTbl.Cols.Description;
                    cmd.CommandText = selectSQL;
                    using (var reader = cmd.ExecuteReader())
                    {
                        var actionCodeIdIdx = reader.GetOrdinal(ActionCodesTbl.Cols.ActionCodeID);
                        var descriptionIdx = reader.GetOrdinal(ActionCodesTbl.Cols.Description);

                        while (reader.Read())
                        {
                            //var code = new ActionCode();
                            //code.ActionCodeID = (Guid)reader[ActionCodesTbl.Cols.ActionCodeID];
                            //code.Description = reader[ActionCodesTbl.Cols.Decription].ToString();

                            var code = new ActionCode()
                            {
                                ActionCodeID = reader.GetGuid(actionCodeIdIdx),
                                Description = reader.GetString(descriptionIdx)
                            };

                            actionList.Add(code);
                        }
                        return actionList;
                    }
                });
        }

        public ActionCode GetActionCodeInfo(Guid actionCodeID)
        {
            return
                db.WithConnection(cmd =>
                {
                    var code = new ActionCode();
                    var selectSQL = "SELECT * FROM " + ActionCodesTbl.Name + " WHERE " + ActionCodesTbl.Cols.ActionCodeID + " = @ActionCodeID";
                    cmd.CommandText = selectSQL;
                    cmd.Parameters.AddWithValue("@ActionCodeID", ActionCodesTbl.Cols.ActionCodeID);

                    using (var reader = cmd.ExecuteReader())
                    {
                        code.ActionCodeID = (Guid)reader[ActionCodesTbl.Cols.ActionCodeID];
                        code.Code = (string)reader[ActionCodesTbl.Cols.Code];
                        code.Description = (string)reader[ActionCodesTbl.Cols.Description];
                        code.ExpirationMonths = (int)reader[ActionCodesTbl.Cols.ExpirationMonths];
                    }
                    return code;
                });
        }

        public void InsertActionCode(ActionCode ac)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO " + ActionCodesTbl.Name +
                    " (" + 
                    ActionCodesTbl.Cols.ActionCodeID + ", " + 
                    ActionCodesTbl.Cols.Code + ", " + 
                    ActionCodesTbl.Cols.Description + ", " + 
                    ActionCodesTbl.Cols.ExpirationMonths + ")"  +
                    "VALUES (@ActionCodeID, @Code, @Description, @ExpirationMonths)";
                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@ActionCodeID", ac.ActionCodeID);
                cmd.Parameters.AddWithValue("@Code", ac.Code);
                cmd.Parameters.AddWithValue("@Description", ac.Description);
                cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);
                return null;
            });
        }

        public void UpdateActionCode(ActionCode ac)
        {
            db.InTransaction<Object>(cmd =>
            {
                var updateSQL =
                    "UPDATE " + ActionCodesTbl.Name + " SET " +
                    ActionCodesTbl.Cols.Code + " = @Code " +
                    ActionCodesTbl.Cols.Description + " = @Description " +
                    ActionCodesTbl.Cols.ExpirationMonths + " = @ExpirationMonths " +
                    "WHERE " +ActionCodesTbl.Cols.ActionCodeID +" = @ActionCodeID";
                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@ActionCodeID", ac.ActionCodeID);
                cmd.Parameters.AddWithValue("@Code", ac.Code);
                cmd.Parameters.AddWithValue("@Description", ac.Description);
                cmd.Parameters.AddWithValue("@ExpirationMonths", ac.ExpirationMonths);
                return null;
            });
        }
    }
}
