﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.SQLite;

namespace StaffPatientTracking.Data
{
    class ActionsDAO
    {
        private readonly DatabaseManager dm;

        public ActionsDAO(DatabaseManager dm)
        {
            this.dm = dm;
        }

        public static void InsertAction(Models.Action act)
        {
            SqlConnection cn = null;
            string insertSQL =
                "INSERT INTO Actions " +
                "(PeopleID, ActionCodeID, DateUpdated, DateExpired) " +
                "VALUES (@PeopleID, @ActionCodeID, @DateExpired, @DateUpdated)";
            SqlCommand cmd = new SqlCommand(insertSQL, cn);
            cmd.Parameters.AddWithValue("@DateExpired", act.DateExpired);
            cmd.Parameters.AddWithValue("@DateUpdated", act.DateUpdated);
            cmd.Parameters.AddWithValue("@PeopleID", act.PeopleID);
            cmd.Parameters.AddWithValue("@ActionCodeID", act.ActionCodeID);

            try
            {
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }

        public static int UpdateAction(Models.Action act)
        {
            SqlConnection cn = null;
            string upSQL =
                "UPDATE Action SET " +
                "PeopleID = @PeopleID " +
                "ActionCodeID = @ActionCodeID " +
                "DateUpdated = @DateUpdated " +
                "DateExpired = @DateExpired " +
                "WHERE ActionID = @ActionID";
            SqlCommand cmd = new SqlCommand(upSQL, cn);
            cmd.Parameters.AddWithValue("@ActionID", act.ActionID);
            cmd.Parameters.AddWithValue("@PeopleID", act.PeopleID);
            cmd.Parameters.AddWithValue("@ActionCodeID", act.ActionCodeID);
            cmd.Parameters.AddWithValue("@DateUpdated", act.DateUpdated);
            cmd.Parameters.AddWithValue("@DateExpired", act.DateExpired);

            try
            {
                cn.Open();
                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }

        }
    }
}
