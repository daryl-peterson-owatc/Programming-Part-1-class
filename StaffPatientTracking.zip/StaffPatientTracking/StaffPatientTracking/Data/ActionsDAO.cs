﻿using StaffPatientTracking.Models;
using System;

namespace StaffPatientTracking.Data
{
    class ActionsDAO
    {
        private readonly Database db;

        public ActionsDAO(Database db)
        {
            this.db = db;
        }

        public void InsertAction(Action act)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO Actions " +
                    "(ActionID, PeopleID, ActionCodeID, DateUpdated, DateExpired) " +
                    "VALUES (@ActionID, @PeopleID, @ActionCodeID, @DateExpired, @DateUpdated)";
                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@ActionID", act.ActionID);
                cmd.Parameters.AddWithValue("@PeopleID", act.PeopleID);
                cmd.Parameters.AddWithValue("@ActionCodeID", act.ActionCodeID);
                cmd.Parameters.AddWithValue("@DateExpired", act.DateExpires);
                cmd.Parameters.AddWithValue("@DateUpdated", act.DateUpdated);
                return null;
            });
        }

        public void UpdateAction(Action act)
        {
            db.InTransaction<object>(cmd =>
            {
                string updateSQL =
                    "UPDATE Action SET " +
                    "PeopleID = @PeopleID " +
                    "ActionCodeID = @ActionCodeID " +
                    "DateUpdated = @DateUpdated " +
                    "DateExpired = @DateExpired " +
                    "WHERE ActionID = @ActionID";
                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@ActionID", act.ActionID);
                cmd.Parameters.AddWithValue("@PeopleID", act.PeopleID);
                cmd.Parameters.AddWithValue("@ActionCodeID", act.ActionCodeID);
                cmd.Parameters.AddWithValue("@DateUpdated", act.DateUpdated);
                cmd.Parameters.AddWithValue("@DateExpired", act.DateExpires);
                return null;
            });

        }
    }
}
