﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;

namespace StaffPatientTracking.Data
{
    class PeopleDAO
    {
        private readonly Database db;

        public PeopleDAO(Database db)
        {
            this.db = db;
        }

        public List<Person> getPeopleWithExpirations()
        {
            return
            db.WithConnection(cmd =>
            {
                var peopleList = new List<Person>();
                var selectSQL = "SELECT Person.PersonID, Person.FirstName, Person.MiddleName, Person.LastName, " +
                    "Expirations.ExpirationID, Expirations.PeopleID, Expirations.ActionCodeID, Expirations.DateUpdated, Expirations.DateExpired " +
                    "ActionCodes.ActionCodeID, ActionCodes.Code, ActionCodes.Description " +
                    "FROM ((People INNER JOIN Expirations ON People.PersonID = Expirations.PeopleID) " +
                    "INNER JOIN ActionCodes ON Expirations.ActionCodeID = ActionCodes.ActionCodeID " +
                    "WHERE Expirations.DateExpired <= @DateExpired ";
                cmd.CommandText = selectSQL;
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var person = new Person();
                        person.PersonID = (Guid)reader["Person.PersonID"];
                        person.FirstName = reader["Person.FirstName"].ToString();
                        person.MiddleName = reader["Person.MiddleName"].ToString();
                        person.LastName = reader["Person.LastName"].ToString();

                        peopleList.Add(person);
                    }
                }

                return peopleList;
            });
        }
    }
}
