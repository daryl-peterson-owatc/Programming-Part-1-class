﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;
using StaffPatientTracking.Data.Contract;

namespace StaffPatientTracking.Data
{
    class PeopleDAO
    {
        private readonly Database db;

        public PeopleDAO(Database db)
        {
            this.db = db;
        }

        public List<Person> getPeopleWithExpirations()
        {
            return
            db.WithConnection(cmd =>
            {
                var peopleList = new List<Person>();
                var selectSQL = "SELECT " +
                    
                    PeopleTbl.Cols.PersonID + ", "+
                    PeopleTbl.Cols.FirstName + ", " +
                    PeopleTbl.Cols.MiddleName + ", " +
                    PeopleTbl.Cols.LastName + ", " +
                    ExpirationsTbl.Cols.ExpirationID + ", " +
                    ExpirationsTbl.Cols.PersonID + ", " +
                    ExpirationsTbl.Cols.ActionCodeID + ", " +
                    ExpirationsTbl.Cols.DateUpdated + ", " +
                    ExpirationsTbl.Cols.DateExpires + ", " +
                    ActionCodesTbl.Cols.ActionCodeID + ", " +
                    ActionCodesTbl.Cols.Code + ", " +
                    ActionCodesTbl.Cols.Description + ", " +
                    "FROM ((" + PeopleTbl.Name + " " + 
                    "INNER JOIN " + ExpirationsTbl.Name + " ON " + PeopleTbl.Cols.PersonID + " = " + ExpirationsTbl.Cols.PersonID + ") " +
                    "INNER JOIN " + ActionCodesTbl.Name + " ON " + ExpirationsTbl.Cols.ActionCodeID + " = " + ActionCodesTbl.Cols.ActionCodeID + ") " +
                    "WHERE " + ExpirationsTbl.Cols.DateExpires + " <= @DateExpires ";
                cmd.CommandText = selectSQL;
                using (var reader = cmd.ExecuteReader())
                {
                    var personIdIdx = reader.GetOrdinal(PeopleTbl.Cols.PersonID);
                    var firstNameIdx = reader.GetOrdinal(PeopleTbl.Cols.FirstName);
                    var middleNameIdx = reader.GetOrdinal(PeopleTbl.Cols.MiddleName);
                    var lastNameIdx = reader.GetOrdinal(PeopleTbl.Cols.LastName);

                    while (reader.Read())
                    {
                        var person = new Person()
                        {
                            PersonID = reader.GetGuid(personIdIdx),
                            FirstName = reader.GetString(firstNameIdx),
                            MiddleName = reader.GetString(middleNameIdx),
                            LastName = reader.GetString(lastNameIdx)
                        };

                        peopleList.Add(person);
                    }
                }

                return peopleList;
            });
        }
    }
}
