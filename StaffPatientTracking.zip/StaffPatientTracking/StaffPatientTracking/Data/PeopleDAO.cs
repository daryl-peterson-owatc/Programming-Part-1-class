﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;
using StaffPatientTracking.Data.Contract;

namespace StaffPatientTracking.Data
{
    public class PeopleDAO
    {
        private readonly Database db;

        public PeopleDAO(Database db)
        {
            this.db = db;
        }

        public List<Person> GetPeopleWithExpirations()
        {
            return
            db.WithConnection(cmd =>
            {
                var peopleList = new List<Person>();
                var selectSQL = "SELECT " +
                    
                    PeopleTbl.Cols.PersonID + ", "+
                    PeopleTbl.Cols.FirstName + ", " +
                    PeopleTbl.Cols.MiddleName + ", " +
                    PeopleTbl.Cols.LastName + ", " +
                    PeopleTbl.Cols.Staff + ", " +
                    ExpirationsTbl.Cols.ExpirationID + ", " +
                    ExpirationsTbl.Cols.PersonID + ", " +
                    ExpirationsTbl.Cols.ActionCodeID + ", " +
                    ExpirationsTbl.Cols.DateUpdated + ", " +
                    ExpirationsTbl.Cols.DateExpires + ", " +
                    ActionCodesTbl.Cols.ActionCodeID + ", " +
                    ActionCodesTbl.Cols.Code + ", " +
                    ActionCodesTbl.Cols.Description + ", " +
                    "FROM ((" + PeopleTbl.Name + " " + 
                    "INNER JOIN " + ExpirationsTbl.Name + " ON " + PeopleTbl.Cols.PersonID + " = " + ExpirationsTbl.Cols.PersonID + ") " +
                    "INNER JOIN " + ActionCodesTbl.Name + " ON " + ExpirationsTbl.Cols.ActionCodeID + " = " + ActionCodesTbl.Cols.ActionCodeID + ") " +
                    "WHERE " + ExpirationsTbl.Cols.DateExpires + " <= @DateExpires ";

                cmd.CommandText = selectSQL;
                using (var reader = cmd.ExecuteReader())
                {
                    var personIdIdx = reader.GetOrdinal(PeopleTbl.Cols.PersonID);
                    var firstNameIdx = reader.GetOrdinal(PeopleTbl.Cols.FirstName);
                    var middleNameIdx = reader.GetOrdinal(PeopleTbl.Cols.MiddleName);
                    var lastNameIdx = reader.GetOrdinal(PeopleTbl.Cols.LastName);
                    var staffIdx = reader.GetOrdinal(PeopleTbl.Cols.Staff);

                    while (reader.Read())
                    {
                        var person = new Person()
                        {
                            PersonID = reader.GetGuid(personIdIdx),
                            FirstName = reader.GetString(firstNameIdx),
                            MiddleName = reader.GetString(middleNameIdx),
                            LastName = reader.GetString(lastNameIdx),
                            Staff = reader.GetBoolean(staffIdx)
                        };

                        peopleList.Add(person);
                    }
                }

                return peopleList;
            });
        }

        public List<Person> GetPeopleList()
        {
            return
                db.WithConnection(cmd =>
                {
                    var peopleList = new List<Person>();
                    var selectSQL =
                        "SELECT * FROM " + PeopleTbl.Name +
                        " ORDER BY " + PeopleTbl.Cols.FirstName + ", " + PeopleTbl.Cols.MiddleName + ", " + PeopleTbl.Cols.LastName;
                    cmd.CommandText = selectSQL;
                    using (var reader = cmd.ExecuteReader())
                    {
                        var personIdIdx = reader.GetOrdinal(PeopleTbl.Cols.PersonID);
                        var firstNameIdx = reader.GetOrdinal(PeopleTbl.Cols.FirstName);
                        var middleNameIdx = reader.GetOrdinal(PeopleTbl.Cols.MiddleName);
                        var lastNameIdx = reader.GetOrdinal(PeopleTbl.Cols.LastName);
                        var staffIdx = reader.GetOrdinal(PeopleTbl.Cols.Staff);

                        while (reader.Read())
                        {
                            var person = new Person()
                            {
                                PersonID = reader.GetGuid(personIdIdx),
                                FirstName = reader.GetString(firstNameIdx),
                                MiddleName = reader.GetString(middleNameIdx),
                                LastName = reader.GetString(lastNameIdx),
                                Staff = reader.GetBoolean(staffIdx)
                            };

                            peopleList.Add(person);
                        }
                    }

                    return peopleList;
                });
        }

        public Person GetPersonInfo(Guid personID)
        {
            return
                db.WithConnection(cmd =>
                {
                    var person = new Person();
                    var selectSQL = "SELECT * FROM " + PeopleTbl.Name + " WHERE " + PeopleTbl.Cols.PersonID + " = @PersonID";
                    cmd.CommandText = selectSQL;
                    cmd.Parameters.AddWithValue("@PersonID", PeopleTbl.Cols.PersonID);

                    using (var reader = cmd.ExecuteReader())
                    {
                        person.PersonID = (Guid)reader[PeopleTbl.Cols.PersonID];
                        person.FirstName = (string)reader[PeopleTbl.Cols.FirstName];
                        person.MiddleName = (string)reader[PeopleTbl.Cols.MiddleName];
                        person.LastName = (string)reader[PeopleTbl.Cols.LastName];
                        person.Staff = (bool)reader[PeopleTbl.Cols.Staff];
                        person.ActiveDate = (DateTime)reader[PeopleTbl.Cols.ActiveDate];
                        person.InactiveDate = (DateTime)reader[PeopleTbl.Cols.InactiveDate];
                    }
                    return person;
                });
        }

        public void InsertPerson(Person pe)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO " + PeopleTbl.Name +
                    "(" +
                    PeopleTbl.Cols.PersonID + ", " +
                    PeopleTbl.Cols.FirstName + ", " +
                    PeopleTbl.Cols.MiddleName + ", " +
                    PeopleTbl.Cols.LastName + ", " +
                    PeopleTbl.Cols.Staff + ", " +
                    PeopleTbl.Cols.ActiveDate + ", " +
                    PeopleTbl.Cols.InactiveDate + ") " +
                    "VALUES (@PersonID, @FirstName, @MiddleName, @LastName, @Staff, @ActiveDate, @InactiveDate)";

                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@PersonID", pe.PersonID);
                cmd.Parameters.AddWithValue("@FirstName", pe.FirstName);
                cmd.Parameters.AddWithValue("@MiddleName", pe.MiddleName);
                cmd.Parameters.AddWithValue("@LastName", pe.LastName);
                cmd.Parameters.AddWithValue("@Staff", pe.Staff);
                cmd.Parameters.AddWithValue("@ActiveDate", pe.ActiveDate);
                cmd.Parameters.AddWithValue("@InactiveDate", pe.InactiveDate);

                cmd.ExecuteNonQuery();
                return null;
            });
        }

        public void UpdatePerson(Person pe)
        {
            db.InTransaction<Object>(cmd =>
            {
                var updateSQL =
                    "UPDATE  " + PeopleTbl.Name + " SET " +
                    PeopleTbl.Cols.FirstName + " = @FirstName " +
                    PeopleTbl.Cols.MiddleName + " = @MiddleName " +
                    PeopleTbl.Cols.LastName + " = @LastName " +
                    PeopleTbl.Cols.Staff + " = @Staff " +
                    PeopleTbl.Cols.ActiveDate + " = @ActiveDate " +
                    PeopleTbl.Cols.InactiveDate + " = @InactiveDate " +
                    "WHERE " + PeopleTbl.Cols.PersonID + " = @PersonID";

                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@PersonID", pe.PersonID);
                cmd.Parameters.AddWithValue("@FirstName", pe.FirstName);
                cmd.Parameters.AddWithValue("@MiddleName", pe.MiddleName);
                cmd.Parameters.AddWithValue("@LastName", pe.LastName);
                cmd.Parameters.AddWithValue("@Staff", pe.Staff);
                cmd.Parameters.AddWithValue("@ActiveDate", pe.ActiveDate);
                cmd.Parameters.AddWithValue("@InactiveDate", pe.InactiveDate);

                cmd.ExecuteNonQuery();
                return null;
            });
        }

        public void DeletePerson(Person pe)
        {
            db.InTransaction<Object>(cmd =>
            {
                var deleteSQL =
                    "DELETE FROM " + PeopleTbl.Name + 
                    "WHERE " + PeopleTbl.Cols.PersonID + " = @PersonID";

                cmd.CommandText = deleteSQL;
                cmd.Parameters.AddWithValue("@PersonID", pe.PersonID);

                cmd.ExecuteNonQuery();
                return null;
            });
        }
    }
}
