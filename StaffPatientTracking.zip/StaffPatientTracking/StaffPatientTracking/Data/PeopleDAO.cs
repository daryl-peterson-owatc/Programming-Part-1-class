﻿using StaffPatientTracking.Models;
using System.Collections.Generic;

namespace StaffPatientTracking.Data
{
    class PeopleDAO
    {
        private readonly Database db;

        public PeopleDAO(Database db)
        {
            this.db = db;
        }

        public List<Person> getPeopleList()
        {

        }
    }
}
