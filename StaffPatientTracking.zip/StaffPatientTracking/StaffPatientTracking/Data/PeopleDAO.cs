﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffPatientTracking.Data
{
    class PeopleDAO
    {
        public static string GetName(Guid peopleID)
        {
            string name = "";

            return name;
        }
    }
}
