﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;

namespace StaffPatientTracking.Data
{
    class ExpirationsDAO
    {
        private readonly Database db;

        public ExpirationsDAO(Database db)
        {
            this.db = db;
        }

        public void InsertAction(Expiration exp)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO Actions " +
                    "(ExpirationID, PeopleID, ActionCodeID, DateUpdated, DateExpired) " +
                    "VALUES (@ExpirationID, @PeopleID, @ActionCodeID, @DateExpired, @DateUpdated)";
                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@ExpirationID", exp.ExpirationID);
                cmd.Parameters.AddWithValue("@PeopleID", exp.PeopleID);
                cmd.Parameters.AddWithValue("@ActionCodeID", exp.ActionCodeID);
                cmd.Parameters.AddWithValue("@DateExpired", exp.DateExpires);
                cmd.Parameters.AddWithValue("@DateUpdated", exp.DateUpdated);
                return null;
            });
        }

        public void UpdateAction(Expiration exp)
        {
            db.InTransaction<object>(cmd =>
            {
                string updateSQL =
                    "UPDATE Action SET " +
                    "PeopleID = @PeopleID " +
                    "ActionCodeID = @ActionCodeID " +
                    "DateUpdated = @DateUpdated " +
                    "DateExpired = @DateExpired " +
                    "WHERE ExpirationID = @ExpirationID";
                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@ExpirationID", exp.ExpirationID);
                cmd.Parameters.AddWithValue("@PeopleID", exp.PeopleID);
                cmd.Parameters.AddWithValue("@ActionCodeID", exp.ActionCodeID);
                cmd.Parameters.AddWithValue("@DateUpdated", exp.DateUpdated);
                cmd.Parameters.AddWithValue("@DateExpired", exp.DateExpires);
                return null;
            });

        }
    }
}
