﻿using StaffPatientTracking.Models;
using System;
using System.Collections.Generic;
using StaffPatientTracking.Data.Contract;

namespace StaffPatientTracking.Data
{
    public class ExpirationsDAO
    {
        private readonly Database db;

        public ExpirationsDAO(Database db)
        {
            this.db = db;
        }

        public void InsertAction(Expiration exp)
        {
            db.InTransaction<Object>(cmd =>
            {
                var insertSQL =
                    "INSERT INTO " + ExpirationsTbl.Name +
                    " (" +
                    ExpirationsTbl.Cols.ExpirationID + ", " +
                    ExpirationsTbl.Cols.PersonID + ", " +
                    ExpirationsTbl.Cols.ActionCodeID + ", " +
                    ExpirationsTbl.Cols.DateExpires + ", " +
                    ExpirationsTbl.Cols.DateUpdated + ") " +
                    "VALUES (@ExpirationID, @PersonID, @ActionCodeID, @DateExpires, @DateUpdated)";
                cmd.CommandText = insertSQL;
                cmd.Parameters.AddWithValue("@ExpirationID", exp.ExpirationID);
                cmd.Parameters.AddWithValue("@PersonID", exp.Person);
                cmd.Parameters.AddWithValue("@ActionCodeID", exp.ActionCode);
                cmd.Parameters.AddWithValue("@DateExpired", exp.DateExpires);
                cmd.Parameters.AddWithValue("@DateUpdated", exp.DateUpdated);

                cmd.ExecuteNonQuery();
                return null;
            });
        }

        public void UpdateAction(Expiration exp)
        {
            db.InTransaction<object>(cmd =>
            {
                string updateSQL =
                    "UPDATE " + ExpirationsTbl.Name + " SET " +
                    ExpirationsTbl.Cols.PersonID + " = @PersonID" +
                    ExpirationsTbl.Cols.ActionCodeID + " = @ActionCodeID " +
                    ExpirationsTbl.Cols.DateUpdated + " = @DateUpdated " +
                    ExpirationsTbl.Cols.DateExpires + " = @DateExpired " +
                    "WHERE " + ExpirationsTbl.Cols.ExpirationID + " = @ExpirationID";
                cmd.CommandText = updateSQL;
                cmd.Parameters.AddWithValue("@ExpirationID", exp.ExpirationID);
                cmd.Parameters.AddWithValue("@PeopleID", exp.Person);
                cmd.Parameters.AddWithValue("@ActionCodeID", exp.ActionCode);
                cmd.Parameters.AddWithValue("@DateUpdated", exp.DateUpdated);
                cmd.Parameters.AddWithValue("@DateExpired", exp.DateExpires);

                cmd.ExecuteNonQuery();
                return null;
            });
        }

        public void DeleteAction(Expiration exp)
        {
            db.InTransaction<object>(cmd =>
            {
                string deleteSQL =
                    "DELETE FROM " + ExpirationsTbl.Name +
                    "WHERE " + ExpirationsTbl.Cols.ExpirationID + " = @ExpirationID";

                cmd.CommandText = deleteSQL;
                cmd.Parameters.AddWithValue("@ExpirationID", exp.ExpirationID);

                cmd.ExecuteNonQuery();
                return null;
            });
        }
    }
}
