﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace StaffPatientTracking.Data
{
    class DatabaseManager
    {
        public string connectionString = "";
        public string dbName = "";

        public DatabaseManager()
        {
            SQLiteConnectionStringBuilder cnString = new SQLiteConnectionStringBuilder();

        }
    }




    // Contract.cs
    // namespace StaffPatientTracking.Data.Contract
    static class People
    {
        public const string Name = "people";

        public static class Cols
        {
            public const string FirstName = "first_name";
            public const string LastName = "last_name";
        }
    }
}
