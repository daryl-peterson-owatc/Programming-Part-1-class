﻿using System.Data.SQLite;
using System.IO;
using System;

namespace StaffPatientTracking.Data
{
    public class DatabaseManager
    {
        private string connectionString = "";

        private string buildConnectionString(string dbFile, bool failIfMissing)
        {
            var cnString = new SQLiteConnectionStringBuilder();
            cnString.BinaryGUID = false;
            cnString.DataSource = dbFile;
            cnString.FailIfMissing = failIfMissing;
            cnString.Password = "";
            //cnString.Password = "fa010964-880a-4ec1-a93d-cdd984cf5b77";
            cnString.Pooling = false;
            cnString.Version = 3;

            return cnString.ToString();
        }

        public void OpenDatabase(string dbFile)
        {
            connectionString = buildConnectionString(dbFile, true);
        }

        public void CreateNewDatabase(string dbFile)
        {
            if (File.Exists(dbFile))
            {
                File.Delete(dbFile);
            }
            connectionString = buildConnectionString(dbFile, false);

            var builder = new BuildDatabase(GetDatabaseConnection());
            builder.BuildTables();
        }

        public Guid GetGuid()
        {
            return Guid.NewGuid();
        }
        public Database GetDatabaseConnection() => new Database(new SQLiteConnection(connectionString));
        public DAOFactory DAO => new DAOFactory(GetDatabaseConnection());
    }
}
