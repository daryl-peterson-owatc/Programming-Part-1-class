﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace StaffPatientTracking.Data
{
    class Database
    {
        private readonly SQLiteConnection cn;

        public Database(SQLiteConnection cn)
        {
            this.cn = cn;
        }

        public T WithConnection<T>(Func<T> fn)
        {
            try
            {
                cn.Open();
                return fn();
            }
            finally
            {
                cn.Close();
            }
        }

        public T InTransaction<T>(Func<T> fn)
        {
            var trans = cn.BeginTransaction();
            try
            {
                var returnValue = fn();
                trans.Commit();
                return returnValue;
            }
            catch (Exception ex)
            {
                trans.Rollback();
                throw ex;
            }
        }
    }
}
