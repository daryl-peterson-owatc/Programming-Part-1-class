﻿using System;
using System.Data.SQLite;

namespace StaffPatientTracking.Data
{
    class Database
    {
        private readonly SQLiteConnection cn;

        public Database(SQLiteConnection cn)
        {
            this.cn = cn;
        }

        public T WithConnection<T>(Func<SQLiteCommand, T> fn)
        {
            cn.Open();
            var cmd = cn.CreateCommand();

            try
            {
                return fn(cmd);
            }
            finally
            {
                cmd.Dispose();
                cn.Close();
            }
        }

        public T InTransaction<T>(Func<SQLiteCommand, T> fn)
        {
            return
                WithConnection(cmd =>
                {
                    var trans = cn.BeginTransaction();
                    try
                    {
                        var returnValue = fn(cmd);
                        trans.Commit();
                        return returnValue;
                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                        throw ex;
                    }
                });
        }
    }
}
