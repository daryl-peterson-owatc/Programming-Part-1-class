﻿Public Class MathTutor
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Property ShowAnswers As Boolean
        Get
            Return chkShowAnswers.Checked
        End Get
        Set(value As Boolean)
            chkShowAnswers.Checked = value
        End Set
    End Property
    Property GradeLevel As Integer
        Get
            Return cboMathLevel.SelectedIndex + 1
        End Get
        Set(value As Integer)
            cboMathLevel.SelectedIndex = value
        End Set
    End Property
    Property MaxIterations As Integer
        Get
            Return cboIterations.SelectedItem
        End Get
        Set(value As Integer)
            cboIterations.SelectedItem = value
        End Set
    End Property
    Public Property FirstNumber As Double = 0
    Public Property SecondNumber As Double = 0
    Public Property TestAnswer As Double = 0
    Public Property CorrectAnswer As Double = 0
    Public Property CurrentIteration As Integer = 0
    Public Property Score As Integer = 0

    Private Function RandomNumber()
        Randomize()
        Return Int((10 * Rnd()) + 1)
    End Function

    Private Sub btnStartAddition_Click(sender As Object, e As EventArgs) Handles btnStartAddition.Click
        lblCurrentIteration.Text = 0
        setAdditionNumbers()
        lblAdditionCompleted.Visible = False
        btnStartAddition.Enabled = False
        btnNextAddition.Enabled = True
        btnCancelAddition.Enabled = True
        btnCheckAnswerAddition.Enabled = True
        Score = 0
        lblAdditionCorrectAnswers.Text = Score
    End Sub

    Private Sub btnStartSubtraction_Click(sender As Object, e As EventArgs) Handles btnStartSubtraction.Click
        lblCurrentIteration.Text = 0
        setSubtractionNumbers()
        btnStartSubtraction.Enabled = False
        btnNextSubtraction.Enabled = True
        btnCancelSubtraction.Enabled = True
        btnCheckAnswerSubtraction.Enabled = True
        Score = 0
        lblSubtractionCorrectAnswers.Text = Score
    End Sub

    Private Sub btnStartMultiplication_Click(sender As Object, e As EventArgs) Handles btnStartMultiplication.Click
        lblCurrentIteration.Text = 0
        setMultiplicationNumbers()
        btnStartMultiplication.Enabled = False
        btnNextMultiplication.Enabled = True
        btnCancelMultiplication.Enabled = True
        btnCheckAnswerMultiplication.Enabled = True
        Score = 0
        lblMultiplicationCorrectAnswers.Text = Score
    End Sub

    Private Sub btnStartDivision_Click(sender As Object, e As EventArgs) Handles btnStartDivision.Click
        lblCurrentIteration.Text = 0
        setDivisionNumbers()
        btnStartDivision.Enabled = False
        btnNextDivision.Enabled = True
        btnCancelDivision.Enabled = True
        btnCheckAnswerDivision.Enabled = True
        Score = 0
        lblDivisionCorrectAnswers.Text = Score
    End Sub

    Private Sub btnNextAddition_Click(sender As Object, e As EventArgs) Handles btnNextAddition.Click
        If CurrentIteration >= MaxIterations Then
            lblAdditionCompleted.Visible = True
            btnNextAddition.Enabled = False
            btnCancelAddition.Enabled = False
            btnCheckAnswerAddition.Enabled = False
            btnStartAddition.Enabled = True
            CurrentIteration = 0
            Score = 0
        Else
            setAdditionNumbers()
        End If
    End Sub

    Private Sub btnNextSubtraction_Click(sender As Object, e As EventArgs) Handles btnNextSubtraction.Click
        If CurrentIteration >= MaxIterations Then
            lblSubtractionCompleted.Visible = True
            btnNextSubtraction.Enabled = False
            btnCancelSubtraction.Enabled = False
            btnCheckAnswerSubtraction.Enabled = False
            btnStartSubtraction.Enabled = True
            CurrentIteration = 0
            Score = 0
        Else
            setSubtractionNumbers()
        End If
    End Sub

    Private Sub btnNextMultiplication_Click(sender As Object, e As EventArgs) Handles btnNextMultiplication.Click
        If CurrentIteration >= MaxIterations Then
            lblMultiplicationCompleted.Visible = True
            btnNextMultiplication.Enabled = False
            btnCancelMultiplication.Enabled = False
            btnCheckAnswerMultiplication.Enabled = False
            btnStartMultiplication.Enabled = True
            CurrentIteration = 0
            Score = 0
        Else
            setMultiplicationNumbers()
        End If
    End Sub

    Private Sub btnNextDivision_Click(sender As Object, e As EventArgs) Handles btnNextDivision.Click
        If CurrentIteration >= MaxIterations Then
            lblDivisionCompleted.Visible = True
            btnNextDivision.Enabled = False
            btnCancelDivision.Enabled = False
            btnCheckAnswerDivision.Enabled = False
            btnStartDivision.Enabled = True
            CurrentIteration = 0
            Score = 0
        Else
            setDivisionNumbers()
        End If
    End Sub

    Private Sub btnCheckAnswerAddition_Click(sender As Object, e As EventArgs) Handles btnCheckAnswerAddition.Click
        Dim testAnswer As Double = Convert.ToDouble(txtAdditionAnswer.Text)
        If testAnswer = CorrectAnswer Then
            Score = Score + 1
            lblAdditionCorrectAnswers.Text = Score
        End If

    End Sub

    Private Sub btnCheckAnswerSubtraction_Click(sender As Object, e As EventArgs) Handles btnCheckAnswerSubtraction.Click
        Dim testAnswer As Double = Convert.ToDouble(txtSubtractionAnswer.Text)
        If testAnswer = CorrectAnswer Then
            Score = Score + 1
            lblSubtractionCorrectAnswers.Text = Score
        End If
    End Sub

    Private Sub btnCheckAnswerMultiplication_Click(sender As Object, e As EventArgs) Handles btnCheckAnswerMultiplication.Click
        Dim testAnswer As Double = Convert.ToDouble(txtMultiplicationAnswer.Text)
        If testAnswer = CorrectAnswer Then
            Score = Score + 1
            lblMultiplicationCorrectAnswers.Text = Score
        End If
    End Sub

    Private Sub btnCheckAnswerDivision_Click(sender As Object, e As EventArgs) Handles btnCheckAnswerDivision.Click
        Dim testAnswer As Double = Convert.ToDouble(txtDivisionAnswer.Text)
        If testAnswer = CorrectAnswer Then
            Score = Score + 1
            lblDivisionCorrectAnswers.Text = Score
        End If
    End Sub

    Private Sub tabAddition_Click(sender As Object, e As EventArgs) Handles tabAddition.Click
        btnStartAddition.Enabled = True
        btnNextAddition.Enabled = False
        btnCheckAnswerAddition.Enabled = False
        btnCancelAddition.Enabled = False
    End Sub

    Private Sub btnCancelAddition_Click(sender As Object, e As EventArgs) Handles btnCancelAddition.Click
        btnStartAddition.Enabled = True
        btnNextAddition.Enabled = False
        btnCheckAnswerAddition.Enabled = False
        btnCancelAddition.Enabled = False
        CurrentIteration = 0
    End Sub

    Private Sub btnCancelSubtraction_Click(sender As Object, e As EventArgs) Handles btnCancelSubtraction.Click
        btnStartSubtraction.Enabled = True
        btnNextSubtraction.Enabled = False
        btnCancelSubtraction.Enabled = False
        btnCheckAnswerSubtraction.Enabled = False
        CurrentIteration = 0
        Score = 0
    End Sub

    Private Sub btnCancelMultiplication_Click(sender As Object, e As EventArgs) Handles btnCancelMultiplication.Click
        btnStartMultiplication.Enabled = True
        btnNextMultiplication.Enabled = False
        btnCancelMultiplication.Enabled = False
        btnCheckAnswerMultiplication.Enabled = False
        CurrentIteration = 0
        Score = 0
    End Sub

    Private Sub btnCancelDivision_Click(sender As Object, e As EventArgs) Handles btnCancelDivision.Click
        btnStartDivision.Enabled = True
        btnNextDivision.Enabled = False
        btnCancelDivision.Enabled = False
        btnCheckAnswerDivision.Enabled = False
        CurrentIteration = 0
        Score = 0
    End Sub

    Private Sub MathTutor_Load(sender As Object, e As EventArgs) Handles Me.Load
        btnNextAddition.Enabled = False
        btnCheckAnswerAddition.Enabled = False
        btnCancelAddition.Enabled = False
        btnNextSubtraction.Enabled = False
        btnCancelSubtraction.Enabled = False
        btnCheckAnswerSubtraction.Enabled = False
        btnNextMultiplication.Enabled = False
        btnCancelMultiplication.Enabled = False
        btnCheckAnswerMultiplication.Enabled = False
        btnNextDivision.Enabled = False
        btnCancelDivision.Enabled = False
        btnCheckAnswerDivision.Enabled = False
        cboIterations.SelectedIndex = 0
        cboMathLevel.SelectedIndex = 0
        btnShowAnswerAddition.Visible = False
        btnShowAnswerSubtraction.Visible = False
        btnShowAnswerMultiplication.Visible = False
        btnShowAnswerDivision.Visible = False
        lblShowAnswerAddition.Visible = False
        lblShowAnswerSubtraction.Visible = False
        lblShowAnswerMultiplication.Visible = False
        lblShowAnswerDivision.Visible = False
    End Sub

    Private Sub cboIterations_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboIterations.SelectedIndexChanged
        MaxIterations = cboIterations.SelectedItem
        lblMaxIterations.Text = MaxIterations
    End Sub

    Private Sub setAdditionNumbers()
        Dim num1 As Double = 0
        Dim num2 As Double = 0
        num1 = RandomNumber()
        num2 = RandomNumber()
        lblAddition1.Text = num1
        lblAddition2.Text = num2
        lblShowAnswerAddition.Text = ""
        CorrectAnswer = num1 + num2
        CurrentIteration += 1
        lblCurrentIteration.Text = CurrentIteration
        txtAdditionAnswer.Text = ""
        txtAdditionAnswer.Focus()
    End Sub

    Private Sub setSubtractionNumbers()
        Dim tmp As Double = 0
        Dim num1 As Double = 0
        Dim num2 As Double = 0
        num1 = RandomNumber()
        num2 = RandomNumber()
        If num2 > num1 Then
            tmp = num1
            num1 = num2
            num2 = tmp
        End If
        lblSubtraction1.Text = num1
        lblSubtraction2.Text = num2
        lblShowAnswerSubtraction.Text = ""
        CorrectAnswer = num1 - num2
        CurrentIteration += 1
        lblCurrentIteration.Text = CurrentIteration
        txtSubtractionAnswer.Text = ""
        txtSubtractionAnswer.Focus()
    End Sub
    Private Sub setMultiplicationNumbers()
        Dim num1 As Double = 0
        Dim num2 As Double = 0
        num1 = RandomNumber()
        num2 = RandomNumber()
        lblMultiplication1.Text = num1
        lblMultiplication2.Text = num2
        lblShowAnswerMultiplication.Text = ""
        CorrectAnswer = num1 * num2
        CurrentIteration += 1
        lblCurrentIteration.Text = CurrentIteration
        txtMultiplicationAnswer.Text = ""
        txtMultiplicationAnswer.Focus()
    End Sub

    Private Sub setDivisionNumbers()
        Dim tmp As Double = 0
        Dim num1 As Double = 0
        Dim num2 As Double = 0
        num1 = RandomNumber()
        num2 = RandomNumber()
        While checkForZero(num1)
            num1 = RandomNumber()
        End While
        While checkForZero(num2)
            num2 = RandomNumber()
        End While
        If num2 > num1 Then
            tmp = num1
            num1 = num2
            num2 = tmp
        End If
        lblDivision1.Text = num1
        lblDivision2.Text = num2
        lblShowAnswerDivision.Text = ""
        CorrectAnswer = num1 / num2
        CurrentIteration += 1
        lblCurrentIteration.Text = CurrentIteration
        txtDivisionAnswer.Text = ""
        txtDivisionAnswer.Focus()
    End Sub

    Private Function checkForZero(number)
        If number = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub chkShowAnswers_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowAnswers.CheckedChanged
        If ShowAnswers = True Then
            btnShowAnswerAddition.Visible = True
            btnShowAnswerSubtraction.Visible = True
            btnShowAnswerMultiplication.Visible = True
            btnShowAnswerDivision.Visible = True
            lblShowAnswerAddition.Visible = True
            lblShowAnswerSubtraction.Visible = True
            lblShowAnswerMultiplication.Visible = True
            lblShowAnswerDivision.Visible = True
        Else
            btnShowAnswerAddition.Visible = False
            btnShowAnswerSubtraction.Visible = False
            btnShowAnswerMultiplication.Visible = False
            btnShowAnswerDivision.Visible = False
            lblShowAnswerAddition.Visible = False
            lblShowAnswerSubtraction.Visible = False
            lblShowAnswerMultiplication.Visible = False
            lblShowAnswerDivision.Visible = False
        End If
    End Sub

    Private Sub btnShowAnswerAddition_Click(sender As Object, e As EventArgs) Handles btnShowAnswerAddition.Click
        lblShowAnswerAddition.Text = CorrectAnswer
    End Sub

    Private Sub btnShowAnswerSubtraction_Click(sender As Object, e As EventArgs) Handles btnShowAnswerSubtraction.Click
        lblShowAnswerSubtraction.Text = CorrectAnswer
    End Sub

    Private Sub btnShowAnswerMultiplication_Click(sender As Object, e As EventArgs) Handles btnShowAnswerMultiplication.Click
        lblShowAnswerMultiplication.Text = CorrectAnswer
    End Sub

    Private Sub btnShowAnswerDivision_Click(sender As Object, e As EventArgs) Handles btnShowAnswerDivision.Click
        lblShowAnswerDivision.Text = CorrectAnswer
    End Sub
End Class
