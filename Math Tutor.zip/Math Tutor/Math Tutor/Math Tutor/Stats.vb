﻿Public Class Stats
    Public Property Iteration As Integer = 0
    Public Property MaxIteration As Integer = 10
End Class
