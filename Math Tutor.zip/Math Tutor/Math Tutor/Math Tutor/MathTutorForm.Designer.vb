﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MathTutor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabOptions = New System.Windows.Forms.TabPage()
        Me.lblIterations = New System.Windows.Forms.Label()
        Me.cboIterations = New System.Windows.Forms.ComboBox()
        Me.chkShowAnswers = New System.Windows.Forms.CheckBox()
        Me.lblMathLevel = New System.Windows.Forms.Label()
        Me.cboMathLevel = New System.Windows.Forms.ComboBox()
        Me.tabAddition = New System.Windows.Forms.TabPage()
        Me.lblAdditionCompleted = New System.Windows.Forms.Label()
        Me.lblAdditionCorrectAnswers = New System.Windows.Forms.Label()
        Me.lblAdditionCorrectAnswersTitle = New System.Windows.Forms.Label()
        Me.lblAdditionSymbol = New System.Windows.Forms.Label()
        Me.txtAdditionAnswer = New System.Windows.Forms.TextBox()
        Me.lblAddition2 = New System.Windows.Forms.Label()
        Me.lblAddition1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerAddition = New System.Windows.Forms.Button()
        Me.btnCancelAddition = New System.Windows.Forms.Button()
        Me.btnNextAddition = New System.Windows.Forms.Button()
        Me.btnStartAddition = New System.Windows.Forms.Button()
        Me.tabSubtraction = New System.Windows.Forms.TabPage()
        Me.lblSubtractionCorrectAnswers = New System.Windows.Forms.Label()
        Me.lblSubtractionCorrectAnswersTitle = New System.Windows.Forms.Label()
        Me.txtSubtractionAnswer = New System.Windows.Forms.TextBox()
        Me.lblSubtractionSymbol = New System.Windows.Forms.Label()
        Me.lblSubtraction2 = New System.Windows.Forms.Label()
        Me.lblSubtraction1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerSubtraction = New System.Windows.Forms.Button()
        Me.btnCancelSubtraction = New System.Windows.Forms.Button()
        Me.btnNextSubtraction = New System.Windows.Forms.Button()
        Me.btnStartSubtraction = New System.Windows.Forms.Button()
        Me.tabMultiplication = New System.Windows.Forms.TabPage()
        Me.lblMultiplicationCorrectAnswers = New System.Windows.Forms.Label()
        Me.lblMultiplicationCorrectAnswersTitle = New System.Windows.Forms.Label()
        Me.txtMultiplicationAnswer = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblMultiplication2 = New System.Windows.Forms.Label()
        Me.lblMultiplication1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerMultiplication = New System.Windows.Forms.Button()
        Me.btnCancelMultiplication = New System.Windows.Forms.Button()
        Me.btnNextMultiplication = New System.Windows.Forms.Button()
        Me.btnStartMultiplication = New System.Windows.Forms.Button()
        Me.tabDivision = New System.Windows.Forms.TabPage()
        Me.lblDivisionCorrectAnswers = New System.Windows.Forms.Label()
        Me.lblDivisionCorrectAnswersTitle = New System.Windows.Forms.Label()
        Me.lblDivisionSymbol = New System.Windows.Forms.Label()
        Me.lblDivision2 = New System.Windows.Forms.Label()
        Me.lblDivision1 = New System.Windows.Forms.Label()
        Me.txtDivisionAnswer = New System.Windows.Forms.TextBox()
        Me.btnCheckAnswerDivision = New System.Windows.Forms.Button()
        Me.btnCancelDivision = New System.Windows.Forms.Button()
        Me.btnNextDivision = New System.Windows.Forms.Button()
        Me.btnStartDivision = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMaxIterations = New System.Windows.Forms.Label()
        Me.lblOf = New System.Windows.Forms.Label()
        Me.lblIterationWord = New System.Windows.Forms.Label()
        Me.lblCurrentIteration = New System.Windows.Forms.Label()
        Me.lblSubtractionCompleted = New System.Windows.Forms.Label()
        Me.lblMultiplicationCompleted = New System.Windows.Forms.Label()
        Me.lblDivisionCompleted = New System.Windows.Forms.Label()
        Me.btnShowAnswerAddition = New System.Windows.Forms.Button()
        Me.lblShowAnswerAddition = New System.Windows.Forms.Label()
        Me.btnShowAnswerSubtraction = New System.Windows.Forms.Button()
        Me.lblShowAnswerSubtraction = New System.Windows.Forms.Label()
        Me.btnShowAnswerMultiplication = New System.Windows.Forms.Button()
        Me.lblShowAnswerMultiplication = New System.Windows.Forms.Label()
        Me.btnShowAnswerDivision = New System.Windows.Forms.Button()
        Me.lblShowAnswerDivision = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.tabOptions.SuspendLayout()
        Me.tabAddition.SuspendLayout()
        Me.tabSubtraction.SuspendLayout()
        Me.tabMultiplication.SuspendLayout()
        Me.tabDivision.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabOptions)
        Me.TabControl1.Controls.Add(Me.tabAddition)
        Me.TabControl1.Controls.Add(Me.tabSubtraction)
        Me.TabControl1.Controls.Add(Me.tabMultiplication)
        Me.TabControl1.Controls.Add(Me.tabDivision)
        Me.TabControl1.Location = New System.Drawing.Point(3, 31)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(516, 337)
        Me.TabControl1.TabIndex = 0
        '
        'tabOptions
        '
        Me.tabOptions.Controls.Add(Me.lblIterations)
        Me.tabOptions.Controls.Add(Me.cboIterations)
        Me.tabOptions.Controls.Add(Me.chkShowAnswers)
        Me.tabOptions.Controls.Add(Me.lblMathLevel)
        Me.tabOptions.Controls.Add(Me.cboMathLevel)
        Me.tabOptions.Location = New System.Drawing.Point(4, 22)
        Me.tabOptions.Name = "tabOptions"
        Me.tabOptions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabOptions.Size = New System.Drawing.Size(508, 311)
        Me.tabOptions.TabIndex = 0
        Me.tabOptions.Text = "Options"
        Me.tabOptions.UseVisualStyleBackColor = True
        '
        'lblIterations
        '
        Me.lblIterations.AutoSize = True
        Me.lblIterations.Location = New System.Drawing.Point(17, 54)
        Me.lblIterations.Name = "lblIterations"
        Me.lblIterations.Size = New System.Drawing.Size(102, 13)
        Me.lblIterations.TabIndex = 4
        Me.lblIterations.Text = "Number of Iterations"
        '
        'cboIterations
        '
        Me.cboIterations.FormattingEnabled = True
        Me.cboIterations.Items.AddRange(New Object() {"10", "25", "50", "100"})
        Me.cboIterations.Location = New System.Drawing.Point(14, 74)
        Me.cboIterations.Name = "cboIterations"
        Me.cboIterations.Size = New System.Drawing.Size(105, 21)
        Me.cboIterations.TabIndex = 1
        '
        'chkShowAnswers
        '
        Me.chkShowAnswers.AutoSize = True
        Me.chkShowAnswers.Location = New System.Drawing.Point(17, 119)
        Me.chkShowAnswers.Name = "chkShowAnswers"
        Me.chkShowAnswers.Size = New System.Drawing.Size(96, 17)
        Me.chkShowAnswers.TabIndex = 2
        Me.chkShowAnswers.Text = "Show Answers"
        Me.chkShowAnswers.UseVisualStyleBackColor = True
        '
        'lblMathLevel
        '
        Me.lblMathLevel.AutoSize = True
        Me.lblMathLevel.Location = New System.Drawing.Point(11, 5)
        Me.lblMathLevel.Name = "lblMathLevel"
        Me.lblMathLevel.Size = New System.Drawing.Size(60, 13)
        Me.lblMathLevel.TabIndex = 3
        Me.lblMathLevel.Text = "Math Level"
        '
        'cboMathLevel
        '
        Me.cboMathLevel.FormattingEnabled = True
        Me.cboMathLevel.Items.AddRange(New Object() {"Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"})
        Me.cboMathLevel.Location = New System.Drawing.Point(14, 21)
        Me.cboMathLevel.Name = "cboMathLevel"
        Me.cboMathLevel.Size = New System.Drawing.Size(105, 21)
        Me.cboMathLevel.TabIndex = 0
        '
        'tabAddition
        '
        Me.tabAddition.Controls.Add(Me.lblShowAnswerAddition)
        Me.tabAddition.Controls.Add(Me.btnShowAnswerAddition)
        Me.tabAddition.Controls.Add(Me.lblAdditionCompleted)
        Me.tabAddition.Controls.Add(Me.lblAdditionCorrectAnswers)
        Me.tabAddition.Controls.Add(Me.lblAdditionCorrectAnswersTitle)
        Me.tabAddition.Controls.Add(Me.lblAdditionSymbol)
        Me.tabAddition.Controls.Add(Me.txtAdditionAnswer)
        Me.tabAddition.Controls.Add(Me.lblAddition2)
        Me.tabAddition.Controls.Add(Me.lblAddition1)
        Me.tabAddition.Controls.Add(Me.btnCheckAnswerAddition)
        Me.tabAddition.Controls.Add(Me.btnCancelAddition)
        Me.tabAddition.Controls.Add(Me.btnNextAddition)
        Me.tabAddition.Controls.Add(Me.btnStartAddition)
        Me.tabAddition.Location = New System.Drawing.Point(4, 22)
        Me.tabAddition.Name = "tabAddition"
        Me.tabAddition.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAddition.Size = New System.Drawing.Size(508, 311)
        Me.tabAddition.TabIndex = 1
        Me.tabAddition.Text = "Addition"
        Me.tabAddition.UseVisualStyleBackColor = True
        '
        'lblAdditionCompleted
        '
        Me.lblAdditionCompleted.AutoSize = True
        Me.lblAdditionCompleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdditionCompleted.Location = New System.Drawing.Point(367, 29)
        Me.lblAdditionCompleted.Name = "lblAdditionCompleted"
        Me.lblAdditionCompleted.Size = New System.Drawing.Size(115, 25)
        Me.lblAdditionCompleted.TabIndex = 10
        Me.lblAdditionCompleted.Text = "Completed"
        Me.lblAdditionCompleted.Visible = False
        '
        'lblAdditionCorrectAnswers
        '
        Me.lblAdditionCorrectAnswers.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdditionCorrectAnswers.Location = New System.Drawing.Point(334, 223)
        Me.lblAdditionCorrectAnswers.Name = "lblAdditionCorrectAnswers"
        Me.lblAdditionCorrectAnswers.Size = New System.Drawing.Size(56, 32)
        Me.lblAdditionCorrectAnswers.TabIndex = 9
        Me.lblAdditionCorrectAnswers.Text = "0"
        Me.lblAdditionCorrectAnswers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAdditionCorrectAnswersTitle
        '
        Me.lblAdditionCorrectAnswersTitle.Location = New System.Drawing.Point(304, 199)
        Me.lblAdditionCorrectAnswersTitle.Name = "lblAdditionCorrectAnswersTitle"
        Me.lblAdditionCorrectAnswersTitle.Size = New System.Drawing.Size(112, 18)
        Me.lblAdditionCorrectAnswersTitle.TabIndex = 8
        Me.lblAdditionCorrectAnswersTitle.Text = "Correct Answers"
        Me.lblAdditionCorrectAnswersTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAdditionSymbol
        '
        Me.lblAdditionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdditionSymbol.Location = New System.Drawing.Point(104, 106)
        Me.lblAdditionSymbol.Name = "lblAdditionSymbol"
        Me.lblAdditionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblAdditionSymbol.TabIndex = 7
        Me.lblAdditionSymbol.Text = "+"
        Me.lblAdditionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtAdditionAnswer
        '
        Me.txtAdditionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdditionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtAdditionAnswer.Name = "txtAdditionAnswer"
        Me.txtAdditionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtAdditionAnswer.TabIndex = 6
        Me.txtAdditionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblAddition2
        '
        Me.lblAddition2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddition2.Location = New System.Drawing.Point(148, 102)
        Me.lblAddition2.Name = "lblAddition2"
        Me.lblAddition2.Size = New System.Drawing.Size(111, 52)
        Me.lblAddition2.TabIndex = 5
        Me.lblAddition2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAddition1
        '
        Me.lblAddition1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddition1.Location = New System.Drawing.Point(148, 50)
        Me.lblAddition1.Name = "lblAddition1"
        Me.lblAddition1.Size = New System.Drawing.Size(111, 52)
        Me.lblAddition1.TabIndex = 4
        Me.lblAddition1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerAddition
        '
        Me.btnCheckAnswerAddition.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerAddition.Name = "btnCheckAnswerAddition"
        Me.btnCheckAnswerAddition.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerAddition.TabIndex = 3
        Me.btnCheckAnswerAddition.Text = "Check Answer"
        Me.btnCheckAnswerAddition.UseVisualStyleBackColor = True
        '
        'btnCancelAddition
        '
        Me.btnCancelAddition.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelAddition.Name = "btnCancelAddition"
        Me.btnCancelAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelAddition.TabIndex = 2
        Me.btnCancelAddition.Text = "Cancel"
        Me.btnCancelAddition.UseVisualStyleBackColor = True
        '
        'btnNextAddition
        '
        Me.btnNextAddition.Location = New System.Drawing.Point(352, 286)
        Me.btnNextAddition.Name = "btnNextAddition"
        Me.btnNextAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnNextAddition.TabIndex = 1
        Me.btnNextAddition.Text = "Next"
        Me.btnNextAddition.UseVisualStyleBackColor = True
        '
        'btnStartAddition
        '
        Me.btnStartAddition.Location = New System.Drawing.Point(6, 6)
        Me.btnStartAddition.Name = "btnStartAddition"
        Me.btnStartAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnStartAddition.TabIndex = 0
        Me.btnStartAddition.Text = "Start"
        Me.btnStartAddition.UseVisualStyleBackColor = True
        '
        'tabSubtraction
        '
        Me.tabSubtraction.Controls.Add(Me.lblShowAnswerSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnShowAnswerSubtraction)
        Me.tabSubtraction.Controls.Add(Me.lblSubtractionCompleted)
        Me.tabSubtraction.Controls.Add(Me.lblSubtractionCorrectAnswers)
        Me.tabSubtraction.Controls.Add(Me.lblSubtractionCorrectAnswersTitle)
        Me.tabSubtraction.Controls.Add(Me.txtSubtractionAnswer)
        Me.tabSubtraction.Controls.Add(Me.lblSubtractionSymbol)
        Me.tabSubtraction.Controls.Add(Me.lblSubtraction2)
        Me.tabSubtraction.Controls.Add(Me.lblSubtraction1)
        Me.tabSubtraction.Controls.Add(Me.btnCheckAnswerSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnCancelSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnNextSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnStartSubtraction)
        Me.tabSubtraction.Location = New System.Drawing.Point(4, 22)
        Me.tabSubtraction.Name = "tabSubtraction"
        Me.tabSubtraction.Size = New System.Drawing.Size(508, 311)
        Me.tabSubtraction.TabIndex = 2
        Me.tabSubtraction.Text = "Subtraction"
        Me.tabSubtraction.UseVisualStyleBackColor = True
        '
        'lblSubtractionCorrectAnswers
        '
        Me.lblSubtractionCorrectAnswers.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtractionCorrectAnswers.Location = New System.Drawing.Point(334, 223)
        Me.lblSubtractionCorrectAnswers.Name = "lblSubtractionCorrectAnswers"
        Me.lblSubtractionCorrectAnswers.Size = New System.Drawing.Size(56, 32)
        Me.lblSubtractionCorrectAnswers.TabIndex = 9
        Me.lblSubtractionCorrectAnswers.Text = "0"
        Me.lblSubtractionCorrectAnswers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSubtractionCorrectAnswersTitle
        '
        Me.lblSubtractionCorrectAnswersTitle.Location = New System.Drawing.Point(304, 199)
        Me.lblSubtractionCorrectAnswersTitle.Name = "lblSubtractionCorrectAnswersTitle"
        Me.lblSubtractionCorrectAnswersTitle.Size = New System.Drawing.Size(112, 18)
        Me.lblSubtractionCorrectAnswersTitle.TabIndex = 8
        Me.lblSubtractionCorrectAnswersTitle.Text = "Correct Answers"
        Me.lblSubtractionCorrectAnswersTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtSubtractionAnswer
        '
        Me.txtSubtractionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubtractionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtSubtractionAnswer.Name = "txtSubtractionAnswer"
        Me.txtSubtractionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtSubtractionAnswer.TabIndex = 7
        Me.txtSubtractionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblSubtractionSymbol
        '
        Me.lblSubtractionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtractionSymbol.Location = New System.Drawing.Point(104, 102)
        Me.lblSubtractionSymbol.Name = "lblSubtractionSymbol"
        Me.lblSubtractionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblSubtractionSymbol.TabIndex = 6
        Me.lblSubtractionSymbol.Text = "-"
        Me.lblSubtractionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSubtraction2
        '
        Me.lblSubtraction2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtraction2.Location = New System.Drawing.Point(148, 102)
        Me.lblSubtraction2.Name = "lblSubtraction2"
        Me.lblSubtraction2.Size = New System.Drawing.Size(111, 52)
        Me.lblSubtraction2.TabIndex = 5
        Me.lblSubtraction2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSubtraction1
        '
        Me.lblSubtraction1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtraction1.Location = New System.Drawing.Point(148, 50)
        Me.lblSubtraction1.Name = "lblSubtraction1"
        Me.lblSubtraction1.Size = New System.Drawing.Size(111, 52)
        Me.lblSubtraction1.TabIndex = 4
        Me.lblSubtraction1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerSubtraction
        '
        Me.btnCheckAnswerSubtraction.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerSubtraction.Name = "btnCheckAnswerSubtraction"
        Me.btnCheckAnswerSubtraction.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerSubtraction.TabIndex = 3
        Me.btnCheckAnswerSubtraction.Text = "Check Answer"
        Me.btnCheckAnswerSubtraction.UseVisualStyleBackColor = True
        '
        'btnCancelSubtraction
        '
        Me.btnCancelSubtraction.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelSubtraction.Name = "btnCancelSubtraction"
        Me.btnCancelSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelSubtraction.TabIndex = 2
        Me.btnCancelSubtraction.Text = "Cancel"
        Me.btnCancelSubtraction.UseVisualStyleBackColor = True
        '
        'btnNextSubtraction
        '
        Me.btnNextSubtraction.Location = New System.Drawing.Point(352, 286)
        Me.btnNextSubtraction.Name = "btnNextSubtraction"
        Me.btnNextSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnNextSubtraction.TabIndex = 1
        Me.btnNextSubtraction.Text = "Next"
        Me.btnNextSubtraction.UseVisualStyleBackColor = True
        '
        'btnStartSubtraction
        '
        Me.btnStartSubtraction.BackColor = System.Drawing.Color.Transparent
        Me.btnStartSubtraction.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStartSubtraction.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnStartSubtraction.Location = New System.Drawing.Point(6, 6)
        Me.btnStartSubtraction.Name = "btnStartSubtraction"
        Me.btnStartSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnStartSubtraction.TabIndex = 0
        Me.btnStartSubtraction.Text = "Start"
        Me.btnStartSubtraction.UseVisualStyleBackColor = False
        '
        'tabMultiplication
        '
        Me.tabMultiplication.Controls.Add(Me.lblShowAnswerMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnShowAnswerMultiplication)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplicationCompleted)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplicationCorrectAnswers)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplicationCorrectAnswersTitle)
        Me.tabMultiplication.Controls.Add(Me.txtMultiplicationAnswer)
        Me.tabMultiplication.Controls.Add(Me.Label3)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplication2)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplication1)
        Me.tabMultiplication.Controls.Add(Me.btnCheckAnswerMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnCancelMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnNextMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnStartMultiplication)
        Me.tabMultiplication.Location = New System.Drawing.Point(4, 22)
        Me.tabMultiplication.Name = "tabMultiplication"
        Me.tabMultiplication.Size = New System.Drawing.Size(508, 311)
        Me.tabMultiplication.TabIndex = 3
        Me.tabMultiplication.Text = "Multiplication"
        Me.tabMultiplication.UseVisualStyleBackColor = True
        '
        'lblMultiplicationCorrectAnswers
        '
        Me.lblMultiplicationCorrectAnswers.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplicationCorrectAnswers.Location = New System.Drawing.Point(334, 223)
        Me.lblMultiplicationCorrectAnswers.Name = "lblMultiplicationCorrectAnswers"
        Me.lblMultiplicationCorrectAnswers.Size = New System.Drawing.Size(56, 32)
        Me.lblMultiplicationCorrectAnswers.TabIndex = 9
        Me.lblMultiplicationCorrectAnswers.Text = "0"
        Me.lblMultiplicationCorrectAnswers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMultiplicationCorrectAnswersTitle
        '
        Me.lblMultiplicationCorrectAnswersTitle.Location = New System.Drawing.Point(304, 199)
        Me.lblMultiplicationCorrectAnswersTitle.Name = "lblMultiplicationCorrectAnswersTitle"
        Me.lblMultiplicationCorrectAnswersTitle.Size = New System.Drawing.Size(112, 18)
        Me.lblMultiplicationCorrectAnswersTitle.TabIndex = 8
        Me.lblMultiplicationCorrectAnswersTitle.Text = "Correct Answers"
        Me.lblMultiplicationCorrectAnswersTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtMultiplicationAnswer
        '
        Me.txtMultiplicationAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMultiplicationAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtMultiplicationAnswer.Name = "txtMultiplicationAnswer"
        Me.txtMultiplicationAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtMultiplicationAnswer.TabIndex = 7
        Me.txtMultiplicationAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(104, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 52)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "x"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMultiplication2
        '
        Me.lblMultiplication2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplication2.Location = New System.Drawing.Point(148, 102)
        Me.lblMultiplication2.Name = "lblMultiplication2"
        Me.lblMultiplication2.Size = New System.Drawing.Size(111, 52)
        Me.lblMultiplication2.TabIndex = 5
        Me.lblMultiplication2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMultiplication1
        '
        Me.lblMultiplication1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplication1.Location = New System.Drawing.Point(148, 50)
        Me.lblMultiplication1.Name = "lblMultiplication1"
        Me.lblMultiplication1.Size = New System.Drawing.Size(111, 52)
        Me.lblMultiplication1.TabIndex = 4
        Me.lblMultiplication1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerMultiplication
        '
        Me.btnCheckAnswerMultiplication.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerMultiplication.Name = "btnCheckAnswerMultiplication"
        Me.btnCheckAnswerMultiplication.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerMultiplication.TabIndex = 3
        Me.btnCheckAnswerMultiplication.Text = "Check Answer"
        Me.btnCheckAnswerMultiplication.UseVisualStyleBackColor = True
        '
        'btnCancelMultiplication
        '
        Me.btnCancelMultiplication.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelMultiplication.Name = "btnCancelMultiplication"
        Me.btnCancelMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelMultiplication.TabIndex = 2
        Me.btnCancelMultiplication.Text = "Cancel"
        Me.btnCancelMultiplication.UseVisualStyleBackColor = True
        '
        'btnNextMultiplication
        '
        Me.btnNextMultiplication.Location = New System.Drawing.Point(352, 286)
        Me.btnNextMultiplication.Name = "btnNextMultiplication"
        Me.btnNextMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnNextMultiplication.TabIndex = 1
        Me.btnNextMultiplication.Text = "Next"
        Me.btnNextMultiplication.UseVisualStyleBackColor = True
        '
        'btnStartMultiplication
        '
        Me.btnStartMultiplication.Location = New System.Drawing.Point(6, 6)
        Me.btnStartMultiplication.Name = "btnStartMultiplication"
        Me.btnStartMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnStartMultiplication.TabIndex = 0
        Me.btnStartMultiplication.Text = "Start"
        Me.btnStartMultiplication.UseVisualStyleBackColor = True
        '
        'tabDivision
        '
        Me.tabDivision.Controls.Add(Me.lblShowAnswerDivision)
        Me.tabDivision.Controls.Add(Me.btnShowAnswerDivision)
        Me.tabDivision.Controls.Add(Me.lblDivisionCompleted)
        Me.tabDivision.Controls.Add(Me.lblDivisionCorrectAnswers)
        Me.tabDivision.Controls.Add(Me.lblDivisionCorrectAnswersTitle)
        Me.tabDivision.Controls.Add(Me.lblDivisionSymbol)
        Me.tabDivision.Controls.Add(Me.lblDivision2)
        Me.tabDivision.Controls.Add(Me.lblDivision1)
        Me.tabDivision.Controls.Add(Me.txtDivisionAnswer)
        Me.tabDivision.Controls.Add(Me.btnCheckAnswerDivision)
        Me.tabDivision.Controls.Add(Me.btnCancelDivision)
        Me.tabDivision.Controls.Add(Me.btnNextDivision)
        Me.tabDivision.Controls.Add(Me.btnStartDivision)
        Me.tabDivision.Location = New System.Drawing.Point(4, 22)
        Me.tabDivision.Name = "tabDivision"
        Me.tabDivision.Size = New System.Drawing.Size(508, 311)
        Me.tabDivision.TabIndex = 4
        Me.tabDivision.Text = "Division"
        Me.tabDivision.UseVisualStyleBackColor = True
        '
        'lblDivisionCorrectAnswers
        '
        Me.lblDivisionCorrectAnswers.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivisionCorrectAnswers.Location = New System.Drawing.Point(334, 223)
        Me.lblDivisionCorrectAnswers.Name = "lblDivisionCorrectAnswers"
        Me.lblDivisionCorrectAnswers.Size = New System.Drawing.Size(56, 32)
        Me.lblDivisionCorrectAnswers.TabIndex = 9
        Me.lblDivisionCorrectAnswers.Text = "0"
        Me.lblDivisionCorrectAnswers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDivisionCorrectAnswersTitle
        '
        Me.lblDivisionCorrectAnswersTitle.Location = New System.Drawing.Point(304, 199)
        Me.lblDivisionCorrectAnswersTitle.Name = "lblDivisionCorrectAnswersTitle"
        Me.lblDivisionCorrectAnswersTitle.Size = New System.Drawing.Size(112, 18)
        Me.lblDivisionCorrectAnswersTitle.TabIndex = 8
        Me.lblDivisionCorrectAnswersTitle.Text = "Correct Answers"
        Me.lblDivisionCorrectAnswersTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDivisionSymbol
        '
        Me.lblDivisionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivisionSymbol.Location = New System.Drawing.Point(104, 102)
        Me.lblDivisionSymbol.Name = "lblDivisionSymbol"
        Me.lblDivisionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblDivisionSymbol.TabIndex = 7
        Me.lblDivisionSymbol.Text = "/"
        Me.lblDivisionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDivision2
        '
        Me.lblDivision2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivision2.Location = New System.Drawing.Point(148, 102)
        Me.lblDivision2.Name = "lblDivision2"
        Me.lblDivision2.Size = New System.Drawing.Size(111, 52)
        Me.lblDivision2.TabIndex = 6
        Me.lblDivision2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDivision1
        '
        Me.lblDivision1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivision1.Location = New System.Drawing.Point(148, 50)
        Me.lblDivision1.Name = "lblDivision1"
        Me.lblDivision1.Size = New System.Drawing.Size(111, 52)
        Me.lblDivision1.TabIndex = 5
        Me.lblDivision1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDivisionAnswer
        '
        Me.txtDivisionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDivisionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtDivisionAnswer.Name = "txtDivisionAnswer"
        Me.txtDivisionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtDivisionAnswer.TabIndex = 4
        Me.txtDivisionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCheckAnswerDivision
        '
        Me.btnCheckAnswerDivision.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerDivision.Name = "btnCheckAnswerDivision"
        Me.btnCheckAnswerDivision.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerDivision.TabIndex = 3
        Me.btnCheckAnswerDivision.Text = "Check Answer"
        Me.btnCheckAnswerDivision.UseVisualStyleBackColor = True
        '
        'btnCancelDivision
        '
        Me.btnCancelDivision.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelDivision.Name = "btnCancelDivision"
        Me.btnCancelDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelDivision.TabIndex = 2
        Me.btnCancelDivision.Text = "Cancel"
        Me.btnCancelDivision.UseVisualStyleBackColor = True
        '
        'btnNextDivision
        '
        Me.btnNextDivision.Location = New System.Drawing.Point(352, 286)
        Me.btnNextDivision.Name = "btnNextDivision"
        Me.btnNextDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnNextDivision.TabIndex = 1
        Me.btnNextDivision.Text = "Next"
        Me.btnNextDivision.UseVisualStyleBackColor = True
        '
        'btnStartDivision
        '
        Me.btnStartDivision.Location = New System.Drawing.Point(6, 6)
        Me.btnStartDivision.Name = "btnStartDivision"
        Me.btnStartDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnStartDivision.TabIndex = 0
        Me.btnStartDivision.Text = "Start"
        Me.btnStartDivision.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTitle.Location = New System.Drawing.Point(195, 3)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(153, 25)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "MATH TUTOR"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(447, 374)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(65, 22)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblMaxIterations
        '
        Me.lblMaxIterations.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMaxIterations.Location = New System.Drawing.Point(323, 367)
        Me.lblMaxIterations.Name = "lblMaxIterations"
        Me.lblMaxIterations.Size = New System.Drawing.Size(45, 24)
        Me.lblMaxIterations.TabIndex = 3
        Me.lblMaxIterations.Text = "0"
        Me.lblMaxIterations.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOf
        '
        Me.lblOf.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOf.Location = New System.Drawing.Point(281, 367)
        Me.lblOf.Name = "lblOf"
        Me.lblOf.Size = New System.Drawing.Size(36, 24)
        Me.lblOf.TabIndex = 4
        Me.lblOf.Text = "of"
        '
        'lblIterationWord
        '
        Me.lblIterationWord.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIterationWord.Location = New System.Drawing.Point(130, 367)
        Me.lblIterationWord.Name = "lblIterationWord"
        Me.lblIterationWord.Size = New System.Drawing.Size(94, 23)
        Me.lblIterationWord.TabIndex = 5
        Me.lblIterationWord.Text = "Iteration"
        '
        'lblCurrentIteration
        '
        Me.lblCurrentIteration.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentIteration.Location = New System.Drawing.Point(228, 367)
        Me.lblCurrentIteration.Name = "lblCurrentIteration"
        Me.lblCurrentIteration.Size = New System.Drawing.Size(47, 23)
        Me.lblCurrentIteration.TabIndex = 6
        Me.lblCurrentIteration.Text = "0"
        Me.lblCurrentIteration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSubtractionCompleted
        '
        Me.lblSubtractionCompleted.AutoSize = True
        Me.lblSubtractionCompleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtractionCompleted.Location = New System.Drawing.Point(367, 29)
        Me.lblSubtractionCompleted.Name = "lblSubtractionCompleted"
        Me.lblSubtractionCompleted.Size = New System.Drawing.Size(115, 25)
        Me.lblSubtractionCompleted.TabIndex = 10
        Me.lblSubtractionCompleted.Text = "Completed"
        Me.lblSubtractionCompleted.Visible = False
        '
        'lblMultiplicationCompleted
        '
        Me.lblMultiplicationCompleted.AutoSize = True
        Me.lblMultiplicationCompleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplicationCompleted.Location = New System.Drawing.Point(367, 29)
        Me.lblMultiplicationCompleted.Name = "lblMultiplicationCompleted"
        Me.lblMultiplicationCompleted.Size = New System.Drawing.Size(115, 25)
        Me.lblMultiplicationCompleted.TabIndex = 10
        Me.lblMultiplicationCompleted.Text = "Completed"
        Me.lblMultiplicationCompleted.Visible = False
        '
        'lblDivisionCompleted
        '
        Me.lblDivisionCompleted.AutoSize = True
        Me.lblDivisionCompleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivisionCompleted.Location = New System.Drawing.Point(367, 29)
        Me.lblDivisionCompleted.Name = "lblDivisionCompleted"
        Me.lblDivisionCompleted.Size = New System.Drawing.Size(115, 25)
        Me.lblDivisionCompleted.TabIndex = 10
        Me.lblDivisionCompleted.Text = "Completed"
        Me.lblDivisionCompleted.Visible = False
        '
        'btnShowAnswerAddition
        '
        Me.btnShowAnswerAddition.Location = New System.Drawing.Point(17, 223)
        Me.btnShowAnswerAddition.Name = "btnShowAnswerAddition"
        Me.btnShowAnswerAddition.Size = New System.Drawing.Size(114, 22)
        Me.btnShowAnswerAddition.TabIndex = 11
        Me.btnShowAnswerAddition.Text = "Show Answer"
        Me.btnShowAnswerAddition.UseVisualStyleBackColor = True
        '
        'lblShowAnswerAddition
        '
        Me.lblShowAnswerAddition.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShowAnswerAddition.Location = New System.Drawing.Point(148, 204)
        Me.lblShowAnswerAddition.Name = "lblShowAnswerAddition"
        Me.lblShowAnswerAddition.Size = New System.Drawing.Size(111, 52)
        Me.lblShowAnswerAddition.TabIndex = 12
        Me.lblShowAnswerAddition.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnShowAnswerSubtraction
        '
        Me.btnShowAnswerSubtraction.Location = New System.Drawing.Point(17, 223)
        Me.btnShowAnswerSubtraction.Name = "btnShowAnswerSubtraction"
        Me.btnShowAnswerSubtraction.Size = New System.Drawing.Size(114, 22)
        Me.btnShowAnswerSubtraction.TabIndex = 11
        Me.btnShowAnswerSubtraction.Text = "Show Answer"
        Me.btnShowAnswerSubtraction.UseVisualStyleBackColor = True
        Me.btnShowAnswerSubtraction.Visible = False
        '
        'lblShowAnswerSubtraction
        '
        Me.lblShowAnswerSubtraction.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShowAnswerSubtraction.Location = New System.Drawing.Point(148, 204)
        Me.lblShowAnswerSubtraction.Name = "lblShowAnswerSubtraction"
        Me.lblShowAnswerSubtraction.Size = New System.Drawing.Size(111, 52)
        Me.lblShowAnswerSubtraction.TabIndex = 12
        Me.lblShowAnswerSubtraction.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblShowAnswerSubtraction.Visible = False
        '
        'btnShowAnswerMultiplication
        '
        Me.btnShowAnswerMultiplication.Location = New System.Drawing.Point(17, 223)
        Me.btnShowAnswerMultiplication.Name = "btnShowAnswerMultiplication"
        Me.btnShowAnswerMultiplication.Size = New System.Drawing.Size(114, 22)
        Me.btnShowAnswerMultiplication.TabIndex = 11
        Me.btnShowAnswerMultiplication.Text = "Show Answer"
        Me.btnShowAnswerMultiplication.UseVisualStyleBackColor = True
        Me.btnShowAnswerMultiplication.Visible = False
        '
        'lblShowAnswerMultiplication
        '
        Me.lblShowAnswerMultiplication.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShowAnswerMultiplication.Location = New System.Drawing.Point(148, 204)
        Me.lblShowAnswerMultiplication.Name = "lblShowAnswerMultiplication"
        Me.lblShowAnswerMultiplication.Size = New System.Drawing.Size(111, 52)
        Me.lblShowAnswerMultiplication.TabIndex = 12
        Me.lblShowAnswerMultiplication.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblShowAnswerMultiplication.Visible = False
        '
        'btnShowAnswerDivision
        '
        Me.btnShowAnswerDivision.Location = New System.Drawing.Point(17, 223)
        Me.btnShowAnswerDivision.Name = "btnShowAnswerDivision"
        Me.btnShowAnswerDivision.Size = New System.Drawing.Size(114, 22)
        Me.btnShowAnswerDivision.TabIndex = 11
        Me.btnShowAnswerDivision.Text = "Show Answer"
        Me.btnShowAnswerDivision.UseVisualStyleBackColor = True
        Me.btnShowAnswerDivision.Visible = False
        '
        'lblShowAnswerDivision
        '
        Me.lblShowAnswerDivision.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShowAnswerDivision.Location = New System.Drawing.Point(148, 204)
        Me.lblShowAnswerDivision.Name = "lblShowAnswerDivision"
        Me.lblShowAnswerDivision.Size = New System.Drawing.Size(111, 52)
        Me.lblShowAnswerDivision.TabIndex = 12
        Me.lblShowAnswerDivision.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblShowAnswerDivision.Visible = False
        '
        'MathTutor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(521, 403)
        Me.Controls.Add(Me.lblCurrentIteration)
        Me.Controls.Add(Me.lblIterationWord)
        Me.Controls.Add(Me.lblOf)
        Me.Controls.Add(Me.lblMaxIterations)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "MathTutor"
        Me.Text = "Math Tutor"
        Me.TabControl1.ResumeLayout(False)
        Me.tabOptions.ResumeLayout(False)
        Me.tabOptions.PerformLayout()
        Me.tabAddition.ResumeLayout(False)
        Me.tabAddition.PerformLayout()
        Me.tabSubtraction.ResumeLayout(False)
        Me.tabSubtraction.PerformLayout()
        Me.tabMultiplication.ResumeLayout(False)
        Me.tabMultiplication.PerformLayout()
        Me.tabDivision.ResumeLayout(False)
        Me.tabDivision.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tabOptions As TabPage
    Friend WithEvents tabAddition As TabPage
    Friend WithEvents btnCancelAddition As Button
    Friend WithEvents btnNextAddition As Button
    Friend WithEvents btnStartAddition As Button
    Friend WithEvents tabSubtraction As TabPage
    Friend WithEvents btnStartSubtraction As Button
    Friend WithEvents tabMultiplication As TabPage
    Friend WithEvents tabDivision As TabPage
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCancelSubtraction As Button
    Friend WithEvents btnNextSubtraction As Button
    Friend WithEvents btnCancelMultiplication As Button
    Friend WithEvents btnNextMultiplication As Button
    Friend WithEvents btnStartMultiplication As Button
    Friend WithEvents btnCancelDivision As Button
    Friend WithEvents btnNextDivision As Button
    Friend WithEvents btnStartDivision As Button
    Friend WithEvents lblMathLevel As Label
    Friend WithEvents cboMathLevel As ComboBox
    Friend WithEvents chkShowAnswers As CheckBox
    Friend WithEvents lblIterations As Label
    Friend WithEvents cboIterations As ComboBox
    Friend WithEvents btnCheckAnswerAddition As Button
    Friend WithEvents btnCheckAnswerSubtraction As Button
    Friend WithEvents btnCheckAnswerMultiplication As Button
    Friend WithEvents btnCheckAnswerDivision As Button
    Friend WithEvents lblAdditionSymbol As Label
    Friend WithEvents txtAdditionAnswer As TextBox
    Friend WithEvents lblAddition2 As Label
    Friend WithEvents lblAddition1 As Label
    Friend WithEvents txtSubtractionAnswer As TextBox
    Friend WithEvents lblSubtractionSymbol As Label
    Friend WithEvents lblSubtraction2 As Label
    Friend WithEvents lblSubtraction1 As Label
    Friend WithEvents txtMultiplicationAnswer As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblMultiplication2 As Label
    Friend WithEvents lblMultiplication1 As Label
    Friend WithEvents lblDivision1 As Label
    Friend WithEvents txtDivisionAnswer As TextBox
    Friend WithEvents lblDivisionSymbol As Label
    Friend WithEvents lblDivision2 As Label
    Friend WithEvents lblMaxIterations As Label
    Friend WithEvents lblAdditionCorrectAnswers As Label
    Friend WithEvents lblAdditionCorrectAnswersTitle As Label
    Friend WithEvents lblOf As Label
    Friend WithEvents lblIterationWord As Label
    Friend WithEvents lblCurrentIteration As Label
    Friend WithEvents lblSubtractionCorrectAnswers As Label
    Friend WithEvents lblSubtractionCorrectAnswersTitle As Label
    Friend WithEvents lblMultiplicationCorrectAnswers As Label
    Friend WithEvents lblMultiplicationCorrectAnswersTitle As Label
    Friend WithEvents lblDivisionCorrectAnswers As Label
    Friend WithEvents lblDivisionCorrectAnswersTitle As Label
    Friend WithEvents lblAdditionCompleted As Label
    Friend WithEvents lblSubtractionCompleted As Label
    Friend WithEvents lblMultiplicationCompleted As Label
    Friend WithEvents lblDivisionCompleted As Label
    Friend WithEvents lblShowAnswerAddition As Label
    Friend WithEvents btnShowAnswerAddition As Button
    Friend WithEvents lblShowAnswerSubtraction As Label
    Friend WithEvents btnShowAnswerSubtraction As Button
    Friend WithEvents lblShowAnswerMultiplication As Label
    Friend WithEvents btnShowAnswerMultiplication As Button
    Friend WithEvents lblShowAnswerDivision As Label
    Friend WithEvents btnShowAnswerDivision As Button
End Class
