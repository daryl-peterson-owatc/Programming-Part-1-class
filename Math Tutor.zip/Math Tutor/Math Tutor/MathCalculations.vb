﻿Module MathCalculations

End Module
