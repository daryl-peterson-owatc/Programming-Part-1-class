﻿Public Class MathTutor
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnSaveOptions_Click(sender As Object, e As EventArgs)
        Dim selectedCboMathLevel As Object
        Dim selectedCboIterations As Object
        Dim selectedChkShowAnswers As Object
        selectedCboMathLevel = cboMathLevel.SelectedItem
        selectedCboIterations = cboIterations.SelectedItem
        selectedChkShowAnswers = chkShowAnswers.Checked

        MessageBox.Show("Math Level: " & selectedCboMathLevel.ToString() & Microsoft.VisualBasic.Constants.vbCrLf _
                         & "Iterations: " & selectedCboIterations.ToString() & Microsoft.VisualBasic.Constants.vbCrLf _
                         & "Show Answers: " & selectedChkShowAnswers)
    End Sub

    Private Sub btnCheckAnswerAddition_Click(sender As Object, e As EventArgs) Handles btnCheckAnswerAddition.Click

    End Sub
    Property ShowAnswers As Boolean
        Get
            Return chkShowAnswers.Checked
        End Get
        Set(value As Boolean)
            chkShowAnswers.Checked = value
        End Set
    End Property
    Property GradeLevel As Integer
        Get
            Return cboMathLevel.SelectedIndex + 1
        End Get
        Set(value As Integer)
            cboMathLevel.SelectedIndex = value
        End Set
    End Property
    Property MaxIterations As Integer
        Get
            Return cboIterations.SelectedItem
        End Get
        Set(value As Integer)
            cboIterations.SelectedItem = value
        End Set
    End Property
    Public Property FirstNumber As Double = 0
    Public Property SecondNumber As Double = 0
    Public Property TestAnswer As Double = 0
    Public Property CorrectAnswer As Double = 0
    Public Property CurrentIteration As Integer = 0
    Public Property Score As Integer = 0

    Private Function RandomNumber()
        Randomize()
        Return Int((10 * Rnd()) + 1)
    End Function

    Private Sub btnStartAddition_Click(sender As Object, e As EventArgs) Handles btnStartAddition.Click
        lblAddition1.Text = RandomNumber()
        lblAddition2.Text = RandomNumber()
    End Sub

    Private Sub btnStartSubtraction_Click(sender As Object, e As EventArgs) Handles btnStartSubtraction.Click
        lblSubtraction1 = RandomNumber()
        lblSubtraction2 = RandomNumber()
    End Sub

    Private Sub btnStartMultiplication_Click(sender As Object, e As EventArgs) Handles btnStartMultiplication.Click
        lblMultiplication1 = RandomNumber()
        lblMultiplication2 = RandomNumber()
    End Sub

    Private Sub btnStartDivision_Click(sender As Object, e As EventArgs) Handles btnStartDivision.Click
        lblDivision1 = RandomNumber()
        lblDivision2 = RandomNumber()
    End Sub

    Private Sub btnNextAddition_Click(sender As Object, e As EventArgs) Handles btnNextAddition.Click
        lblAddition1.Text = RandomNumber()
        lblAddition2.Text = RandomNumber()
    End Sub

    Private Sub btnNextSubtraction_Click(sender As Object, e As EventArgs) Handles btnNextSubtraction.Click
        lblSubtraction1 = RandomNumber()
        lblSubtraction2 = RandomNumber()
    End Sub

    Private Sub btnNextMultiplication_Click(sender As Object, e As EventArgs) Handles btnNextMultiplication.Click
        lblMultiplication1 = RandomNumber()
        lblMultiplication2 = RandomNumber()
    End Sub

    Private Sub btnNextDivision_Click(sender As Object, e As EventArgs) Handles btnNextDivision.Click
        lblDivision1 = RandomNumber()
        lblDivision2 = RandomNumber()
    End Sub
End Class
