﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MathTutor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabOptions = New System.Windows.Forms.TabPage()
        Me.lblIterations = New System.Windows.Forms.Label()
        Me.cboIterations = New System.Windows.Forms.ComboBox()
        Me.chkShowAnswers = New System.Windows.Forms.CheckBox()
        Me.lblMathLevel = New System.Windows.Forms.Label()
        Me.cboMathLevel = New System.Windows.Forms.ComboBox()
        Me.tabAddition = New System.Windows.Forms.TabPage()
        Me.lblAdditionSymbol = New System.Windows.Forms.Label()
        Me.txtAdditionAnswer = New System.Windows.Forms.TextBox()
        Me.lblAddition2 = New System.Windows.Forms.Label()
        Me.lblAddition1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerAddition = New System.Windows.Forms.Button()
        Me.btnCancelAddition = New System.Windows.Forms.Button()
        Me.btnNextAddition = New System.Windows.Forms.Button()
        Me.btnStartAddition = New System.Windows.Forms.Button()
        Me.tabSubtraction = New System.Windows.Forms.TabPage()
        Me.txtSubtractionAnswer = New System.Windows.Forms.TextBox()
        Me.lblSubtractionSymbol = New System.Windows.Forms.Label()
        Me.lblSubtraction2 = New System.Windows.Forms.Label()
        Me.lblSubtraction1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerSubtraction = New System.Windows.Forms.Button()
        Me.btnCancelSubtraction = New System.Windows.Forms.Button()
        Me.btnNextSubtraction = New System.Windows.Forms.Button()
        Me.btnStartSubtraction = New System.Windows.Forms.Button()
        Me.tabMultiplication = New System.Windows.Forms.TabPage()
        Me.txtMultiplicationAnswer = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblMultiplication2 = New System.Windows.Forms.Label()
        Me.lblMultiplication1 = New System.Windows.Forms.Label()
        Me.btnCheckAnswerMultiplication = New System.Windows.Forms.Button()
        Me.btnCancelMultiplication = New System.Windows.Forms.Button()
        Me.btnNextMultiplication = New System.Windows.Forms.Button()
        Me.btnStartMultiplication = New System.Windows.Forms.Button()
        Me.tabDivision = New System.Windows.Forms.TabPage()
        Me.lblDivisionSymbol = New System.Windows.Forms.Label()
        Me.lblDivision2 = New System.Windows.Forms.Label()
        Me.lblDivision1 = New System.Windows.Forms.Label()
        Me.txtDivisionAnswer = New System.Windows.Forms.TextBox()
        Me.btnCheckAnswerDivision = New System.Windows.Forms.Button()
        Me.btnCancelDivision = New System.Windows.Forms.Button()
        Me.btnNextDivision = New System.Windows.Forms.Button()
        Me.btnStartDivision = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.tabOptions.SuspendLayout()
        Me.tabAddition.SuspendLayout()
        Me.tabSubtraction.SuspendLayout()
        Me.tabMultiplication.SuspendLayout()
        Me.tabDivision.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabOptions)
        Me.TabControl1.Controls.Add(Me.tabAddition)
        Me.TabControl1.Controls.Add(Me.tabSubtraction)
        Me.TabControl1.Controls.Add(Me.tabMultiplication)
        Me.TabControl1.Controls.Add(Me.tabDivision)
        Me.TabControl1.Location = New System.Drawing.Point(3, 31)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(516, 337)
        Me.TabControl1.TabIndex = 0
        '
        'tabOptions
        '
        Me.tabOptions.Controls.Add(Me.lblIterations)
        Me.tabOptions.Controls.Add(Me.cboIterations)
        Me.tabOptions.Controls.Add(Me.chkShowAnswers)
        Me.tabOptions.Controls.Add(Me.lblMathLevel)
        Me.tabOptions.Controls.Add(Me.cboMathLevel)
        Me.tabOptions.Location = New System.Drawing.Point(4, 22)
        Me.tabOptions.Name = "tabOptions"
        Me.tabOptions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabOptions.Size = New System.Drawing.Size(508, 311)
        Me.tabOptions.TabIndex = 0
        Me.tabOptions.Text = "Options"
        Me.tabOptions.UseVisualStyleBackColor = True
        '
        'lblIterations
        '
        Me.lblIterations.AutoSize = True
        Me.lblIterations.Location = New System.Drawing.Point(17, 54)
        Me.lblIterations.Name = "lblIterations"
        Me.lblIterations.Size = New System.Drawing.Size(102, 13)
        Me.lblIterations.TabIndex = 4
        Me.lblIterations.Text = "Number of Iterations"
        '
        'cboIterations
        '
        Me.cboIterations.FormattingEnabled = True
        Me.cboIterations.Items.AddRange(New Object() {"10", "25", "50", "100"})
        Me.cboIterations.Location = New System.Drawing.Point(14, 74)
        Me.cboIterations.Name = "cboIterations"
        Me.cboIterations.Size = New System.Drawing.Size(105, 21)
        Me.cboIterations.TabIndex = 1
        '
        'chkShowAnswers
        '
        Me.chkShowAnswers.AutoSize = True
        Me.chkShowAnswers.Location = New System.Drawing.Point(17, 119)
        Me.chkShowAnswers.Name = "chkShowAnswers"
        Me.chkShowAnswers.Size = New System.Drawing.Size(96, 17)
        Me.chkShowAnswers.TabIndex = 2
        Me.chkShowAnswers.Text = "Show Answers"
        Me.chkShowAnswers.UseVisualStyleBackColor = True
        '
        'lblMathLevel
        '
        Me.lblMathLevel.AutoSize = True
        Me.lblMathLevel.Location = New System.Drawing.Point(11, 5)
        Me.lblMathLevel.Name = "lblMathLevel"
        Me.lblMathLevel.Size = New System.Drawing.Size(60, 13)
        Me.lblMathLevel.TabIndex = 3
        Me.lblMathLevel.Text = "Math Level"
        '
        'cboMathLevel
        '
        Me.cboMathLevel.FormattingEnabled = True
        Me.cboMathLevel.Items.AddRange(New Object() {"Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"})
        Me.cboMathLevel.Location = New System.Drawing.Point(14, 21)
        Me.cboMathLevel.Name = "cboMathLevel"
        Me.cboMathLevel.Size = New System.Drawing.Size(105, 21)
        Me.cboMathLevel.TabIndex = 0
        '
        'tabAddition
        '
        Me.tabAddition.Controls.Add(Me.lblAdditionSymbol)
        Me.tabAddition.Controls.Add(Me.txtAdditionAnswer)
        Me.tabAddition.Controls.Add(Me.lblAddition2)
        Me.tabAddition.Controls.Add(Me.lblAddition1)
        Me.tabAddition.Controls.Add(Me.btnCheckAnswerAddition)
        Me.tabAddition.Controls.Add(Me.btnCancelAddition)
        Me.tabAddition.Controls.Add(Me.btnNextAddition)
        Me.tabAddition.Controls.Add(Me.btnStartAddition)
        Me.tabAddition.Location = New System.Drawing.Point(4, 22)
        Me.tabAddition.Name = "tabAddition"
        Me.tabAddition.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAddition.Size = New System.Drawing.Size(508, 311)
        Me.tabAddition.TabIndex = 1
        Me.tabAddition.Text = "Addition"
        Me.tabAddition.UseVisualStyleBackColor = True
        '
        'lblAdditionSymbol
        '
        Me.lblAdditionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdditionSymbol.Location = New System.Drawing.Point(104, 106)
        Me.lblAdditionSymbol.Name = "lblAdditionSymbol"
        Me.lblAdditionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblAdditionSymbol.TabIndex = 7
        Me.lblAdditionSymbol.Text = "+"
        Me.lblAdditionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtAdditionAnswer
        '
        Me.txtAdditionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdditionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtAdditionAnswer.Name = "txtAdditionAnswer"
        Me.txtAdditionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtAdditionAnswer.TabIndex = 6
        Me.txtAdditionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblAddition2
        '
        Me.lblAddition2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddition2.Location = New System.Drawing.Point(148, 102)
        Me.lblAddition2.Name = "lblAddition2"
        Me.lblAddition2.Size = New System.Drawing.Size(111, 52)
        Me.lblAddition2.TabIndex = 5
        Me.lblAddition2.Text = "1234"
        Me.lblAddition2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAddition1
        '
        Me.lblAddition1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddition1.Location = New System.Drawing.Point(148, 50)
        Me.lblAddition1.Name = "lblAddition1"
        Me.lblAddition1.Size = New System.Drawing.Size(111, 52)
        Me.lblAddition1.TabIndex = 4
        Me.lblAddition1.Text = "1234"
        Me.lblAddition1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerAddition
        '
        Me.btnCheckAnswerAddition.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerAddition.Name = "btnCheckAnswerAddition"
        Me.btnCheckAnswerAddition.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerAddition.TabIndex = 3
        Me.btnCheckAnswerAddition.Text = "Check Answer"
        Me.btnCheckAnswerAddition.UseVisualStyleBackColor = True
        '
        'btnCancelAddition
        '
        Me.btnCancelAddition.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelAddition.Name = "btnCancelAddition"
        Me.btnCancelAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelAddition.TabIndex = 2
        Me.btnCancelAddition.Text = "Cancel"
        Me.btnCancelAddition.UseVisualStyleBackColor = True
        '
        'btnNextAddition
        '
        Me.btnNextAddition.Location = New System.Drawing.Point(352, 286)
        Me.btnNextAddition.Name = "btnNextAddition"
        Me.btnNextAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnNextAddition.TabIndex = 1
        Me.btnNextAddition.Text = "Next"
        Me.btnNextAddition.UseVisualStyleBackColor = True
        '
        'btnStartAddition
        '
        Me.btnStartAddition.Location = New System.Drawing.Point(6, 6)
        Me.btnStartAddition.Name = "btnStartAddition"
        Me.btnStartAddition.Size = New System.Drawing.Size(65, 22)
        Me.btnStartAddition.TabIndex = 0
        Me.btnStartAddition.Text = "Start"
        Me.btnStartAddition.UseVisualStyleBackColor = True
        '
        'tabSubtraction
        '
        Me.tabSubtraction.Controls.Add(Me.txtSubtractionAnswer)
        Me.tabSubtraction.Controls.Add(Me.lblSubtractionSymbol)
        Me.tabSubtraction.Controls.Add(Me.lblSubtraction2)
        Me.tabSubtraction.Controls.Add(Me.lblSubtraction1)
        Me.tabSubtraction.Controls.Add(Me.btnCheckAnswerSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnCancelSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnNextSubtraction)
        Me.tabSubtraction.Controls.Add(Me.btnStartSubtraction)
        Me.tabSubtraction.Location = New System.Drawing.Point(4, 22)
        Me.tabSubtraction.Name = "tabSubtraction"
        Me.tabSubtraction.Size = New System.Drawing.Size(508, 311)
        Me.tabSubtraction.TabIndex = 2
        Me.tabSubtraction.Text = "Subtraction"
        Me.tabSubtraction.UseVisualStyleBackColor = True
        '
        'txtSubtractionAnswer
        '
        Me.txtSubtractionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubtractionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtSubtractionAnswer.Name = "txtSubtractionAnswer"
        Me.txtSubtractionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtSubtractionAnswer.TabIndex = 7
        Me.txtSubtractionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblSubtractionSymbol
        '
        Me.lblSubtractionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtractionSymbol.Location = New System.Drawing.Point(104, 102)
        Me.lblSubtractionSymbol.Name = "lblSubtractionSymbol"
        Me.lblSubtractionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblSubtractionSymbol.TabIndex = 6
        Me.lblSubtractionSymbol.Text = "-"
        Me.lblSubtractionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSubtraction2
        '
        Me.lblSubtraction2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtraction2.Location = New System.Drawing.Point(148, 102)
        Me.lblSubtraction2.Name = "lblSubtraction2"
        Me.lblSubtraction2.Size = New System.Drawing.Size(111, 52)
        Me.lblSubtraction2.TabIndex = 5
        Me.lblSubtraction2.Text = "1234"
        Me.lblSubtraction2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSubtraction1
        '
        Me.lblSubtraction1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtraction1.Location = New System.Drawing.Point(148, 50)
        Me.lblSubtraction1.Name = "lblSubtraction1"
        Me.lblSubtraction1.Size = New System.Drawing.Size(111, 52)
        Me.lblSubtraction1.TabIndex = 4
        Me.lblSubtraction1.Text = "1234"
        Me.lblSubtraction1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerSubtraction
        '
        Me.btnCheckAnswerSubtraction.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerSubtraction.Name = "btnCheckAnswerSubtraction"
        Me.btnCheckAnswerSubtraction.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerSubtraction.TabIndex = 3
        Me.btnCheckAnswerSubtraction.Text = "Check Answer"
        Me.btnCheckAnswerSubtraction.UseVisualStyleBackColor = True
        '
        'btnCancelSubtraction
        '
        Me.btnCancelSubtraction.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelSubtraction.Name = "btnCancelSubtraction"
        Me.btnCancelSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelSubtraction.TabIndex = 2
        Me.btnCancelSubtraction.Text = "Cancel"
        Me.btnCancelSubtraction.UseVisualStyleBackColor = True
        '
        'btnNextSubtraction
        '
        Me.btnNextSubtraction.Location = New System.Drawing.Point(352, 286)
        Me.btnNextSubtraction.Name = "btnNextSubtraction"
        Me.btnNextSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnNextSubtraction.TabIndex = 1
        Me.btnNextSubtraction.Text = "Next"
        Me.btnNextSubtraction.UseVisualStyleBackColor = True
        '
        'btnStartSubtraction
        '
        Me.btnStartSubtraction.BackColor = System.Drawing.Color.Transparent
        Me.btnStartSubtraction.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStartSubtraction.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnStartSubtraction.Location = New System.Drawing.Point(6, 6)
        Me.btnStartSubtraction.Name = "btnStartSubtraction"
        Me.btnStartSubtraction.Size = New System.Drawing.Size(65, 22)
        Me.btnStartSubtraction.TabIndex = 0
        Me.btnStartSubtraction.Text = "Start"
        Me.btnStartSubtraction.UseVisualStyleBackColor = False
        '
        'tabMultiplication
        '
        Me.tabMultiplication.Controls.Add(Me.txtMultiplicationAnswer)
        Me.tabMultiplication.Controls.Add(Me.Label3)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplication2)
        Me.tabMultiplication.Controls.Add(Me.lblMultiplication1)
        Me.tabMultiplication.Controls.Add(Me.btnCheckAnswerMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnCancelMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnNextMultiplication)
        Me.tabMultiplication.Controls.Add(Me.btnStartMultiplication)
        Me.tabMultiplication.Location = New System.Drawing.Point(4, 22)
        Me.tabMultiplication.Name = "tabMultiplication"
        Me.tabMultiplication.Size = New System.Drawing.Size(508, 311)
        Me.tabMultiplication.TabIndex = 3
        Me.tabMultiplication.Text = "Multiplication"
        Me.tabMultiplication.UseVisualStyleBackColor = True
        '
        'txtMultiplicationAnswer
        '
        Me.txtMultiplicationAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMultiplicationAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtMultiplicationAnswer.Name = "txtMultiplicationAnswer"
        Me.txtMultiplicationAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtMultiplicationAnswer.TabIndex = 7
        Me.txtMultiplicationAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(104, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 52)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "x"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMultiplication2
        '
        Me.lblMultiplication2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplication2.Location = New System.Drawing.Point(148, 102)
        Me.lblMultiplication2.Name = "lblMultiplication2"
        Me.lblMultiplication2.Size = New System.Drawing.Size(111, 52)
        Me.lblMultiplication2.TabIndex = 5
        Me.lblMultiplication2.Text = "1234"
        Me.lblMultiplication2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMultiplication1
        '
        Me.lblMultiplication1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMultiplication1.Location = New System.Drawing.Point(148, 50)
        Me.lblMultiplication1.Name = "lblMultiplication1"
        Me.lblMultiplication1.Size = New System.Drawing.Size(111, 52)
        Me.lblMultiplication1.TabIndex = 4
        Me.lblMultiplication1.Text = "1234"
        Me.lblMultiplication1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCheckAnswerMultiplication
        '
        Me.btnCheckAnswerMultiplication.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerMultiplication.Name = "btnCheckAnswerMultiplication"
        Me.btnCheckAnswerMultiplication.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerMultiplication.TabIndex = 3
        Me.btnCheckAnswerMultiplication.Text = "Check Answer"
        Me.btnCheckAnswerMultiplication.UseVisualStyleBackColor = True
        '
        'btnCancelMultiplication
        '
        Me.btnCancelMultiplication.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelMultiplication.Name = "btnCancelMultiplication"
        Me.btnCancelMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelMultiplication.TabIndex = 2
        Me.btnCancelMultiplication.Text = "Cancel"
        Me.btnCancelMultiplication.UseVisualStyleBackColor = True
        '
        'btnNextMultiplication
        '
        Me.btnNextMultiplication.Location = New System.Drawing.Point(352, 286)
        Me.btnNextMultiplication.Name = "btnNextMultiplication"
        Me.btnNextMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnNextMultiplication.TabIndex = 1
        Me.btnNextMultiplication.Text = "Next"
        Me.btnNextMultiplication.UseVisualStyleBackColor = True
        '
        'btnStartMultiplication
        '
        Me.btnStartMultiplication.Location = New System.Drawing.Point(6, 6)
        Me.btnStartMultiplication.Name = "btnStartMultiplication"
        Me.btnStartMultiplication.Size = New System.Drawing.Size(65, 22)
        Me.btnStartMultiplication.TabIndex = 0
        Me.btnStartMultiplication.Text = "Start"
        Me.btnStartMultiplication.UseVisualStyleBackColor = True
        '
        'tabDivision
        '
        Me.tabDivision.Controls.Add(Me.lblDivisionSymbol)
        Me.tabDivision.Controls.Add(Me.lblDivision2)
        Me.tabDivision.Controls.Add(Me.lblDivision1)
        Me.tabDivision.Controls.Add(Me.txtDivisionAnswer)
        Me.tabDivision.Controls.Add(Me.btnCheckAnswerDivision)
        Me.tabDivision.Controls.Add(Me.btnCancelDivision)
        Me.tabDivision.Controls.Add(Me.btnNextDivision)
        Me.tabDivision.Controls.Add(Me.btnStartDivision)
        Me.tabDivision.Location = New System.Drawing.Point(4, 22)
        Me.tabDivision.Name = "tabDivision"
        Me.tabDivision.Size = New System.Drawing.Size(508, 311)
        Me.tabDivision.TabIndex = 4
        Me.tabDivision.Text = "Division"
        Me.tabDivision.UseVisualStyleBackColor = True
        '
        'lblDivisionSymbol
        '
        Me.lblDivisionSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivisionSymbol.Location = New System.Drawing.Point(104, 102)
        Me.lblDivisionSymbol.Name = "lblDivisionSymbol"
        Me.lblDivisionSymbol.Size = New System.Drawing.Size(38, 52)
        Me.lblDivisionSymbol.TabIndex = 7
        Me.lblDivisionSymbol.Text = "/"
        Me.lblDivisionSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDivision2
        '
        Me.lblDivision2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivision2.Location = New System.Drawing.Point(148, 102)
        Me.lblDivision2.Name = "lblDivision2"
        Me.lblDivision2.Size = New System.Drawing.Size(111, 52)
        Me.lblDivision2.TabIndex = 6
        Me.lblDivision2.Text = "1234"
        Me.lblDivision2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDivision1
        '
        Me.lblDivision1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDivision1.Location = New System.Drawing.Point(148, 50)
        Me.lblDivision1.Name = "lblDivision1"
        Me.lblDivision1.Size = New System.Drawing.Size(111, 52)
        Me.lblDivision1.TabIndex = 5
        Me.lblDivision1.Text = "1234"
        Me.lblDivision1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDivisionAnswer
        '
        Me.txtDivisionAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDivisionAnswer.Location = New System.Drawing.Point(148, 157)
        Me.txtDivisionAnswer.Name = "txtDivisionAnswer"
        Me.txtDivisionAnswer.Size = New System.Drawing.Size(111, 44)
        Me.txtDivisionAnswer.TabIndex = 4
        Me.txtDivisionAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCheckAnswerDivision
        '
        Me.btnCheckAnswerDivision.Location = New System.Drawing.Point(303, 166)
        Me.btnCheckAnswerDivision.Name = "btnCheckAnswerDivision"
        Me.btnCheckAnswerDivision.Size = New System.Drawing.Size(114, 22)
        Me.btnCheckAnswerDivision.TabIndex = 3
        Me.btnCheckAnswerDivision.Text = "Check Answer"
        Me.btnCheckAnswerDivision.UseVisualStyleBackColor = True
        '
        'btnCancelDivision
        '
        Me.btnCancelDivision.Location = New System.Drawing.Point(440, 286)
        Me.btnCancelDivision.Name = "btnCancelDivision"
        Me.btnCancelDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnCancelDivision.TabIndex = 2
        Me.btnCancelDivision.Text = "Cancel"
        Me.btnCancelDivision.UseVisualStyleBackColor = True
        '
        'btnNextDivision
        '
        Me.btnNextDivision.Location = New System.Drawing.Point(352, 286)
        Me.btnNextDivision.Name = "btnNextDivision"
        Me.btnNextDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnNextDivision.TabIndex = 1
        Me.btnNextDivision.Text = "Next"
        Me.btnNextDivision.UseVisualStyleBackColor = True
        '
        'btnStartDivision
        '
        Me.btnStartDivision.Location = New System.Drawing.Point(6, 6)
        Me.btnStartDivision.Name = "btnStartDivision"
        Me.btnStartDivision.Size = New System.Drawing.Size(65, 22)
        Me.btnStartDivision.TabIndex = 0
        Me.btnStartDivision.Text = "Start"
        Me.btnStartDivision.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(195, 3)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(153, 25)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "MATH TUTOR"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(447, 374)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(65, 22)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'MathTutor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(521, 403)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "MathTutor"
        Me.Text = "Math Tutor"
        Me.TabControl1.ResumeLayout(False)
        Me.tabOptions.ResumeLayout(False)
        Me.tabOptions.PerformLayout()
        Me.tabAddition.ResumeLayout(False)
        Me.tabAddition.PerformLayout()
        Me.tabSubtraction.ResumeLayout(False)
        Me.tabSubtraction.PerformLayout()
        Me.tabMultiplication.ResumeLayout(False)
        Me.tabMultiplication.PerformLayout()
        Me.tabDivision.ResumeLayout(False)
        Me.tabDivision.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tabOptions As TabPage
    Friend WithEvents tabAddition As TabPage
    Friend WithEvents btnCancelAddition As Button
    Friend WithEvents btnNextAddition As Button
    Friend WithEvents btnStartAddition As Button
    Friend WithEvents tabSubtraction As TabPage
    Friend WithEvents btnStartSubtraction As Button
    Friend WithEvents tabMultiplication As TabPage
    Friend WithEvents tabDivision As TabPage
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCancelSubtraction As Button
    Friend WithEvents btnNextSubtraction As Button
    Friend WithEvents btnCancelMultiplication As Button
    Friend WithEvents btnNextMultiplication As Button
    Friend WithEvents btnStartMultiplication As Button
    Friend WithEvents btnCancelDivision As Button
    Friend WithEvents btnNextDivision As Button
    Friend WithEvents btnStartDivision As Button
    Friend WithEvents lblMathLevel As Label
    Friend WithEvents cboMathLevel As ComboBox
    Friend WithEvents chkShowAnswers As CheckBox
    Friend WithEvents lblIterations As Label
    Friend WithEvents cboIterations As ComboBox
    Friend WithEvents btnCheckAnswerAddition As Button
    Friend WithEvents btnCheckAnswerSubtraction As Button
    Friend WithEvents btnCheckAnswerMultiplication As Button
    Friend WithEvents btnCheckAnswerDivision As Button
    Friend WithEvents lblAdditionSymbol As Label
    Friend WithEvents txtAdditionAnswer As TextBox
    Friend WithEvents lblAddition2 As Label
    Friend WithEvents lblAddition1 As Label
    Friend WithEvents txtSubtractionAnswer As TextBox
    Friend WithEvents lblSubtractionSymbol As Label
    Friend WithEvents lblSubtraction2 As Label
    Friend WithEvents lblSubtraction1 As Label
    Friend WithEvents txtMultiplicationAnswer As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblMultiplication2 As Label
    Friend WithEvents lblMultiplication1 As Label
    Friend WithEvents lblDivision1 As Label
    Friend WithEvents txtDivisionAnswer As TextBox
    Friend WithEvents lblDivisionSymbol As Label
    Friend WithEvents lblDivision2 As Label
End Class
