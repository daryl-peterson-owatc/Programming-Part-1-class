﻿Module GlobalVariables
    Public global_GradeLevel As String
    Public global_Iterations As Integer
    Public global_ShowAnswers As Boolean
    Public global_CurrentIteration As Integer
    Public global_FirstNumber As Integer
    Public global_SecondNumber As Integer
    Public global_TestAnswer As Integer
    Public global_CorrectAnswer As Integer
End Module
