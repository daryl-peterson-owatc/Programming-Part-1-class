﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        char[] delimeter = { ' ' };

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void countWordsbutton_Click(object sender, EventArgs e)
        {
            int numberWords = CountWords(sentenceTextBox.Text);
            DisplayWordCount(numberWords);
        }

        private int CountWords(string sentence)
        {
            string[] tokens = sentence.Split(delimeter);
            return tokens.Count();
        }

        private void DisplayWordCount(int words)
        {
            wordCountLabel.Text = "There are " + words + " in the sentence.";
        }
    }
}
