﻿namespace Word_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sentenceTextBox = new System.Windows.Forms.TextBox();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.wordCountLabel = new System.Windows.Forms.Label();
            this.countWordsbutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sentenceTextBox
            // 
            this.sentenceTextBox.Location = new System.Drawing.Point(14, 32);
            this.sentenceTextBox.Name = "sentenceTextBox";
            this.sentenceTextBox.Size = new System.Drawing.Size(473, 20);
            this.sentenceTextBox.TabIndex = 0;
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(107, 9);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(293, 13);
            this.instructionsLabel.TabIndex = 1;
            this.instructionsLabel.Text = "Enter a sentence and I will tell you how many word there are.";
            // 
            // wordCountLabel
            // 
            this.wordCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wordCountLabel.Location = new System.Drawing.Point(110, 68);
            this.wordCountLabel.Name = "wordCountLabel";
            this.wordCountLabel.Size = new System.Drawing.Size(290, 23);
            this.wordCountLabel.TabIndex = 2;
            this.wordCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // countWordsbutton
            // 
            this.countWordsbutton.Location = new System.Drawing.Point(216, 105);
            this.countWordsbutton.Name = "countWordsbutton";
            this.countWordsbutton.Size = new System.Drawing.Size(85, 23);
            this.countWordsbutton.TabIndex = 3;
            this.countWordsbutton.Text = "Count Words";
            this.countWordsbutton.UseVisualStyleBackColor = true;
            this.countWordsbutton.Click += new System.EventHandler(this.countWordsbutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(423, 134);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 169);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.countWordsbutton);
            this.Controls.Add(this.wordCountLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.sentenceTextBox);
            this.Name = "Form1";
            this.Text = "Word Counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox sentenceTextBox;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label wordCountLabel;
        private System.Windows.Forms.Button countWordsbutton;
        private System.Windows.Forms.Button exitButton;
    }
}

