﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_Calculator
{
    public partial class DormAndMealPlanTotals : Form
    {
        public string dorm;
        public decimal dormAmount;
        public string mealPlan;
        public decimal mealPlanAmount;
        private decimal totalAmount;

        public DormAndMealPlanTotals()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DormAndMealPlanTotals_Load(object sender, EventArgs e)
        {
            CalculatePlansTotal();
            DisplayPlans();
        }

        private void DisplayPlans()
        {
            selectedDorm.Text = dorm;
            dormAmountLabel.Text = dormAmount.ToString("c");
            selectedMealPlanLabel.Text = mealPlan;
            mealPlanAmountLabel.Text = mealPlanAmount.ToString("c");
            totalAmountLabel.Text = totalAmount.ToString("c");
        }

        private void CalculatePlansTotal()
        {
            totalAmount = dormAmount + mealPlanAmount;
        }
    }
}
