﻿namespace Dorm_Calculator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormGroupBox = new System.Windows.Forms.GroupBox();
            this.mealPlanGroupBox = new System.Windows.Forms.GroupBox();
            this.showTotalButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dormGroupBox
            // 
            this.dormGroupBox.Location = new System.Drawing.Point(12, 12);
            this.dormGroupBox.Name = "dormGroupBox";
            this.dormGroupBox.Size = new System.Drawing.Size(175, 191);
            this.dormGroupBox.TabIndex = 1;
            this.dormGroupBox.TabStop = false;
            this.dormGroupBox.Text = "Select a dormitory";
            // 
            // mealPlanGroupBox
            // 
            this.mealPlanGroupBox.Location = new System.Drawing.Point(220, 11);
            this.mealPlanGroupBox.Name = "mealPlanGroupBox";
            this.mealPlanGroupBox.Size = new System.Drawing.Size(193, 191);
            this.mealPlanGroupBox.TabIndex = 2;
            this.mealPlanGroupBox.TabStop = false;
            this.mealPlanGroupBox.Text = "Select a meal plan";
            // 
            // showTotalButton
            // 
            this.showTotalButton.Location = new System.Drawing.Point(112, 218);
            this.showTotalButton.Name = "showTotalButton";
            this.showTotalButton.Size = new System.Drawing.Size(75, 23);
            this.showTotalButton.TabIndex = 3;
            this.showTotalButton.Text = "Show Total";
            this.showTotalButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(220, 218);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showTotalButton);
            this.Controls.Add(this.mealPlanGroupBox);
            this.Controls.Add(this.dormGroupBox);
            this.Name = "MainForm";
            this.Text = "Dorm Calculator";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox dormGroupBox;
        private System.Windows.Forms.GroupBox mealPlanGroupBox;
        private System.Windows.Forms.Button showTotalButton;
        private System.Windows.Forms.Button exitButton;
    }
}

