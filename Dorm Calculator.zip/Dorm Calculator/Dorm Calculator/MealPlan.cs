﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dorm_Calculator
{
    class MealPlan
    {
        private string _mealDescription;
        private decimal _mealCost;

        public MealPlan()
        {
            _mealDescription = "";
            _mealCost = 0.00m;
        }

        public MealPlan(string description, decimal cost)
        {
            _mealDescription = description;
            _mealCost = cost;
        }

        public string MealDescription
        {
            get { return _mealDescription; }
            set { _mealDescription = value; }
        }

        public decimal MealCost
        {
            get { return _mealCost; }
            set { _mealCost = value; }
        }
    }
}
