﻿namespace Dorm_Calculator
{
    partial class DormAndMealPlanTotals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.closeButton = new System.Windows.Forms.Button();
            this.dormAmountLabel = new System.Windows.Forms.Label();
            this.mealPlanAmountLabel = new System.Windows.Forms.Label();
            this.totalAmountLabel = new System.Windows.Forms.Label();
            this.selectedDorm = new System.Windows.Forms.Label();
            this.selectedMealPlanLabel = new System.Windows.Forms.Label();
            this.totalDescriptionLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(102, 130);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 0;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // dormAmountLabel
            // 
            this.dormAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dormAmountLabel.Location = new System.Drawing.Point(172, 22);
            this.dormAmountLabel.Name = "dormAmountLabel";
            this.dormAmountLabel.Size = new System.Drawing.Size(71, 23);
            this.dormAmountLabel.TabIndex = 1;
            this.dormAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mealPlanAmountLabel
            // 
            this.mealPlanAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mealPlanAmountLabel.Location = new System.Drawing.Point(172, 56);
            this.mealPlanAmountLabel.Name = "mealPlanAmountLabel";
            this.mealPlanAmountLabel.Size = new System.Drawing.Size(71, 23);
            this.mealPlanAmountLabel.TabIndex = 2;
            this.mealPlanAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalAmountLabel
            // 
            this.totalAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalAmountLabel.Location = new System.Drawing.Point(172, 91);
            this.totalAmountLabel.Name = "totalAmountLabel";
            this.totalAmountLabel.Size = new System.Drawing.Size(71, 23);
            this.totalAmountLabel.TabIndex = 3;
            this.totalAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // selectedDorm
            // 
            this.selectedDorm.Location = new System.Drawing.Point(29, 22);
            this.selectedDorm.Name = "selectedDorm";
            this.selectedDorm.Size = new System.Drawing.Size(137, 23);
            this.selectedDorm.TabIndex = 4;
            this.selectedDorm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // selectedMealPlanLabel
            // 
            this.selectedMealPlanLabel.Location = new System.Drawing.Point(32, 56);
            this.selectedMealPlanLabel.Name = "selectedMealPlanLabel";
            this.selectedMealPlanLabel.Size = new System.Drawing.Size(134, 23);
            this.selectedMealPlanLabel.TabIndex = 5;
            this.selectedMealPlanLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalDescriptionLabel
            // 
            this.totalDescriptionLabel.AutoSize = true;
            this.totalDescriptionLabel.Location = new System.Drawing.Point(132, 96);
            this.totalDescriptionLabel.Name = "totalDescriptionLabel";
            this.totalDescriptionLabel.Size = new System.Drawing.Size(34, 13);
            this.totalDescriptionLabel.TabIndex = 6;
            this.totalDescriptionLabel.Text = "Total:";
            // 
            // DormAndMealPlanTotals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 174);
            this.Controls.Add(this.totalDescriptionLabel);
            this.Controls.Add(this.selectedMealPlanLabel);
            this.Controls.Add(this.selectedDorm);
            this.Controls.Add(this.totalAmountLabel);
            this.Controls.Add(this.mealPlanAmountLabel);
            this.Controls.Add(this.dormAmountLabel);
            this.Controls.Add(this.closeButton);
            this.Name = "DormAndMealPlanTotals";
            this.Text = "Dorm and meal plan totals";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label dormAmountLabel;
        private System.Windows.Forms.Label mealPlanAmountLabel;
        private System.Windows.Forms.Label totalAmountLabel;
        private System.Windows.Forms.Label selectedDorm;
        private System.Windows.Forms.Label selectedMealPlanLabel;
        private System.Windows.Forms.Label totalDescriptionLabel;
    }
}