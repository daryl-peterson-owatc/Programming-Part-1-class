﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_Calculator
{
    public partial class MainForm : Form
    {
        int somenumber = 0;
        List<Dormitories> dormList = new List<Dormitories>();
        List<MealPlan> mealPlanList = new List<MealPlan>();

        public MainForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            DormAndMealPlanTotals dm = new DormAndMealPlanTotals();
            somenumber = 5;
            dm.Show();
            //this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
          
        }
        public int bill
        {
            get { return somenumber; }
          
        }
    }
}
