﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_Calculator
{
    public partial class MainForm : Form
    {
        List<Dormitories> dormList = new List<Dormitories>();
        List<MealPlan> mealPlanList = new List<MealPlan>();

        public string dorm;
        public decimal dormAmount;
        public string mealPlan;
        public decimal mealPlanAmount;

        public MainForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            BuildDormList();
            BuildMealPlanList();
        }

        private void BuildDormList()
        {
            string dormName = "Allen Hall";
            decimal amount = 1500m;
            AddDorm(dormName, amount);

            dormName = "Pike Hall";
            amount = 1600m;
            AddDorm(dormName, amount);

            dormName = "Farthing Hall";
            amount = 1800m;
            AddDorm(dormName, amount);

            dormName = "University Suites";
            amount = 2500m;
            AddDorm(dormName, amount);
        }

        private void AddDorm(string dormName, decimal amount)
        {
            Dormitories building = new Dormitories();

            building.Dormitory = dormName;
            building.DormCost = amount;
            string formatedAmount = amount.ToString("c");

            dormList.Add(building);
            dormsListBox.Items.Add(dormName + " - " + formatedAmount);
        }

        private void BuildMealPlanList()
        {
            string plan = "7 meals per week";
            decimal amount = 600m;
            AddMealPlan(plan, amount);

            plan = "14 meals per week";
            amount = 1200m;
            AddMealPlan(plan, amount);

            plan = "Unlimited meals";
            amount = 1700m;
            AddMealPlan(plan, amount);
        }

        private void AddMealPlan(string plan, decimal amount)
        {
            MealPlan mealPlan = new MealPlan();

            mealPlan.MealDescription = plan;
            mealPlan.MealCost = amount;
            string formatedAmount = amount.ToString("c");
            mealPlanList.Add(mealPlan);
            mealPlansListBox.Items.Add(plan + " - " + formatedAmount);
        }

        private void showTotalButton_Click(object sender, EventArgs e)
        {
            DormAndMealPlanTotals dm = new DormAndMealPlanTotals();

            dm.mealPlan = mealPlan;
            dm.mealPlanAmount = mealPlanAmount;
            dm.dorm = dorm;
            dm.dormAmount = dormAmount;

            dm.Show();
        }

        private void dormsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = dormsListBox.SelectedIndex;
            dorm = dormList[index].Dormitory;
            dormAmount = dormList[index].DormCost;
        }

        private void mealPlansListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = mealPlansListBox.SelectedIndex;
            mealPlan = mealPlanList[index].MealDescription;
            mealPlanAmount = mealPlanList[index].MealCost;
        }
    }
}
