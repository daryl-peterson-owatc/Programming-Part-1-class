﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dorm_Calculator
{
    class Dormitories
    {
        private string _dormitory;
        private decimal _dormCost;

        public Dormitories()
        {
            _dormitory = "";
            _dormCost = 0.00m;
        }

        public Dormitories(string dormitory, decimal cost)
        {
            _dormitory = dormitory;
            _dormCost = cost;
        }

        public string Dormitory
        {
            get { return _dormitory; }
            set { _dormitory = value; }
        }

        public decimal DormCost
        {
            get { return _dormCost; }
            set { _dormCost = value; }
        }
    }
}
