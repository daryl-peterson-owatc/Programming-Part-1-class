﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class ProductionWorker : Employee
    {
        private int _shiftNumber;
        private decimal _hourlyPayRate;
        private string _shiftDescription;

        public ProductionWorker()
        {
            _shiftNumber = 0;
            _hourlyPayRate = 0.0m;
        }

        public ProductionWorker(int shift, decimal hourlyRate)
        {
            _shiftNumber = shift;
            _hourlyPayRate = hourlyRate;
        }

        public int ShiftNumber
        {
            get { return _shiftNumber; }
            set { _shiftNumber = value; }
        }

        public decimal HourlyPayRate
        {
            get { return _hourlyPayRate; }
            set { _hourlyPayRate = value; }
        }
    }
}
